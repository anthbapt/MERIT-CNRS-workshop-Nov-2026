"""Module 3 — registration (alignment + landmarks) of H&E / IF / proteomics onto the ST frame.

``register_image`` is the pipeline entry point. The original ``register``
package lives in :mod:`multispace.registration._core` (pair classes such as
``HEIFRegistration`` remain importable from here) and the Tkinter tools in
:mod:`multispace.registration.gui` (``pip install 'multispace[gui]'``).
"""
from .api import RegistrationResult, get_registration, register_image, working_array

__all__ = ["register_image", "get_registration", "working_array", "RegistrationResult",
           "BaseMultimodalRegistration", "HEIFRegistration", "MetallomicsHERegistration",
           "MetallomicsIFRegistration", "MetallomicsMetallomicsRegistration"]


def __getattr__(name):  # lazy access to the original register package
    if name in __all__[4:]:
        from . import _core

        return getattr(_core, name)
    raise AttributeError(name)
