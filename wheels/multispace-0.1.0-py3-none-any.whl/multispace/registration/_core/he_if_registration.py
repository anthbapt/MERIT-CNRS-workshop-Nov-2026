#!/usr/bin/env python3
"""
HE-IF Registration Module
=========================

This module provides the HEIFRegistration class for registering H&E stained images
with immunofluorescence (IF) images from spatial transcriptomics.

Example
-------
    from he_if_registration import HEIFRegistration

    reg = HEIFRegistration(
        he_path="he_image.tif",
        if_path="if_image.tif",
        he_is_rgb=True,
        pre_rotation=180
    )

    reg.setup_shared_mask(define_on='he', interactive=True)
    reg.preview_masks()
    reg.preprocess()
    reg.register_affine_optimization(metric='ncc')
    reg.compute_registration_quality()
    reg.apply_transform_to_fullres()
    reg.save_results("output/")
"""

from pathlib import Path
from typing import Optional

import matplotlib.pyplot as plt
import numpy as np
import tifffile
from .registration_core import (
    BaseMultimodalRegistration,
    logger,
    percentile_normalize,
)


class HEIFRegistration(BaseMultimodalRegistration):
    """
    Register H&E stained images to immunofluorescence (IF) images.

    This class extends BaseMultimodalRegistration with H&E-specific functionality:
    - RGB image handling for H&E
    - Automatic grayscale conversion for registration
    - H&E-specific visualization with proper colormaps

    The H&E image is treated as the "fixed" image (reference), and the IF image
    is the "moving" image that gets transformed to align with H&E.

    Attributes
    ----------
    he : np.ndarray
        The H&E image (grayscale version for registration)
    he_rgb : np.ndarray
        The H&E image in RGB (for display)
    if_original : np.ndarray
        The original IF image (high resolution)
    if_downsampled : np.ndarray
        IF image downsampled to H&E resolution
    """

    FIXED_IMAGE_NAME = "HE"
    MOVING_IMAGE_NAME = "IF"

    def __init__(
        self,
        he_path: Optional[str] = None,
        if_path: Optional[str] = None,
        he_array: Optional[np.ndarray] = None,
        if_array: Optional[np.ndarray] = None,
        he_channel: Optional[int] = None,
        combine_if_channels: bool = True,
        pre_rotation: int = 0,
        rotate_which: str = "if",
        he_is_rgb: bool = False,
    ) -> None:
        """
        Initialize HE-IF registration.

        Parameters
        ----------
        he_path : str, optional
            Path to H&E image
        if_path : str, optional
            Path to IF image (high-res)
        he_array : np.ndarray, optional
            H&E image as array
        if_array : np.ndarray, optional
            IF image as array
        he_channel : int, optional
            Channel to use for H&E (ignored if he_is_rgb=True)
        combine_if_channels : bool
            If True, combine IF channels via mean projection
        pre_rotation : int
            Coarse rotation (0, 90, 180, 270, or 'auto')
        rotate_which : str
            Which image to rotate: 'if' or 'he'
        he_is_rgb : bool
            If True, treat H&E as RGB image
        """
        self.he_is_rgb = he_is_rgb

        # Map 'if'/'he' to 'moving'/'fixed' for base class
        rotate_mapped = "moving" if rotate_which == "if" else "fixed"

        # Call parent constructor
        super().__init__(
            fixed_path=he_path,
            moving_path=if_path,
            fixed_array=he_array,
            moving_array=if_array,
            fixed_channel=he_channel,
            combine_moving_channels=combine_if_channels,
            pre_rotation=pre_rotation,
            rotate_which=rotate_mapped,
        )

    def _load_fixed_image(self, path: str, channel: Optional[int] = None) -> np.ndarray:
        """Load H&E image with RGB handling."""
        if self.he_is_rgb:
            return self._load_image_rgb(path)
        else:
            return self._load_image(path, channel=channel)

    def _load_image_rgb(self, path: str) -> np.ndarray:
        """
        Load an RGB image (H&E stained) and store both grayscale and RGB versions.

        Parameters
        ----------
        path : str
            Path to RGB image file

        Returns
        -------
        np.ndarray
            Grayscale image for registration
        """
        from skimage import io

        path = Path(path)

        if not path.exists():
            raise FileNotFoundError(f"Image file not found: {path}")

        if path.suffix.lower() in [".tif", ".tiff"]:
            img = tifffile.imread(str(path))
        else:
            img = io.imread(str(path))

        logger.info(f"Loaded RGB image {path.name}: shape={img.shape}, dtype={img.dtype}")

        if img.ndim != 3:
            raise ValueError(f"Expected RGB image with 3 dimensions, got {img.ndim}")

        # Handle channels first vs channels last
        if img.shape[0] == 3 and img.shape[-1] != 3:
            img = np.transpose(img, (1, 2, 0))
            logger.info("Transposed from channels-first to channels-last")

        if img.shape[-1] != 3:
            raise ValueError(f"Expected 3 channels for RGB, got {img.shape[-1]}")

        # Store RGB version (normalize to 0-1 for display)
        rgb_img = img.astype(np.float64)
        if rgb_img.max() > 1.0:
            self.fixed_rgb = rgb_img / 255.0
        else:
            self.fixed_rgb = rgb_img

        # Convert to grayscale using ITU-R BT.601 formula
        grayscale = (0.2989 * img[..., 0] + 0.5870 * img[..., 1] + 0.1140 * img[..., 2]).astype(
            np.float64
        )

        logger.info(f"Converted RGB to grayscale: {grayscale.shape}")
        logger.info(f"RGB image stored for display: {self.fixed_rgb.shape}")

        return grayscale

    # =========================================================================
    # Convenience Properties (aliases for clarity)
    # =========================================================================

    @property
    def he(self) -> np.ndarray:
        """Alias for fixed_image (H&E grayscale)."""
        return self.fixed_image

    @property
    def he_rgb(self) -> Optional[np.ndarray]:
        """H&E RGB image for display."""
        return self.fixed_rgb

    @he_rgb.setter
    def he_rgb(self, value):
        self.fixed_rgb = value

    @property
    def if_original(self) -> np.ndarray:
        """Alias for moving_image (IF original)."""
        return self.moving_image

    @property
    def if_downsampled(self) -> Optional[np.ndarray]:
        """Alias for moving_downsampled (IF downsampled)."""
        return self.moving_downsampled

    @property
    def registered_if(self) -> Optional[np.ndarray]:
        """Alias for registered_moving (registered IF)."""
        return self.registered_moving

    @property
    def mask_he(self) -> Optional[np.ndarray]:
        """Alias for mask_fixed (H&E mask)."""
        return self.mask_fixed

    @mask_he.setter
    def mask_he(self, value):
        self.mask_fixed = value

    @property
    def mask_if(self) -> Optional[np.ndarray]:
        """Alias for mask_moving (IF mask)."""
        return self.mask_moving

    @mask_if.setter
    def mask_if(self, value):
        self.mask_moving = value

    @property
    def mask_if_downsampled(self) -> Optional[np.ndarray]:
        """Alias for mask_moving_downsampled."""
        return self.mask_moving_downsampled

    @mask_if_downsampled.setter
    def mask_if_downsampled(self, value):
        self.mask_moving_downsampled = value

    # =========================================================================
    # H&E-specific Methods
    # =========================================================================

    def setup_shared_mask(
        self,
        define_on: str = "he",
        interactive: bool = True,
        threshold_percentile: float = 10,
        dilate_radius: int = 2,
        brush_size: int = 5,
        mask_array: Optional[np.ndarray] = None,
    ) -> "HEIFRegistration":
        """
        Setup a shared mask defined on one image and applied to both.

        Parameters
        ----------
        define_on : str
            Which image to define mask on: 'he' or 'if'
        interactive : bool
            If True, opens interactive drawing tool
        threshold_percentile : float
            Percentile for automatic mask creation
        dilate_radius : int
            Radius for morphological dilation
        brush_size : int
            Initial brush size for interactive drawing
        mask_array : np.ndarray, optional
            Pre-computed mask array

        Returns
        -------
        self
            Returns self for method chaining
        """
        # Map 'he'/'if' to 'fixed'/'moving'
        define_on_mapped = "fixed" if define_on == "he" else "moving"
        return super().setup_shared_mask(
            define_on=define_on_mapped,
            interactive=interactive,
            threshold_percentile=threshold_percentile,
            dilate_radius=dilate_radius,
            brush_size=brush_size,
            mask_array=mask_array,
        )

    def draw_mask_interactive(
        self, which: str = "he", brush_size: int = 5, flood_tolerance: float = 0.1
    ) -> np.ndarray:
        """
        Interactive mask drawing tool.

        Parameters
        ----------
        which : str
            Which image to draw mask for: 'he' or 'if'
        brush_size : int
            Initial brush radius
        flood_tolerance : float
            Intensity tolerance for flood fill

        Returns
        -------
        np.ndarray
            Binary mask array
        """
        which_mapped = "fixed" if which == "he" else "moving"
        return super().draw_mask_interactive(
            which=which_mapped, brush_size=brush_size, flood_tolerance=flood_tolerance
        )

    def create_he_if_overlay(
        self, alpha: float = 0.5, if_color: tuple[float, float, float] = (0.0, 1.0, 0.0)
    ) -> np.ndarray:
        """
        Create overlay with H&E as base and IF as colored overlay.

        Parameters
        ----------
        alpha : float
            Blending factor for IF (0-1)
        if_color : tuple
            RGB color for IF overlay (default: green)

        Returns
        -------
        np.ndarray
            RGB overlay image
        """
        return self.create_overlay(alpha=alpha, use_downsampled=True, moving_color=if_color)

    def visualize_he_if_comparison(
        self, figsize: tuple[int, int] = (20, 8), save_path: Optional[str] = None
    ) -> None:
        """
        Create a comprehensive visualization comparing H&E and IF.

        Shows:
        1. H&E image (RGB if available)
        2. IF image (downsampled)
        3. Overlay before registration
        4. Overlay after registration
        """
        self._validate_registered()

        fig, axes = plt.subplots(1, 4, figsize=figsize)

        # H&E
        if self.he_rgb is not None:
            axes[0].imshow(self.he_rgb)
        else:
            he_norm = percentile_normalize(self.he)
            axes[0].imshow(he_norm, cmap="gray")
        axes[0].set_title("H&E Image", fontweight="bold", fontsize=12)
        axes[0].axis("off")

        # IF
        if_norm = percentile_normalize(self.if_downsampled)
        axes[1].imshow(if_norm, cmap="gray")
        axes[1].set_title("IF Image (downsampled)", fontweight="bold", fontsize=12)
        axes[1].axis("off")

        # Before registration
        he_gray = percentile_normalize(self.he)
        overlay_before = np.zeros((*self.he.shape, 3))
        overlay_before[..., 0] = he_gray  # Red = H&E
        overlay_before[..., 1] = if_norm  # Green = IF
        axes[2].imshow(overlay_before)
        axes[2].set_title(
            "Before Registration\n(Red=H&E, Green=IF)", fontweight="bold", fontsize=12
        )
        axes[2].axis("off")

        # After registration
        from skimage.transform import warp

        if_registered = warp(
            self.if_downsampled,
            self.transform_matrix.inverse,
            output_shape=self.he.shape,
            order=1,
            mode="constant",
            cval=0,
        )
        if_reg_norm = percentile_normalize(if_registered)

        overlay_after = np.zeros((*self.he.shape, 3))
        overlay_after[..., 0] = he_gray
        overlay_after[..., 1] = if_reg_norm
        axes[3].imshow(overlay_after)
        axes[3].set_title("After Registration\n(Red=H&E, Green=IF)", fontweight="bold", fontsize=12)
        axes[3].axis("off")

        plt.suptitle("H&E to IF Registration Results", fontsize=14, fontweight="bold")
        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches="tight")
            logger.info(f"Visualization saved to: {save_path}")

        plt.show()


# Convenience function for quick registration
def register_he_to_if(
    he_path: str,
    if_path: str,
    he_is_rgb: bool = True,
    pre_rotation: int = 0,
    method: str = "affine",
    metric: str = "ncc",
    output_dir: Optional[str] = None,
) -> HEIFRegistration:
    """
    Quick registration of H&E to IF images.

    Parameters
    ----------
    he_path : str
        Path to H&E image
    if_path : str
        Path to IF image
    he_is_rgb : bool
        If True, treat H&E as RGB
    pre_rotation : int
        Pre-rotation angle (0, 90, 180, 270)
    method : str
        Registration method: 'phase', 'affine', 'sitk', or 'boundary'
    metric : str
        Similarity metric for affine: 'nmi', 'ncc', 'mse'
    output_dir : str, optional
        If provided, save results to this directory

    Returns
    -------
    HEIFRegistration
        The registration object with results
    """
    reg = HEIFRegistration(
        he_path=he_path, if_path=if_path, he_is_rgb=he_is_rgb, pre_rotation=pre_rotation
    )

    reg.preprocess()

    if method == "phase":
        reg.register_phase_correlation()
    elif method == "affine":
        reg.register_affine_optimization(metric=metric)
    elif method == "sitk":
        reg.register_sitk()
    elif method == "boundary":
        reg.register_boundary_based()
    else:
        raise ValueError(f"Unknown method: {method}")

    reg.apply_transform_to_fullres()

    if output_dir:
        reg.save_results(output_dir)

    return reg
