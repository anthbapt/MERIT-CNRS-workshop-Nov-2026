#!/usr/bin/env python3
"""
Metallomics-HE Registration Module
====================================

This module provides the MetallomicsHERegistration class for registering
metallomics data (e.g., LA-ICP-MS) with H&E (Hematoxylin & Eosin) stained images.

The metallomics image is the "fixed" (reference) image and H&E is the "moving"
image that is aligned to the metallomics space. After registration the
transformation matrix can be used in both directions:
- H&E → metallomics space   (apply_transform_to_fullres)
- metallomics channels → H&E space  (warp_metals_to_he)

Example
-------
    from metallomics_he_registration import MetallomicsHERegistration

    reg = MetallomicsHERegistration(
        metallomics_path="metal.tif",
        he_path="he.tif",
        metallomics_channel=9,   # Zn
        he_is_rgb=True,
        pre_rotation=180,
    )

    reg.setup_shared_mask(define_on='metallomics', interactive=True)
    reg.preprocess()
    reg.register_affine_optimization(metric='ncc')
    reg.compute_registration_quality()
    reg.apply_transform_to_fullres()
    reg.warp_metals_to_he("metal_stack.tif")
    reg.save_results("output/")

Channel Mapping (LA-ICP-MS):
    0: 0TIC - Total Ion Count
    1: Na   - Sodium
    2: Mg   - Magnesium
    3: P    - Phosphorus (nucleic acids, cell density)
    4: S    - Sulfur (protein content)
    5: Ca   - Calcium
    6: Mn   - Manganese
    7: Fe   - Iron (macrophages, blood)
    8: Cu   - Copper (stellate cells, bile ducts)
    9: Zn   - Zinc (hepatocytes, structure)
   10: Rb   - Rubidium
   11: Sr   - Strontium
   12: 118Sn - Tin-118
   13: Ba   - Barium
"""

from pathlib import Path
from typing import Optional

import matplotlib.pyplot as plt
import numpy as np
import tifffile
from .registration_core import (
    BaseMultimodalRegistration,
    logger,
    percentile_normalize,
)
from skimage import transform as sktransform

# Channel mapping for LA-ICP-MS metallomics data
METAL_CHANNELS = {
    0: ("0TIC", "Total Ion Count"),
    1: ("Na", "Sodium"),
    2: ("Mg", "Magnesium"),
    3: ("P", "Phosphorus - nucleic acids, cell density"),
    4: ("S", "Sulfur - protein content"),
    5: ("Ca", "Calcium"),
    6: ("Mn", "Manganese"),
    7: ("Fe", "Iron - macrophages, blood"),
    8: ("Cu", "Copper - stellate cells, bile ducts"),
    9: ("Zn", "Zinc - hepatocytes, structure"),
    10: ("Rb", "Rubidium"),
    11: ("Sr", "Strontium"),
    12: ("118Sn", "Tin-118"),
    13: ("Ba", "Barium"),
}


class MetallomicsHERegistration(BaseMultimodalRegistration):
    """
    Register metallomics data to H&E (Hematoxylin & Eosin) images.

    Metallomics data (LA-ICP-MS) is typically very low resolution (~50x50 pixels)
    while H&E images are high resolution (~4000x4000 pixels, RGB).

    The metallomics image is the "fixed" reference; H&E is the "moving" image
    that is transformed to align with the metallomics field of view.

    Attributes
    ----------
    metallomics : np.ndarray
        The metallomics image used for registration (fixed, low-res, 2-D)
    he_original : np.ndarray
        The H&E image in grayscale (moving, full-res, used by base class)
    he_rgb : np.ndarray or None
        H&E image in RGB for display (H x W x 3, float [0-1])
    he_downsampled : np.ndarray
        H&E grayscale downsampled to metallomics resolution (set by preprocess)
    registered_he : np.ndarray
        H&E registered to metallomics space (set by apply_transform_to_fullres)
    metal_shape : tuple
        (H, W) of the metallomics image
    he_shape : tuple
        (H, W) of the H&E image
    """

    FIXED_IMAGE_NAME = "Metallomics"
    MOVING_IMAGE_NAME = "HE"

    def __init__(
        self,
        metallomics_path: Optional[str] = None,
        he_path: Optional[str] = None,
        metallomics_array: Optional[np.ndarray] = None,
        he_array: Optional[np.ndarray] = None,
        metallomics_channel: Optional[int] = None,
        he_is_rgb: bool = True,
        pre_rotation: int = 0,
        rotate_which: str = "he",
    ) -> None:
        """
        Initialize Metallomics-HE registration.

        Parameters
        ----------
        metallomics_path : str, optional
            Path to metallomics image (low-res, single or multi-channel TIFF)
        he_path : str, optional
            Path to H&E image (high-res; RGB TIFF, JPEG or PNG)
        metallomics_array : np.ndarray, optional
            Metallomics image as numpy array (alternative to path)
        he_array : np.ndarray, optional
            H&E image as numpy array (alternative to path)
        metallomics_channel : int, optional
            Channel index to use for metallomics (0-indexed). None = first channel.
        he_is_rgb : bool
            If True, H&E image is RGB and is converted to grayscale for registration.
            The RGB version is stored separately in he_rgb for visualisation.
        pre_rotation : int
            Coarse pre-rotation applied before fine registration: 0 / 90 / 180 / 270
        rotate_which : str
            Which image to rotate: 'he' (default) or 'metallomics'
        """
        self.he_is_rgb = he_is_rgb
        self._he_rgb_store: Optional[np.ndarray] = None  # set before super().__init__

        # Map domain names to base-class 'fixed'/'moving'
        rotate_mapped = "moving" if rotate_which == "he" else "fixed"

        # Base class loads metallomics as fixed, H&E as moving.
        # combine_moving_channels=True → mean of R,G,B → grayscale for registration.
        super().__init__(
            fixed_path=metallomics_path,
            moving_path=he_path,
            fixed_array=metallomics_array,
            moving_array=he_array,
            fixed_channel=metallomics_channel,
            combine_moving_channels=True,
            pre_rotation=pre_rotation,
            rotate_which=rotate_mapped,
        )

        # Additionally store the RGB H&E for display
        if he_path is not None and he_is_rgb:
            self._he_rgb_store = self._load_he_rgb(he_path)
        elif he_array is not None and he_array.ndim == 3:
            rgb = he_array.astype(np.float64)
            if rgb.max() > 1.0:
                rgb = rgb / 255.0
            # Ensure H x W x 3
            if rgb.shape[0] == 3 and rgb.shape[-1] != 3:
                rgb = np.transpose(rgb, (1, 2, 0))
            if rgb.shape[-1] == 3:
                self._he_rgb_store = rgb

        if self._he_rgb_store is not None:
            logger.info(f"H&E RGB stored for display: {self._he_rgb_store.shape}")

    # -------------------------------------------------------------------------
    # Private helpers
    # -------------------------------------------------------------------------

    def _load_he_rgb(self, path: str) -> Optional[np.ndarray]:
        """Load H&E as RGB float [0, 1] array (H x W x 3) for display."""
        from skimage import io

        p = Path(path)
        if not p.exists():
            logger.warning(f"H&E path not found for RGB load: {path}")
            return None

        if p.suffix.lower() in [".tif", ".tiff"]:
            img = tifffile.imread(str(p))
        else:
            img = io.imread(str(p))

        img = img.astype(np.float64)
        if img.max() > 1.0:
            img = img / 255.0

        if img.ndim == 2:
            # Greyscale → repeat to RGB for display
            img = np.stack([img, img, img], axis=-1)
        elif img.ndim == 3:
            # Channels first → channels last
            if img.shape[0] in [1, 3, 4] and img.shape[-1] not in [1, 3, 4]:
                img = np.transpose(img, (1, 2, 0))
            # Drop alpha channel
            if img.shape[-1] == 4:
                img = img[..., :3]

        if img.shape[-1] != 3:
            logger.warning(f"Unexpected shape for RGB H&E: {img.shape}. Display may be wrong.")
            return None

        return np.clip(img, 0.0, 1.0)

    # -------------------------------------------------------------------------
    # Properties — friendly names for fixed / moving
    # -------------------------------------------------------------------------

    @property
    def metallomics(self) -> np.ndarray:
        """Metallomics image used for registration (fixed, low-res)."""
        return self.fixed_image

    @property
    def he_original(self) -> np.ndarray:
        """H&E image (grayscale, full-res) as loaded by base class."""
        return self.moving_image

    @property
    def he_rgb(self) -> Optional[np.ndarray]:
        """H&E image in RGB (H x W x 3, float [0-1]) for display."""
        return self._he_rgb_store

    @property
    def he_downsampled(self) -> Optional[np.ndarray]:
        """H&E grayscale downsampled to metallomics resolution."""
        return self.moving_downsampled

    @property
    def registered_he(self) -> Optional[np.ndarray]:
        """H&E registered to metallomics space."""
        return self.registered_moving

    @property
    def metal_shape(self) -> tuple[int, int]:
        """Shape (H, W) of the metallomics image."""
        return self.fixed_shape

    @property
    def he_shape(self) -> tuple[int, int]:
        """Shape (H, W) of the H&E image."""
        return self.moving_shape

    @property
    def mask_metallomics(self) -> Optional[np.ndarray]:
        return self.mask_fixed

    @mask_metallomics.setter
    def mask_metallomics(self, value):
        self.mask_fixed = value

    @property
    def mask_he(self) -> Optional[np.ndarray]:
        return self.mask_moving

    @mask_he.setter
    def mask_he(self, value):
        self.mask_moving = value

    @property
    def mask_he_downsampled(self) -> Optional[np.ndarray]:
        return self.mask_moving_downsampled

    @mask_he_downsampled.setter
    def mask_he_downsampled(self, value):
        self.mask_moving_downsampled = value

    # -------------------------------------------------------------------------
    # Masking
    # -------------------------------------------------------------------------

    def setup_shared_mask(
        self,
        define_on: str = "metallomics",
        interactive: bool = True,
        threshold_percentile: float = 10,
        dilate_radius: int = 2,
        brush_size: int = 5,
        mask_array: Optional[np.ndarray] = None,
    ) -> "MetallomicsHERegistration":
        """
        Set up a shared mask defined on one image and applied to both.

        Parameters
        ----------
        define_on : str
            Which image to define the mask on: 'metallomics' or 'he'
        interactive : bool
            If True, opens the interactive brush drawing tool
        threshold_percentile : float
            Percentile for automatic tissue detection (when interactive=False)
        dilate_radius : int
            Morphological dilation radius applied to the automatic mask
        brush_size : int
            Initial brush radius for the interactive tool
        mask_array : np.ndarray, optional
            Supply a pre-computed binary mask to skip the interactive step
        """
        define_on_mapped = "fixed" if define_on == "metallomics" else "moving"
        return super().setup_shared_mask(
            define_on=define_on_mapped,
            interactive=interactive,
            threshold_percentile=threshold_percentile,
            dilate_radius=dilate_radius,
            brush_size=brush_size,
            mask_array=mask_array,
        )

    def draw_mask_interactive(
        self,
        which: str = "metallomics",
        brush_size: int = 5,
        flood_tolerance: float = 0.1,
    ) -> np.ndarray:
        """
        Interactive mask drawing tool.

        Parameters
        ----------
        which : str
            Image to draw on: 'metallomics' or 'he'
        brush_size : int
            Initial brush radius in pixels
        flood_tolerance : float
            Intensity tolerance for flood-fill mode

        Returns
        -------
        np.ndarray
            Binary mask (bool array)
        """
        which_mapped = "fixed" if which == "metallomics" else "moving"
        return super().draw_mask_interactive(
            which=which_mapped,
            brush_size=brush_size,
            flood_tolerance=flood_tolerance,
        )

    # -------------------------------------------------------------------------
    # Visualisation
    # -------------------------------------------------------------------------

    def preview_images(self, figsize: tuple[int, int] = (12, 5)) -> None:
        """Preview metallomics and H&E side by side."""
        fig, axes = plt.subplots(1, 2, figsize=figsize)

        axes[0].imshow(self.metallomics, cmap="viridis")
        axes[0].set_title("Metallomics (fixed)", fontsize=12)
        axes[0].axis("off")

        if self.he_rgb is not None:
            axes[1].imshow(self.he_rgb)
            axes[1].set_title("H&E (moving, RGB)", fontsize=12)
        else:
            axes[1].imshow(self.he_original, cmap="gray")
            axes[1].set_title("H&E (moving, grayscale)", fontsize=12)
        axes[1].axis("off")

        plt.tight_layout()
        plt.show()

    def visualize_registration(
        self,
        figsize: tuple[int, int] = (20, 8),
        save_path: Optional[str] = None,
        show: bool = True,
    ) -> None:
        """
        Four-panel view: metallomics | H&E (downsampled) | before overlay | after overlay.

        Red channel = metallomics, Green channel = H&E.
        """
        self._validate_registered()

        fig, axes = plt.subplots(1, 4, figsize=figsize)

        # Metallomics
        metal_norm = self._norm(self.metallomics)
        axes[0].imshow(metal_norm, cmap="viridis")
        axes[0].set_title("Metallomics (fixed)", fontweight="bold")
        axes[0].axis("off")

        # H&E downsampled
        he_ds_norm = self._norm(self.he_downsampled)
        if self.he_rgb is not None:
            he_ds_rgb = sktransform.resize(
                self.he_rgb,
                self.metal_shape,
                order=1,
                anti_aliasing=True,
                preserve_range=True,
            )
            axes[1].imshow(np.clip(he_ds_rgb, 0, 1))
        else:
            axes[1].imshow(he_ds_norm, cmap="gray")
        axes[1].set_title("H&E (downsampled)", fontweight="bold")
        axes[1].axis("off")

        # Before registration overlay
        overlay_before = np.zeros((*self.metal_shape, 3))
        overlay_before[..., 0] = metal_norm
        overlay_before[..., 1] = he_ds_norm
        axes[2].imshow(overlay_before)
        axes[2].set_title("Before Registration\n(Red=Metal, Green=H&E)", fontweight="bold")
        axes[2].axis("off")

        # After registration overlay
        from skimage.transform import warp

        he_registered = warp(
            self.he_downsampled,
            self.transform_matrix.inverse,
            output_shape=self.metal_shape,
            order=1,
            mode="constant",
            cval=0,
        )
        he_reg_norm = self._norm(he_registered)
        overlay_after = np.zeros((*self.metal_shape, 3))
        overlay_after[..., 0] = metal_norm
        overlay_after[..., 1] = he_reg_norm
        axes[3].imshow(overlay_after)
        axes[3].set_title("After Registration\n(Red=Metal, Green=H&E)", fontweight="bold")
        axes[3].axis("off")

        plt.suptitle("Metallomics to H&E Registration", fontsize=14, fontweight="bold")
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches="tight")
            logger.info(f"Saved visualisation to {save_path}")
        if show:
            plt.show()
        else:
            plt.close(fig)

    @staticmethod
    def _norm(img: np.ndarray) -> np.ndarray:
        """Percentile-stretched normalization for display/overlay purposes.

        Plain min/max normalization is easily dominated by a handful of
        bright outlier pixels (common in metallomics/IF data), which crushes
        the rest of the signal down near black in overlays. This is used
        only for display — never in preprocess()/registration math.
        """
        return percentile_normalize(img)

    # -------------------------------------------------------------------------
    # Warp metallomics channels into H&E space
    # -------------------------------------------------------------------------

    def warp_metals_to_he(
        self,
        metallomics_stack_path: str,
        channels: Optional[list] = None,
        order: int = 1,
    ) -> np.ndarray:
        """
        Warp every channel of the metallomics stack into H&E space.

        Parameters
        ----------
        metallomics_stack_path : str
            Path to the full multi-channel metallomics TIFF (C, H, W) or (H, W, C)
        channels : list, optional
            Channel indices to warp. If None, all channels are warped.
        order : int
            Interpolation order (1 = bilinear, 3 = bicubic)

        Returns
        -------
        np.ndarray
            Registered stack (C, H_he, W_he) in float32
        """
        self._validate_registered()

        stack = tifffile.imread(metallomics_stack_path)
        stack = self._to_chw(stack)

        if channels is None:
            channels = list(range(stack.shape[0]))

        full_matrix = self.get_full_transform_matrix()
        tform = sktransform.AffineTransform(matrix=full_matrix)

        registered = np.zeros((len(channels), *self.he_shape), dtype=np.float32)
        for out_idx, ch_idx in enumerate(channels):
            metal_name = METAL_CHANNELS.get(ch_idx, (f"Ch{ch_idx}", ""))[0]
            registered[out_idx] = sktransform.warp(
                stack[ch_idx].astype(float),
                tform,
                output_shape=self.he_shape,
                order=order,
                preserve_range=True,
            )
            logger.info(f"  Warped channel {ch_idx} ({metal_name}) → H&E space")

        return registered

    @staticmethod
    def _to_chw(stack: np.ndarray) -> np.ndarray:
        """Ensure array is (C, H, W)."""
        if stack.ndim == 2:
            return stack[np.newaxis]
        if stack.ndim == 3 and stack.shape[-1] <= stack.shape[0]:
            return np.moveaxis(stack, -1, 0)
        return stack

    def visualize_metal_on_he(
        self,
        metal_channel_warped: np.ndarray,
        channel_idx: int = 9,
        alpha: float = 0.5,
        metal_cmap: str = "hot",
        figsize: tuple[int, int] = (12, 6),
    ) -> None:
        """
        Overlay a single warped metallomics channel on the H&E image.

        Parameters
        ----------
        metal_channel_warped : np.ndarray
            2-D array of the metallomics channel already warped to H&E space
        channel_idx : int
            Channel index (for the title label)
        alpha : float
            Opacity of the metallomics overlay (0–1)
        metal_cmap : str
            Colormap for the metal signal (e.g. 'hot', 'viridis', 'plasma')
        figsize : tuple
            Figure size
        """
        metal_name = METAL_CHANNELS.get(channel_idx, (f"Ch{channel_idx}", ""))[0]

        fig, axes = plt.subplots(1, 2, figsize=figsize)

        # H&E background
        if self.he_rgb is not None:
            he_bg = self.he_rgb
        else:
            g = self._norm(self.he_original)
            he_bg = np.stack([g, g, g], axis=-1)

        axes[0].imshow(he_bg)
        axes[0].set_title("H&E", fontsize=12)
        axes[0].axis("off")

        # Overlay
        axes[1].imshow(he_bg)
        nonzero = metal_channel_warped[metal_channel_warped > 0]
        if len(nonzero):
            vmin, vmax = np.percentile(nonzero, [2, 98])
        else:
            vmin, vmax = 0, 1
        im = axes[1].imshow(
            metal_channel_warped,
            cmap=metal_cmap,
            alpha=alpha,
            vmin=vmin,
            vmax=vmax,
        )
        plt.colorbar(im, ax=axes[1], fraction=0.03)
        axes[1].set_title(f"H&E + {metal_name} overlay", fontsize=12)
        axes[1].axis("off")

        plt.suptitle(f"Metallomics channel {channel_idx} ({metal_name}) on H&E", fontsize=13)
        plt.tight_layout()
        plt.show()

    # -------------------------------------------------------------------------
    # Save
    # -------------------------------------------------------------------------

    def save_results(
        self,
        output_dir: str,
        prefix: str = "metallomics_he_registration",
        save_overlay: bool = True,
        save_registered_he: bool = True,
        save_transform: bool = True,
        save_comparison: bool = True,
    ) -> dict[str, str]:
        """
        Save registration results to disk.

        Parameters
        ----------
        output_dir : str
            Output directory path
        prefix : str
            Filename prefix for all saved files
        save_overlay : bool
            Save before/after overlay PNG
        save_registered_he : bool
            Save the H&E registered to metallomics space as TIFF
        save_transform : bool
            Save the 3×3 transformation matrix as .npy
        save_comparison : bool
            Save the four-panel visualize_registration() figure as a PNG
            (previously only shown as a transient pop-up window).

        Returns
        -------
        dict
            Mapping {'type': 'path'} for each saved file
        """
        if self.registered_he is None:
            self.apply_transform_to_fullres()

        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        saved: dict[str, str] = {}

        if save_registered_he:
            p = out / f"{prefix}_registered_he.tif"
            tifffile.imwrite(str(p), self.registered_he.astype(np.float32))
            saved["registered_he"] = str(p)
            logger.info(f"Saved registered H&E: {p}")

        if save_overlay:
            # Build the overlay at metallomics resolution by warping the
            # downsampled H&E with the registration transform.
            # registered_he lives at H&E full resolution, so we cannot use it
            # directly here (shape mismatch with metal_shape).
            from skimage.transform import warp as sk_warp

            he_at_metal = sk_warp(
                self.he_downsampled,
                self.transform_matrix.inverse,
                output_shape=self.metal_shape,
                order=1,
                mode="constant",
                cval=0,
            )
            metal_norm = self._norm(self.metallomics)
            he_reg_norm = self._norm(he_at_metal)
            overlay = np.zeros((*self.metal_shape, 3))
            overlay[..., 0] = metal_norm  # Red   = metallomics
            overlay[..., 1] = he_reg_norm  # Green = H&E (registered)
            p = out / f"{prefix}_overlay.png"
            plt.imsave(str(p), overlay)
            saved["overlay"] = str(p)
            logger.info(f"Saved overlay: {p}")

        if save_comparison:
            p = out / f"{prefix}_comparison.png"
            self.visualize_registration(save_path=str(p), show=False)
            saved["comparison"] = str(p)

        if save_transform and self.transform_matrix is not None:
            p = out / f"{prefix}_transform.npy"
            np.save(str(p), self.get_full_transform_matrix())
            saved["transform"] = str(p)
            logger.info(f"Saved transform: {p}")

        return saved


# =============================================================================
# Convenience function
# =============================================================================


def register_metallomics_to_he(
    metallomics_path: str,
    he_path: str,
    metallomics_channel: Optional[int] = 9,
    he_is_rgb: bool = True,
    pre_rotation: int = 0,
    method: str = "affine",
    metric: str = "ncc",
    output_dir: Optional[str] = None,
) -> MetallomicsHERegistration:
    """
    Quick one-call registration of metallomics to H&E.

    Parameters
    ----------
    metallomics_path : str
        Path to metallomics image
    he_path : str
        Path to H&E image
    metallomics_channel : int, optional
        Channel to use for metallomics (default 9 = Zn)
    he_is_rgb : bool
        Whether the H&E image is RGB
    pre_rotation : int
        Pre-rotation angle applied to H&E (0 / 90 / 180 / 270)
    method : str
        Registration method: 'affine' | 'phase' | 'sitk' | 'boundary'
    metric : str
        Similarity metric for affine method: 'ncc' | 'nmi' | 'mse'
    output_dir : str, optional
        If provided, save results to this directory

    Returns
    -------
    MetallomicsHERegistration
        Completed registration object
    """
    reg = MetallomicsHERegistration(
        metallomics_path=metallomics_path,
        he_path=he_path,
        metallomics_channel=metallomics_channel,
        he_is_rgb=he_is_rgb,
        pre_rotation=pre_rotation,
    )

    reg.preprocess()

    if method == "affine":
        reg.register_affine_optimization(metric=metric)
    elif method == "phase":
        reg.register_phase_correlation()
    elif method == "sitk":
        reg.register_sitk(transform_type="affine", metric="mattes")
    elif method == "boundary":
        reg.register_boundary_based(boundary_mode="convex_hull")
    else:
        raise ValueError(f"Unknown method: '{method}'")

    reg.apply_transform_to_fullres()

    if output_dir:
        reg.save_results(output_dir)

    return reg
