#!/usr/bin/env python3
"""
Metallomics-Metallomics Registration Module
============================================

This module provides the MetallomicsMetallomicsRegistration class for registering
two metallomics datasets (e.g., LA-ICP-MS from consecutive tissue sections).

Example
-------
    from metallomics_metallomics_registration import MetallomicsMetallomicsRegistration

    reg = MetallomicsMetallomicsRegistration(
        fixed_path="metal_section1.tif",
        moving_path="metal_section2.tif",
        fixed_channel=9,   # Zn
        moving_channel=9,  # Zn
    )

    reg.preprocess()
    reg.register_affine_optimization(metric='ncc')
    reg.compute_registration_quality()
    reg.apply_transform_to_fullres()
    reg.save_results("output/")

Channel Mapping (LA-ICP-MS):
    0: 0TIC - Total Ion Count
    1: Na   - Sodium
    2: Mg   - Magnesium
    3: P    - Phosphorus (nucleic acids, cell density)
    4: S    - Sulfur (protein content)
    5: Ca   - Calcium
    6: Mn   - Manganese
    7: Fe   - Iron (macrophages, blood)
    8: Cu   - Copper (stellate cells, bile ducts)
    9: Zn   - Zinc (hepatocytes, structure)
    10: Rb  - Rubidium
    11: Sr  - Strontium
    12: 118Sn - Tin-118
    13: Ba  - Barium
"""

import numpy as np
from pathlib import Path
from typing import Optional, Tuple, Dict, Any, List
import logging
import matplotlib.pyplot as plt
from skimage import transform, exposure, filters
import tifffile

from .registration_core import (
    BaseMultimodalRegistration,
    RegistrationQualityMetrics,
    RegistrationError,
    logger,
    percentile_normalize,
)


# Channel mapping for LA-ICP-MS metallomics data
METAL_CHANNELS = {
    0: ('0TIC', 'Total Ion Count'),
    1: ('Na', 'Sodium'),
    2: ('Mg', 'Magnesium'),
    3: ('P', 'Phosphorus - nucleic acids, cell density'),
    4: ('S', 'Sulfur - protein content'),
    5: ('Ca', 'Calcium'),
    6: ('Mn', 'Manganese'),
    7: ('Fe', 'Iron - macrophages, blood'),
    8: ('Cu', 'Copper - stellate cells, bile ducts'),
    9: ('Zn', 'Zinc - hepatocytes, structure'),
    10: ('Rb', 'Rubidium'),
    11: ('Sr', 'Strontium'),
    12: ('118Sn', 'Tin-118'),
    13: ('Ba', 'Barium'),
}


class MetallomicsMetallomicsRegistration(BaseMultimodalRegistration):
    """
    Register two metallomics datasets from consecutive tissue sections.

    This class extends BaseMultimodalRegistration for metallomics-to-metallomics
    registration workflows. Both images are typically at similar resolution
    (~50x50 pixels) from LA-ICP-MS or similar techniques.

    The "fixed" image is the reference (will not be transformed).
    The "moving" image will be transformed to align with the fixed image.

    Attributes
    ----------
    fixed_image : np.ndarray
        The fixed (reference) metallomics image
    moving_image : np.ndarray
        The moving metallomics image to be registered
    fixed_channel : int
        Channel index used for the fixed image
    moving_channel : int
        Channel index used for the moving image
    registered_moving : np.ndarray
        The registered moving image (after registration)

    Notes
    -----
    Since both images are at similar resolution, no downsampling is needed.
    The registration is performed directly on the loaded images.
    """

    FIXED_IMAGE_NAME  = "Fixed Metallomics"
    MOVING_IMAGE_NAME = "Moving Metallomics"

    def __init__(
        self,
        fixed_path: Optional[str] = None,
        moving_path: Optional[str] = None,
        fixed_array: Optional[np.ndarray] = None,
        moving_array: Optional[np.ndarray] = None,
        fixed_channel: Optional[int] = None,
        moving_channel: Optional[int] = None,
        pre_rotation: int = 0,
        rotate_which: str = 'moving'
    ):
        """
        Initialize metallomics-to-metallomics registration.

        Parameters
        ----------
        fixed_path : str, optional
            Path to fixed (reference) metallomics image
        moving_path : str, optional
            Path to moving metallomics image
        fixed_array : np.ndarray, optional
            Fixed image as numpy array (alternative to path)
        moving_array : np.ndarray, optional
            Moving image as numpy array (alternative to path)
        fixed_channel : int, optional
            Channel to use for fixed image (0-indexed). If None, uses first channel.
        moving_channel : int, optional
            Channel to use for moving image (0-indexed). If None, uses first channel.
        pre_rotation : int
            Pre-rotation angle (0, 90, 180, 270) to apply before registration
        rotate_which : str
            Which image to rotate: 'moving' (default) or 'fixed'

        Raises
        ------
        RegistrationError
            If required paths/arrays are not provided
        ValueError
            If rotate_which is not 'fixed' or 'moving'
        """
        self._validate_inputs(
            fixed_path, moving_path, fixed_array, moving_array,
            pre_rotation, rotate_which
        )

        self.pre_rotation   = pre_rotation
        self.rotate_which   = rotate_which
        self.fixed_channel  = fixed_channel
        self.moving_channel = moving_channel

        # Required by base class draw_mask_interactive
        self.fixed_rgb: Optional[np.ndarray] = None

        # Load images
        if fixed_path is not None:
            self.fixed_original = self._load_image(fixed_path, channel=fixed_channel)
        else:
            self._validate_array(fixed_array, "fixed")
            self.fixed_original = fixed_array.astype(np.float64)

        if moving_path is not None:
            self.moving_original = self._load_image(moving_path, channel=moving_channel)
        else:
            self._validate_array(moving_array, "moving")
            self.moving_original = moving_array.astype(np.float64)

        # Apply pre-rotation if requested
        if self.pre_rotation != 0:
            self._apply_pre_rotation()

        # Store shapes
        self.fixed_shape:  Tuple[int, int] = self.fixed_original.shape[:2]
        self.moving_shape: Tuple[int, int] = self.moving_original.shape[:2]

        logger.info(f"Fixed metallomics shape: {self.fixed_shape}")
        logger.info(f"Moving metallomics shape: {self.moving_shape}")

        if fixed_channel is not None:
            metal_name = METAL_CHANNELS.get(fixed_channel, (f'Ch{fixed_channel}', ''))[0]
            logger.info(f"Fixed channel: {fixed_channel} ({metal_name})")
        if moving_channel is not None:
            metal_name = METAL_CHANNELS.get(moving_channel, (f'Ch{moving_channel}', ''))[0]
            logger.info(f"Moving channel: {moving_channel} ({metal_name})")

        # Working copies (updated by preprocess)
        self.fixed_image:  np.ndarray = self.fixed_original.copy()
        self.moving_image: np.ndarray = self.moving_original.copy()

        # moving_downsampled is the same as moving_image for same-resolution images.
        # Base class registration methods (register_affine_optimization, etc.) all
        # read from self.moving_downsampled, so we must keep it in sync.
        self.moving_downsampled: Optional[np.ndarray] = None

        # Scale factor (1:1 — both images at same resolution)
        self.scale_factor: np.ndarray = np.array([1.0, 1.0])

        # Masks
        self.mask_fixed:              Optional[np.ndarray] = None
        self.mask_moving:             Optional[np.ndarray] = None
        self.mask_moving_downsampled: Optional[np.ndarray] = None  # required by base class
        self.use_masking: bool = False

        # Registration state
        self.transform_matrix:  Optional[Any] = None   # AffineTransform set by base class methods
        self.registered_moving: Optional[np.ndarray] = None
        self.is_preprocessed:   bool = False

    # -------------------------------------------------------------------------
    # Input validation
    # -------------------------------------------------------------------------

    def _validate_inputs(
        self,
        fixed_path, moving_path, fixed_array, moving_array,
        pre_rotation, rotate_which
    ) -> None:
        if fixed_path is None and fixed_array is None:
            raise RegistrationError("Must provide either fixed_path or fixed_array")
        if moving_path is None and moving_array is None:
            raise RegistrationError("Must provide either moving_path or moving_array")
        if pre_rotation not in [0, 90, 180, 270]:
            raise ValueError(f"pre_rotation must be 0/90/180/270, got {pre_rotation}")
        if rotate_which not in ['fixed', 'moving']:
            raise ValueError(f"rotate_which must be 'fixed' or 'moving', got '{rotate_which}'")

    # -------------------------------------------------------------------------
    # Private helpers (not in base class for this modality)
    # -------------------------------------------------------------------------

    def _normalize_image(self, img: np.ndarray) -> np.ndarray:
        """Normalise image to [0, 1]."""
        lo, hi = img.min(), img.max()
        if hi > lo:
            return (img - lo) / (hi - lo)
        return np.zeros_like(img, dtype=float)

    def _apply_clahe(self, img: np.ndarray) -> np.ndarray:
        """Apply CLAHE contrast enhancement."""
        img_u8 = (np.clip(img, 0, 1) * 255).astype(np.uint8)
        enhanced = exposure.equalize_adapthist(img_u8, clip_limit=0.03)
        return enhanced.astype(float)

    def _apply_gaussian(self, img: np.ndarray, sigma: float) -> np.ndarray:
        """Apply Gaussian smoothing."""
        return filters.gaussian(img, sigma=sigma)

    @staticmethod
    def _make_overlay(
        fixed: np.ndarray,
        moving: np.ndarray,
        alpha: float = 0.5
    ) -> np.ndarray:
        """Build a simple green/magenta RGB overlay from two greyscale images.

        If `fixed` and `moving` have different shapes (e.g. when overlaying the
        original moving image on the fixed canvas before registration), the
        moving image is placed at the origin (0, 0) of a zero-padded canvas the
        size of `fixed`. Any part of the moving image that extends past the
        fixed canvas is cropped.
        """
        # Percentile-stretched (not plain min/max) so a handful of bright
        # outlier pixels — common in LA-ICP-MS data — don't crush the rest
        # of the signal down near black. This is what made the saved
        # overlay PNGs hard to interpret.
        f = percentile_normalize(fixed)
        m = percentile_normalize(moving)

        # Align moving to fixed shape by padding/cropping when sizes differ
        if m.shape != f.shape:
            canvas = np.zeros_like(f, dtype=float)
            h = min(m.shape[0], f.shape[0])
            w = min(m.shape[1], f.shape[1])
            canvas[:h, :w] = m[:h, :w]
            m = canvas

        rgb = np.zeros((*f.shape, 3), dtype=float)
        # Fixed  → magenta  (R + B)
        rgb[..., 0] = f
        rgb[..., 2] = f
        # Moving → green
        rgb[..., 1] = m * alpha + rgb[..., 1] * (1 - alpha)
        rgb[..., 0] = rgb[..., 0] * (1 - alpha)
        rgb[..., 2] = rgb[..., 2] * (1 - alpha)
        return np.clip(rgb, 0, 1)

    # -------------------------------------------------------------------------
    # Pre-rotation
    # -------------------------------------------------------------------------

    def _apply_pre_rotation(self) -> None:
        k = self.pre_rotation // 90
        if self.rotate_which == 'moving':
            logger.info(f"Applying {self.pre_rotation}° rotation to moving image...")
            self.moving_original = np.rot90(self.moving_original, k=k)
        else:
            logger.info(f"Applying {self.pre_rotation}° rotation to fixed image...")
            self.fixed_original = np.rot90(self.fixed_original, k=k)

    # -------------------------------------------------------------------------
    # Property aliases
    # -------------------------------------------------------------------------

    @property
    def fixed(self) -> np.ndarray:
        return self.fixed_image

    @fixed.setter
    def fixed(self, value):
        self.fixed_image = value

    @property
    def moving(self) -> np.ndarray:
        return self.moving_image

    @moving.setter
    def moving(self, value):
        self.moving_image = value

    # -------------------------------------------------------------------------
    # Preprocessing
    # -------------------------------------------------------------------------

    def preprocess(
        self,
        normalize: bool = True,
        clahe: bool = False,
        gaussian_sigma: float = 0
    ) -> None:
        """
        Preprocess both metallomics images for registration.

        Since both images are at similar resolution, no downsampling is needed.

        Parameters
        ----------
        normalize : bool
            Normalise images to [0, 1]
        clahe : bool
            Apply CLAHE contrast enhancement
        gaussian_sigma : float
            Sigma for Gaussian smoothing (0 = disabled)
        """
        logger.info("Preprocessing metallomics images...")

        for attr_orig, attr_out in [
            ('fixed_original',  'fixed_image'),
            ('moving_original', 'moving_image'),
        ]:
            img = getattr(self, attr_orig).copy()
            if normalize:
                img = self._normalize_image(img)
            if clahe:
                img = self._apply_clahe(img)
            if gaussian_sigma > 0:
                img = self._apply_gaussian(img, gaussian_sigma)
            setattr(self, attr_out, img)

        # Keep moving_downsampled in sync — base class registration methods
        # (register_affine_optimization, register_phase_correlation, etc.) all
        # read from this attribute via _validate_preprocessed().
        self.moving_downsampled = self.moving_image.copy()

        # Sync mask if already defined
        if self.mask_moving is not None:
            self.mask_moving_downsampled = self.mask_moving.copy()

        self.is_preprocessed = True
        logger.info(f"Preprocessing complete. Working resolution: {self.fixed_shape}")

    # -------------------------------------------------------------------------
    # Masking
    # -------------------------------------------------------------------------

    def setup_shared_mask(
        self,
        define_on: str = 'fixed',
        interactive: bool = True,
        threshold_percentile: float = 10
    ) -> None:
        """
        Set up a single mask applied to BOTH fixed and moving images.

        Parameters
        ----------
        define_on : str
            Which image to draw on: 'fixed' or 'moving'
        interactive : bool
            Use the interactive drawing tool if True; auto-threshold otherwise
        threshold_percentile : float
            Percentile for automatic tissue detection (used when interactive=False)
        """
        if define_on not in ['fixed', 'moving']:
            raise ValueError("define_on must be 'fixed' or 'moving'")

        if interactive:
            # draw_mask_interactive(which=) uses self.fixed_image or
            # self.moving_downsampled internally — make sure both are set.
            if self.moving_downsampled is None:
                self.moving_downsampled = self.moving_image.copy()
            mask = self.draw_mask_interactive(which=define_on)
        else:
            source = (
                self.fixed_image if define_on == 'fixed' else self.moving_image
            )
            mask = self.create_tissue_mask(source, threshold_percentile)

        self.mask_fixed              = mask
        self.mask_moving             = mask
        self.mask_moving_downsampled = mask  # keep base class in sync
        self.use_masking             = True

        logger.info(f"Shared mask created from {define_on} image")

    # -------------------------------------------------------------------------
    # Visualisation
    # -------------------------------------------------------------------------

    def preview_images(self, figsize: Tuple[int, int] = (12, 5)) -> None:
        """Preview both metallomics images side by side."""
        fig, axes = plt.subplots(1, 2, figsize=figsize)

        def _title(base, channel):
            if channel is not None:
                name = METAL_CHANNELS.get(channel, (f'Ch{channel}', ''))[0]
                return f"{base} (Ch {channel}: {name})"
            return base

        axes[0].imshow(self.fixed_original,  cmap='viridis')
        axes[0].set_title(_title("Fixed Metallomics",  self.fixed_channel))
        axes[0].axis('off')

        axes[1].imshow(self.moving_original, cmap='viridis')
        axes[1].set_title(_title("Moving Metallomics", self.moving_channel))
        axes[1].axis('off')

        plt.tight_layout()
        plt.show()

    def preview_masks(self, figsize: Tuple[int, int] = (12, 5)) -> None:
        """Preview masks overlaid on both images."""
        if not self.use_masking:
            logger.warning("No masks defined. Call setup_shared_mask() first.")
            return

        fig, axes = plt.subplots(1, 2, figsize=figsize)

        for ax, img, mask, title in [
            (axes[0], self.fixed_original,  self.mask_fixed,  "Fixed Metallomics + Mask"),
            (axes[1], self.moving_original, self.mask_moving, "Moving Metallomics + Mask"),
        ]:
            ax.imshow(img, cmap='viridis')
            if mask is not None:
                ax.imshow(mask, cmap='Reds', alpha=0.3)
            ax.set_title(title)
            ax.axis('off')

        plt.tight_layout()
        plt.show()

    def preview_registration(
        self,
        alpha: float = 0.5,
        use_downsampled: bool = True,
        figsize: Tuple[int, int] = (15, 5),
        save_path: Optional[str] = None,
        show: bool = True,
    ) -> None:
        """
        Preview registration result (fixed | registered moving | overlay).

        Parameters
        ----------
        save_path : str, optional
            If given, save this figure to disk (PNG, 150 dpi) before/instead
            of showing it. This is the clearer, percentile-stretched overlay
            that previously only appeared as a transient pop-up window and
            was never written to disk — pass show=False to save silently.
        show : bool
            Whether to display the figure interactively (plt.show()).
        """
        if self.transform_matrix is None:
            logger.warning("Not registered yet. Call a registration method first.")
            return

        if self.registered_moving is None:
            self.apply_transform_to_fullres()

        fig, axes = plt.subplots(1, 3, figsize=figsize)

        axes[0].imshow(self.fixed_image, cmap='viridis')
        axes[0].set_title("Fixed Metallomics")
        axes[0].axis('off')

        axes[1].imshow(self.registered_moving, cmap='magma')
        axes[1].set_title("Registered Moving")
        axes[1].axis('off')

        overlay = self._make_overlay(self.fixed_image, self.registered_moving, alpha)
        axes[2].imshow(overlay)
        axes[2].set_title("Overlay (Fixed=Magenta, Moving=Green)")
        axes[2].axis('off')

        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            logger.info(f"Saved registration preview: {save_path}")
        if show:
            plt.show()
        else:
            plt.close(fig)

    def visualize_metallomics_comparison(
        self,
        figsize: Tuple[int, int] = (15, 10),
        save_path: Optional[str] = None,
        show: bool = True,
    ) -> None:
        """
        Comprehensive before/after registration comparison.

        Parameters
        ----------
        save_path : str, optional
            If given, save this figure to disk (PNG, 150 dpi).
        show : bool
            Whether to display the figure interactively (plt.show()).
        """
        if self.transform_matrix is None:
            logger.warning("Not registered yet. Call a registration method first.")
            return

        if self.registered_moving is None:
            self.apply_transform_to_fullres()

        fig, axes = plt.subplots(2, 3, figsize=figsize)

        # Row 1: before registration
        axes[0, 0].imshow(self.fixed_original,  cmap='viridis')
        axes[0, 0].set_title("Fixed (Reference)")
        axes[0, 0].axis('off')

        axes[0, 1].imshow(self.moving_original, cmap='magma')
        axes[0, 1].set_title("Moving (Original)")
        axes[0, 1].axis('off')

        overlay_before = self._make_overlay(
            self._normalize_image(self.fixed_original),
            self._normalize_image(self.moving_original),
        )
        axes[0, 2].imshow(overlay_before)
        axes[0, 2].set_title("Before Registration")
        axes[0, 2].axis('off')

        # Row 2: after registration
        axes[1, 0].imshow(self.fixed_image, cmap='viridis')
        axes[1, 0].set_title("Fixed (Preprocessed)")
        axes[1, 0].axis('off')

        axes[1, 1].imshow(self.registered_moving, cmap='magma')
        axes[1, 1].set_title("Moving (Registered)")
        axes[1, 1].axis('off')

        overlay_after = self._make_overlay(self.fixed_image, self.registered_moving)
        axes[1, 2].imshow(overlay_after)
        axes[1, 2].set_title("After Registration")
        axes[1, 2].axis('off')

        plt.suptitle("Metallomics-Metallomics Registration Comparison", fontsize=14)
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            logger.info(f"Saved comparison figure: {save_path}")
        if show:
            plt.show()
        else:
            plt.close(fig)

    # -------------------------------------------------------------------------
    # Transform application
    # -------------------------------------------------------------------------

    def apply_transform_to_fullres(self) -> np.ndarray:
        """
        Apply the registration transform to the original moving image.

        For metallomics-metallomics registration both images are already at
        full resolution, so no up-scaling is needed.

        Returns
        -------
        np.ndarray
            Registered moving image
        """
        if self.transform_matrix is None:
            raise RegistrationError("No transform available. Run registration first.")

        # transform_matrix is an AffineTransform object (set by base class methods)
        self.registered_moving = transform.warp(
            self.moving_original,
            self.transform_matrix.inverse,
            output_shape=self.fixed_shape,
            order=1,
            preserve_range=True,
        )

        logger.info(f"Transform applied. Output shape: {self.registered_moving.shape}")
        return self.registered_moving

    def get_full_transform_matrix(self) -> np.ndarray:
        """
        Return the 3×3 affine transformation matrix as a numpy array.

        For metallomics-metallomics registration the working resolution equals
        the full resolution, so no scale correction is needed.

        Returns
        -------
        np.ndarray
            3×3 affine transformation matrix
        """
        if self.transform_matrix is None:
            raise RegistrationError("No transform available. Run registration first.")
        # transform_matrix is an AffineTransform — return its underlying matrix
        return self.transform_matrix.params.copy()

    # -------------------------------------------------------------------------
    # Save
    # -------------------------------------------------------------------------

    def save_results(
        self,
        output_dir: str,
        prefix: str = "metallomics_registration",
        save_overlay: bool = True,
        save_registered: bool = True,
        save_transform: bool = True,
        save_comparison: bool = True,
    ) -> Dict[str, str]:
        """
        Save registration results to disk.

        Parameters
        ----------
        output_dir : str
            Output directory
        prefix : str
            Filename prefix
        save_overlay : bool
            Save overlay PNG
        save_registered : bool
            Save registered moving image as TIFF
        save_transform : bool
            Save transformation matrix as .npy
        save_comparison : bool
            Save the clearer preview_registration() and
            visualize_metallomics_comparison() figures as PNGs. These are the
            figures that previously only appeared as transient pop-up windows
            (plt.show()) and were lost unless manually screenshotted.

        Returns
        -------
        dict
            Mapping from result type to saved file path
        """
        if self.registered_moving is None:
            self.apply_transform_to_fullres()

        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        saved = {}

        if save_registered:
            p = output_path / f"{prefix}_registered_moving.tif"
            tifffile.imwrite(str(p), self.registered_moving.astype(np.float32))
            saved['registered_moving'] = str(p)
            logger.info(f"Saved registered moving: {p}")

        if save_overlay:
            overlay = self._make_overlay(self.fixed_image, self.registered_moving)
            p = output_path / f"{prefix}_overlay.png"
            plt.imsave(str(p), overlay)
            saved['overlay'] = str(p)
            logger.info(f"Saved overlay: {p}")

        if save_comparison:
            p = output_path / f"{prefix}_overlay_comparison.png"
            self.preview_registration(save_path=str(p), show=False)
            saved['overlay_comparison'] = str(p)

            p = output_path / f"{prefix}_full_comparison.png"
            self.visualize_metallomics_comparison(save_path=str(p), show=False)
            saved['full_comparison'] = str(p)

        if save_transform and self.transform_matrix is not None:
            p = output_path / f"{prefix}_transform.npy"
            np.save(str(p), self.transform_matrix.params)
            saved['transform'] = str(p)
            logger.info(f"Saved transform: {p}")

        return saved


# ---------------------------------------------------------------------------
# Convenience function
# ---------------------------------------------------------------------------

def register_metallomics_to_metallomics(
    fixed_path: str,
    moving_path: str,
    fixed_channel: Optional[int] = None,
    moving_channel: Optional[int] = None,
    pre_rotation: int = 0,
    method: str = 'affine',
    metric: str = 'ncc',
    output_dir: Optional[str] = None,
) -> MetallomicsMetallomicsRegistration:
    """
    Convenience function for quick metallomics-to-metallomics registration.

    Parameters
    ----------
    fixed_path : str
        Path to fixed (reference) metallomics image
    moving_path : str
        Path to moving metallomics image
    fixed_channel : int, optional
        Channel to use for fixed image
    moving_channel : int, optional
        Channel to use for moving image
    pre_rotation : int
        Pre-rotation angle (0, 90, 180, 270)
    method : str
        Registration method: 'phase' | 'affine' | 'sitk' | 'boundary'
    metric : str
        Similarity metric: 'nmi' | 'ncc' | 'mse'
    output_dir : str, optional
        If provided, save results to this directory

    Returns
    -------
    MetallomicsMetallomicsRegistration
    """
    reg = MetallomicsMetallomicsRegistration(
        fixed_path=fixed_path,
        moving_path=moving_path,
        fixed_channel=fixed_channel,
        moving_channel=moving_channel,
        pre_rotation=pre_rotation,
    )

    reg.preprocess()

    if method == 'phase':
        reg.register_phase_correlation()
    elif method == 'affine':
        reg.register_affine_optimization(metric=metric)
    elif method == 'sitk':
        reg.register_sitk(transform_type='affine', metric='mattes')
    elif method == 'boundary':
        reg.register_boundary_based()
    else:
        raise ValueError(f"Unknown method: '{method}'")

    reg.apply_transform_to_fullres()

    if output_dir:
        reg.save_results(output_dir)

    return reg
