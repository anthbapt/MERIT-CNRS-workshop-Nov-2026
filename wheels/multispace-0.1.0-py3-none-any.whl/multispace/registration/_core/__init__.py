"""
Multimodal Registration Package
===============================

A modular library for registering multimodal images in spatial biology workflows.

Modules:
--------
- registration_core: Base classes and shared functionality
- he_if_registration: H&E to IF registration
- metallomics_if_registration: Metallomics to IF registration
- metallomics_metallomics_registration: Metallomics to Metallomics registration

Quick Start:
------------
For H&E to IF registration:
    >>> from multispace.registration import HEIFRegistration
    >>> reg = HEIFRegistration(he_path="he.tif", if_path="if.tif", he_is_rgb=True)
    >>> reg.preprocess()
    >>> reg.register_affine_optimization(metric='ncc')
    >>> reg.save_results("output/")

For Metallomics to IF registration:
    >>> from multispace.registration import MetallomicsIFRegistration
    >>> reg = MetallomicsIFRegistration(metallomics_path="metal.tif", if_path="if.tif")
    >>> reg.preprocess()
    >>> reg.register_affine_optimization(metric='ncc')
    >>> reg.save_results("output/")

For Metallomics to Metallomics registration:
    >>> from multispace.registration import MetallomicsMetallomicsRegistration
    >>> reg = MetallomicsMetallomicsRegistration(fixed_path="section1.tif", moving_path="section2.tif")
    >>> reg.preprocess()
    >>> reg.register_affine_optimization(metric='ncc')
    >>> reg.save_results("output/")
"""

from .he_if_registration import HEIFRegistration, register_he_to_if
from .metallomics_he_registration import MetallomicsHERegistration, register_metallomics_to_he
from .metallomics_if_registration import MetallomicsIFRegistration, register_metallomics_to_if
from .metallomics_metallomics_registration import (
    METAL_CHANNELS,
    MetallomicsMetallomicsRegistration,
    register_metallomics_to_metallomics,
)
from .registration_core import BaseMultimodalRegistration, RegistrationQualityMetrics

__version__ = "1.1.0"
__author__ = "Spatial Biology Lab"

__all__ = [
    # Core
    "BaseMultimodalRegistration",
    "RegistrationQualityMetrics",
    # H&E-IF
    "HEIFRegistration",
    "register_he_to_if",
    # Metallomics-HE
    "MetallomicsHERegistration",
    "register_metallomics_to_he",
    # Metallomics-IF
    "MetallomicsIFRegistration",
    "register_metallomics_to_if",
    # Metallomics-Metallomics
    "MetallomicsMetallomicsRegistration",
    "register_metallomics_to_metallomics",
    "METAL_CHANNELS",
]
