#!/usr/bin/env python3
"""
Metallomics-IF Registration Module
==================================

This module provides the MetallomicsIFRegistration class for registering
metallomics data (e.g., LA-ICP-MS) with immunofluorescence (IF) images.

Example
-------
    from metallomics_if_registration import MetallomicsIFRegistration

    reg = MetallomicsIFRegistration(
        metallomics_path="metal.tif",
        if_path="if.tif",
        pre_rotation=180
    )

    reg.setup_shared_mask(define_on='metallomics', interactive=True)
    reg.preview_masks()
    reg.preprocess()
    reg.register_affine_optimization(metric='ncc')
    reg.compute_registration_quality()
    reg.apply_transform_to_fullres()
    reg.save_results("output/")
"""

from typing import Optional

import matplotlib.pyplot as plt
import numpy as np
from .registration_core import (
    BaseMultimodalRegistration,
    logger,
    percentile_normalize,
)


class MetallomicsIFRegistration(BaseMultimodalRegistration):
    """
    Register metallomics data to immunofluorescence (IF) images.

    This class extends BaseMultimodalRegistration for metallomics-specific
    registration workflows. Metallomics data (e.g., from LA-ICP-MS) is typically
    low resolution (~50x50 pixels) while IF images are high resolution (~4000x4000).

    The metallomics image is treated as the "fixed" image (reference), and the IF
    image is the "moving" image that gets transformed to align with metallomics.

    Attributes
    ----------
    metallomics : np.ndarray
        The metallomics image (low resolution)
    if_original : np.ndarray
        The original IF image (high resolution)
    if_downsampled : np.ndarray
        IF image downsampled to metallomics resolution
    """

    FIXED_IMAGE_NAME = "Metallomics"
    MOVING_IMAGE_NAME = "IF"

    def __init__(
        self,
        metallomics_path: Optional[str] = None,
        if_path: Optional[str] = None,
        metallomics_array: Optional[np.ndarray] = None,
        if_array: Optional[np.ndarray] = None,
        metallomics_channel: Optional[int] = None,
        combine_if_channels: bool = True,
        pre_rotation: int = 0,
        rotate_which: str = "if",
    ) -> None:
        """
        Initialize Metallomics-IF registration.

        Parameters
        ----------
        metallomics_path : str, optional
            Path to metallomics image (low-res, ~50x50)
        if_path : str, optional
            Path to IF image (high-res, ~4000x4000)
        metallomics_array : np.ndarray, optional
            Metallomics image as array
        if_array : np.ndarray, optional
            IF image as array
        metallomics_channel : int, optional
            Channel to use for metallomics (0-indexed)
        combine_if_channels : bool
            If True, combine IF channels via mean projection
        pre_rotation : int
            Coarse rotation (0, 90, 180, 270, or 'auto')
        rotate_which : str
            Which image to rotate: 'if' or 'metallomics'
        """
        # Map 'if'/'metallomics' to 'moving'/'fixed' for base class
        rotate_mapped = "moving" if rotate_which == "if" else "fixed"

        # Call parent constructor
        super().__init__(
            fixed_path=metallomics_path,
            moving_path=if_path,
            fixed_array=metallomics_array,
            moving_array=if_array,
            fixed_channel=metallomics_channel,
            combine_moving_channels=combine_if_channels,
            pre_rotation=pre_rotation,
            rotate_which=rotate_mapped,
        )

    # =========================================================================
    # Convenience Properties (aliases for clarity)
    # =========================================================================

    @property
    def metallomics(self) -> np.ndarray:
        """Alias for fixed_image (metallomics)."""
        return self.fixed_image

    @property
    def if_original(self) -> np.ndarray:
        """Alias for moving_image (IF original)."""
        return self.moving_image

    @property
    def if_downsampled(self) -> Optional[np.ndarray]:
        """Alias for moving_downsampled (IF downsampled)."""
        return self.moving_downsampled

    @property
    def registered_if(self) -> Optional[np.ndarray]:
        """Alias for registered_moving (registered IF)."""
        return self.registered_moving

    @property
    def metal_shape(self) -> tuple[int, int]:
        """Alias for fixed_shape (metallomics shape)."""
        return self.fixed_shape

    @property
    def if_shape(self) -> tuple[int, int]:
        """Alias for moving_shape (IF shape)."""
        return self.moving_shape

    @property
    def mask_metallomics(self) -> Optional[np.ndarray]:
        """Alias for mask_fixed (metallomics mask)."""
        return self.mask_fixed

    @mask_metallomics.setter
    def mask_metallomics(self, value):
        self.mask_fixed = value

    @property
    def mask_if(self) -> Optional[np.ndarray]:
        """Alias for mask_moving (IF mask)."""
        return self.mask_moving

    @mask_if.setter
    def mask_if(self, value):
        self.mask_moving = value

    @property
    def mask_if_downsampled(self) -> Optional[np.ndarray]:
        """Alias for mask_moving_downsampled."""
        return self.mask_moving_downsampled

    @mask_if_downsampled.setter
    def mask_if_downsampled(self, value):
        self.mask_moving_downsampled = value

    # =========================================================================
    # Metallomics-specific Methods
    # =========================================================================

    def setup_shared_mask(
        self,
        define_on: str = "metallomics",
        interactive: bool = True,
        threshold_percentile: float = 10,
        dilate_radius: int = 2,
        brush_size: int = 5,
        mask_array: Optional[np.ndarray] = None,
    ) -> "MetallomicsIFRegistration":
        """
        Setup a shared mask defined on one image and applied to both.

        Parameters
        ----------
        define_on : str
            Which image to define mask on: 'metallomics' or 'if'
        interactive : bool
            If True, opens interactive drawing tool
        threshold_percentile : float
            Percentile for automatic mask creation
        dilate_radius : int
            Radius for morphological dilation
        brush_size : int
            Initial brush size for interactive drawing
        mask_array : np.ndarray, optional
            Pre-computed mask array

        Returns
        -------
        self
            Returns self for method chaining
        """
        # Map 'metallomics'/'if' to 'fixed'/'moving'
        define_on_mapped = "fixed" if define_on == "metallomics" else "moving"
        return super().setup_shared_mask(
            define_on=define_on_mapped,
            interactive=interactive,
            threshold_percentile=threshold_percentile,
            dilate_radius=dilate_radius,
            brush_size=brush_size,
            mask_array=mask_array,
        )

    def draw_mask_interactive(
        self, which: str = "metallomics", brush_size: int = 5, flood_tolerance: float = 0.1
    ) -> np.ndarray:
        """
        Interactive mask drawing tool.

        Parameters
        ----------
        which : str
            Which image to draw mask for: 'metallomics' or 'if'
        brush_size : int
            Initial brush radius
        flood_tolerance : float
            Intensity tolerance for flood fill

        Returns
        -------
        np.ndarray
            Binary mask array
        """
        which_mapped = "fixed" if which == "metallomics" else "moving"
        return super().draw_mask_interactive(
            which=which_mapped, brush_size=brush_size, flood_tolerance=flood_tolerance
        )

    def setup_roi_box(
        self,
        box: Optional[tuple[int, int, int, int]] = None,
        interactive: bool = True,
        combine_with_tissue: bool = True,
        threshold_percentile: float = 10,
    ) -> "MetallomicsIFRegistration":
        """
        Define a rectangular ROI (box) on the metallomics image.

        Use this when the IF image is cropped and you want to select
        the region of metallomics that corresponds to the IF field of view.

        Parameters
        ----------
        box : tuple, optional
            Box coordinates as (row_start, row_end, col_start, col_end).
            If None and interactive=True, opens interactive selection.
        interactive : bool
            If True and box is None, opens interactive box selection
        combine_with_tissue : bool
            If True, also detect tissue within the box
        threshold_percentile : float
            Percentile for tissue detection

        Returns
        -------
        self
            Returns self for method chaining
        """
        self.use_masking = True

        logger.info("=" * 60)
        logger.info("SETTING UP ROI BOX ON METALLOMICS")
        logger.info("=" * 60)

        if box is None and interactive:
            box = self._select_box_interactive()
        elif box is None:
            margin = 2
            box = (margin, self.metal_shape[0] - margin, margin, self.metal_shape[1] - margin)
            logger.info(f"Using default box with {margin}px margin")

        row_start, row_end, col_start, col_end = box

        # Validate box
        row_start = max(0, min(row_start, self.metal_shape[0] - 1))
        row_end = max(row_start + 1, min(row_end, self.metal_shape[0]))
        col_start = max(0, min(col_start, self.metal_shape[1] - 1))
        col_end = max(col_start + 1, min(col_end, self.metal_shape[1]))

        logger.info(f"ROI box: rows [{row_start}:{row_end}], cols [{col_start}:{col_end}]")

        # Create mask at metallomics resolution
        metal_mask = np.zeros(self.metal_shape, dtype=bool)
        metal_mask[row_start:row_end, col_start:col_end] = True

        if combine_with_tissue:
            tissue_mask = self.create_tissue_mask(
                self.metallomics, threshold_percentile, dilate_radius=2
            )
            metal_mask = metal_mask & tissue_mask
            logger.info("Combined with tissue detection")

        self.mask_metallomics = metal_mask
        self.mask_if_downsampled = np.ones(self.metal_shape, dtype=bool)
        self.mask_if = np.ones(self.if_shape, dtype=bool)

        coverage = np.sum(metal_mask) / metal_mask.size * 100
        logger.info(f"Final mask coverage: {coverage:.1f}%")
        logger.info("=" * 60)

        return self

    def _select_box_interactive(self) -> tuple[int, int, int, int]:
        """Interactive box selection on metallomics image."""
        from matplotlib.widgets import RectangleSelector

        logger.info("=" * 60)
        logger.info("INTERACTIVE BOX SELECTION")
        logger.info("Click and drag to draw a rectangle")
        logger.info("Press Enter or 'q' to confirm, 'r' to reset")
        logger.info("=" * 60)

        metal_norm = (self.metallomics - self.metallomics.min()) / (
            self.metallomics.max() - self.metallomics.min() + 1e-10
        )

        fig, ax = plt.subplots(1, 1, figsize=(10, 10))
        ax.imshow(metal_norm, cmap="viridis")
        ax.set_title(
            "Draw a box around the region corresponding to IF\n"
            "Click and drag, then press Enter to confirm",
            fontsize=12,
            fontweight="bold",
        )

        selection = {"box": None, "done": False}

        def on_select(eclick, erelease):
            x1, y1 = int(eclick.xdata), int(eclick.ydata)
            x2, y2 = int(erelease.xdata), int(erelease.ydata)
            col_start, col_end = min(x1, x2), max(x1, x2)
            row_start, row_end = min(y1, y2), max(y1, y2)
            selection["box"] = (row_start, row_end, col_start, col_end)
            logger.info(f"Selected: rows [{row_start}:{row_end}], cols [{col_start}:{col_end}]")

        def on_key(event):
            if event.key in ["enter", "q"]:
                selection["done"] = True
                plt.close(fig)
            elif event.key == "r":
                selection["box"] = None
                ax.set_title("Selection reset - draw again", fontsize=12)
                fig.canvas.draw_idle()

        rect_selector = (  # noqa: F841 -- must stay alive to keep widget callbacks active
            RectangleSelector(
                ax,
                on_select,
                useblit=True,
                button=[1],
                minspanx=5,
                minspany=5,
                spancoords="pixels",
                interactive=True,
            )
        )

        fig.canvas.mpl_connect("key_press_event", on_key)
        plt.tight_layout()
        plt.show(block=True)

        if selection["box"] is None:
            margin = 2
            selection["box"] = (
                margin,
                self.metal_shape[0] - margin,
                margin,
                self.metal_shape[1] - margin,
            )
            logger.warning("No selection made, using default")

        return selection["box"]

    def visualize_metallomics_if_comparison(
        self, figsize: tuple[int, int] = (20, 8), save_path: Optional[str] = None
    ) -> None:
        """
        Create a comprehensive visualization comparing metallomics and IF.

        Shows:
        1. Metallomics image
        2. IF image (downsampled)
        3. Overlay before registration
        4. Overlay after registration
        """
        self._validate_registered()

        fig, axes = plt.subplots(1, 4, figsize=figsize)

        # Metallomics
        metal_norm = percentile_normalize(self.metallomics)
        axes[0].imshow(metal_norm, cmap="viridis")
        axes[0].set_title("Metallomics", fontweight="bold", fontsize=12)
        axes[0].axis("off")

        # IF
        if_norm = percentile_normalize(self.if_downsampled)
        axes[1].imshow(if_norm, cmap="gray")
        axes[1].set_title("IF (downsampled)", fontweight="bold", fontsize=12)
        axes[1].axis("off")

        # Before registration
        overlay_before = np.zeros((*self.metallomics.shape, 3))
        overlay_before[..., 0] = metal_norm  # Red = Metallomics
        overlay_before[..., 1] = if_norm  # Green = IF
        axes[2].imshow(overlay_before)
        axes[2].set_title(
            "Before Registration\n(Red=Metal, Green=IF)", fontweight="bold", fontsize=12
        )
        axes[2].axis("off")

        # After registration
        from skimage.transform import warp

        if_registered = warp(
            self.if_downsampled,
            self.transform_matrix.inverse,
            output_shape=self.metallomics.shape,
            order=1,
            mode="constant",
            cval=0,
        )
        if_reg_norm = percentile_normalize(if_registered)

        overlay_after = np.zeros((*self.metallomics.shape, 3))
        overlay_after[..., 0] = metal_norm
        overlay_after[..., 1] = if_reg_norm
        axes[3].imshow(overlay_after)
        axes[3].set_title(
            "After Registration\n(Red=Metal, Green=IF)", fontweight="bold", fontsize=12
        )
        axes[3].axis("off")

        plt.suptitle("Metallomics to IF Registration Results", fontsize=14, fontweight="bold")
        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches="tight")
            logger.info(f"Visualization saved to: {save_path}")

        plt.show()

    def get_ellipse_mask(self, binary_image: np.ndarray) -> np.ndarray:
        """
        Fit an ellipse to a binary mask and return the ellipse as a binary mask.

        Parameters
        ----------
        binary_image : np.ndarray
            Binary image (2D array)

        Returns
        -------
        np.ndarray
            Binary mask of the fitted ellipse
        """
        from skimage.draw import ellipse
        from skimage.measure import label as sk_label
        from skimage.measure import regionprops

        labeled = sk_label(binary_image)

        if labeled.max() == 0:
            return np.zeros_like(binary_image, dtype=bool)

        props = regionprops(labeled)
        if len(props) == 0:
            return np.zeros_like(binary_image, dtype=bool)

        # Get the largest region
        props = sorted(props, key=lambda x: x.area, reverse=True)[0]

        y0, x0 = props.centroid
        orientation = props.orientation
        major_axis = props.major_axis_length
        minor_axis = props.minor_axis_length

        ellipse_mask = np.zeros_like(binary_image, dtype=bool)

        rr, cc = ellipse(
            int(y0),
            int(x0),
            int(major_axis / 2),
            int(minor_axis / 2),
            shape=binary_image.shape,
            rotation=orientation,
        )

        ellipse_mask[rr, cc] = True
        return ellipse_mask


# Convenience function for quick registration
def register_metallomics_to_if(
    metallomics_path: str,
    if_path: str,
    pre_rotation: int = 0,
    method: str = "affine",
    metric: str = "ncc",
    output_dir: Optional[str] = None,
) -> MetallomicsIFRegistration:
    """
    Quick registration of metallomics to IF images.

    Parameters
    ----------
    metallomics_path : str
        Path to metallomics image
    if_path : str
        Path to IF image
    pre_rotation : int
        Pre-rotation angle (0, 90, 180, 270)
    method : str
        Registration method: 'phase', 'affine', 'sitk', or 'boundary'
    metric : str
        Similarity metric for affine: 'nmi', 'ncc', 'mse'
    output_dir : str, optional
        If provided, save results to this directory

    Returns
    -------
    MetallomicsIFRegistration
        The registration object with results
    """
    reg = MetallomicsIFRegistration(
        metallomics_path=metallomics_path, if_path=if_path, pre_rotation=pre_rotation
    )

    reg.preprocess()

    if method == "phase":
        reg.register_phase_correlation()
    elif method == "affine":
        reg.register_affine_optimization(metric=metric)
    elif method == "sitk":
        reg.register_sitk()
    elif method == "boundary":
        reg.register_boundary_based()
    else:
        raise ValueError(f"Unknown method: {method}")

    reg.apply_transform_to_fullres()

    if output_dir:
        reg.save_results(output_dir)

    return reg
