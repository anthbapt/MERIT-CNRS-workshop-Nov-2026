#!/usr/bin/env python3
"""
Multimodal Image Registration Core Module
==========================================

This module provides the base classes and utilities for multimodal image registration
between different imaging modalities (H&E, IF, Metallomics, etc.).

The module is designed to be extended by modality-specific wrappers.
"""

import numpy as np
from pathlib import Path
import warnings
import logging
from typing import Optional, Tuple, Dict, Union, Any, List
from dataclasses import dataclass
from abc import ABC, abstractmethod
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
from matplotlib.colors import LinearSegmentedColormap

# Image I/O and processing
from skimage import io, transform, exposure, filters
from skimage.registration import phase_cross_correlation
from skimage.transform import AffineTransform, warp
from skimage.morphology import binary_dilation, binary_erosion, disk, remove_small_objects
from skimage.measure import find_contours, regionprops, label
from skimage.filters import threshold_otsu
from scipy.optimize import minimize
from scipy import ndimage
from scipy.ndimage import binary_fill_holes
from scipy.spatial.distance import cdist
import tifffile

# Setup logging
# NOTE (multispace): the original module called logging.basicConfig() and
# warnings.filterwarnings('ignore') at import time. Libraries must not change
# global logging/warning state, so both were removed; configure logging in the
# application (the multispace CLI does this).
logger = logging.getLogger(__name__)

# Optional: SimpleITK for advanced registration
try:
    import SimpleITK as sitk
    HAS_SITK = True
except ImportError:
    HAS_SITK = False
    logger.debug("SimpleITK not available. Install with: pip install SimpleITK")


# =============================================================================
# Utility Functions
# =============================================================================

def check_interactive_backend() -> bool:
    """
    Check if matplotlib backend supports interactive features.
    
    Returns
    -------
    bool
        True if backend is interactive, False otherwise
    """
    current_backend = matplotlib.get_backend()
    interactive_backends = ['qt5agg', 'qt4agg', 'tkagg', 'wxagg', 'macosx', 'qtagg']
    is_interactive = any(ib in current_backend.lower() for ib in interactive_backends)
    
    print("=" * 60)
    print(f"Current matplotlib backend: {current_backend}")
    print("=" * 60)
    
    if is_interactive:
        print("Backend supports interactive features!")
    else:
        print("Backend does NOT support interactive features!")
        print("\nTo fix: run %matplotlib qt5 or change Spyder preferences")
    
    print("=" * 60)
    return is_interactive


def setup_interactive_backend() -> bool:
    """Attempt to switch to an interactive matplotlib backend."""
    backends_to_try = ['Qt5Agg', 'TkAgg', 'MacOSX', 'WXAgg']

    for backend in backends_to_try:
        try:
            matplotlib.use(backend)
            print(f"Switched to {backend} backend")
            return True
        except Exception:
            continue

    print("Could not switch to interactive backend")
    return False


def percentile_normalize(
    img: np.ndarray,
    low: float = 1.0,
    high: float = 99.0,
) -> np.ndarray:
    """
    Contrast-stretch an image to [0, 1] using percentile clipping.

    Plain min/max normalization (used throughout the display/overlay code)
    is easily dominated by a handful of outlier-bright pixels — common in
    LA-ICP-MS metallomics data and IF images — which crushes the rest of
    the useful signal down near zero and makes overlays look almost black.
    Clipping to the [low, high] percentile range before normalizing keeps
    those outliers from swamping the display.

    This is a *display-only* utility — it must not be used anywhere the
    normalized values feed back into registration math (e.g. preprocess()),
    only in overlay/preview/visualize code paths.

    Parameters
    ----------
    img : np.ndarray
        Input image (any shape).
    low, high : float
        Percentile bounds (0-100) to clip to before normalizing.

    Returns
    -------
    np.ndarray
        Image rescaled to [0, 1], float64.
    """
    img = np.asarray(img, dtype=np.float64)
    finite = img[np.isfinite(img)]
    if finite.size == 0:
        return np.zeros_like(img, dtype=np.float64)
    lo, hi = np.percentile(finite, [low, high])
    if hi <= lo:
        lo, hi = float(finite.min()), float(finite.max())
    if hi <= lo:
        return np.zeros_like(img, dtype=np.float64)
    return np.clip((img - lo) / (hi - lo), 0.0, 1.0)


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class RegistrationQualityMetrics:
    """Container for comprehensive registration quality metrics."""
    # Core similarity metrics
    nmi: float  # Normalized Mutual Information (1-2 typical, higher=better)
    ncc: float  # Normalized Cross-Correlation (-1 to 1, higher=better)
    mse: float  # Mean Squared Error (lower=better)
    ssim: float  # Structural Similarity Index (0-1, higher=better)
    
    # Additional metrics
    mi: Optional[float] = None
    psnr: Optional[float] = None
    mae: Optional[float] = None
    rmse: Optional[float] = None
    
    # Edge-based metrics
    edge_correlation: Optional[float] = None
    gradient_correlation: Optional[float] = None
    
    # Spatial metrics
    centroid_distance: Optional[float] = None
    
    # Mask-based metrics
    mask_iou: Optional[float] = None
    mask_dice: Optional[float] = None
    
    # Landmark-based
    tre: Optional[float] = None
    tre_std: Optional[float] = None
    tre_max: Optional[float] = None
    
    def __str__(self) -> str:
        lines = [
            "=" * 60,
            "REGISTRATION QUALITY METRICS",
            "=" * 60,
            "",
            "Core Similarity Metrics:",
            f"  NMI (Normalized Mutual Information): {self.nmi:.4f}",
            f"  NCC (Normalized Cross-Correlation): {self.ncc:.4f}",
            f"  MSE (Mean Squared Error): {self.mse:.6f}",
            f"  SSIM (Structural Similarity): {self.ssim:.4f}",
        ]
        
        if self.mi is not None:
            lines.append(f"  MI (Mutual Information): {self.mi:.4f}")
        
        if any(x is not None for x in [self.psnr, self.mae, self.rmse]):
            lines.append("")
            lines.append("Error Metrics:")
            if self.psnr is not None:
                lines.append(f"  PSNR (Peak SNR): {self.psnr:.2f} dB")
            if self.mae is not None:
                lines.append(f"  MAE (Mean Absolute Error): {self.mae:.6f}")
            if self.rmse is not None:
                lines.append(f"  RMSE (Root MSE): {self.rmse:.6f}")
        
        if any(x is not None for x in [self.edge_correlation, self.gradient_correlation]):
            lines.append("")
            lines.append("Edge/Gradient Metrics:")
            if self.edge_correlation is not None:
                lines.append(f"  Edge Correlation: {self.edge_correlation:.4f}")
            if self.gradient_correlation is not None:
                lines.append(f"  Gradient Correlation: {self.gradient_correlation:.4f}")
        
        if self.centroid_distance is not None:
            lines.append("")
            lines.append("Spatial Metrics:")
            lines.append(f"  Centroid Distance: {self.centroid_distance:.2f} pixels")
        
        if any(x is not None for x in [self.mask_iou, self.mask_dice]):
            lines.append("")
            lines.append("Mask Overlap Metrics:")
            if self.mask_iou is not None:
                lines.append(f"  Mask IoU: {self.mask_iou:.4f}")
            if self.mask_dice is not None:
                lines.append(f"  Mask Dice: {self.mask_dice:.4f}")
        
        if any(x is not None for x in [self.tre, self.tre_std, self.tre_max]):
            lines.append("")
            lines.append("Landmark-based Metrics (TRE):")
            if self.tre is not None:
                lines.append(f"  Mean TRE: {self.tre:.4f} pixels")
            if self.tre_std is not None:
                lines.append(f"  TRE Std Dev: {self.tre_std:.4f} pixels")
            if self.tre_max is not None:
                lines.append(f"  Max TRE: {self.tre_max:.4f} pixels")
        
        lines.append("")
        lines.append("=" * 60)
        return "\n".join(lines)
    
    def to_dict(self) -> Dict[str, Optional[float]]:
        """Convert metrics to dictionary for easy export."""
        return {
            'nmi': self.nmi, 'ncc': self.ncc, 'mse': self.mse, 'ssim': self.ssim,
            'mi': self.mi, 'psnr': self.psnr, 'mae': self.mae, 'rmse': self.rmse,
            'edge_correlation': self.edge_correlation,
            'gradient_correlation': self.gradient_correlation,
            'centroid_distance': self.centroid_distance,
            'mask_iou': self.mask_iou, 'mask_dice': self.mask_dice,
            'tre': self.tre, 'tre_std': self.tre_std, 'tre_max': self.tre_max,
        }
    
    def get_summary_score(self) -> float:
        """Compute a single summary score (0-1) combining key metrics."""
        scores = []
        scores.append(min(self.nmi / 2.0, 1.0))
        scores.append((self.ncc + 1) / 2.0)
        scores.append(self.ssim)
        mse_score = max(0, 1 - self.mse / 0.1)
        scores.append(mse_score)
        return np.mean(scores)
    
    def is_good_registration(self, nmi_threshold: float = 1.2,
                             ncc_threshold: float = 0.5,
                             ssim_threshold: float = 0.5) -> bool:
        """Quick check if registration quality meets minimum thresholds."""
        return (self.nmi >= nmi_threshold and
                self.ncc >= ncc_threshold and
                self.ssim >= ssim_threshold)


class RegistrationError(Exception):
    """Custom exception for registration errors."""
    pass


# =============================================================================
# Base Registration Class
# =============================================================================

class BaseMultimodalRegistration(ABC):
    """
    Abstract base class for multimodal image registration.
    
    This class provides the core functionality for registering images from
    different modalities. Subclasses should implement modality-specific
    loading and display methods.
    
    Attributes
    ----------
    fixed_image : np.ndarray
        The fixed/reference image (typically lower resolution)
    moving_image : np.ndarray
        The moving image to be registered (typically higher resolution)
    moving_downsampled : np.ndarray
        Moving image downsampled to fixed image resolution
    transform_matrix : AffineTransform
        The computed transformation matrix
    registered_moving : np.ndarray
        The registered moving image at full resolution
    """
    
    # Subclasses should define these
    FIXED_IMAGE_NAME: str = "fixed"
    MOVING_IMAGE_NAME: str = "moving"
    
    def __init__(
        self,
        fixed_path: Optional[str] = None,
        moving_path: Optional[str] = None,
        fixed_array: Optional[np.ndarray] = None,
        moving_array: Optional[np.ndarray] = None,
        fixed_channel: Optional[int] = None,
        combine_moving_channels: bool = True,
        pre_rotation: int = 0,
        rotate_which: str = 'moving'
    ) -> None:
        """
        Initialize the registration object.
        
        Parameters
        ----------
        fixed_path : str, optional
            Path to fixed image
        moving_path : str, optional
            Path to moving image
        fixed_array : np.ndarray, optional
            Fixed image as array
        moving_array : np.ndarray, optional
            Moving image as array
        fixed_channel : int, optional
            Channel to use for fixed image
        combine_moving_channels : bool
            If True, combine moving image channels via mean projection
        pre_rotation : int
            Coarse rotation (0, 90, 180, 270, or 'auto')
        rotate_which : str
            Which image to rotate: 'moving' or 'fixed'
        """
        logger.info(f"Initializing {self.__class__.__name__}...")
        
        # Validate inputs
        self._validate_init_inputs(
            fixed_path, moving_path, fixed_array, moving_array,
            pre_rotation, rotate_which
        )
        
        # Store settings
        self.pre_rotation = pre_rotation if pre_rotation != 'auto' else 0
        self.rotate_which = rotate_which
        self._auto_rotation = (pre_rotation == 'auto')
        
        # Placeholders for RGB display (used by HE subclass)
        self.fixed_rgb: Optional[np.ndarray] = None
        
        # Load images - subclasses may override _load_fixed_image
        if fixed_path is not None:
            self.fixed_image = self._load_fixed_image(fixed_path, fixed_channel)
        elif fixed_array is not None:
            self._validate_array(fixed_array, self.FIXED_IMAGE_NAME)
            self.fixed_image = fixed_array.astype(np.float64)
        else:
            raise RegistrationError(f"Must provide either {self.FIXED_IMAGE_NAME}_path or {self.FIXED_IMAGE_NAME}_array")
        
        if moving_path is not None:
            self.moving_image = self._load_image(moving_path, combine_channels=combine_moving_channels)
        elif moving_array is not None:
            self._validate_array(moving_array, self.MOVING_IMAGE_NAME)
            self.moving_image = moving_array.astype(np.float64)
        else:
            raise RegistrationError(f"Must provide either {self.MOVING_IMAGE_NAME}_path or {self.MOVING_IMAGE_NAME}_array")
        
        # Handle auto-rotation detection
        if self._auto_rotation:
            logger.info("Auto-detecting optimal rotation...")
            temp_moving_ds = transform.resize(
                self.moving_image, self.fixed_image.shape[:2],
                order=1, anti_aliasing=True, preserve_range=True
            )
            best_rotation, best_score = self._find_best_rotation(self.fixed_image, temp_moving_ds)
            self.pre_rotation = best_rotation
            logger.info(f"Auto-detected rotation: {best_rotation} (score: {best_score:.4f})")
            del temp_moving_ds
        
        # Store original moving shape BEFORE rotation
        self.moving_shape_before_rotation: Tuple[int, int] = self.moving_image.shape[:2]
        
        # Apply pre-rotation
        if self.pre_rotation != 0:
            self._apply_pre_rotation()
        
        # Store dimensions (after pre-rotation)
        self.fixed_shape: Tuple[int, int] = self.fixed_image.shape[:2]
        self.moving_shape: Tuple[int, int] = self.moving_image.shape[:2]
        
        # Calculate scale factor
        self.scale_factor: np.ndarray = np.array(self.moving_shape) / np.array(self.fixed_shape)
        
        logger.info(f"{self.FIXED_IMAGE_NAME} shape: {self.fixed_shape}")
        logger.info(f"{self.MOVING_IMAGE_NAME} shape: {self.moving_shape}")
        logger.info(f"Scale factor: {self.scale_factor}")
        if self.pre_rotation != 0:
            logger.info(f"Pre-rotation applied: {self.pre_rotation} to {rotate_which}")
        
        # Placeholders
        self.moving_downsampled: Optional[np.ndarray] = None
        self.transform_matrix: Optional[AffineTransform] = None
        self.registered_moving: Optional[np.ndarray] = None
        self.mask_fixed: Optional[np.ndarray] = None
        self.mask_moving: Optional[np.ndarray] = None
        self.mask_moving_downsampled: Optional[np.ndarray] = None
        self.use_masking: bool = False
        self._sitk_transform: Optional[Any] = None
        self._landmarks_fixed: Optional[np.ndarray] = None
        self._landmarks_moving: Optional[np.ndarray] = None
        self._tps_transform: Optional[Dict] = None
        self._use_tps: bool = False
    
    def _validate_init_inputs(
        self,
        fixed_path: Optional[str],
        moving_path: Optional[str],
        fixed_array: Optional[np.ndarray],
        moving_array: Optional[np.ndarray],
        pre_rotation: Union[int, str],
        rotate_which: str
    ) -> None:
        """Validate initialization inputs."""
        if fixed_path is None and fixed_array is None:
            raise RegistrationError(f"Must provide either {self.FIXED_IMAGE_NAME}_path or {self.FIXED_IMAGE_NAME}_array")
        if moving_path is None and moving_array is None:
            raise RegistrationError(f"Must provide either {self.MOVING_IMAGE_NAME}_path or {self.MOVING_IMAGE_NAME}_array")
        
        valid_rotations = [0, 90, 180, 270, 'auto']
        if pre_rotation not in valid_rotations:
            raise ValueError(f"pre_rotation must be one of {valid_rotations}, got {pre_rotation}")
        
        valid_rotate_which = ['moving', 'fixed', self.MOVING_IMAGE_NAME.lower(), self.FIXED_IMAGE_NAME.lower()]
        if rotate_which not in valid_rotate_which:
            raise ValueError(f"rotate_which must be 'moving' or 'fixed', got '{rotate_which}'")
    
    def _validate_array(self, arr: np.ndarray, name: str) -> None:
        """Validate that an array is suitable for registration."""
        if not isinstance(arr, np.ndarray):
            raise TypeError(f"{name} array must be a numpy array, got {type(arr)}")
        if arr.ndim < 2:
            raise ValueError(f"{name} array must be at least 2D, got {arr.ndim}D")
        if arr.size == 0:
            raise ValueError(f"{name} array is empty")
        if not np.isfinite(arr).all():
            logger.warning(f"{name} array contains non-finite values (NaN or Inf)")
    
    def _validate_preprocessed(self) -> None:
        """Check that preprocessing has been run."""
        if self.moving_downsampled is None:
            raise RegistrationError("Must run preprocess() before registration.")
    
    def _validate_registered(self) -> None:
        """Check that registration has been run."""
        if self.transform_matrix is None:
            raise RegistrationError("Must run registration before this operation.")
    
    def _validate_fullres_applied(self) -> None:
        """Check that full-resolution transform has been applied."""
        if self.registered_moving is None:
            raise RegistrationError("Must run apply_transform_to_fullres() before this operation.")
    
    def _load_fixed_image(self, path: str, channel: Optional[int] = None) -> np.ndarray:
        """Load fixed image. Subclasses may override for special handling (e.g., RGB)."""
        return self._load_image(path, channel=channel)
    
    def _load_image(
        self,
        path: str,
        channel: Optional[int] = None,
        combine_channels: bool = False
    ) -> np.ndarray:
        """Load image from various formats."""
        path = Path(path)
        
        if not path.exists():
            raise FileNotFoundError(f"Image file not found: {path}")
        
        if path.suffix.lower() in ['.tif', '.tiff']:
            img = tifffile.imread(str(path))
        else:
            img = io.imread(str(path))
        
        logger.info(f"Loaded {path.name}: shape={img.shape}, dtype={img.dtype}")
        
        # Handle multi-channel images
        if img.ndim > 2:
            if img.shape[0] < img.shape[-1]:  # Channels first
                n_channels = img.shape[0]
                channel_axis = 0
            else:  # Channels last
                n_channels = img.shape[-1]
                channel_axis = -1
            
            logger.info(f"Detected {n_channels} channels (axis={channel_axis})")
            
            if combine_channels:
                img = np.mean(img, axis=channel_axis)
                logger.info("Combined channels via mean projection")
            elif channel is not None:
                if channel >= n_channels:
                    raise ValueError(f"Channel {channel} requested but only {n_channels} available")
                if channel_axis == 0:
                    img = img[channel]
                else:
                    img = img[..., channel]
                logger.info(f"Selected channel {channel}")
            else:
                if channel_axis == 0:
                    img = img[0]
                else:
                    img = img[..., 0]
                logger.info("Using first channel (default)")
        
        return img.astype(np.float64)
    
    def _apply_pre_rotation(self) -> None:
        """Apply coarse rotation (90, 180, 270) to one of the images."""
        k = self.pre_rotation // 90
        
        if self.rotate_which in ['moving', self.MOVING_IMAGE_NAME.lower()]:
            logger.info(f"Applying {self.pre_rotation} rotation to {self.MOVING_IMAGE_NAME}...")
            self.moving_image = np.rot90(self.moving_image, k=k)
            logger.info(f"{self.MOVING_IMAGE_NAME} shape after rotation: {self.moving_image.shape}")
        else:
            logger.info(f"Applying {self.pre_rotation} rotation to {self.FIXED_IMAGE_NAME}...")
            self.fixed_image = np.rot90(self.fixed_image, k=k)
            if self.fixed_rgb is not None:
                self.fixed_rgb = np.rot90(self.fixed_rgb, k=k)
            logger.info(f"{self.FIXED_IMAGE_NAME} shape after rotation: {self.fixed_image.shape}")
    
    def _find_best_rotation(self, fixed: np.ndarray, moving: np.ndarray) -> Tuple[int, float]:
        """Find the best 90-degree rotation by comparing NCC scores."""
        best_rotation = 0
        best_score = -np.inf
        
        for rotation in [0, 90, 180, 270]:
            k = rotation // 90
            rotated = np.rot90(moving, k=k)
            
            if rotated.shape != fixed.shape:
                rotated = transform.resize(rotated, fixed.shape, order=1, 
                                          anti_aliasing=True, preserve_range=True)
            
            # Compute NCC
            f_norm = (fixed - fixed.mean()) / (fixed.std() + 1e-10)
            m_norm = (rotated - rotated.mean()) / (rotated.std() + 1e-10)
            score = np.mean(f_norm * m_norm)
            
            if score > best_score:
                best_score = score
                best_rotation = rotation
        
        return best_rotation, best_score

    
    # =========================================================================
    # Preprocessing Methods
    # =========================================================================
    
    def preprocess(
        self,
        normalize: bool = True,
        clahe: bool = False,
        gaussian_sigma: float = 0
    ) -> 'BaseMultimodalRegistration':
        """
        Preprocess images for registration.
        
        Parameters
        ----------
        normalize : bool
            Normalize images to [0, 1] range
        clahe : bool
            Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
        gaussian_sigma : float
            Sigma for Gaussian smoothing (0 = no smoothing)
        
        Returns
        -------
        self
            Returns self for method chaining
        """
        logger.info("Preprocessing images...")
        
        # Downsample moving to fixed resolution
        self.moving_downsampled = transform.resize(
            self.moving_image, self.fixed_shape,
            order=1, anti_aliasing=True, preserve_range=True
        )
        
        # Process fixed image
        fixed_proc = self.fixed_image.copy()
        moving_proc = self.moving_downsampled.copy()
        
        if gaussian_sigma > 0:
            fixed_proc = filters.gaussian(fixed_proc, sigma=gaussian_sigma)
            moving_proc = filters.gaussian(moving_proc, sigma=gaussian_sigma)
            logger.info(f"Applied Gaussian smoothing (sigma={gaussian_sigma})")
        
        if normalize:
            fixed_proc = (fixed_proc - fixed_proc.min()) / (fixed_proc.max() - fixed_proc.min() + 1e-10)
            moving_proc = (moving_proc - moving_proc.min()) / (moving_proc.max() - moving_proc.min() + 1e-10)
            logger.info("Normalized images to [0, 1]")
        
        if clahe:
            fixed_proc = exposure.equalize_adapthist(fixed_proc, clip_limit=0.03)
            moving_proc = exposure.equalize_adapthist(moving_proc, clip_limit=0.03)
            logger.info("Applied CLAHE")
        
        self.fixed_image = fixed_proc
        self.moving_downsampled = moving_proc
        
        logger.info(f"Preprocessing complete. Working resolution: {self.fixed_shape}")
        return self
    
    # =========================================================================
    # Masking Methods
    # =========================================================================
    
    def create_tissue_mask(
        self,
        image: np.ndarray,
        threshold_percentile: float = 10,
        dilate_radius: int = 2
    ) -> np.ndarray:
        """
        Create a binary mask for tissue regions.
        
        Parameters
        ----------
        image : np.ndarray
            Input image
        threshold_percentile : float
            Percentile for thresholding
        dilate_radius : int
            Radius for morphological dilation
        
        Returns
        -------
        np.ndarray
            Binary mask
        """
        img_norm = (image - image.min()) / (image.max() - image.min() + 1e-10)
        threshold = np.percentile(img_norm, threshold_percentile)
        mask = img_norm > threshold
        
        if dilate_radius > 0:
            selem = disk(dilate_radius)
            mask = binary_dilation(mask, selem)
        
        return mask
    
    def setup_shared_mask(
        self,
        define_on: str = 'fixed',
        interactive: bool = True,
        threshold_percentile: float = 10,
        dilate_radius: int = 2,
        brush_size: int = 5,
        mask_array: Optional[np.ndarray] = None
    ) -> 'BaseMultimodalRegistration':
        """
        Setup a shared mask defined on one image and applied to both.
        
        Parameters
        ----------
        define_on : str
            Which image to define mask on: 'fixed' or 'moving'
        interactive : bool
            If True, opens interactive drawing tool
        threshold_percentile : float
            Percentile for automatic mask creation
        dilate_radius : int
            Radius for morphological dilation
        brush_size : int
            Initial brush size for interactive drawing
        mask_array : np.ndarray, optional
            Pre-computed mask array
        
        Returns
        -------
        self
            Returns self for method chaining
        """
        self.use_masking = True
        
        logger.info("=" * 60)
        logger.info(f"SETTING UP SHARED MASK (defined on {define_on})")
        logger.info("=" * 60)
        
        if mask_array is not None:
            self._validate_array(mask_array, "mask")
            mask = mask_array.astype(bool)
            logger.info("Using provided mask array")
        elif interactive:
            mask = self.draw_mask_interactive(which=define_on, brush_size=brush_size)
        else:
            if define_on == 'fixed':
                mask = self.create_tissue_mask(
                    self.fixed_image, threshold_percentile, dilate_radius
                )
            else:
                img = self.moving_downsampled if self.moving_downsampled is not None else \
                      transform.resize(self.moving_image, self.fixed_shape, order=1, 
                                      anti_aliasing=True, preserve_range=True)
                mask = self.create_tissue_mask(img, threshold_percentile, dilate_radius)
            logger.info("Created automatic tissue mask")
        
        # Apply mask to both images
        self.mask_fixed = mask
        self.mask_moving_downsampled = mask.copy()
        
        # Scale mask to full moving resolution
        self.mask_moving = transform.resize(
            mask.astype(float), self.moving_shape,
            order=0, preserve_range=True
        ) > 0.5
        
        coverage = np.sum(mask) / mask.size * 100
        logger.info(f"Mask coverage: {coverage:.1f}%")
        logger.info("=" * 60)
        
        return self
    
    def setup_boundary_mask(
        self,
        boundary_width_fixed: int = 3,
        boundary_width_moving: Optional[int] = None,
        combine_with_tissue: bool = True,
        threshold_percentile: float = 10
    ) -> 'BaseMultimodalRegistration':
        """
        Setup a mask that excludes image boundaries.
        
        Parameters
        ----------
        boundary_width_fixed : int
            Pixels to exclude from fixed image edges
        boundary_width_moving : int, optional
            Pixels to exclude from moving image edges (auto-scaled if None)
        combine_with_tissue : bool
            If True, also detect tissue within the boundary
        threshold_percentile : float
            Percentile for tissue detection
        
        Returns
        -------
        self
            Returns self for method chaining
        """
        self.use_masking = True
        
        logger.info("=" * 60)
        logger.info("SETTING UP BOUNDARY MASK")
        logger.info("=" * 60)
        
        if boundary_width_moving is None:
            boundary_width_moving = int(boundary_width_fixed * self.scale_factor.mean())
        
        logger.info(f"Excluding {boundary_width_fixed}px from fixed edges")
        logger.info(f"Excluding {boundary_width_moving}px from moving edges (scaled)")
        
        # Create mask at fixed resolution
        fixed_mask = np.ones(self.fixed_shape, dtype=bool)
        
        if boundary_width_fixed > 0:
            fixed_mask[:boundary_width_fixed, :] = False
            fixed_mask[-boundary_width_fixed:, :] = False
            fixed_mask[:, :boundary_width_fixed] = False
            fixed_mask[:, -boundary_width_fixed:] = False
        
        if combine_with_tissue:
            tissue_mask = self.create_tissue_mask(
                self.fixed_image, threshold_percentile, dilate_radius=2
            )
            fixed_mask = fixed_mask & tissue_mask
        
        self.mask_fixed = fixed_mask
        self.mask_moving_downsampled = fixed_mask.copy()
        
        # Create moving mask at full resolution
        moving_mask = np.ones(self.moving_shape, dtype=bool)
        if boundary_width_moving > 0:
            moving_mask[:boundary_width_moving, :] = False
            moving_mask[-boundary_width_moving:, :] = False
            moving_mask[:, :boundary_width_moving] = False
            moving_mask[:, -boundary_width_moving:] = False
        self.mask_moving = moving_mask
        
        coverage = np.sum(fixed_mask) / fixed_mask.size * 100
        logger.info(f"Final mask coverage: {coverage:.1f}%")
        logger.info("=" * 60)
        
        return self
    
    def draw_mask_interactive(
        self,
        which: str = 'fixed',
        brush_size: int = 5,
        flood_tolerance: float = 0.1
    ) -> np.ndarray:
        """
        Interactive mask drawing tool using matplotlib.
        
        Instructions:
        - Left click and drag to draw (add to mask)
        - Right click and drag to erase
        - Press 'i' to invert mask
        - Press 'c' to clear mask
        - Press 'f' then click to flood fill
        - Press '+'/'-' to change brush size
        - Press 'q' or close window when done
        
        Parameters
        ----------
        which : str
            Which image to draw mask for: 'fixed' or 'moving'
        brush_size : int
            Initial brush radius in pixels
        flood_tolerance : float
            Intensity tolerance for flood fill
        
        Returns
        -------
        np.ndarray
            Binary mask array
        """
        # Get image to work with
        if which == 'fixed':
            img = self.fixed_image.copy()
            img_display = self.fixed_rgb if self.fixed_rgb is not None else None
            title = f"Draw {self.FIXED_IMAGE_NAME} Mask"
        else:
            if self.moving_downsampled is not None:
                img = self.moving_downsampled.copy()
            else:
                img = transform.resize(
                    self.moving_image, self.fixed_shape,
                    order=1, anti_aliasing=True, preserve_range=True
                )
            img_display = None
            title = f"Draw {self.MOVING_IMAGE_NAME} Mask (downsampled)"
        
        img_norm = (img - img.min()) / (img.max() - img.min() + 1e-10)
        mask = np.zeros(img.shape[:2], dtype=bool)
        
        state = {
            'drawing': False, 'erasing': False, 'brush_size': brush_size,
            'mode': 'brush', 'flood_tolerance': flood_tolerance, 'done': False
        }
        
        fig = plt.figure(figsize=(16, 7))
        ax1 = fig.add_subplot(1, 2, 1)
        ax2 = fig.add_subplot(1, 2, 2)
        
        fig.suptitle(
            'DRAW ON THE TISSUE YOU WANT TO KEEP (red = included)\n'
            'Controls: Left-click=Draw | Right-click=Erase | I=Invert | C=Clear | Q=Done',
            fontsize=11, fontweight='bold', color='darkblue'
        )
        
        if img_display is not None:
            ax1.imshow(img_display)
            ax2.imshow(img_display)
        else:
            ax1.imshow(img_norm, cmap='gray')
            ax2.imshow(img_norm, cmap='gray')
        
        ax1.set_title(f'{title}\n(Original Image)', fontsize=12, fontweight='bold')
        ax1.axis('off')
        
        mask_overlay = ax2.imshow(np.ma.masked_where(~mask, mask),
                                  cmap='Reds', alpha=0.5, vmin=0, vmax=1)
        ax2.set_title(f'Mask (red = INCLUDED)\nBrush: {brush_size} | Mode: brush', 
                     fontsize=12, fontweight='bold')
        ax2.axis('off')
        
        brush_circle = Circle((0, 0), state['brush_size'], fill=False, 
                              edgecolor='yellow', linewidth=2)
        ax2.add_patch(brush_circle)
        brush_circle.set_visible(False)
        
        def update_display():
            mask_overlay.set_data(np.ma.masked_where(~mask, mask))
            ax2.set_title(f'Mask (red overlay)\nBrush: {state["brush_size"]} | Mode: {state["mode"]}',
                         fontsize=12, fontweight='bold')
            fig.canvas.draw_idle()
        
        def draw_at_position(x, y, erase=False):
            nonlocal mask
            x, y = int(round(x)), int(round(y))
            h, w = mask.shape
            yy, xx = np.ogrid[:h, :w]
            circle = (xx - x)**2 + (yy - y)**2 <= state['brush_size']**2
            mask[circle] = False if erase else True
        
        def on_mouse_press(event):
            nonlocal mask
            if event.inaxes != ax2:
                return
            if event.button == 1:
                if state['mode'] == 'brush':
                    state['drawing'] = True
                    draw_at_position(event.xdata, event.ydata)
                    update_display()
                elif state['mode'] == 'flood':
                    mask = self._flood_fill(mask, (event.xdata, event.ydata), 
                                           img_norm, state['flood_tolerance'])
                    update_display()
            elif event.button == 3 and state['mode'] == 'brush':
                state['erasing'] = True
                draw_at_position(event.xdata, event.ydata, erase=True)
                update_display()
        
        def on_mouse_release(event):
            state['drawing'] = False
            state['erasing'] = False
        
        def on_mouse_move(event):
            if event.inaxes != ax2:
                brush_circle.set_visible(False)
                fig.canvas.draw_idle()
                return
            brush_circle.center = (event.xdata, event.ydata)
            brush_circle.radius = state['brush_size']
            brush_circle.set_visible(state['mode'] == 'brush')
            if state['drawing']:
                draw_at_position(event.xdata, event.ydata)
                update_display()
            elif state['erasing']:
                draw_at_position(event.xdata, event.ydata, erase=True)
                update_display()
            else:
                fig.canvas.draw_idle()
        
        def on_key_press(event):
            nonlocal mask
            if event.key == 'q':
                state['done'] = True
                plt.close(fig)
            elif event.key == 'c':
                mask[:] = False
                update_display()
            elif event.key == 'i':
                mask[:] = ~mask
                update_display()
            elif event.key in ['+', '=']:
                state['brush_size'] = min(state['brush_size'] + 2, 50)
                update_display()
            elif event.key in ['-', '_']:
                state['brush_size'] = max(state['brush_size'] - 2, 1)
                update_display()
            elif event.key == 'f':
                state['mode'] = 'flood'
                update_display()
            elif event.key == 'b':
                state['mode'] = 'brush'
                update_display()
        
        fig.canvas.mpl_connect('button_press_event', on_mouse_press)
        fig.canvas.mpl_connect('button_release_event', on_mouse_release)
        fig.canvas.mpl_connect('motion_notify_event', on_mouse_move)
        fig.canvas.mpl_connect('key_press_event', on_key_press)
        
        plt.tight_layout()
        plt.show(block=True)
        
        logger.info(f"Mask created: {np.sum(mask)} pixels ({100*np.sum(mask)/mask.size:.1f}% coverage)")
        return mask
    
    def _flood_fill(
        self,
        mask: np.ndarray,
        seed_point: Tuple[int, int],
        image: np.ndarray,
        tolerance: float = 0.1
    ) -> np.ndarray:
        """Perform flood fill on the mask starting from seed_point."""
        from skimage.segmentation import flood
        
        x, y = int(round(seed_point[0])), int(round(seed_point[1]))
        
        if not (0 <= y < image.shape[0] and 0 <= x < image.shape[1]):
            logger.warning(f"Seed point ({x}, {y}) out of bounds")
            return mask
        
        img_norm = (image - image.min()) / (image.max() - image.min() + 1e-10)
        filled_region = flood(img_norm, (y, x), tolerance=tolerance)
        mask = mask | filled_region
        
        return mask
    
    def preview_masks(
        self,
        figsize: Tuple[int, int] = (14, 6),
        save_path: Optional[str] = None,
        show: bool = True
    ) -> Optional[plt.Figure]:
        """Show a side-by-side preview of the mask applied to both images."""
        if not self.use_masking:
            logger.warning("No masks defined.")
            return None
        
        fig, axes = plt.subplots(1, 2, figsize=figsize)
        fig.suptitle('Mask Preview - Verify mask on both images', fontsize=14, fontweight='bold')
        
        colors = [(1, 0, 0, 0), (1, 0, 0, 0.6)]
        mask_cmap = LinearSegmentedColormap.from_list('mask_overlay', colors)
        
        # Fixed image with mask
        ax1 = axes[0]
        if self.fixed_rgb is not None:
            ax1.imshow(self.fixed_rgb)
        else:
            fixed_norm = (self.fixed_image - self.fixed_image.min()) / \
                        (self.fixed_image.max() - self.fixed_image.min() + 1e-10)
            ax1.imshow(fixed_norm, cmap='viridis')
        
        if self.mask_fixed is not None:
            ax1.imshow(self.mask_fixed.astype(float), cmap=mask_cmap, vmin=0, vmax=1)
            ax1.contour(self.mask_fixed, colors='red', linewidths=2, levels=[0.5])
            coverage = np.sum(self.mask_fixed) / self.mask_fixed.size * 100
            ax1.set_title(f'{self.FIXED_IMAGE_NAME}\n{self.fixed_shape}\nMask coverage: {coverage:.1f}%',
                         fontsize=11, fontweight='bold')
        ax1.axis('off')
        
        # Moving image with mask
        ax2 = axes[1]
        if self.moving_downsampled is not None:
            moving_img = self.moving_downsampled
        else:
            moving_img = transform.resize(self.moving_image, self.fixed_shape, 
                                         order=1, anti_aliasing=True, preserve_range=True)
        
        moving_norm = (moving_img - moving_img.min()) / (moving_img.max() - moving_img.min() + 1e-10)
        ax2.imshow(moving_norm, cmap='gray')
        
        mask_display = self.mask_moving_downsampled if self.mask_moving_downsampled is not None else self.mask_fixed
        if mask_display is not None:
            ax2.imshow(mask_display.astype(float), cmap=mask_cmap, vmin=0, vmax=1)
            ax2.contour(mask_display, colors='red', linewidths=2, levels=[0.5])
            coverage = np.sum(mask_display) / mask_display.size * 100
            ax2.set_title(f'{self.MOVING_IMAGE_NAME} (downsampled)\nMask coverage: {coverage:.1f}%',
                         fontsize=11, fontweight='bold')
        ax2.axis('off')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            logger.info(f"Mask preview saved to: {save_path}")
        
        if show:
            plt.show()
            return None
        return fig

    
    # =========================================================================
    # Registration Methods
    # =========================================================================
    
    def register_phase_correlation(self) -> Dict[str, Any]:
        """
        Fast translation-only registration using phase correlation.
        
        Returns
        -------
        dict
            Dictionary with shift and error values
        """
        self._validate_preprocessed()
        
        logger.info("Running phase correlation registration...")
        
        shift, error, diffphase = phase_cross_correlation(
            self.fixed_image, self.moving_downsampled,
            upsample_factor=10
        )
        
        self.transform_matrix = AffineTransform(translation=shift[::-1])
        
        logger.info(f"Phase correlation result:")
        logger.info(f"  Shift: {shift}")
        logger.info(f"  Error: {error:.4f}")
        
        return {'shift': shift, 'error': error, 'diffphase': diffphase}
    
    def register_affine_optimization(
        self,
        metric: str = 'nmi',
        include_rotation: bool = True,
        include_scale: bool = False,
        initial_rotation: float = 0.0,
        rotation_range: float = 0.2
    ) -> Dict[str, Any]:
        """
        Affine registration using optimization.
        
        Parameters
        ----------
        metric : str
            Similarity metric: 'nmi', 'ncc', or 'mse'
        include_rotation : bool
            Include rotation in optimization
        include_scale : bool
            Include scale in optimization
        initial_rotation : float
            Initial rotation angle in radians
        rotation_range : float
            Maximum rotation range in radians
        
        Returns
        -------
        dict
            Dictionary with transformation parameters
        """
        self._validate_preprocessed()
        
        valid_metrics = ['nmi', 'ncc', 'mse']
        if metric not in valid_metrics:
            raise ValueError(f"metric must be one of {valid_metrics}")
        
        logger.info(f"Running affine optimization (metric={metric})...")
        
        fixed = self.fixed_image
        moving = self.moving_downsampled
        mask_fixed = self.mask_fixed if self.use_masking else None
        mask_moving = self.mask_moving_downsampled if self.use_masking else None
        
        # Initial parameters
        x0 = [0, 0]  # tx, ty
        if include_rotation:
            x0.append(initial_rotation)
        if include_scale:
            x0.extend([1, 1])  # sx, sy
        
        def cost_function(params):
            tx, ty = params[0], params[1]
            idx = 2
            rotation = params[idx] if include_rotation else 0
            idx += 1 if include_rotation else 0
            scale = params[idx:idx+2] if include_scale else [1, 1]
            
            tform = AffineTransform(scale=scale, rotation=rotation, translation=(tx, ty))
            warped = warp(moving, tform.inverse, output_shape=fixed.shape,
                         order=1, mode='constant', cval=0)
            
            warped_mask = None
            if mask_moving is not None:
                warped_mask = warp(mask_moving.astype(float), tform.inverse,
                                  output_shape=fixed.shape, order=0, mode='constant', cval=0) > 0.5
            
            if metric == 'nmi':
                return -self._normalized_mutual_information(fixed, warped, mask_fixed, warped_mask)
            elif metric == 'ncc':
                return -self._normalized_cross_correlation(fixed, warped, mask_fixed, warped_mask)
            else:
                if mask_fixed is not None or warped_mask is not None:
                    combined_mask = np.ones_like(fixed, dtype=bool)
                    if mask_fixed is not None:
                        combined_mask &= mask_fixed
                    if warped_mask is not None:
                        combined_mask &= warped_mask
                    return np.mean((fixed[combined_mask] - warped[combined_mask]) ** 2)
                return np.mean((fixed - warped) ** 2)
        
        logger.info("Starting optimization...")
        result = minimize(cost_function, x0, method='Powell',
                         options={'maxiter': 1000, 'disp': False})
        
        tx, ty = result.x[0], result.x[1]
        idx = 2
        rotation = result.x[idx] if include_rotation else 0
        idx += 1 if include_rotation else 0
        scale = result.x[idx:idx+2] if include_scale else [1, 1]
        
        self.transform_matrix = AffineTransform(scale=scale, rotation=rotation, translation=(tx, ty))
        
        logger.info(f"Optimization result:")
        logger.info(f"  Translation: ({tx:.2f}, {ty:.2f})")
        logger.info(f"  Rotation: {np.degrees(rotation):.2f}")
        logger.info(f"  Scale: {scale}")
        logger.info(f"  Final {metric.upper()}: {-result.fun:.4f}")
        
        return {
            'translation': (tx, ty),
            'rotation': rotation,
            'scale': scale,
            'metric_value': -result.fun
        }
    
    def register_sitk(
        self,
        transform_type: str = 'affine',
        metric: str = 'mattes'
    ) -> Dict[str, Any]:
        """
        Registration using SimpleITK (more robust for multimodal).
        
        Parameters
        ----------
        transform_type : str
            'translation', 'rigid', 'affine', or 'bspline'
        metric : str
            'mattes' (mutual information), 'correlation', 'mse'
        
        Returns
        -------
        dict
            Dictionary with transformation and metric value
        """
        if not HAS_SITK:
            raise ImportError("SimpleITK required. Install with: pip install SimpleITK")
        
        self._validate_preprocessed()
        
        valid_transforms = ['translation', 'rigid', 'affine', 'bspline']
        if transform_type not in valid_transforms:
            raise ValueError(f"transform_type must be one of {valid_transforms}")
        
        valid_metrics = ['mattes', 'correlation', 'mse']
        if metric not in valid_metrics:
            raise ValueError(f"metric must be one of {valid_metrics}")
        
        fixed = sitk.GetImageFromArray(self.fixed_image.astype(np.float32))
        moving = sitk.GetImageFromArray(self.moving_downsampled.astype(np.float32))
        
        # Initialize transform
        initial_transform = sitk.CenteredTransformInitializer(
            fixed, moving,
            sitk.Euler2DTransform() if transform_type in ['translation', 'rigid']
            else sitk.AffineTransform(2),
            sitk.CenteredTransformInitializerFilter.GEOMETRY
        )
        
        registration = sitk.ImageRegistrationMethod()
        
        if metric == 'mattes':
            registration.SetMetricAsMattesMutualInformation(numberOfHistogramBins=50)
        elif metric == 'correlation':
            registration.SetMetricAsCorrelation()
        else:
            registration.SetMetricAsMeanSquares()
        
        registration.SetMetricSamplingStrategy(registration.RANDOM)
        registration.SetMetricSamplingPercentage(0.5)
        
        if self.use_masking:
            if self.mask_fixed is not None:
                fixed_mask = sitk.GetImageFromArray(self.mask_fixed.astype(np.uint8))
                registration.SetMetricFixedMask(fixed_mask)
            if self.mask_moving_downsampled is not None:
                moving_mask = sitk.GetImageFromArray(self.mask_moving_downsampled.astype(np.uint8))
                registration.SetMetricMovingMask(moving_mask)
        
        registration.SetOptimizerAsGradientDescent(
            learningRate=1.0, numberOfIterations=200,
            convergenceMinimumValue=1e-6, convergenceWindowSize=10
        )
        registration.SetOptimizerScalesFromPhysicalShift()
        
        registration.SetShrinkFactorsPerLevel([4, 2, 1])
        registration.SetSmoothingSigmasPerLevel([2, 1, 0])
        registration.SmoothingSigmasAreSpecifiedInPhysicalUnitsOn()
        
        registration.SetInitialTransform(initial_transform, inPlace=False)
        registration.SetInterpolator(sitk.sitkLinear)
        
        final_transform = registration.Execute(fixed, moving)
        self._sitk_transform = final_transform
        
        # Convert to skimage-compatible matrix
        if transform_type in ['translation', 'rigid', 'affine']:
            params = final_transform.GetParameters()
            if transform_type == 'translation':
                matrix = np.array([[1, 0, params[0]], [0, 1, params[1]], [0, 0, 1]])
            elif transform_type == 'rigid':
                angle = params[0]
                cos_a, sin_a = np.cos(angle), np.sin(angle)
                matrix = np.array([[cos_a, -sin_a, params[1]], [sin_a, cos_a, params[2]], [0, 0, 1]])
            else:
                matrix = np.array([[params[0], params[1], params[4]],
                                  [params[2], params[3], params[5]], [0, 0, 1]])
            self.transform_matrix = AffineTransform(matrix=matrix)
        
        logger.info(f"SimpleITK registration complete")
        logger.info(f"  Final metric: {registration.GetMetricValue():.4f}")
        
        return {'sitk_transform': final_transform, 'metric_value': registration.GetMetricValue()}
    
    def register_boundary_based(
        self,
        threshold_method: str = 'otsu',
        threshold_percentile: float = 10,
        min_tissue_size: int = 100,
        dilate_radius: int = 3,
        n_contour_points: int = 200,
        allow_scale: bool = False,
        boundary_mode: str = 'convex_hull',
        visualize: bool = True
    ) -> Dict[str, Any]:
        """
        Boundary-based registration using tissue contour alignment.
        
        Parameters
        ----------
        threshold_method : str
            Method for tissue detection: 'otsu', 'percentile', or 'adaptive'
        threshold_percentile : float
            Percentile for thresholding
        min_tissue_size : int
            Minimum tissue region size in pixels
        dilate_radius : int
            Radius for morphological dilation
        n_contour_points : int
            Number of points to sample from each contour
        allow_scale : bool
            If True, allow scaling in the transformation
        boundary_mode : str
            'convex_hull', 'alpha_shape', or 'filled'
        visualize : bool
            If True, show visualization
        
        Returns
        -------
        dict
            Dictionary with transformation and contour information
        """
        from skimage.morphology import convex_hull_image, closing, opening
        
        self._validate_preprocessed()
        
        logger.info("=" * 60)
        logger.info("BOUNDARY-BASED REGISTRATION")
        logger.info("=" * 60)
        
        def _percentile_mask(img_norm):
            thresh = np.percentile(img_norm, threshold_percentile)
            return img_norm > thresh

        def detect_tissue_mask(img, name):
            close_rad = dilate_radius * 2
            img_norm = (img - img.min()) / (img.max() - img.min() + 1e-10)

            if threshold_method == 'otsu':
                try:
                    thresh = threshold_otsu(img_norm)
                    mask = img_norm < thresh if name == self.FIXED_IMAGE_NAME else img_norm > thresh
                    coverage = float(np.mean(mask))
                    if coverage < 0.02 or coverage > 0.98:
                        # Otsu picked a degenerate threshold (near-empty or
                        # near-full mask) — this happens on low-contrast /
                        # near-uniform metallomics channels and leaves no
                        # tissue boundary to extract a contour from. Fall
                        # back to percentile thresholding instead.
                        logger.warning(
                            f"  {name}: Otsu threshold gave degenerate coverage "
                            f"({coverage * 100:.1f}%); falling back to percentile "
                            f"threshold ({threshold_percentile})."
                        )
                        mask = _percentile_mask(img_norm)
                except Exception:
                    mask = _percentile_mask(img_norm)
            else:
                mask = _percentile_mask(img_norm)

            mask = remove_small_objects(mask, min_size=min_tissue_size)
            mask = binary_fill_holes(mask)
            
            if close_rad > 0:
                mask = closing(mask, disk(close_rad))
            mask = binary_fill_holes(mask)
            
            if boundary_mode == 'convex_hull':
                try:
                    mask = convex_hull_image(mask)
                except:
                    pass
            
            if dilate_radius > 0:
                mask = binary_dilation(mask, disk(dilate_radius))
                mask = binary_erosion(mask, disk(dilate_radius))
            
            logger.info(f"  {name} mask: {np.sum(mask)} pixels ({100*np.sum(mask)/mask.size:.1f}% coverage)")
            return mask
        
        def extract_contour_points(mask, n_points, name):
            # Pad with a 1px border of False before contour-finding. If the
            # detected mask touches the image edges (e.g. covers ~100% of
            # the frame, as can happen with a degenerate threshold), there
            # is no 0/1 transition *inside* the array and find_contours()
            # returns nothing — this padding guarantees a boundary exists
            # unless the mask is truly empty everywhere.
            padded = np.pad(mask.astype(float), pad_width=1, mode='constant', constant_values=0)
            contours = find_contours(padded, 0.5)
            if len(contours) == 0:
                coverage = 100 * np.mean(mask)
                raise RegistrationError(
                    f"No tissue boundary found in the {name} mask (coverage "
                    f"{coverage:.1f}%). Try a different threshold_method "
                    f"('otsu' vs 'percentile'), adjust threshold_percentile, "
                    f"or provide a manual mask via setup_shared_mask()."
                )
            largest_contour = max(contours, key=len) - 1  # undo the 1px pad offset
            indices = np.linspace(0, len(largest_contour) - 1, n_points).astype(int)
            return largest_contour[indices][:, ::-1]  # Return as (x, y)

        # Detect masks
        mask_fixed = detect_tissue_mask(self.fixed_image, self.FIXED_IMAGE_NAME)
        mask_moving = detect_tissue_mask(self.moving_downsampled, self.MOVING_IMAGE_NAME)

        # Extract contours
        contour_fixed = extract_contour_points(mask_fixed, n_contour_points, self.FIXED_IMAGE_NAME)
        contour_moving = extract_contour_points(mask_moving, n_contour_points, self.MOVING_IMAGE_NAME)
        
        # ICP alignment
        from skimage.transform import SimilarityTransform, EuclideanTransform
        
        tform_class = SimilarityTransform if allow_scale else EuclideanTransform
        tform = tform_class()
        tform.estimate(contour_moving, contour_fixed)
        
        self.transform_matrix = AffineTransform(matrix=tform.params)
        self.mask_fixed = mask_fixed
        self.mask_moving_downsampled = mask_moving
        self.use_masking = True
        
        # Compute alignment error
        transformed = tform(contour_moving)
        distances = np.sqrt(np.sum((contour_fixed - transformed) ** 2, axis=1))
        icp_error = np.mean(distances)
        
        logger.info(f"Boundary registration complete. Mean error: {icp_error:.4f} pixels")
        
        if visualize:
            self._visualize_boundary_registration(
                mask_fixed, mask_moving, contour_fixed, contour_moving, transformed
            )
        
        return {
            'transform_matrix': self.transform_matrix,
            'mask_fixed': mask_fixed,
            'mask_moving': mask_moving,
            'contour_fixed': contour_fixed,
            'contour_moving': contour_moving,
            'icp_error': icp_error
        }
    
    def _visualize_boundary_registration(self, mask_fixed, mask_moving, 
                                         contour_fixed, contour_moving, transformed):
        """Visualize boundary-based registration results."""
        fig, axes = plt.subplots(1, 3, figsize=(18, 6))
        
        axes[0].imshow(mask_fixed, cmap='gray')
        axes[0].plot(contour_fixed[:, 0], contour_fixed[:, 1], 'r-', linewidth=2)
        axes[0].set_title(f'{self.FIXED_IMAGE_NAME} Boundary', fontweight='bold')
        axes[0].axis('off')
        
        axes[1].imshow(mask_moving, cmap='gray')
        axes[1].plot(contour_moving[:, 0], contour_moving[:, 1], 'b-', linewidth=2)
        axes[1].set_title(f'{self.MOVING_IMAGE_NAME} Boundary', fontweight='bold')
        axes[1].axis('off')
        
        axes[2].imshow(mask_fixed, cmap='gray', alpha=0.5)
        axes[2].plot(contour_fixed[:, 0], contour_fixed[:, 1], 'r-', linewidth=2, label=self.FIXED_IMAGE_NAME)
        axes[2].plot(transformed[:, 0], transformed[:, 1], 'g--', linewidth=2, label='Aligned')
        axes[2].legend()
        axes[2].set_title('Alignment Result', fontweight='bold')
        axes[2].axis('off')
        
        plt.tight_layout()
        plt.show()

    
    # =========================================================================
    # Quality Metrics
    # =========================================================================
    
    def _normalized_mutual_information(
        self,
        img1: np.ndarray,
        img2: np.ndarray,
        mask1: Optional[np.ndarray] = None,
        mask2: Optional[np.ndarray] = None,
        bins: int = 64
    ) -> float:
        """Calculate normalized mutual information."""
        if mask1 is not None or mask2 is not None:
            combined_mask = np.ones_like(img1, dtype=bool)
            if mask1 is not None:
                combined_mask &= mask1
            if mask2 is not None:
                combined_mask &= mask2
            if np.sum(combined_mask) < 100:
                return 0.0
            img1_flat = img1[combined_mask]
            img2_flat = img2[combined_mask]
        else:
            img1_flat = img1.ravel()
            img2_flat = img2.ravel()
        
        hist_2d, _, _ = np.histogram2d(img1_flat, img2_flat, bins=bins)
        hist_1 = hist_2d.sum(axis=1)
        hist_2 = hist_2d.sum(axis=0)
        
        pxy = hist_2d / float(np.sum(hist_2d))
        px = hist_1 / float(np.sum(hist_1))
        py = hist_2 / float(np.sum(hist_2))
        
        nzs = pxy > 0
        h_x = -np.sum(px[px > 0] * np.log(px[px > 0]))
        h_y = -np.sum(py[py > 0] * np.log(py[py > 0]))
        h_xy = -np.sum(pxy[nzs] * np.log(pxy[nzs]))
        
        return (h_x + h_y) / h_xy if h_xy > 0 else 0
    
    def _normalized_cross_correlation(
        self,
        img1: np.ndarray,
        img2: np.ndarray,
        mask1: Optional[np.ndarray] = None,
        mask2: Optional[np.ndarray] = None
    ) -> float:
        """Calculate normalized cross-correlation."""
        if mask1 is not None or mask2 is not None:
            combined_mask = np.ones_like(img1, dtype=bool)
            if mask1 is not None:
                combined_mask &= mask1
            if mask2 is not None:
                combined_mask &= mask2
            if np.sum(combined_mask) < 100:
                return 0.0
            img1_vals = img1[combined_mask]
            img2_vals = img2[combined_mask]
        else:
            img1_vals = img1.ravel()
            img2_vals = img2.ravel()
        
        img1_norm = (img1_vals - img1_vals.mean()) / (img1_vals.std() + 1e-10)
        img2_norm = (img2_vals - img2_vals.mean()) / (img2_vals.std() + 1e-10)
        return np.mean(img1_norm * img2_norm)
    
    def _structural_similarity(
        self,
        img1: np.ndarray,
        img2: np.ndarray,
        mask1: Optional[np.ndarray] = None,
        mask2: Optional[np.ndarray] = None,
        win_size: int = 7
    ) -> float:
        """Compute Structural Similarity Index (SSIM)."""
        from skimage.metrics import structural_similarity
        
        img1_norm = (img1 - img1.min()) / (img1.max() - img1.min() + 1e-10)
        img2_norm = (img2 - img2.min()) / (img2.max() - img2.min() + 1e-10)
        
        try:
            return structural_similarity(img1_norm, img2_norm, win_size=win_size, data_range=1.0)
        except ValueError:
            return structural_similarity(img1_norm, img2_norm, 
                                        win_size=min(3, min(img1.shape)), data_range=1.0)
    
    def _compute_error_metrics(
        self,
        img1: np.ndarray,
        img2: np.ndarray,
        mask1: Optional[np.ndarray] = None,
        mask2: Optional[np.ndarray] = None
    ) -> Tuple[float, float, float]:
        """Compute MSE, MAE, and RMSE."""
        if mask1 is not None or mask2 is not None:
            combined_mask = np.ones_like(img1, dtype=bool)
            if mask1 is not None:
                combined_mask &= mask1
            if mask2 is not None:
                combined_mask &= mask2
            if np.sum(combined_mask) > 0:
                diff = img1[combined_mask] - img2[combined_mask]
            else:
                diff = (img1 - img2).ravel()
        else:
            diff = (img1 - img2).ravel()
        
        mse = np.mean(diff ** 2)
        mae = np.mean(np.abs(diff))
        rmse = np.sqrt(mse)
        return mse, mae, rmse
    
    def compute_registration_quality(
        self,
        use_downsampled: bool = True,
        compute_edge_metrics: bool = True
    ) -> RegistrationQualityMetrics:
        """
        Compute comprehensive registration quality metrics.
        
        Parameters
        ----------
        use_downsampled : bool
            If True, compute metrics on downsampled images
        compute_edge_metrics : bool
            If True, compute edge and gradient correlation metrics
        
        Returns
        -------
        RegistrationQualityMetrics
            Dataclass containing all computed metrics
        """
        self._validate_registered()
        
        if use_downsampled:
            fixed = self.fixed_image
            moving = warp(
                self.moving_downsampled,
                self.transform_matrix.inverse,
                output_shape=fixed.shape,
                order=1, mode='constant', cval=0
            )
            mask_fixed = self.mask_fixed
            mask_moving = self.mask_moving_downsampled
            if mask_moving is not None:
                mask_moving = warp(
                    mask_moving.astype(float),
                    self.transform_matrix.inverse,
                    output_shape=fixed.shape,
                    order=0, mode='constant', cval=0
                ) > 0.5
        else:
            self._validate_fullres_applied()
            fixed = transform.resize(self.fixed_image, self.moving_shape, order=3, preserve_range=True)
            moving = self.registered_moving
            mask_fixed = None
            mask_moving = None
        
        # Core metrics
        nmi = self._normalized_mutual_information(fixed, moving, mask_fixed, mask_moving)
        ncc = self._normalized_cross_correlation(fixed, moving, mask_fixed, mask_moving)
        mse, mae, rmse = self._compute_error_metrics(fixed, moving, mask_fixed, mask_moving)
        ssim = self._structural_similarity(fixed, moving, mask_fixed, mask_moving)
        
        # PSNR
        psnr = 10 * np.log10(1.0 / mse) if mse > 0 else float('inf')
        
        # Edge metrics
        edge_corr = None
        grad_corr = None
        if compute_edge_metrics:
            from skimage.feature import canny
            
            fixed_norm = (fixed - fixed.min()) / (fixed.max() - fixed.min() + 1e-10)
            moving_norm = (moving - moving.min()) / (moving.max() - moving.min() + 1e-10)
            
            edges1 = canny(fixed_norm, sigma=1.0).astype(float)
            edges2 = canny(moving_norm, sigma=1.0).astype(float)
            
            if edges1.std() > 1e-10 and edges2.std() > 1e-10:
                edge_corr = np.corrcoef(edges1.ravel(), edges2.ravel())[0, 1]
            
            gy1, gx1 = np.gradient(fixed)
            gy2, gx2 = np.gradient(moving)
            grad_mag1 = np.sqrt(gx1**2 + gy1**2)
            grad_mag2 = np.sqrt(gx2**2 + gy2**2)
            
            if grad_mag1.std() > 1e-10 and grad_mag2.std() > 1e-10:
                grad_corr = np.corrcoef(grad_mag1.ravel(), grad_mag2.ravel())[0, 1]
        
        # Mask metrics
        mask_iou = None
        mask_dice = None
        if mask_fixed is not None and mask_moving is not None:
            intersection = np.sum(mask_fixed & mask_moving)
            union = np.sum(mask_fixed | mask_moving)
            sum_masks = np.sum(mask_fixed) + np.sum(mask_moving)
            if union > 0:
                mask_iou = intersection / union
            if sum_masks > 0:
                mask_dice = 2 * intersection / sum_masks
        
        metrics = RegistrationQualityMetrics(
            nmi=nmi, ncc=ncc, mse=mse, ssim=ssim,
            psnr=psnr, mae=mae, rmse=rmse,
            edge_correlation=edge_corr,
            gradient_correlation=grad_corr,
            mask_iou=mask_iou,
            mask_dice=mask_dice
        )
        
        logger.info(str(metrics))
        return metrics
    
    def compare_before_after(self) -> Dict[str, Dict[str, float]]:
        """Compare registration quality before and after alignment."""
        self._validate_preprocessed()
        self._validate_registered()

        fixed = self.fixed_image
        moving_before = self.moving_downsampled

        # Ensure moving_before has the same shape as fixed.
        # For subclasses (e.g. metallomics-metallomics) where moving_downsampled
        # is NOT resized to fixed.shape, we place the original moving image into
        # a canvas of fixed.shape using the identity transform. This represents
        # the "no registration applied" state and keeps array lengths consistent
        # for metric computation.
        if moving_before.shape != fixed.shape:
            moving_before = warp(
                moving_before,
                AffineTransform().inverse,
                output_shape=fixed.shape,
                order=1, mode='constant', cval=0,
                preserve_range=True,
            )

        moving_after = warp(
            self.moving_downsampled,
            self.transform_matrix.inverse,
            output_shape=fixed.shape,
            order=1, mode='constant', cval=0
        )

        mask_fixed = self.mask_fixed
        mask_moving = self.mask_moving_downsampled

        # Align mask_moving to fixed.shape the same way (identity warp) when needed.
        mask_moving_before = mask_moving
        if mask_moving is not None and mask_moving.shape != fixed.shape:
            mask_moving_before = warp(
                mask_moving.astype(float),
                AffineTransform().inverse,
                output_shape=fixed.shape,
                order=0, mode='constant', cval=0,
            ) > 0.5

        # Before metrics
        nmi_before = self._normalized_mutual_information(fixed, moving_before, mask_fixed, mask_moving_before)
        ncc_before = self._normalized_cross_correlation(fixed, moving_before, mask_fixed, mask_moving_before)
        ssim_before = self._structural_similarity(fixed, moving_before, mask_fixed, mask_moving_before)
        mse_before, _, _ = self._compute_error_metrics(fixed, moving_before, mask_fixed, mask_moving_before)

        # After metrics
        mask_moving_warped = None
        if mask_moving is not None:
            mask_moving_warped = warp(mask_moving.astype(float), self.transform_matrix.inverse,
                                     output_shape=fixed.shape, order=0) > 0.5

        nmi_after = self._normalized_mutual_information(fixed, moving_after, mask_fixed, mask_moving_warped)
        ncc_after = self._normalized_cross_correlation(fixed, moving_after, mask_fixed, mask_moving_warped)
        ssim_after = self._structural_similarity(fixed, moving_after, mask_fixed, mask_moving_warped)
        mse_after, _, _ = self._compute_error_metrics(fixed, moving_after, mask_fixed, mask_moving_warped)
        
        results = {
            'before': {'nmi': nmi_before, 'ncc': ncc_before, 'ssim': ssim_before, 'mse': mse_before},
            'after': {'nmi': nmi_after, 'ncc': ncc_after, 'ssim': ssim_after, 'mse': mse_after},
            'improvement': {
                'nmi': nmi_after - nmi_before,
                'ncc': ncc_after - ncc_before,
                'ssim': ssim_after - ssim_before,
                'mse': mse_before - mse_after
            }
        }
        
        logger.info("=" * 60)
        logger.info("BEFORE vs AFTER REGISTRATION COMPARISON")
        logger.info("=" * 60)
        logger.info(f"{'Metric':<10} {'Before':>12} {'After':>12} {'Change':>12}")
        logger.info("-" * 50)
        logger.info(f"{'NMI':<10} {nmi_before:>12.4f} {nmi_after:>12.4f} {nmi_after-nmi_before:>+12.4f}")
        logger.info(f"{'NCC':<10} {ncc_before:>12.4f} {ncc_after:>12.4f} {ncc_after-ncc_before:>+12.4f}")
        logger.info(f"{'SSIM':<10} {ssim_before:>12.4f} {ssim_after:>12.4f} {ssim_after-ssim_before:>+12.4f}")
        logger.info(f"{'MSE':<10} {mse_before:>12.6f} {mse_after:>12.6f} {mse_before-mse_after:>+12.6f}")
        logger.info("=" * 60)
        
        return results
    
    # =========================================================================
    # Transform Application
    # =========================================================================
    
    def get_full_transform_matrix(self) -> Optional[np.ndarray]:
        """
        Get a READY-TO-USE transformation matrix that maps original moving pixel
        coordinates directly to fixed pixel coordinates.
        
        Returns
        -------
        np.ndarray or None
            3x3 transformation matrix
        """
        if self.transform_matrix is None:
            return None
        
        finetuning = self.transform_matrix.params.copy()
        
        # Downscale matrix
        inv_scale = 1.0 / self.scale_factor
        S_inv = AffineTransform(scale=inv_scale[::-1])
        
        if self.pre_rotation == 0:
            return finetuning @ S_inv.params
        
        # Build pre-rotation matrix
        orig_h, orig_w = self.moving_shape_before_rotation
        k = self.pre_rotation // 90
        
        if k == 1:
            pre_rot = np.array([[0.0, 1.0, 0.0], [-1.0, 0.0, orig_w - 1.0], [0.0, 0.0, 1.0]])
        elif k == 2:
            pre_rot = np.array([[-1.0, 0.0, orig_w - 1.0], [0.0, -1.0, orig_h - 1.0], [0.0, 0.0, 1.0]])
        elif k == 3:
            pre_rot = np.array([[0.0, -1.0, orig_h - 1.0], [1.0, 0.0, 0.0], [0.0, 0.0, 1.0]])
        else:
            pre_rot = np.eye(3)
        
        return finetuning @ S_inv.params @ pre_rot
    
    def apply_transform_to_fullres(
        self,
        output_shape: Optional[Tuple[int, int]] = None,
        use_sitk: bool = False
    ) -> np.ndarray:
        """
        Apply the computed transformation to full-resolution moving image.
        
        Parameters
        ----------
        output_shape : tuple, optional
            Output shape (default: same as moving original)
        use_sitk : bool
            Use SimpleITK transform if available
        
        Returns
        -------
        np.ndarray
            Registered full-resolution moving image
        """
        self._validate_registered()
        
        if output_shape is None:
            output_shape = self.moving_shape
        
        # Use skimage warp
        reg_transform_lowres = self.transform_matrix.params.copy()
        scale_transform = AffineTransform(scale=self.scale_factor[::-1])
        
        scaled_matrix = (
            scale_transform.params @
            reg_transform_lowres @
            np.linalg.inv(scale_transform.params)
        )
        full_res_transform = AffineTransform(matrix=scaled_matrix)
        
        self.registered_moving = warp(
            self.moving_image,
            full_res_transform.inverse,
            output_shape=output_shape,
            order=3,
            mode='constant',
            cval=0,
            preserve_range=True
        )
        
        logger.info(f"Full-resolution registration complete: {self.registered_moving.shape}")
        return self.registered_moving

    
    # =========================================================================
    # Visualization Methods
    # =========================================================================
    
    def preview_images(
        self,
        figsize: Tuple[int, int] = (14, 6),
        save_path: Optional[str] = None
    ) -> None:
        """Preview both images side-by-side BEFORE registration."""
        fig, axes = plt.subplots(1, 2, figsize=figsize)
        
        # Fixed image
        if self.fixed_rgb is not None:
            axes[0].imshow(self.fixed_rgb)
        else:
            fixed_norm = (self.fixed_image - self.fixed_image.min()) / \
                        (self.fixed_image.max() - self.fixed_image.min() + 1e-10)
            axes[0].imshow(fixed_norm, cmap='viridis')
        axes[0].set_title(f'{self.FIXED_IMAGE_NAME}\n{self.fixed_shape}', fontweight='bold')
        axes[0].axis('off')
        
        # Moving image (downsampled)
        if self.moving_downsampled is not None:
            moving_img = self.moving_downsampled
        else:
            moving_img = transform.resize(self.moving_image, self.fixed_shape,
                                         order=1, anti_aliasing=True, preserve_range=True)
        
        moving_norm = (moving_img - moving_img.min()) / (moving_img.max() - moving_img.min() + 1e-10)
        axes[1].imshow(moving_norm, cmap='gray')
        
        rotation_info = f"Pre-rotation: {self.pre_rotation}" if self.pre_rotation != 0 else "No pre-rotation"
        axes[1].set_title(f'{self.MOVING_IMAGE_NAME} (downsampled)\n{moving_img.shape}\n{rotation_info}',
                         fontweight='bold')
        axes[1].axis('off')
        
        fig.suptitle('Image Preview - Verify alignment before registration', fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
    
    def preview_registration(
        self,
        use_downsampled: bool = True,
        alpha: float = 0.5,
        figsize: Tuple[int, int] = (18, 6),
        save_path: Optional[str] = None
    ) -> None:
        """Preview the registration result with before/after comparison."""
        self._validate_registered()
        
        fig, axes = plt.subplots(1, 3, figsize=figsize)
        
        if use_downsampled:
            fixed = self.fixed_image
            moving_before = self.moving_downsampled
            moving_after = warp(
                self.moving_downsampled,
                self.transform_matrix.inverse,
                output_shape=fixed.shape,
                order=1, mode='constant', cval=0
            )
        else:
            self._validate_fullres_applied()
            fixed = transform.resize(self.fixed_image, self.moving_shape, order=3, preserve_range=True)
            moving_before = self.moving_image
            moving_after = self.registered_moving
        
        # Normalize (percentile-stretched — see percentile_normalize())
        fixed_norm = percentile_normalize(fixed)
        moving_before_norm = percentile_normalize(moving_before)
        moving_after_norm = percentile_normalize(moving_after)
        
        # Before overlay
        overlay_before = np.zeros((*fixed.shape, 3))
        overlay_before[..., 0] = fixed_norm
        overlay_before[..., 1] = moving_before_norm
        axes[0].imshow(overlay_before)
        axes[0].set_title('BEFORE Registration\n(Red=Fixed, Green=Moving)', fontweight='bold')
        axes[0].axis('off')
        
        # After overlay
        overlay_after = np.zeros((*fixed.shape, 3))
        overlay_after[..., 0] = fixed_norm
        overlay_after[..., 1] = moving_after_norm
        axes[1].imshow(overlay_after)
        axes[1].set_title('AFTER Registration\n(Red=Fixed, Green=Moving)', fontweight='bold')
        axes[1].axis('off')
        
        # Blended
        blended = alpha * fixed_norm + (1 - alpha) * moving_after_norm
        axes[2].imshow(blended, cmap='gray')
        axes[2].set_title(f'Blended (alpha={alpha})', fontweight='bold')
        axes[2].axis('off')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()
    
    def create_overlay(
        self,
        alpha: float = 0.5,
        use_downsampled: bool = True,
        fixed_color: Tuple[float, float, float] = (1.0, 0.0, 1.0),
        moving_color: Tuple[float, float, float] = (0.0, 1.0, 0.0)
    ) -> np.ndarray:
        """
        Create RGB overlay for visual inspection.
        
        Parameters
        ----------
        alpha : float
            Blending factor
        use_downsampled : bool
            Use downsampled images
        fixed_color : tuple
            RGB color for fixed image
        moving_color : tuple
            RGB color for moving image
        
        Returns
        -------
        np.ndarray
            RGB overlay image
        """
        self._validate_registered()
        
        if use_downsampled:
            fixed = self.fixed_image
            moving = warp(
                self.moving_downsampled,
                self.transform_matrix.inverse,
                output_shape=fixed.shape,
                order=1, mode='constant', cval=0
            )
        else:
            self._validate_fullres_applied()
            fixed = transform.resize(self.fixed_image, self.moving_shape, order=3, preserve_range=True)
            moving = self.registered_moving

        # Normalize — percentile-stretched so a handful of bright outlier
        # pixels (common in metallomics/IF data) don't crush the rest of
        # the signal down near black. See percentile_normalize().
        fixed_norm = percentile_normalize(fixed)
        moving_norm = percentile_normalize(moving)

        # Create overlay
        if self.fixed_rgb is not None and use_downsampled:
            # Use RGB fixed as base
            overlay = self.fixed_rgb.copy()
            if overlay.max() > 1:
                overlay = overlay / 255.0
            # Add moving as colored overlay
            for i, c in enumerate(moving_color):
                overlay[..., i] = (1 - alpha) * overlay[..., i] + alpha * moving_norm * c
            overlay = np.clip(overlay, 0, 1)
        else:
            # Standard magenta/green overlay
            overlay = np.zeros((*fixed.shape, 3))
            for i, c in enumerate(fixed_color):
                overlay[..., i] += fixed_norm * c
            for i, c in enumerate(moving_color):
                overlay[..., i] += moving_norm * c
            overlay = np.clip(overlay / overlay.max(), 0, 1)
        
        return overlay
    
    # =========================================================================
    # Landmark Methods
    # =========================================================================
    
    def select_landmarks_interactive(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Interactive landmark selection tool with pause/resume for zooming.

        Click alternately on fixed and moving images to select corresponding
        points. Landmark collection is automatically paused when the matplotlib
        toolbar is in zoom/pan mode, so you can frame a zoom rectangle or drag
        without accidentally placing a point. Resume by deactivating the
        toolbar tool, or toggle a manual pause at any time with Space / 'p'.

        Keyboard shortcuts
        ------------------
        q           : finish and close
        z           : undo last landmark
        space / p   : toggle manual pause (useful on touchpads)
        r           : reset both views to full extent
        h           : show / hide on-screen help

        Returns
        -------
        tuple
            (landmarks_fixed, landmarks_moving) as Nx2 arrays
        """
        import matplotlib as _mpl

        # ------------------------------------------------------------------
        # Ensure an interactive backend. Spyder / Jupyter often default to
        # 'inline' or 'agg', where plt.show(block=True) returns immediately
        # and mouse/key events never fire — so the selection window appears
        # to open and close instantly with 0 landmarks.
        # ------------------------------------------------------------------
        original_backend = _mpl.get_backend()
        non_interactive_markers = ('agg', 'inline', 'pdf', 'ps', 'svg',
                                   'template', 'nbagg', 'ipympl')
        is_non_interactive = any(m in original_backend.lower()
                                 for m in non_interactive_markers)
        # nbagg / ipympl are nominally interactive but don't block on show()
        # in the way this tool requires, so we treat them as non-interactive here.

        switched_backend = False
        if is_non_interactive:
            candidates = ['QtAgg', 'Qt5Agg', 'TkAgg', 'MacOSX', 'WXAgg', 'GTK3Agg']
            for backend in candidates:
                try:
                    plt.switch_backend(backend)
                    switched_backend = True
                    logger.info(
                        f"Switched matplotlib backend: '{original_backend}' → "
                        f"'{backend}' for interactive landmark selection."
                    )
                    break
                except Exception:
                    continue
            if not switched_backend:
                raise RuntimeError(
                    "Interactive matplotlib backend required for landmark "
                    f"selection, but the current backend is '{original_backend}' "
                    "and no interactive backend (Qt/Tk/MacOSX) could be loaded.\n"
                    "  • In Spyder: run '%matplotlib qt' in the console "
                    "before calling this function.\n"
                    "  • In Jupyter: run '%matplotlib qt' or '%matplotlib tk'.\n"
                    "  • Or install PyQt5 / PySide6 in this environment."
                )

        try:
            return self._select_landmarks_interactive_impl()
        finally:
            if switched_backend:
                try:
                    plt.switch_backend(original_backend)
                    logger.info(f"Restored matplotlib backend to '{original_backend}'.")
                except Exception as exc:
                    logger.warning(
                        f"Could not restore backend '{original_backend}': {exc}"
                    )

    def _select_landmarks_interactive_impl(self) -> Tuple[np.ndarray, np.ndarray]:
        """Core implementation of interactive landmark selection (see
        :meth:`select_landmarks_interactive`)."""
        fixed_img = self.fixed_image
        moving_img = self.moving_downsampled if self.moving_downsampled is not None else \
                    transform.resize(self.moving_image, self.fixed_shape, order=1,
                                    anti_aliasing=True, preserve_range=True)

        fixed_norm = (fixed_img - fixed_img.min()) / (fixed_img.max() - fixed_img.min() + 1e-10)
        moving_norm = (moving_img - moving_img.min()) / (moving_img.max() - moving_img.min() + 1e-10)

        landmarks_fixed = []
        landmarks_moving = []
        # Explicit artist handles so we only add/remove the landmark delta
        # instead of wiping every line/text in the axes. Keeping the image
        # artist untouched avoids the slowdown we saw on large tissue images.
        landmark_artists_fixed = []   # list of (line, text) tuples
        landmark_artists_moving = []
        state = {
            'current_image': 'fixed',
            'manual_pause': False,
            'help_visible': False,
        }

        fig, axes = plt.subplots(1, 2, figsize=(16, 8))

        if self.fixed_rgb is not None:
            axes[0].imshow(self.fixed_rgb)
        else:
            axes[0].imshow(fixed_norm, cmap='viridis')
        axes[0].axis('off')

        axes[1].imshow(moving_norm, cmap='gray')
        axes[1].axis('off')

        # Remember the initial (full-extent) view limits for reset
        initial_xlims = [ax.get_xlim() for ax in axes]
        initial_ylims = [ax.get_ylim() for ax in axes]

        # Help text — toggled with 'h'
        help_text = (
            "click: add  z: undo  space/p: pause\n"
            "r: reset  h: help  q: finish\n"
            "toolbar zoom/pan auto-pauses"
        )
        help_artist = fig.text(
            0.01, 0.99, help_text,
            ha='left', va='top', fontsize=7, family='monospace',
            bbox=dict(boxstyle='round,pad=0.3', facecolor='#ffffee',
                      edgecolor='#888888', alpha=0.9),
            visible=False,
        )

        # ------------------------------------------------------------------
        # Helpers
        # ------------------------------------------------------------------
        def _toolbar_active() -> bool:
            """True if matplotlib's zoom/pan toolbar tool is currently engaged."""
            tb = getattr(fig.canvas, 'toolbar', None)
            if tb is None:
                return False
            mode = getattr(tb, 'mode', '') or ''
            # NavigationToolbar2.mode is '' when idle, 'zoom rect' or 'pan/zoom'
            # when a tool is active. Both ToolManager-based and classic toolbars
            # expose this attribute.
            return bool(mode)

        def _is_paused() -> bool:
            return state['manual_pause'] or _toolbar_active()

        def _status_line() -> str:
            n = min(len(landmarks_fixed), len(landmarks_moving))
            if state['manual_pause']:
                return "PAUSED (manual)", 'red', n
            if _toolbar_active():
                return "PAUSED (zoom/pan)", 'darkorange', n
            next_img = 'Fixed' if state['current_image'] == 'fixed' else 'Moving'
            return f"next: {next_img}", 'blue', n

        colors = plt.cm.tab10.colors

        def _add_landmark_artist(ax, artist_list, idx, pt):
            c = colors[idx % 10]
            line, = ax.plot(pt[0], pt[1], 'o', color=c, markersize=7,
                            markeredgecolor='white', markeredgewidth=1.5)
            txt = ax.text(pt[0] + 5, pt[1] - 5, str(idx + 1),
                          color=c, fontsize=7, fontweight='bold')
            artist_list.append((line, txt))

        def _remove_last_artist(artist_list):
            if not artist_list:
                return
            line, txt = artist_list.pop()
            try:
                line.remove()
            except Exception:
                pass
            try:
                txt.remove()
            except Exception:
                pass

        def _sync_artists():
            """Add/remove only the delta between artists and landmark lists."""
            while len(landmark_artists_fixed) > len(landmarks_fixed):
                _remove_last_artist(landmark_artists_fixed)
            for i in range(len(landmark_artists_fixed), len(landmarks_fixed)):
                _add_landmark_artist(axes[0], landmark_artists_fixed, i,
                                     landmarks_fixed[i])
            while len(landmark_artists_moving) > len(landmarks_moving):
                _remove_last_artist(landmark_artists_moving)
            for i in range(len(landmark_artists_moving), len(landmarks_moving)):
                _add_landmark_artist(axes[1], landmark_artists_moving, i,
                                     landmarks_moving[i])

        def _update_titles():
            if state['current_image'] == 'fixed':
                axes[0].set_title('Fixed (next)', fontsize=9, fontweight='bold',
                                  color='blue')
                axes[1].set_title('Moving', fontsize=9, fontweight='bold',
                                  color='black')
            else:
                axes[0].set_title('Fixed', fontsize=9, fontweight='bold',
                                  color='black')
                axes[1].set_title('Moving (next)', fontsize=9, fontweight='bold',
                                  color='blue')

            status, color, n = _status_line()
            fig.suptitle(f'{n} pairs  |  {status}  |  h: help',
                         fontsize=9, fontweight='bold', color=color)
            help_artist.set_visible(state['help_visible'])

        def update_display():
            """Incremental redraw — touches only the changed landmarks and
            the titles, then requests a single draw_idle."""
            _sync_artists()
            _update_titles()
            fig.canvas.draw_idle()

        # ------------------------------------------------------------------
        # Event handlers
        # ------------------------------------------------------------------
        def on_click(event):
            # Ignore clicks outside image axes or while paused for any reason
            if event.inaxes not in axes:
                return
            if _is_paused():
                return
            # Only react to primary mouse button
            if getattr(event, 'button', 1) != 1:
                return

            if event.inaxes == axes[0] and state['current_image'] == 'fixed':
                landmarks_fixed.append((event.xdata, event.ydata))
                state['current_image'] = 'moving'
                update_display()
            elif event.inaxes == axes[1] and state['current_image'] == 'moving':
                landmarks_moving.append((event.xdata, event.ydata))
                state['current_image'] = 'fixed'
                update_display()

        def on_key(event):
            key = (event.key or '').lower()

            if key == 'q':
                plt.close(fig)
                return

            if key == 'z':
                # Undo: remove the most recently added point
                if state['current_image'] == 'moving' and landmarks_fixed:
                    landmarks_fixed.pop()
                    state['current_image'] = 'fixed'
                elif landmarks_moving:
                    landmarks_moving.pop()
                    if len(landmarks_fixed) > len(landmarks_moving):
                        landmarks_fixed.pop()
                    state['current_image'] = 'fixed'
                update_display()
                return

            if key in (' ', 'space', 'p'):
                state['manual_pause'] = not state['manual_pause']
                update_display()
                return

            if key == 'r':
                for ax, xl, yl in zip(axes, initial_xlims, initial_ylims):
                    ax.set_xlim(xl)
                    ax.set_ylim(yl)
                fig.canvas.draw_idle()
                return

            if key == 'h':
                state['help_visible'] = not state['help_visible']
                update_display()
                return

        # Track toolbar mode so we can refresh the pause indicator only when
        # it actually flips — avoids the draw_event → update_display →
        # draw_idle feedback loop that made the window unresponsive.
        last_mode = {'v': None}

        def on_motion(_event):
            tb = getattr(fig.canvas, 'toolbar', None)
            current = (getattr(tb, 'mode', '') or '') if tb is not None else ''
            if current != last_mode['v']:
                last_mode['v'] = current
                _update_titles()
                fig.canvas.draw_idle()

        fig.canvas.mpl_connect('button_press_event', on_click)
        fig.canvas.mpl_connect('key_press_event', on_key)
        fig.canvas.mpl_connect('motion_notify_event', on_motion)

        update_display()

        plt.tight_layout()
        plt.show(block=True)

        n_pairs = min(len(landmarks_fixed), len(landmarks_moving))
        landmarks_fixed = landmarks_fixed[:n_pairs]
        landmarks_moving = landmarks_moving[:n_pairs]

        self._landmarks_fixed = np.array(landmarks_fixed) if n_pairs > 0 else np.array([]).reshape(0, 2)
        self._landmarks_moving = np.array(landmarks_moving) if n_pairs > 0 else np.array([]).reshape(0, 2)

        logger.info(f"Selected {n_pairs} landmark pairs")
        return self._landmarks_fixed, self._landmarks_moving
    
    def register_landmarks(
        self,
        landmarks_fixed: Optional[np.ndarray] = None,
        landmarks_moving: Optional[np.ndarray] = None,
        transform_type: str = 'affine'
    ) -> Dict[str, Any]:
        """
        Register using landmark correspondences.
        
        Parameters
        ----------
        landmarks_fixed : np.ndarray, optional
            Nx2 array on fixed image
        landmarks_moving : np.ndarray, optional
            Nx2 array on moving image
        transform_type : str
            'affine', 'similarity', 'euclidean', or 'projective'
        
        Returns
        -------
        dict
            Dictionary with transform and error metrics
        """
        from skimage.transform import SimilarityTransform, EuclideanTransform, ProjectiveTransform
        
        if landmarks_fixed is None:
            landmarks_fixed = getattr(self, '_landmarks_fixed', None)
        if landmarks_moving is None:
            landmarks_moving = getattr(self, '_landmarks_moving', None)
        
        if landmarks_fixed is None or landmarks_moving is None:
            raise ValueError("No landmarks. Run select_landmarks_interactive() first.")
        
        n_points = len(landmarks_fixed)
        min_points = {'euclidean': 2, 'similarity': 2, 'affine': 3, 'projective': 4}
        
        if transform_type not in min_points:
            raise ValueError(f"Unknown transform_type: {transform_type}")
        if n_points < min_points[transform_type]:
            raise ValueError(f"'{transform_type}' needs {min_points[transform_type]}+ points")
        
        logger.info(f"Computing {transform_type} transform from {n_points} landmarks...")
        
        tform_classes = {
            'euclidean': EuclideanTransform,
            'similarity': SimilarityTransform,
            'affine': AffineTransform,
            'projective': ProjectiveTransform
        }
        
        tform = tform_classes[transform_type]()
        tform.estimate(landmarks_moving, landmarks_fixed)
        self.transform_matrix = tform
        
        transformed = tform(landmarks_moving)
        residuals = np.sqrt(np.sum((landmarks_fixed - transformed) ** 2, axis=1))
        mean_error = np.mean(residuals)
        max_error = np.max(residuals)
        
        logger.info(f"  Mean error: {mean_error:.4f} px, Max error: {max_error:.4f} px")
        
        return {
            'transform': tform,
            'residuals': residuals,
            'mean_error': mean_error,
            'max_error': max_error,
            'n_landmarks': n_points,
            'transform_type': transform_type
        }
    
    # =========================================================================
    # Save Methods
    # =========================================================================
    
    def save_results(
        self,
        output_dir: str,
        prefix: str = 'registration',
        save_overlay: bool = True,
        save_registered: bool = True,
        save_transform: bool = True
    ) -> Dict[str, str]:
        """
        Save registration results to files.
        
        Parameters
        ----------
        output_dir : str
            Output directory
        prefix : str
            Filename prefix
        save_overlay : bool
            Save overlay visualization
        save_registered : bool
            Save registered moving image
        save_transform : bool
            Save transformation matrix
        
        Returns
        -------
        dict
            Dictionary of saved file paths
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        saved_files = {}
        
        if save_transform and self.transform_matrix is not None:
            transform_path = output_dir / f"{prefix}_transform.npy"
            np.save(transform_path, self.transform_matrix.params)
            saved_files['transform'] = str(transform_path)
            
            full_matrix = self.get_full_transform_matrix()
            if full_matrix is not None:
                full_transform_path = output_dir / f"{prefix}_full_transform.npy"
                np.save(full_transform_path, full_matrix)
                saved_files['full_transform'] = str(full_transform_path)
        
        if save_registered and self.registered_moving is not None:
            registered_path = output_dir / f"{prefix}_registered.tif"
            tifffile.imwrite(str(registered_path), self.registered_moving.astype(np.float32))
            saved_files['registered'] = str(registered_path)
        
        if save_overlay and self.transform_matrix is not None:
            overlay = self.create_overlay()
            overlay_path = output_dir / f"{prefix}_overlay.png"
            plt.imsave(str(overlay_path), overlay)
            saved_files['overlay'] = str(overlay_path)
        
        logger.info(f"Results saved to: {output_dir}")
        for key, path in saved_files.items():
            logger.info(f"  {key}: {path}")
        
        return saved_files
