#!/usr/bin/env python3
"""
SpatialData bridge
===================

Wraps the outputs of a completed registration (fixed image, registered
moving image, and — where available — the registration transform) into a
single ``spatialdata.SpatialData`` object with a shared coordinate system,
and provides the bounding-box / polygon query helpers used by
``region_selector_gui.select_region_and_query()``. Mirrors the pattern in:
https://spatialdata.scverse.org/en/latest/tutorials/notebooks/notebooks/examples/spatial_query.html

The "aligned" coordinate system (the default `target_coordinate_system`
used throughout this module) is the space the *moving* image has been
registered into, i.e. the fixed image's own pixel grid. The fixed image
gets an Identity transform into "aligned"; the moving image gets the
registration's Affine transform (or Identity, if no transform is known —
e.g. it was already resampled onto the fixed grid before being handed to
this function).
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import Any

import numpy as np
from spatialdata import SpatialData, bounding_box_query, polygon_query
from spatialdata.models import Image2DModel
from spatialdata.transformations import Affine, Identity


def _as_cyx(image: np.ndarray, channel_names: Sequence[str] | None = None) -> tuple[np.ndarray, list[str]]:
    """
    Coerce a 2D (Y, X) or 3D array into (C, Y, X) as spatialdata's
    Image2DModel expects, using the same channel-first/channel-last
    heuristic as ``register.registration_core``/``loaders.py`` (whichever
    of the first/last axis is smaller is assumed to be the channel axis).
    Returns the (C, Y, X) array and a list of channel-name strings.
    """
    arr = np.asarray(image)
    if arr.ndim == 2:
        arr = arr[np.newaxis, ...]
    elif arr.ndim == 3:
        if arr.shape[0] > arr.shape[-1]:
            # channel-last (Y, X, C) -> (C, Y, X)
            arr = np.moveaxis(arr, -1, 0)
    else:
        raise ValueError(f"Expected a 2D or 3D image array, got shape {arr.shape}")

    n_channels = arr.shape[0]
    if channel_names is not None:
        if len(channel_names) != n_channels:
            raise ValueError(
                f"channel_names has {len(channel_names)} entries but image has {n_channels} channels"
            )
        names = list(channel_names)
    else:
        names = [f"c{i}" for i in range(n_channels)]
    return arr, names


def _affine_from_matrix(matrix: np.ndarray) -> Affine:
    """
    Build a spatialdata Affine transformation (y, x) -> (y, x) from a 2x3 or
    3x3 registration matrix in (x, y) image convention (the convention used
    throughout register/registration_core.py, e.g. cv2/skimage-style
    [[a, b, tx], [c, d, ty]] operating on (x, y) points).

    spatialdata's Affine expects the matrix in homogeneous form mapping
    input_axes -> output_axes; we give it input_axes=output_axes=("x", "y")
    so it lines up directly with the (x, y) convention already used by the
    registration matrices, and let spatialdata handle the ("x", "y") <->
    ("y", "x") bookkeeping internally.
    """
    mat = np.asarray(matrix, dtype=np.float64)
    if mat.shape == (2, 3):
        full = np.vstack([mat, [0.0, 0.0, 1.0]])
    elif mat.shape == (3, 3):
        full = mat
    else:
        raise ValueError(f"Expected a 2x3 or 3x3 affine matrix, got shape {mat.shape}")
    return Affine(full, input_axes=("x", "y"), output_axes=("x", "y"))


def build_spatialdata_from_registration(
    fixed_image: np.ndarray,
    moving_image: np.ndarray,
    transform_matrix: np.ndarray | None = None,
    fixed_name: str = "fixed",
    moving_name: str = "moving",
    fixed_channel_names: Sequence[str] | None = None,
    moving_channel_names: Sequence[str] | None = None,
    coordinate_system: str = "aligned",
    extra_images: dict[str, np.ndarray] | None = None,
) -> SpatialData:
    """
    Package a fixed/moving registration result into a SpatialData object
    with both images living in the same `coordinate_system`.

    Parameters
    ----------
    fixed_image, moving_image : np.ndarray
        (Y, X), (Y, X, C) or (C, Y, X) arrays. `moving_image` should
        already be whatever registration produced — either the resampled
        (already-warped-onto-the-fixed-grid) image (pass
        transform_matrix=None), or the original moving image alongside its
        recovered `transform_matrix` (in which case spatialdata applies the
        transform on read/query rather than the pixels being resampled).
    transform_matrix : np.ndarray, optional
        2x3 or 3x3 affine matrix (in (x, y) convention, matching
        register/registration_core.py's convention) mapping moving -> fixed.
        If None, both images get an Identity transform (appropriate when
        `moving_image` has already been resampled onto the fixed grid).
    fixed_name, moving_name : str
        Element names in the returned SpatialData.
    fixed_channel_names, moving_channel_names : sequence of str, optional
        Per-channel names (e.g. metal isotope labels); auto-generated if
        omitted.
    coordinate_system : str
        Shared coordinate system both images are registered into.
    extra_images : dict[str, np.ndarray], optional
        Any additional already-aligned images to include (e.g. a second
        modality pre-registered onto the same grid) — each gets an
        Identity transform into `coordinate_system`.

    Returns
    -------
    SpatialData
    """
    fixed_cyx, fixed_names = _as_cyx(fixed_image, fixed_channel_names)
    moving_cyx, moving_names = _as_cyx(moving_image, moving_channel_names)

    fixed_element = Image2DModel.parse(
        fixed_cyx, dims=("c", "y", "x"), c_coords=fixed_names,
        transformations={coordinate_system: Identity()},
    )

    moving_transform = _affine_from_matrix(transform_matrix) if transform_matrix is not None else Identity()
    moving_element = Image2DModel.parse(
        moving_cyx, dims=("c", "y", "x"), c_coords=moving_names,
        transformations={coordinate_system: moving_transform},
    )

    images: dict[str, Any] = {fixed_name: fixed_element, moving_name: moving_element}

    if extra_images:
        for name, img in extra_images.items():
            cyx, names = _as_cyx(img)
            images[name] = Image2DModel.parse(
                cyx, dims=("c", "y", "x"), c_coords=names,
                transformations={coordinate_system: Identity()},
            )

    return SpatialData(images=images)


def query_bounding_box(
    sdata: SpatialData,
    min_coordinate: Sequence[float],
    max_coordinate: Sequence[float],
    axes: tuple[str, ...] = ("y", "x"),
    target_coordinate_system: str = "aligned",
    filter_table: bool = True,
) -> SpatialData:
    """
    Crop every element of `sdata` that lives in `target_coordinate_system`
    to an axis-aligned box, via spatialdata.bounding_box_query. Mirrors the
    bounding-box section of the spatialdata spatial_query tutorial.

    `min_coordinate`/`max_coordinate` are given in the same (row, col) i.e.
    (y, x) order as `axes` defaults to, matching
    RegionSelectorGUI.get_region()'s rectangle coords (row0, row1, col0, col1)
    -> min_coordinate=[row0, col0], max_coordinate=[row1, col1].
    """
    result = bounding_box_query(
        sdata,
        axes=axes,
        min_coordinate=list(min_coordinate),
        max_coordinate=list(max_coordinate),
        target_coordinate_system=target_coordinate_system,
        filter_table=filter_table,
    )
    if result is None:
        raise ValueError(
            "bounding_box_query returned no data — the requested box does not "
            "intersect any element in this coordinate system."
        )
    return result


def query_polygon(
    sdata: SpatialData,
    polygon_xy: Sequence[tuple[float, float]],
    target_coordinate_system: str = "aligned",
    filter_table: bool = True,
    clip: bool = False,
):
    """
    Crop every element of `sdata` that lives in `target_coordinate_system`
    to an arbitrary polygon, via spatialdata.polygon_query. Mirrors the
    polygon section of the spatialdata spatial_query tutorial.

    `polygon_xy` is a sequence of (x, y) vertices in display/data
    coordinates — exactly what RegionSelectorGUI.get_region() returns for
    a polygon selection (matplotlib data coords are already (x, y)).
    """
    from shapely.geometry import Polygon

    poly = Polygon(list(polygon_xy))
    if not poly.is_valid:
        poly = poly.buffer(0)
    result = polygon_query(
        sdata,
        polygon=poly,
        target_coordinate_system=target_coordinate_system,
        filter_table=filter_table,
        clip=clip,
    )
    if result is None:
        raise ValueError(
            "polygon_query returned no data — the requested polygon does not "
            "intersect any element in this coordinate system."
        )
    return result


def save_subset(sdata: SpatialData, path: str | Path, overwrite: bool = False) -> Path:
    """
    Write a (typically cropped) SpatialData object to a .zarr store.

    Parameters
    ----------
    sdata : SpatialData
    path : str or Path
        Destination; a `.zarr` suffix is added if missing.
    overwrite : bool
        Passed through to SpatialData.write().

    Returns
    -------
    Path
        The path actually written to.
    """
    path = Path(path)
    if path.suffix != ".zarr":
        path = path.with_suffix(".zarr")
    sdata.write(str(path), overwrite=overwrite)
    return path
