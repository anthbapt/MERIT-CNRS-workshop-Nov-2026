"""
spatial_registration_gui
=========================

Tkinter-based GUI tools that sit on top of the existing ``register``
package (registration_core.py and the four modality-pair classes):

- ``loaders``: a modality-agnostic image loader (any two images, not just
  the four hard-coded pairs), plus separate fixed/moving/output folder
  configuration.
- ``landmark_gui``: a Tkinter landmark-selection window with the same
  controls as ``BaseMultimodalRegistration.select_landmarks_interactive()``
  (click-to-add, undo, pause, reset, help, finish), plus real zoom in/out
  (buttons + mouse wheel) that the matplotlib-only tool doesn't have.
- ``region_selector_gui``: a Tkinter rectangle/polygon region selector that
  crops a SpatialData object built from the registered images (see
  ``spatialdata_io``) via bounding_box_query / polygon_query, mirroring
  https://spatialdata.scverse.org/en/latest/tutorials/notebooks/notebooks/examples/spatial_query.html
- ``spatialdata_io``: wraps registered images (+ the registration
  transform) into a SpatialData object, and the bounding-box/polygon query
  helpers used by ``region_selector_gui``.

None of this changes how registration itself works — it's a GUI + modality
+ SpatialData layer on top of the existing ``register`` package, which
remains fully usable on its own (pipelines, notebooks, scripted use).

This package expects the `register` package's directory to also be on
`sys.path` (as it already needs to be for `import registration_core` to
work); if it isn't, the percentile-normalize display helper falls back to
a local copy and the modality classes simply aren't importable — only
`loaders`, `landmark_gui`'s standalone `select_landmarks_tk()`, and
`region_selector_gui`'s standalone selector would still work.
"""

__version__ = "0.1.0"

__all__ = [
    "loaders",
    "landmark_gui",
    "region_selector_gui",
    "spatialdata_io",
]
