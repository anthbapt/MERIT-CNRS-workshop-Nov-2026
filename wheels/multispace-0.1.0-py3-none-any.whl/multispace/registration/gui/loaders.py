#!/usr/bin/env python3
"""
Modality-agnostic image loading
================================

The existing ``register`` package has one registration class per modality
*pair* (``HEIFRegistration``, ``MetallomicsHERegistration``, ...), each with
its own copy of image-loading logic. This module factors that loading logic
out into a single, modality-agnostic loader so the GUI tools in this package
(``landmark_gui``, ``region_selector_gui``) can work with any two images —
not just the four hard-coded pairings — while still producing arrays that
are fully compatible with everything in ``register/registration_core.py``.

Nothing here changes how registration math is performed; this is purely
about getting an image (and enough metadata to display and later wrap it
in a SpatialData object) off disk.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from skimage import io as skio

try:
    import tifffile
    HAS_TIFFFILE = True
except ImportError:  # pragma: no cover - tifffile is a core dependency
    HAS_TIFFFILE = False


# ---------------------------------------------------------------------------
# Known modality presets
# ---------------------------------------------------------------------------

#: LA-ICP-MS metallomics channel mapping, mirrors
#: register/metallomics_metallomics_registration.py::METAL_CHANNELS
METALLOMICS_CHANNELS: dict[int, tuple[str, str]] = {
    0: ("0TIC", "Total Ion Count"),
    1: ("Na", "Sodium"),
    2: ("Mg", "Magnesium"),
    3: ("P", "Phosphorus - nucleic acids, cell density"),
    4: ("S", "Sulfur - protein content"),
    5: ("Ca", "Calcium"),
    6: ("Mn", "Manganese"),
    7: ("Fe", "Iron - macrophages, blood"),
    8: ("Cu", "Copper - stellate cells, bile ducts"),
    9: ("Zn", "Zinc - hepatocytes, structure"),
    10: ("Rb", "Rubidium"),
    11: ("Sr", "Strontium"),
    12: ("118Sn", "Tin-118"),
    13: ("Ba", "Barium"),
}

#: Known modality identifiers. Custom modality strings are also accepted —
#: this is just used to pick sensible display/loading defaults.
KNOWN_MODALITIES = ("he", "if", "metallomics", "generic")


@dataclass
class ModalityImage:
    """
    A loaded image plus enough metadata to display it correctly and later
    wrap it in a SpatialData element.

    Attributes
    ----------
    array : np.ndarray
        2D (H, W) float64 array used for registration / display. For
        multi-channel sources this is the *selected* channel (or a mean
        projection), matching register/registration_core.py::_load_image.
    rgb : np.ndarray, optional
        (H, W, 3) uint8/float RGB array for display, when the source is an
        RGB modality (e.g. H&E). None otherwise.
    modality : str
        One of KNOWN_MODALITIES or a free-form label.
    name : str
        Human-readable label (defaults to the file stem).
    path : Path, optional
        Source file path, if loaded from disk.
    channel : int, optional
        Channel index used to produce `array`, if applicable.
    channel_names : dict, optional
        {index: (symbol, description)} mapping, when known (e.g. metallomics).
    n_channels : int
        Number of channels in the *original* (pre-selection) source array.
    pixel_size : float
        Physical size of one pixel, in whatever unit the caller is using
        (e.g. microns). Defaults to 1.0 (i.e. "pixel units"). This is used
        by spatialdata_io when wrapping images for region queries.
    """

    array: np.ndarray
    modality: str = "generic"
    name: str = ""
    rgb: np.ndarray | None = None
    path: Path | None = None
    channel: int | None = None
    channel_names: dict[int, tuple[str, str]] | None = None
    n_channels: int = 1
    pixel_size: float = 1.0
    extra: dict = field(default_factory=dict)

    @property
    def shape(self) -> tuple[int, int]:
        return self.array.shape[:2]

    @property
    def channel_label(self) -> str:
        if self.channel is None:
            return ""
        if self.channel_names and self.channel in self.channel_names:
            symbol, desc = self.channel_names[self.channel]
            return f"Ch{self.channel}: {symbol}"
        return f"Ch{self.channel}"

    def display_array(self) -> np.ndarray:
        """Return whatever should be shown on screen: RGB if available,
        otherwise the single-channel array (caller normalizes for display)."""
        return self.rgb if self.rgb is not None else self.array


def _read_raw(path: str | Path) -> np.ndarray:
    """Read any supported image file into a raw numpy array (no channel
    selection yet). Mirrors BaseMultimodalRegistration._load_image's I/O
    branch in register/registration_core.py."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Image file not found: {path}")

    if path.suffix.lower() in (".tif", ".tiff"):
        if not HAS_TIFFFILE:
            raise ImportError("tifffile is required to read .tif/.tiff files")
        return tifffile.imread(str(path))
    return skio.imread(str(path))


def _split_channels(img: np.ndarray) -> tuple[np.ndarray | None, int, int]:
    """
    For an ndim>2 array, return (moved-to-channels-first array, n_channels,
    channel_axis_before_move). channel_axis_before_move is 0 or -1, matching
    the "channels-first if smaller than channels-last" heuristic used
    throughout register/registration_core.py.
    """
    if img.ndim <= 2:
        return None, 1, 0
    if img.shape[0] < img.shape[-1]:
        return np.moveaxis(img, 0, 0), img.shape[0], 0  # already channels-first
    return np.moveaxis(img, -1, 0), img.shape[-1], -1


def load_modality_image(
    path: str | Path,
    modality: str = "generic",
    name: str | None = None,
    channel: int | None = None,
    combine_channels: bool = False,
    is_rgb: bool | None = None,
    pixel_size: float = 1.0,
) -> ModalityImage:
    """
    Load a single image file into a modality-agnostic ``ModalityImage``.

    This intentionally mirrors ``BaseMultimodalRegistration._load_image``'s
    behaviour exactly (same channel-first/last heuristic, same default of
    "first channel" when neither `channel` nor `combine_channels` is given)
    so a ``ModalityImage.array`` can be fed straight into a
    ``*Registration`` class via its ``*_array=`` constructor argument.

    Parameters
    ----------
    path : str or Path
        Image file to load (.tif/.tiff via tifffile, anything else via
        skimage.io).
    modality : str
        'he', 'if', 'metallomics', or a free-form label. Only affects
        display defaults (e.g. RGB handling, channel-name lookup) — the
        loading logic itself is identical for every modality.
    name : str, optional
        Display label. Defaults to the file stem.
    channel : int, optional
        Channel to select from a multi-channel source. Ignored if
        combine_channels=True. If neither is given, the first channel is
        used (matching the existing package's default).
    combine_channels : bool
        Mean-project all channels into one (used for e.g. multi-channel IF
        combined into a single registration channel).
    is_rgb : bool, optional
        Force RGB handling. If None, inferred as True when modality=='he'
        and the source has exactly 3 (or 4, alpha-dropped) channels-last.
    pixel_size : float
        Physical pixel size to attach to the result (see ModalityImage).

    Returns
    -------
    ModalityImage
    """
    path = Path(path)
    raw = _read_raw(path)
    display_name = name or path.stem

    if is_rgb is None:
        is_rgb = modality == "he" and raw.ndim == 3 and raw.shape[-1] in (3, 4)

    rgb_arr = None
    if is_rgb and raw.ndim == 3 and raw.shape[-1] in (3, 4):
        rgb_arr = raw[..., :3]
        if rgb_arr.dtype != np.uint8 and rgb_arr.max() > 1:
            rgb_arr = rgb_arr.astype(np.float64) / 255.0
        # Registration itself still works off a single-channel projection
        # of the RGB image, matching HEIFRegistration's behaviour.
        gray = np.asarray(raw[..., :3], dtype=np.float64).mean(axis=-1)
        return ModalityImage(
            array=gray,
            modality=modality,
            name=display_name,
            rgb=rgb_arr,
            path=path,
            channel=None,
            n_channels=raw.shape[-1],
            pixel_size=pixel_size,
        )

    moved, n_channels, _axis = _split_channels(raw)
    channel_names = METALLOMICS_CHANNELS if modality == "metallomics" else None

    if moved is None:
        # Already 2D
        array = raw.astype(np.float64)
        used_channel = None
    elif combine_channels:
        array = np.mean(moved, axis=0).astype(np.float64)
        used_channel = None
    elif channel is not None:
        if channel >= n_channels:
            raise ValueError(f"Channel {channel} requested but only {n_channels} available")
        array = moved[channel].astype(np.float64)
        used_channel = channel
    else:
        array = moved[0].astype(np.float64)
        used_channel = 0

    return ModalityImage(
        array=array,
        modality=modality,
        name=display_name,
        rgb=None,
        path=path,
        channel=used_channel,
        channel_names=channel_names,
        n_channels=n_channels,
        pixel_size=pixel_size,
    )


@dataclass
class ModalityPairConfig:
    """
    Separate fixed/moving/output directories, matching the folder-separation
    pattern added to pipeline/*.py — one input folder each for the fixed and
    moving image, plus an independent output folder, instead of a single
    shared directory with suffixed filenames.
    """

    fixed_folder: str | Path
    moving_folder: str | Path
    output_dir: str | Path
    fixed_filename: str
    moving_filename: str
    prefix: str = "registration"

    @property
    def fixed_path(self) -> Path:
        return Path(self.fixed_folder) / self.fixed_filename

    @property
    def moving_path(self) -> Path:
        return Path(self.moving_folder) / self.moving_filename

    def ensure_output_dir(self) -> Path:
        out = Path(self.output_dir)
        out.mkdir(parents=True, exist_ok=True)
        return out
