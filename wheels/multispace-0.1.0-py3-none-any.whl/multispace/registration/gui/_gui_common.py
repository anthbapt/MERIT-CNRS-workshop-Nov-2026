#!/usr/bin/env python3
"""
Shared Tkinter + matplotlib helpers used by both landmark_gui.py and
region_selector_gui.py.

The one thing genuinely missing from the existing matplotlib-only tools in
register/registration_core.py is a dedicated zoom in/out control: today,
"zoom" only means matplotlib's own toolbar rectangle-zoom tool. This module
adds mouse-wheel zoom (centered on the cursor) plus Zoom In / Zoom Out /
Reset buttons that can be attached to any matplotlib Axes embedded in a
Tkinter FigureCanvasTkAgg widget.
"""

from __future__ import annotations

from collections.abc import Callable


class ZoomPanController:
    """
    Attaches mouse-wheel zoom (centered on the cursor) to a matplotlib Axes
    hosted in a Tkinter FigureCanvasTkAgg widget, and exposes zoom_in() /
    zoom_out() / reset_view() for button/keyboard-shortcut wiring.

    Deliberately does *not* implement click-drag panning: both landmark_gui
    and region_selector_gui use left-click-drag for their own interactions
    (placing landmarks / dragging a selection), so panning is left to
    matplotlib's own toolbar pan tool (already present, already respected
    by the "pause landmark placement while toolbar is active" logic).
    """

    def __init__(
        self,
        ax,
        canvas,
        zoom_factor: float = 1.25,
        on_change: Callable[[], None] | None = None,
    ):
        self.ax = ax
        self.canvas = canvas
        self.zoom_factor = zoom_factor
        self.on_change = on_change
        self._initial_xlim = ax.get_xlim()
        self._initial_ylim = ax.get_ylim()

        widget = canvas.get_tk_widget()
        # Windows / macOS deliver a single <MouseWheel> event with a signed
        # `delta`; X11/Linux instead sends discrete Button-4 (up) / Button-5
        # (down) events. Binding all three covers every platform.
        widget.bind("<MouseWheel>", self._on_mousewheel, add="+")
        widget.bind("<Button-4>", self._on_scroll_up, add="+")
        widget.bind("<Button-5>", self._on_scroll_down, add="+")

    def capture_initial_view(self) -> None:
        """Call once the image has been drawn, to set the 'home' view that
        reset_view() restores."""
        self._initial_xlim = self.ax.get_xlim()
        self._initial_ylim = self.ax.get_ylim()

    # ------------------------------------------------------------------
    # Zoom
    # ------------------------------------------------------------------
    def _zoom(self, factor: float, cx: float | None = None, cy: float | None = None) -> None:
        xlim = self.ax.get_xlim()
        ylim = self.ax.get_ylim()
        if cx is None:
            cx = (xlim[0] + xlim[1]) / 2
        if cy is None:
            cy = (ylim[0] + ylim[1]) / 2

        new_w = (xlim[1] - xlim[0]) * factor
        new_h = (ylim[1] - ylim[0]) * factor
        # Keep the point under the cursor fixed on screen while zooming, by
        # preserving its relative offset within the view.
        rel_x = (cx - xlim[0]) / (xlim[1] - xlim[0]) if xlim[1] != xlim[0] else 0.5
        rel_y = (cy - ylim[0]) / (ylim[1] - ylim[0]) if ylim[1] != ylim[0] else 0.5

        new_x0 = cx - rel_x * new_w
        new_y0 = cy - rel_y * new_h

        self.ax.set_xlim(new_x0, new_x0 + new_w)
        self.ax.set_ylim(new_y0, new_y0 + new_h)
        self.canvas.draw_idle()
        if self.on_change:
            self.on_change()

    def zoom_in(self, cx: float | None = None, cy: float | None = None) -> None:
        self._zoom(1.0 / self.zoom_factor, cx, cy)

    def zoom_out(self, cx: float | None = None, cy: float | None = None) -> None:
        self._zoom(self.zoom_factor, cx, cy)

    def reset_view(self) -> None:
        self.ax.set_xlim(self._initial_xlim)
        self.ax.set_ylim(self._initial_ylim)
        self.canvas.draw_idle()
        if self.on_change:
            self.on_change()

    # ------------------------------------------------------------------
    # Event -> data-coordinate helper
    # ------------------------------------------------------------------
    def _event_data_coords(self, event) -> tuple[float | None, float | None]:
        """Convert a raw Tk mouse event (pixel coords, origin top-left) into
        data coordinates for this Axes (origin bottom-left, matplotlib
        convention)."""
        widget = self.canvas.get_tk_widget()
        try:
            height = widget.winfo_height()
            inv = self.ax.transData.inverted()
            x_data, y_data = inv.transform((event.x, height - event.y))
        except Exception:
            return None, None
        return x_data, y_data

    def _on_mousewheel(self, event) -> None:
        cx, cy = self._event_data_coords(event)
        if cx is None:
            return
        # Windows sends multiples of 120; macOS sends small integers — the
        # sign is what matters in both cases.
        if event.delta > 0:
            self.zoom_in(cx, cy)
        else:
            self.zoom_out(cx, cy)

    def _on_scroll_up(self, event) -> None:
        cx, cy = self._event_data_coords(event)
        if cx is not None:
            self.zoom_in(cx, cy)

    def _on_scroll_down(self, event) -> None:
        cx, cy = self._event_data_coords(event)
        if cx is not None:
            self.zoom_out(cx, cy)


def percentile_normalize_fallback(img, low: float = 1.0, high: float = 99.0):
    """
    Local fallback percentile-normalize, used only if
    register.registration_core.percentile_normalize can't be imported
    (e.g. this package is used standalone, without `register` on
    sys.path). Behaviour matches registration_core.percentile_normalize.
    """
    import numpy as np

    img = np.asarray(img, dtype=np.float64)
    finite = img[np.isfinite(img)]
    if finite.size == 0:
        return np.zeros_like(img, dtype=np.float64)
    lo, hi = np.percentile(finite, [low, high])
    if hi <= lo:
        lo, hi = float(finite.min()), float(finite.max())
    if hi <= lo:
        return np.zeros_like(img, dtype=np.float64)
    return np.clip((img - lo) / (hi - lo), 0.0, 1.0)
