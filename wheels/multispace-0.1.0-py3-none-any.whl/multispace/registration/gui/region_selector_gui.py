#!/usr/bin/env python3
"""
Tkinter region-selection GUI
==============================

A Tkinter tool for drawing a rectangle or a free-form polygon on a
displayed image, then using that selection to crop a SpatialData object
via ``spatialdata.bounding_box_query`` / ``spatialdata.polygon_query`` —
mirroring:
https://spatialdata.scverse.org/en/latest/tutorials/notebooks/notebooks/examples/spatial_query.html

Shares zoom in/out (buttons + mouse wheel) with landmark_gui.py via
``_gui_common.ZoomPanController``; panning is left to matplotlib's own
toolbar pan tool, same as landmark_gui, since left-click-drag here draws
the rectangle.

Typical usage
-------------
    from multispace.registration.gui.spatialdata_io import build_spatialdata_from_registration
    from multispace.registration.gui.region_selector_gui import select_region_and_query

    sdata = build_spatialdata_from_registration(reg)
    region, sdata_subset = select_region_and_query(sdata, reference_element="fixed")
    sdata_subset.write("subset.zarr")
"""

from __future__ import annotations

import tkinter as tk
from collections.abc import Callable
from tkinter import ttk
from typing import Any

import matplotlib

matplotlib.use("TkAgg")
import numpy as np  # noqa: E402
from matplotlib.backends.backend_tkagg import (  # noqa: E402
    FigureCanvasTkAgg,
    NavigationToolbar2Tk,
)
from matplotlib.figure import Figure  # noqa: E402
from matplotlib.patches import Polygon as MplPolygon
from matplotlib.patches import Rectangle  # noqa: E402

try:  # normal case: imported as spatial_registration_gui.region_selector_gui
    from ._gui_common import ZoomPanController, percentile_normalize_fallback
except ImportError:  # flat import, e.g. `sys.path` has this dir added directly
    from _gui_common import ZoomPanController, percentile_normalize_fallback  # type: ignore

try:
    from .._core.registration_core import percentile_normalize  # type: ignore
except ImportError:  # pragma: no cover - fallback if register/ isn't on sys.path
    percentile_normalize = percentile_normalize_fallback


class RegionSelectorGUI:
    """Single-panel Tkinter rectangle/polygon region selector."""

    MODES = ("rectangle", "polygon")

    def __init__(
        self,
        master,
        image: np.ndarray,
        rgb: np.ndarray | None = None,
        cmap: str = "viridis",
        mode: str = "rectangle",
        title: str = "Select Region",
        on_close: Callable[[], None] | None = None,
    ):
        if mode not in self.MODES:
            raise ValueError(f"mode must be one of {self.MODES}, got {mode!r}")

        self.master = master
        self.image = image
        self.rgb = rgb
        self.cmap = cmap
        self.mode = tk.StringVar(value=mode)
        self.on_close = on_close

        self._rect_start: tuple[float, float] | None = None
        self._rect_patch: Rectangle | None = None
        self._rect_coords: tuple[float, float, float, float] | None = None  # (r0, r1, c0, c1)

        self._polygon_pts: list[tuple[float, float]] = []
        self._polygon_artists: list = []
        self._polygon_closed = False

        self._finished = False
        self._confirmed = False
        self._help_visible = False

        self.window = tk.Toplevel(master) if isinstance(master, (tk.Tk, tk.Toplevel)) else master
        self.window.title(title)
        self.window.geometry("800x700")
        self.window.protocol("WM_DELETE_WINDOW", self._on_cancel)

        self._build_ui()
        self._draw_image()
        self._bind_events()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        control_bar = ttk.Frame(self.window)
        control_bar.pack(side=tk.TOP, fill=tk.X, padx=4, pady=4)

        ttk.Label(control_bar, text="Shape:").pack(side=tk.LEFT, padx=(2, 4))
        for m in self.MODES:
            ttk.Radiobutton(
                control_bar, text=m.capitalize(), value=m, variable=self.mode,
                command=self._on_mode_change,
            ).pack(side=tk.LEFT, padx=2)

        ttk.Separator(control_bar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)
        ttk.Button(control_bar, text="Zoom In (+)", command=lambda: self.zoom.zoom_in()).pack(
            side=tk.LEFT, padx=2
        )
        ttk.Button(control_bar, text="Zoom Out (-)", command=lambda: self.zoom.zoom_out()).pack(
            side=tk.LEFT, padx=2
        )
        ttk.Button(control_bar, text="Reset View (R)", command=lambda: self.zoom.reset_view()).pack(
            side=tk.LEFT, padx=2
        )

        ttk.Separator(control_bar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)
        ttk.Button(control_bar, text="Undo Point", command=self._undo_point).pack(side=tk.LEFT, padx=2)
        ttk.Button(control_bar, text="Clear", command=self._clear_selection).pack(side=tk.LEFT, padx=2)
        self.close_poly_btn = ttk.Button(
            control_bar, text="Close Polygon", command=self._close_polygon
        )
        self.close_poly_btn.pack(side=tk.LEFT, padx=2)

        ttk.Button(control_bar, text="Cancel", command=self._on_cancel).pack(side=tk.RIGHT, padx=2)
        self.confirm_btn = ttk.Button(control_bar, text="Confirm Region", command=self._on_confirm)
        self.confirm_btn.pack(side=tk.RIGHT, padx=2)

        status_bar = ttk.Frame(self.window)
        status_bar.pack(side=tk.TOP, fill=tk.X, padx=4)
        self.status_var = tk.StringVar(value="")
        ttk.Label(status_bar, textvariable=self.status_var).pack(side=tk.LEFT, padx=2, pady=2)

        canvas_frame = ttk.Frame(self.window)
        canvas_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=4, pady=4)

        self.fig = Figure(figsize=(7, 7))
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=canvas_frame)
        self.toolbar = NavigationToolbar2Tk(self.canvas, canvas_frame)
        self.toolbar.update()
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.help_var = tk.StringVar(
            value=(
                "Rectangle: click-drag to draw a box.   Polygon: click to add "
                "vertices, then Close Polygon (or double-click).\n"
                "Undo Point removes the last polygon vertex.   Clear resets the "
                "current selection.   scroll/+/-: zoom   toolbar pan/zoom-rect auto-pauses drawing."
            )
        )
        self.help_label = ttk.Label(
            self.window, textvariable=self.help_var, relief=tk.SUNKEN, justify=tk.LEFT, padding=6
        )
        self.help_label.pack(side=tk.BOTTOM, fill=tk.X)

        self.zoom = ZoomPanController(self.ax, self.canvas)
        self._update_status()

    def _draw_image(self) -> None:
        if self.rgb is not None:
            self.ax.imshow(self.rgb)
        else:
            self.ax.imshow(percentile_normalize(self.image), cmap=self.cmap)
        self.ax.axis("off")
        self.canvas.draw()
        self.zoom.capture_initial_view()

    def _bind_events(self) -> None:
        self.canvas.mpl_connect("button_press_event", self._on_press)
        self.canvas.mpl_connect("motion_notify_event", self._on_motion)
        self.canvas.mpl_connect("button_release_event", self._on_release)

        for seq in ("<Key-r>", "<Key-R>"):
            self.window.bind(seq, lambda e: self.zoom.reset_view())
        for seq in ("<plus>", "<KP_Add>", "<Key-equal>"):
            self.window.bind(seq, lambda e: self.zoom.zoom_in())
        for seq in ("<minus>", "<KP_Subtract>"):
            self.window.bind(seq, lambda e: self.zoom.zoom_out())
        for seq in ("<Key-c>", "<Key-C>"):
            self.window.bind(seq, lambda e: self._clear_selection())
        self.window.bind("<Return>", lambda e: self._close_polygon())

    # ------------------------------------------------------------------
    @staticmethod
    def _toolbar_active(toolbar) -> bool:
        return bool(getattr(toolbar, "mode", "") or "")

    def _on_mode_change(self) -> None:
        self._clear_selection()

    def _on_press(self, event) -> None:
        if self._finished or event.inaxes != self.ax or self._toolbar_active(self.toolbar):
            return
        if getattr(event, "button", 1) != 1:
            return

        if self.mode.get() == "rectangle":
            self._rect_start = (event.xdata, event.ydata)
            if self._rect_patch is not None:
                try:
                    self._rect_patch.remove()
                except Exception:
                    pass
            self._rect_patch = Rectangle(
                (event.xdata, event.ydata), 0, 0, fill=False, edgecolor="cyan", linewidth=2
            )
            self.ax.add_patch(self._rect_patch)
            self.canvas.draw_idle()
        else:  # polygon
            if self._polygon_closed:
                return
            # Double-click closes the polygon (matplotlib reports dblclick)
            if getattr(event, "dblclick", False) and len(self._polygon_pts) >= 3:
                self._close_polygon()
                return
            self._polygon_pts.append((event.xdata, event.ydata))
            self._redraw_polygon()
            self._update_status()

    def _on_motion(self, event) -> None:
        if self._finished or event.inaxes != self.ax:
            return
        if self.mode.get() == "rectangle" and self._rect_start is not None and self._rect_patch is not None:
            x0, y0 = self._rect_start
            w = event.xdata - x0
            h = event.ydata - y0
            self._rect_patch.set_width(w)
            self._rect_patch.set_height(h)
            self.canvas.draw_idle()

    def _on_release(self, event) -> None:
        if self._finished or self.mode.get() != "rectangle" or self._rect_start is None:
            return
        if event.inaxes != self.ax or event.xdata is None:
            # released outside the axes — keep whatever the last valid drag gave us
            self._rect_start = None
            return
        x0, y0 = self._rect_start
        x1, y1 = event.xdata, event.ydata
        col0, col1 = sorted((x0, x1))
        row0, row1 = sorted((y0, y1))
        self._rect_coords = (row0, row1, col0, col1)
        self._rect_start = None
        self._update_status()

    # ------------------------------------------------------------------
    # Polygon helpers
    # ------------------------------------------------------------------
    def _redraw_polygon(self) -> None:
        for artist in self._polygon_artists:
            try:
                artist.remove()
            except Exception:
                pass
        self._polygon_artists = []

        for i, (x, y) in enumerate(self._polygon_pts):
            (pt,) = self.ax.plot(x, y, "o", color="cyan", markersize=6, markeredgecolor="white")
            self._polygon_artists.append(pt)
        if len(self._polygon_pts) >= 2:
            xs = [p[0] for p in self._polygon_pts]
            ys = [p[1] for p in self._polygon_pts]
            (line,) = self.ax.plot(xs, ys, "-", color="cyan", linewidth=1.5)
            self._polygon_artists.append(line)
        self.canvas.draw_idle()

    def _close_polygon(self) -> None:
        if self.mode.get() != "polygon" or len(self._polygon_pts) < 3 or self._polygon_closed:
            return
        for artist in self._polygon_artists:
            try:
                artist.remove()
            except Exception:
                pass
        self._polygon_artists = []
        poly_patch = MplPolygon(
            self._polygon_pts, closed=True, fill=True, facecolor="cyan", alpha=0.2,
            edgecolor="cyan", linewidth=2,
        )
        self.ax.add_patch(poly_patch)
        self._polygon_artists.append(poly_patch)
        self._polygon_closed = True
        self.canvas.draw_idle()
        self._update_status()

    def _undo_point(self) -> None:
        if self.mode.get() == "polygon" and self._polygon_pts and not self._polygon_closed:
            self._polygon_pts.pop()
            self._redraw_polygon()
            self._update_status()

    def _clear_selection(self) -> None:
        if self._rect_patch is not None:
            try:
                self._rect_patch.remove()
            except Exception:
                pass
            self._rect_patch = None
        self._rect_start = None
        self._rect_coords = None

        for artist in self._polygon_artists:
            try:
                artist.remove()
            except Exception:
                pass
        self._polygon_artists = []
        self._polygon_pts = []
        self._polygon_closed = False

        self.canvas.draw_idle()
        self._update_status()

    def _update_status(self) -> None:
        if self.mode.get() == "rectangle":
            if self._rect_coords:
                r0, r1, c0, c1 = self._rect_coords
                self.status_var.set(
                    f"Rectangle: rows [{r0:.1f}:{r1:.1f}]  cols [{c0:.1f}:{c1:.1f}]"
                )
            else:
                self.status_var.set("Rectangle: click-drag to draw")
        else:
            n = len(self._polygon_pts)
            state = "closed" if self._polygon_closed else "open"
            self.status_var.set(f"Polygon: {n} vertices ({state})")

    # ------------------------------------------------------------------
    def _has_valid_region(self) -> bool:
        if self.mode.get() == "rectangle":
            return self._rect_coords is not None
        return self._polygon_closed and len(self._polygon_pts) >= 3

    def _on_confirm(self) -> None:
        if not self._has_valid_region():
            self.status_var.set(
                (self.status_var.get() or "") + "  — draw and close a region first"
            )
            return
        self._confirmed = True
        self._finish()

    def _on_cancel(self) -> None:
        self._confirmed = False
        self._finish()

    def _finish(self) -> None:
        if self._finished:
            return
        self._finished = True
        if self.on_close:
            self.on_close()
        try:
            self.window.destroy()
        except Exception:
            pass

    # ------------------------------------------------------------------
    def get_region(self) -> dict[str, Any] | None:
        """
        Returns
        -------
        dict or None
            None if the user cancelled without confirming a region.
            Otherwise: {"shape": "rectangle", "coords": (row0, row1, col0, col1)}
            or {"shape": "polygon", "coords": [(x, y), ...]} in image pixel
            (data) coordinates.
        """
        if not self._confirmed:
            return None
        if self.mode.get() == "rectangle":
            return {"shape": "rectangle", "coords": self._rect_coords}
        return {"shape": "polygon", "coords": list(self._polygon_pts)}


def select_region_tk(
    image: np.ndarray,
    rgb: np.ndarray | None = None,
    cmap: str = "viridis",
    mode: str = "rectangle",
    title: str = "Select Region",
) -> dict[str, Any] | None:
    """
    Open the Tkinter region-selection window and block until the user
    confirms a region or cancels.

    Returns
    -------
    dict or None
        See RegionSelectorGUI.get_region().
    """
    root = tk.Tk()
    root.withdraw()
    gui = RegionSelectorGUI(root, image, rgb=rgb, cmap=cmap, mode=mode, title=title)
    root.wait_window(gui.window)
    region = gui.get_region()
    root.destroy()
    return region


def _to_display_array(data: np.ndarray) -> np.ndarray:
    """
    Reduce a (C, Y, X) array (as stored in a SpatialData Image2DModel
    element) down to a single 2D array suitable for imshow — mean-projects
    across channels when there's more than one.
    """
    arr = np.asarray(data)
    if arr.ndim == 2:
        return arr
    if arr.ndim == 3:
        return arr.mean(axis=0) if arr.shape[0] <= arr.shape[-1] else arr.mean(axis=-1)
    raise ValueError(f"Expected a 2D or 3D (C,Y,X) array, got shape {arr.shape}")


def select_region_and_query(
    sdata,
    reference_element: str,
    mode: str = "rectangle",
    coordinate_system: str = "aligned",
    cmap: str = "viridis",
):
    """
    Open the region selector on ``sdata[reference_element]`` and crop the
    *entire* SpatialData object (every element in `coordinate_system`, not
    just the reference image) to the selected region, via
    spatialdata.bounding_box_query / polygon_query. Mirrors:
    https://spatialdata.scverse.org/en/latest/tutorials/notebooks/notebooks/examples/spatial_query.html

    Parameters
    ----------
    sdata : SpatialData
        Typically the output of spatialdata_io.build_spatialdata_from_registration(),
        but any SpatialData object works — including ones where
        `reference_element` is related to `coordinate_system` by a genuine
        affine (rotation/scale/translation), not just an Identity transform
        (e.g. a real multi-modal dataset where the reference image was
        itself registered into a shared frame). The selection is always
        mapped through that element's own registered transformation before
        querying, so the crop lands in the right physical location either way.
    reference_element : str
        Name of the image element in `sdata` to display for selection.
    mode : str
        'rectangle' or 'polygon'.
    coordinate_system : str
        Coordinate system the query operates in (the reference element need
        not itself use pixel coordinates equal to this system — see above).
    cmap : str
        Colormap for single-channel display.

    Returns
    -------
    tuple
        (region_info, cropped_sdata) — region_info is None and cropped_sdata
        is None if the user cancelled without confirming a region. Note
        `region_info["coords"]` is always in `reference_element`'s own pixel
        space (what was actually drawn on screen), not `coordinate_system`.
    """
    try:  # normal case: imported as spatial_registration_gui.region_selector_gui
        from .spatialdata_io import (
            is_axis_aligned_transform,
            query_bounding_box,
            query_polygon,
            transform_points_to_coordinate_system,
        )
    except ImportError:  # flat import, e.g. `sys.path` has this dir added directly
        from spatialdata_io import (  # type: ignore
            is_axis_aligned_transform,
            query_bounding_box,
            query_polygon,
            transform_points_to_coordinate_system,
        )

    display = _to_display_array(np.asarray(sdata[reference_element]))
    region = select_region_tk(display, mode=mode)
    if region is None:
        return None, None

    if region["shape"] == "rectangle":
        row0, row1, col0, col1 = region["coords"]
        corners_xy = [(col0, row0), (col1, row0), (col1, row1), (col0, row1)]
        transformed = transform_points_to_coordinate_system(
            sdata, reference_element, corners_xy, target_coordinate_system=coordinate_system
        )
        if is_axis_aligned_transform(sdata, reference_element, target_coordinate_system=coordinate_system):
            # No rotation/shear between reference_element and coordinate_system:
            # the axis-aligned rectangle stays axis-aligned, so a plain
            # bounding_box_query is exact (and cheaper than a polygon query).
            min_xy = transformed.min(axis=0)
            max_xy = transformed.max(axis=0)
            cropped = query_bounding_box(
                sdata,
                min_coordinate=[min_xy[1], min_xy[0]],
                max_coordinate=[max_xy[1], max_xy[0]],
                axes=("y", "x"),
                target_coordinate_system=coordinate_system,
            )
        else:
            # A real rotation/shear turns the rectangle into a quadrilateral
            # in `coordinate_system` — only a polygon query is exact here.
            cropped = query_polygon(
                sdata, polygon_xy=[tuple(p) for p in transformed], target_coordinate_system=coordinate_system
            )
    else:
        transformed = transform_points_to_coordinate_system(
            sdata, reference_element, region["coords"], target_coordinate_system=coordinate_system
        )
        cropped = query_polygon(
            sdata, polygon_xy=[tuple(p) for p in transformed], target_coordinate_system=coordinate_system
        )

    return region, cropped
