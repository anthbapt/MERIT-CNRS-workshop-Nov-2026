#!/usr/bin/env python3
"""
Tkinter landmark-selection GUI
===============================

A drop-in Tkinter replacement for
``register.registration_core.BaseMultimodalRegistration.select_landmarks_interactive()``,
built as a real Tkinter window (two embedded matplotlib canvases) rather
than a bare matplotlib figure.

It reproduces every control the existing tool has — click-to-add
alternating landmarks, undo ('z'), manual pause (space/'p'), reset view
('r'), help ('h'), finish ('q'), and pausing landmark placement while the
matplotlib toolbar's zoom-rectangle/pan tool is active — as real Tkinter
widgets, and adds what the matplotlib-only version doesn't have: dedicated
Zoom In / Zoom Out buttons and mouse-wheel zoom centered on the cursor.

Typical usage
-------------
    from multispace.registration.gui.landmark_gui import select_landmarks_interactive_tk

    landmarks_fixed, landmarks_moving = select_landmarks_interactive_tk(reg)
    reg.register_landmarks(transform_type="affine")

``reg`` can be any instance of a ``BaseMultimodalRegistration`` subclass
from the ``register`` package (already preprocessed). This sets
``reg._landmarks_fixed`` / ``reg._landmarks_moving`` exactly as the
matplotlib-only tool does, so everything downstream (``register_landmarks()``,
pipelines, notebooks) keeps working unchanged.
"""

from __future__ import annotations

import tkinter as tk
from collections.abc import Callable
from tkinter import ttk

import matplotlib

matplotlib.use("TkAgg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.backends.backend_tkagg import (  # noqa: E402
    FigureCanvasTkAgg,
    NavigationToolbar2Tk,
)
from matplotlib.figure import Figure  # noqa: E402

try:  # normal case: imported as spatial_registration_gui.landmark_gui
    from ._gui_common import ZoomPanController, percentile_normalize_fallback
except ImportError:  # flat import, e.g. `sys.path` has this dir added directly
    from _gui_common import ZoomPanController, percentile_normalize_fallback  # type: ignore

try:
    from .._core.registration_core import percentile_normalize  # type: ignore
except ImportError:  # pragma: no cover - fallback if register/ isn't on sys.path
    percentile_normalize = percentile_normalize_fallback


class LandmarkGUI:
    """Two-panel Tkinter landmark picker. See module docstring."""

    def __init__(
        self,
        master,
        fixed_image: np.ndarray,
        moving_image: np.ndarray,
        fixed_rgb: np.ndarray | None = None,
        fixed_cmap: str = "viridis",
        moving_cmap: str = "gray",
        title: str = "Landmark Selection",
        on_close: Callable[[], None] | None = None,
    ):
        self.master = master
        self.fixed_image = fixed_image
        self.moving_image = moving_image
        self.fixed_rgb = fixed_rgb
        self.fixed_cmap = fixed_cmap
        self.moving_cmap = moving_cmap
        self.on_close = on_close

        self.landmarks_fixed: list[tuple[float, float]] = []
        self.landmarks_moving: list[tuple[float, float]] = []
        self._artists_fixed: list[tuple] = []
        self._artists_moving: list[tuple] = []
        self._current = "fixed"
        self._manual_pause = False
        self._help_visible = False
        self._finished = False

        self.window = tk.Toplevel(master) if isinstance(master, (tk.Tk, tk.Toplevel)) else master
        self.window.title(title)
        self.window.geometry("1200x650")
        self.window.protocol("WM_DELETE_WINDOW", self._on_finish)

        self._build_ui()
        self._draw_images()
        self._bind_events()
        self._update_status_loop()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        control_bar = ttk.Frame(self.window)
        control_bar.pack(side=tk.TOP, fill=tk.X, padx=4, pady=4)

        self.status_var = tk.StringVar(value="")
        ttk.Label(
            control_bar, textvariable=self.status_var, font=("TkDefaultFont", 10, "bold")
        ).pack(side=tk.LEFT, padx=(2, 14))

        ttk.Button(control_bar, text="Zoom In (+)", command=self._zoom_in_both).pack(
            side=tk.LEFT, padx=2
        )
        ttk.Button(control_bar, text="Zoom Out (-)", command=self._zoom_out_both).pack(
            side=tk.LEFT, padx=2
        )
        ttk.Button(control_bar, text="Reset View (R)", command=self._reset_view).pack(
            side=tk.LEFT, padx=2
        )
        ttk.Separator(control_bar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)
        ttk.Button(control_bar, text="Undo (Z)", command=self._undo).pack(side=tk.LEFT, padx=2)
        self.pause_btn = ttk.Button(control_bar, text="Pause (Space)", command=self._toggle_pause)
        self.pause_btn.pack(side=tk.LEFT, padx=2)
        ttk.Separator(control_bar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)
        ttk.Button(control_bar, text="Help (H)", command=self._toggle_help).pack(side=tk.LEFT, padx=2)
        ttk.Button(control_bar, text="Finish (Q)", command=self._on_finish).pack(side=tk.RIGHT, padx=2)

        panels = ttk.Frame(self.window)
        panels.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        fixed_frame = ttk.Frame(panels)
        fixed_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(4, 2), pady=4)
        moving_frame = ttk.Frame(panels)
        moving_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(2, 4), pady=4)

        self.fig_fixed = Figure(figsize=(6, 6))
        self.ax_fixed = self.fig_fixed.add_subplot(111)
        self.canvas_fixed = FigureCanvasTkAgg(self.fig_fixed, master=fixed_frame)
        # Toolbar first (it packs itself, side=TOP by default), then the
        # canvas widget explicitly below it — the standard matplotlib/Tk
        # embedding order; reversing this squeezes the toolbar to nothing.
        self.toolbar_fixed = NavigationToolbar2Tk(self.canvas_fixed, fixed_frame)
        self.toolbar_fixed.update()
        self.canvas_fixed.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.fig_moving = Figure(figsize=(6, 6))
        self.ax_moving = self.fig_moving.add_subplot(111)
        self.canvas_moving = FigureCanvasTkAgg(self.fig_moving, master=moving_frame)
        self.toolbar_moving = NavigationToolbar2Tk(self.canvas_moving, moving_frame)
        self.toolbar_moving.update()
        self.canvas_moving.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        self.help_var = tk.StringVar(
            value=(
                "click: add landmark (alternates Fixed ↔ Moving)   "
                "z: undo   space/p: pause   r: reset view\n"
                "scroll wheel or +/- buttons: zoom   h: help   q: finish   "
                "toolbar pan/zoom-rect tools auto-pause landmark clicks"
            )
        )
        self.help_label = ttk.Label(
            self.window, textvariable=self.help_var, relief=tk.SUNKEN, justify=tk.LEFT, padding=6
        )

        self.zoom_fixed = ZoomPanController(self.ax_fixed, self.canvas_fixed)
        self.zoom_moving = ZoomPanController(self.ax_moving, self.canvas_moving)

    def _draw_images(self) -> None:
        if self.fixed_rgb is not None:
            self.ax_fixed.imshow(self.fixed_rgb)
        else:
            self.ax_fixed.imshow(percentile_normalize(self.fixed_image), cmap=self.fixed_cmap)
        self.ax_fixed.axis("off")
        self.ax_fixed.set_title("Fixed (next)", fontsize=10, fontweight="bold", color="blue")

        self.ax_moving.imshow(percentile_normalize(self.moving_image), cmap=self.moving_cmap)
        self.ax_moving.axis("off")
        self.ax_moving.set_title("Moving", fontsize=10, fontweight="bold", color="black")

        self.canvas_fixed.draw()
        self.canvas_moving.draw()
        self.zoom_fixed.capture_initial_view()
        self.zoom_moving.capture_initial_view()

    def _bind_events(self) -> None:
        self.canvas_fixed.mpl_connect("button_press_event", self._on_click_fixed)
        self.canvas_moving.mpl_connect("button_press_event", self._on_click_moving)

        # Keyboard shortcuts on the whole window — same keys as the
        # matplotlib-only tool.
        for seq in ("<Key-z>", "<Key-Z>"):
            self.window.bind(seq, lambda e: self._undo())
        for seq in ("<space>", "<Key-p>", "<Key-P>"):
            self.window.bind(seq, lambda e: self._toggle_pause())
        for seq in ("<Key-r>", "<Key-R>"):
            self.window.bind(seq, lambda e: self._reset_view())
        for seq in ("<Key-h>", "<Key-H>"):
            self.window.bind(seq, lambda e: self._toggle_help())
        for seq in ("<Key-q>", "<Key-Q>"):
            self.window.bind(seq, lambda e: self._on_finish())
        for seq in ("<plus>", "<KP_Add>", "<Key-equal>"):
            self.window.bind(seq, lambda e: self._zoom_in_both())
        for seq in ("<minus>", "<KP_Subtract>"):
            self.window.bind(seq, lambda e: self._zoom_out_both())

    # ------------------------------------------------------------------
    # Zoom (buttons/keys act on both panels together, matching "reset both
    # views" in the matplotlib-only tool; scroll-wheel zoom is bound
    # per-canvas in ZoomPanController and only affects the panel under the
    # cursor).
    # ------------------------------------------------------------------
    def _zoom_in_both(self) -> None:
        self.zoom_fixed.zoom_in()
        self.zoom_moving.zoom_in()

    def _zoom_out_both(self) -> None:
        self.zoom_fixed.zoom_out()
        self.zoom_moving.zoom_out()

    def _reset_view(self) -> None:
        self.zoom_fixed.reset_view()
        self.zoom_moving.reset_view()

    # ------------------------------------------------------------------
    # Landmark logic (mirrors _select_landmarks_interactive_impl in
    # register/registration_core.py)
    # ------------------------------------------------------------------
    @staticmethod
    def _toolbar_active(toolbar) -> bool:
        return bool(getattr(toolbar, "mode", "") or "")

    def _is_paused(self) -> bool:
        return (
            self._manual_pause
            or self._toolbar_active(self.toolbar_fixed)
            or self._toolbar_active(self.toolbar_moving)
        )

    def _on_click_fixed(self, event) -> None:
        if self._finished or event.inaxes != self.ax_fixed or self._is_paused():
            return
        if getattr(event, "button", 1) != 1 or self._current != "fixed":
            return
        self.landmarks_fixed.append((event.xdata, event.ydata))
        self._add_artist(self.ax_fixed, self._artists_fixed, len(self.landmarks_fixed) - 1,
                          (event.xdata, event.ydata))
        self._current = "moving"
        self.canvas_fixed.draw_idle()
        self._refresh_titles()
        self._update_status()

    def _on_click_moving(self, event) -> None:
        if self._finished or event.inaxes != self.ax_moving or self._is_paused():
            return
        if getattr(event, "button", 1) != 1 or self._current != "moving":
            return
        self.landmarks_moving.append((event.xdata, event.ydata))
        self._add_artist(self.ax_moving, self._artists_moving, len(self.landmarks_moving) - 1,
                          (event.xdata, event.ydata))
        self._current = "fixed"
        self.canvas_moving.draw_idle()
        self._refresh_titles()
        self._update_status()

    def _add_artist(self, ax, artist_list, idx, pt) -> None:
        colors = plt.cm.tab10.colors
        c = colors[idx % 10]
        (line,) = ax.plot(
            pt[0], pt[1], "o", color=c, markersize=7, markeredgecolor="white", markeredgewidth=1.5
        )
        txt = ax.text(pt[0] + 5, pt[1] - 5, str(idx + 1), color=c, fontsize=9, fontweight="bold")
        artist_list.append((line, txt))

    def _remove_last_artist(self, artist_list) -> None:
        if not artist_list:
            return
        line, txt = artist_list.pop()
        for artist in (line, txt):
            try:
                artist.remove()
            except Exception:
                pass

    def _undo(self) -> None:
        if self._finished:
            return
        if self._current == "moving" and self.landmarks_fixed:
            self.landmarks_fixed.pop()
            self._remove_last_artist(self._artists_fixed)
            self._current = "fixed"
            self.canvas_fixed.draw_idle()
        elif self.landmarks_moving:
            self.landmarks_moving.pop()
            self._remove_last_artist(self._artists_moving)
            if len(self.landmarks_fixed) > len(self.landmarks_moving):
                self.landmarks_fixed.pop()
                self._remove_last_artist(self._artists_fixed)
                self.canvas_fixed.draw_idle()
            self._current = "fixed"
            self.canvas_moving.draw_idle()
        self._refresh_titles()
        self._update_status()

    def _toggle_pause(self) -> None:
        if self._finished:
            return
        self._manual_pause = not self._manual_pause
        self._update_status()

    def _toggle_help(self) -> None:
        self._help_visible = not self._help_visible
        if self._help_visible:
            self.help_label.pack(side=tk.BOTTOM, fill=tk.X)
        else:
            self.help_label.pack_forget()

    def _refresh_titles(self) -> None:
        if self._current == "fixed":
            self.ax_fixed.set_title("Fixed (next)", fontsize=10, fontweight="bold", color="blue")
            self.ax_moving.set_title("Moving", fontsize=10, fontweight="bold", color="black")
        else:
            self.ax_fixed.set_title("Fixed", fontsize=10, fontweight="bold", color="black")
            self.ax_moving.set_title("Moving (next)", fontsize=10, fontweight="bold", color="blue")

    def _update_status(self) -> None:
        if self._finished:
            return
        n = min(len(self.landmarks_fixed), len(self.landmarks_moving))
        if self._manual_pause:
            status = "PAUSED (manual)"
        elif self._toolbar_active(self.toolbar_fixed) or self._toolbar_active(self.toolbar_moving):
            status = "PAUSED (zoom/pan)"
        else:
            status = f"next: {'Fixed' if self._current == 'fixed' else 'Moving'}"
        self.status_var.set(f"{n} pairs  |  {status}")

    def _update_status_loop(self) -> None:
        """Keep the PAUSED (zoom/pan) indicator live even when the user is
        only interacting with the toolbar (no landmark click to trigger a
        refresh otherwise)."""
        if self._finished:
            return
        self._update_status()
        try:
            self.window.after(200, self._update_status_loop)
        except Exception:
            pass

    def _on_finish(self) -> None:
        if self._finished:
            return
        self._finished = True
        n = min(len(self.landmarks_fixed), len(self.landmarks_moving))
        self.landmarks_fixed = self.landmarks_fixed[:n]
        self.landmarks_moving = self.landmarks_moving[:n]
        if self.on_close:
            self.on_close()
        try:
            self.window.destroy()
        except Exception:
            pass

    # ------------------------------------------------------------------
    def get_landmarks(self) -> tuple[np.ndarray, np.ndarray]:
        fixed = np.array(self.landmarks_fixed) if self.landmarks_fixed else np.array([]).reshape(0, 2)
        moving = np.array(self.landmarks_moving) if self.landmarks_moving else np.array([]).reshape(0, 2)
        return fixed, moving


def select_landmarks_tk(
    fixed_image: np.ndarray,
    moving_image: np.ndarray,
    fixed_rgb: np.ndarray | None = None,
    fixed_cmap: str = "viridis",
    moving_cmap: str = "gray",
    title: str = "Landmark Selection",
) -> tuple[np.ndarray, np.ndarray]:
    """
    Open the Tkinter landmark-selection window and block until the user
    finishes (Finish button, 'q', or closing the window).

    Returns
    -------
    tuple
        (landmarks_fixed, landmarks_moving) as Nx2 arrays — same contract
        as BaseMultimodalRegistration.select_landmarks_interactive().
    """
    root = tk.Tk()
    root.withdraw()  # only the Toplevel window created below is shown
    gui = LandmarkGUI(
        root, fixed_image, moving_image, fixed_rgb=fixed_rgb,
        fixed_cmap=fixed_cmap, moving_cmap=moving_cmap, title=title,
    )
    root.wait_window(gui.window)
    landmarks = gui.get_landmarks()
    root.destroy()
    return landmarks


def select_landmarks_interactive_tk(reg) -> tuple[np.ndarray, np.ndarray]:
    """
    Drop-in Tkinter replacement for ``reg.select_landmarks_interactive()``.

    Same inputs, same effect (sets ``reg._landmarks_fixed`` /
    ``reg._landmarks_moving``), same return value — but opens the Tkinter
    GUI instead of a bare matplotlib figure.

    Parameters
    ----------
    reg : BaseMultimodalRegistration subclass instance
        Any registration object from the `register` package that has
        already had preprocess() called (so `moving_downsampled` exists).
    """
    from skimage import transform as sktransform

    fixed_img = reg.fixed_image
    moving_img = (
        reg.moving_downsampled
        if getattr(reg, "moving_downsampled", None) is not None
        else sktransform.resize(
            reg.moving_image, reg.fixed_shape, order=1, anti_aliasing=True, preserve_range=True
        )
    )
    fixed_rgb = getattr(reg, "fixed_rgb", None)

    landmarks_fixed, landmarks_moving = select_landmarks_tk(fixed_img, moving_img, fixed_rgb=fixed_rgb)
    reg._landmarks_fixed = landmarks_fixed
    reg._landmarks_moving = landmarks_moving
    return landmarks_fixed, landmarks_moving
