"""Module 3 — registration of extra image modalities onto the ST frame.

How it works
------------
1. Take a downscaled working copy of the fixed image (ST morphology by
   default) and of the moving image (H&E, IF, ...): a pyramid level when one
   exists, otherwise a block-mean downscale. Full-resolution pixels are never
   loaded, so whole-slide H&E fits in memory.
2. Estimate the transform with the ``register`` core
   (:class:`~multispace.registration._core.registration_core.BaseMultimodalRegistration`):
   intensity-based affine optimisation, phase correlation, SimpleITK,
   tissue-boundary matching, or landmarks (given, or picked in the Tkinter GUI).
3. Compose ``moving full-res px → moving working px → fixed working px →
   fixed full-res px → global`` into one 3x3 affine and attach it to the
   moving image as its transform into ``global``. Nothing is resampled:
   SpatialData applies the transform on read, plot and query.

The registration record (matrix, method, landmark residuals, quality metrics)
is stored in ``sdata.attrs['multispace']['registration'][moving]``.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np

from .._sdata import ContractError, get_meta, record_step
from ..constants import Attrs, Keys

logger = logging.getLogger(__name__)

__all__ = ["register_image", "RegistrationResult", "working_array", "get_registration"]

Method = Literal["affine", "phase", "sitk", "boundary", "landmarks", "gui"]


@dataclass
class RegistrationResult:
    moving: str
    fixed: str
    method: str
    #: 3x3 matrix mapping moving full-resolution pixel (x, y, 1) → global (x, y, 1).
    matrix: np.ndarray
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"fixed": self.fixed, "method": self.method, "matrix": self.matrix.tolist(), **self.details}


# ── image access ─────────────────────────────────────────────────────────────
def _levels(element):
    """[(DataArray c,y,x), ...] from full resolution down."""
    if hasattr(element, "children") and len(element.children):  # multiscale DataTree
        out = []
        for k in sorted(element.children, key=lambda s: int(s.replace("scale", "") or 0)):
            node = element[k]
            da_ = node.ds["image"] if "image" in node.ds else next(iter(node.ds.data_vars.values()))
            out.append(da_)
        return out
    return [element]


def working_array(element, max_side: int = 2000, channels: int | list[int] | str | None = None,
                  rgb_to_gray: bool = False, invert: bool = False):
    """Downscaled 2-D float array of an image element + its (fy, fx) factor.

    ``factor`` is full-resolution pixels per working pixel, so
    ``full = working * factor``.
    """
    levels = _levels(element)
    full = levels[0]
    H, W = int(full.sizes["y"]), int(full.sizes["x"])
    # coarsest level that is still >= max_side on its long edge
    chosen = levels[0]
    for lvl in levels:
        if max(int(lvl.sizes["y"]), int(lvl.sizes["x"])) >= max_side:
            chosen = lvl
    data = chosen.data
    n_c = int(chosen.sizes["c"])
    if rgb_to_gray and n_c >= 3:
        rgb = data[:3].astype("float32")
        img = 0.2125 * rgb[0] + 0.7154 * rgb[1] + 0.0721 * rgb[2]
    elif channels is None or channels == "mean":
        img = data.astype("float32").mean(axis=0) if n_c > 1 else data[0].astype("float32")
    elif isinstance(channels, int):
        img = data[channels].astype("float32")
    else:
        img = data[list(channels)].astype("float32").mean(axis=0)
    h, w = img.shape
    k = max(1, int(np.ceil(max(h, w) / max_side)))
    if k > 1:
        import dask.array as da

        img = da.from_array(img) if isinstance(img, np.ndarray) else img
        img = da.coarsen(np.mean, img, {0: k, 1: k}, trim_excess=True)
    img = np.asarray(img.compute() if hasattr(img, "compute") else img, dtype=np.float64)
    if invert:
        img = img.max() - img
    factor = (H / img.shape[0], W / img.shape[1])
    return img, factor


def _to_global_matrix(element, coordinate_system: str) -> np.ndarray:
    from spatialdata.transformations import get_transformation

    t = get_transformation(element, to_coordinate_system=coordinate_system)
    return np.asarray(t.to_affine_matrix(input_axes=("x", "y"), output_axes=("x", "y")), dtype=float)


def _scale(fx: float, fy: float) -> np.ndarray:
    return np.diag([fx, fy, 1.0])


# ── main entry point ─────────────────────────────────────────────────────────
def register_image(
    sdata,
    moving: str,
    fixed: str = Keys.MORPHOLOGY,
    *,
    method: Method = "affine",
    coordinate_system: str = Keys.COORDINATE_SYSTEM,
    max_side: int = 2000,
    fixed_channel: int | list[int] | str | None = 0,
    moving_channel: int | list[int] | str | None = None,
    moving_is_rgb: bool | None = None,
    invert_moving: bool | None = None,
    pre_rotation: int | str = 0,
    metric: str = "nmi",
    include_scale: bool = True,
    landmarks: tuple[np.ndarray, np.ndarray] | None = None,
    transform_type: str = "affine",
    preprocess: dict | None = None,
    method_kwargs: dict | None = None,
    compute_quality: bool = True,
) -> RegistrationResult:
    """Register ``sdata.images[moving]`` onto ``sdata.images[fixed]``.

    Parameters
    ----------
    moving, fixed
        Image element names. ``fixed`` must already be in ``coordinate_system``.
    method
        ``"affine"`` (intensity optimisation, default), ``"phase"`` (translation
        only), ``"sitk"`` (SimpleITK, needs ``multispace[registration]``),
        ``"boundary"`` (tissue outline), ``"landmarks"`` (pass ``landmarks``) or
        ``"gui"`` (pick landmarks in the Tkinter window, needs a display).
    fixed_channel, moving_channel
        Channel index / list (averaged) / ``"mean"``. ST default: channel 0 (DAPI).
    moving_is_rgb, invert_moving
        Default from the image's modality: H&E is converted to grayscale and
        inverted so nuclei are bright like DAPI.
    landmarks
        ``(fixed_xy, moving_xy)``, each ``(N, 2)`` in **full-resolution pixel**
        ``(x, y)`` coordinates of the respective image.
    preprocess
        kwargs for ``BaseMultimodalRegistration.preprocess`` (``clahe``, ``gaussian_sigma``).
    """
    from spatialdata.transformations import Affine, get_transformation, set_transformation

    if moving not in sdata.images:
        raise ContractError(f"No image '{moving}'. Add it with multispace.io.add_image().")
    if fixed not in sdata.images:
        raise ContractError(f"No fixed image '{fixed}'. Available: {list(sdata.images)}")
    fixed_el, moving_el = sdata.images[fixed], sdata.images[moving]
    if coordinate_system not in get_transformation(fixed_el, get_all=True):
        raise ContractError(f"Fixed image '{fixed}' is not in coordinate system '{coordinate_system}'.")

    modality = get_meta(sdata).get("images", {}).get(moving, {}).get("modality", "generic")
    if moving_is_rgb is None:
        moving_is_rgb = modality == "he"
    if invert_moving is None:
        invert_moving = modality == "he"

    fixed_ws, (ffy, ffx) = working_array(fixed_el, max_side, channels=fixed_channel)
    moving_ws, (mfy, mfx) = working_array(moving_el, max_side, channels=moving_channel,
                                          rgb_to_gray=moving_is_rgb, invert=invert_moving)
    T_fixed = _to_global_matrix(fixed_el, coordinate_system)
    details: dict[str, Any] = {"modality": modality, "max_side": max_side,
                               "fixed_working_shape": list(fixed_ws.shape),
                               "moving_working_shape": list(moving_ws.shape)}

    if method == "landmarks":
        if landmarks is None:
            raise ValueError("method='landmarks' needs landmarks=(fixed_xy, moving_xy).")
        M, lm = _from_landmarks(*landmarks, transform_type=transform_type)
        details.update(lm)
        matrix = T_fixed @ M
    else:
        reg = _make_core(fixed_ws, moving_ws, pre_rotation)
        reg.preprocess(**(preprocess or {}))
        kw = dict(method_kwargs or {})
        if method == "affine":
            out = reg.register_affine_optimization(metric=metric, include_scale=include_scale, **kw)
        elif method == "phase":
            out = reg.register_phase_correlation()
        elif method == "sitk":
            out = reg.register_sitk(**kw)
        elif method == "boundary":
            out = reg.register_boundary_based(**{"visualize": False, **kw})
        elif method == "gui":
            from .gui.landmark_gui import select_landmarks_interactive_tk

            select_landmarks_interactive_tk(reg)
            out = reg.register_landmarks(transform_type=transform_type)
        else:
            raise ValueError(f"Unknown registration method '{method}'.")
        M_ws = reg.get_full_transform_matrix()  # moving working px → fixed working px
        if M_ws is None:
            raise RuntimeError(f"Registration method '{method}' produced no affine transform.")
        # moving full → moving working → fixed working → fixed full → global
        matrix = T_fixed @ _scale(ffx, ffy) @ M_ws @ _scale(1 / mfx, 1 / mfy)
        details["core_output"] = {k: v for k, v in out.items() if isinstance(v, (int, float, str, list, tuple, np.ndarray, np.generic))}
        if compute_quality:
            try:
                details["quality"] = reg.compute_registration_quality().to_dict()
            except Exception as err:  # quality is informative only
                logger.warning("Could not compute registration quality: %s", err)

    affine = Affine(matrix, input_axes=("x", "y"), output_axes=("x", "y"))
    set_transformation(moving_el, affine, to_coordinate_system=coordinate_system)
    result = RegistrationResult(moving=moving, fixed=fixed, method=method, matrix=matrix, details=details)
    get_meta(sdata).setdefault(Attrs.REGISTRATION, {})[moving] = _jsonable(result.to_dict())
    record_step(sdata, f"register:{moving}", {"fixed": fixed, "method": method, "max_side": max_side})
    logger.info("Registered '%s' → '%s' with %s", moving, fixed, method)
    return result


def get_registration(sdata, moving: str) -> dict | None:
    """Stored registration record for ``moving`` (or None)."""
    return get_meta(sdata).get(Attrs.REGISTRATION, {}).get(moving)


def _make_core(fixed_ws, moving_ws, pre_rotation):
    from ._core.registration_core import BaseMultimodalRegistration

    class _Registration(BaseMultimodalRegistration):
        FIXED_IMAGE_NAME = "fixed"
        MOVING_IMAGE_NAME = "moving"

    return _Registration(fixed_array=fixed_ws, moving_array=moving_ws, pre_rotation=pre_rotation)


def _from_landmarks(fixed_xy, moving_xy, transform_type="affine"):
    from skimage.transform import AffineTransform, EuclideanTransform, ProjectiveTransform, SimilarityTransform

    classes = {"affine": AffineTransform, "similarity": SimilarityTransform,
               "euclidean": EuclideanTransform, "projective": ProjectiveTransform}
    if transform_type not in classes:
        raise ValueError(f"transform_type must be one of {sorted(classes)}")
    if transform_type == "projective":
        raise ValueError("A projective transform cannot be stored as a SpatialData affine; use 'affine'.")
    fixed_xy, moving_xy = np.asarray(fixed_xy, float), np.asarray(moving_xy, float)
    if fixed_xy.shape != moving_xy.shape or fixed_xy.ndim != 2 or fixed_xy.shape[1] != 2:
        raise ValueError("landmarks must be two (N, 2) arrays of equal shape.")
    cls = classes[transform_type]
    if hasattr(cls, "from_estimate"):  # scikit-image >= 0.26
        t = cls.from_estimate(moving_xy, fixed_xy)
        ok = bool(t)
    else:  # pragma: no cover - older scikit-image
        t = cls()
        ok = t.estimate(moving_xy, fixed_xy)
    if not ok:
        raise RuntimeError("Landmark transform estimation failed (degenerate points?).")
    res = np.linalg.norm(t(moving_xy) - fixed_xy, axis=1)
    return t.params, {"n_landmarks": int(len(fixed_xy)), "landmark_mean_error_px": float(res.mean()),
                      "landmark_max_error_px": float(res.max()), "transform_type": transform_type}


def _jsonable(d):
    from .._sdata import _jsonable as j

    return j(d)
