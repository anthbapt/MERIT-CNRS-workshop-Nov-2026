"""Module 2 — resegmentation of ST data (Cellpose + optional Proseg).

``resegment`` drives the original platform classes kept in
:mod:`multispace.segmentation._legacy` (``pip install 'multispace[seg]'``).
"""
from .api import check_atera_origin, resegment, resegment_atera

__all__ = ["resegment", "resegment_atera", "check_atera_origin"]
