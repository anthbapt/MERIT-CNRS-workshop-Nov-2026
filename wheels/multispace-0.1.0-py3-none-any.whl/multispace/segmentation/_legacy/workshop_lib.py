import warnings
import spatialdata as sd
import pandas as pd
from tqdm import tqdm
import matplotlib.pyplot as plt
import seaborn as sns
import scanpy as sc
import numpy as np
from scipy import sparse
from scipy.stats import gmean
import mygene
from sklearn.neighbors import NearestNeighbors
import anndata as ad

def get_custom_palette(extended=False):
    """
    Get custom color palette for cell type visualization.
    
    Parameters
    ----------
    extended : bool, default False
        If True, return extended palette with additional cell types.
        If False, return base palette.
        
    Returns
    -------
    dict
        Dictionary mapping cell type names to hex color codes.
        
    Examples
    --------
    >>> palette = get_custom_palette()
    >>> palette['T cell']
    '#5b5bd6'
    
    >>> extended_palette = get_custom_palette(extended=True)
    >>> extended_palette['M1 Macrophage']
    '#d62728'
    """
    
    CUSTOM_PALETTE = {
        "Myeloid cell": "#e6550d",
        "T cell": "#5b5bd6",
        "NK cell": "#a63603",
        "B cell": "#984ea3",
        "Plasmacytoid dendritic cell": "#20b2aa",
        "Fibroblast": "#d8b365",
        "Pericyte": "#67a9cf",
        "Endothelial cell": "#66c2a5",
        "Epithelial cell": "#636363",
        "Megakaryocyte": "#fb9a99",
        "Mast cell": "#ffd92f",
        "Malignant cell": "#999999"
    }
    
    if extended:
        CUSTOM_PALETTE_EXTENDED = {
            **CUSTOM_PALETTE,
            "M1 Macrophage": "#d62728",
            "M2 Macrophage": "#ff7f0e",
            "Pan-Myeloid": "#e6550d",
            "Adipocyte": "#f4a582",
        }
        return CUSTOM_PALETTE_EXTENDED
    
    return CUSTOM_PALETTE


def get_custom_palette_wu(extended=False):
    """
    Get custom color palette for cell type visualization.
    
    Parameters
    ----------
    extended : bool, default False
        If True, return extended palette with additional cell types.
        If False, return base palette.
        
    Returns
    -------
    dict
        Dictionary mapping cell type names to hex color codes.
        
    Examples
    --------
    >>> palette = get_custom_palette_wu()
    >>> palette['T cell']
    '#5b5bd6'
    
    >>> extended_palette = get_custom_palette_wu(extended=True)
    >>> extended_palette['CD4-positive, alpha-beta T cell']
    '#4a90e2'
    """
    
    CUSTOM_PALETTE = {
        # T cells - shades of blue/purple
        "T cell": "#5b5bd6",
        "CD4-positive, alpha-beta T cell": "#4a90e2",
        "CD8-positive, alpha-beta T cell": "#7b68ee",
        "mature NK T cell": "#9370db",
        
        # NK cells - dark orange/red
        "natural killer cell": "#a63603",
        
        # B cells - purple shades
        "B cell": "#984ea3",
        "naive B cell": "#ab82c5",
        "memory B cell": "#8b6ba8",
        "plasmablast": "#c77ddb",
        
        # Myeloid cells - orange/red shades
        "myeloid cell": "#e6550d",
        "macrophage": "#d62728",
        "monocyte": "#ff7f0e",
        
        # Fibroblasts - tan/brown
        "fibroblast of breast": "#d8b365",
        
        # Pericytes - blue-gray
        "pericyte": "#67a9cf",
        
        # Endothelial cells - teal/green
        "endothelial cell": "#66c2a5",
        "endothelial cell of lymphatic vessel": "#5aae9e",
        
        # Epithelial cells - gray shades
        "mammary gland epithelial cell": "#636363",
        "luminal epithelial cell of mammary gland": "#7f7f7f",
        "basal-myoepithelial cell of mammary gland": "#4a4a4a",
    }
    
    if extended:
        CUSTOM_PALETTE_EXTENDED = {
            **CUSTOM_PALETTE,
            # Add any future extended cell types here
            "M1 Macrophage": "#d62728",
            "M2 Macrophage": "#ff7f0e",
            "Pan-Myeloid": "#e6550d",
            "adipocyte": "#f4a582",
        }
        return CUSTOM_PALETTE_EXTENDED
    
    return CUSTOM_PALETTE



def normalize_spatial(adata, method='library_size', target_sum=1e4, inplace=True, **kwargs):
    """
    Unified normalization function for spatial transcriptomics data.
    Drop-in replacement for sc.pp.normalize_total() with additional methods.
    
    Parameters:
    -----------
    adata : AnnData
        Annotated data matrix with cells x genes
    method : str
        Normalization method. Options:
        - 'library_size': Standard total count normalization (default)
        - 'sctransform': Pearson residuals (regularized negative binomial)
        - 'deseq2': DESeq2-style size factor normalization
        - 'tmm': Trimmed Mean of M-values (edgeR)
        - 'cell_area': Normalize by cell volume/area (spatial-specific)
        - 'none': No normalization (returns copy)
    target_sum : float
        Target sum for library_size normalization (default: 1e4)
    inplace : bool
        Whether to modify adata in place or return a copy
    **kwargs : dict
        Additional parameters for specific methods:
        - M_trim, A_trim: for TMM
        - area_key: for cell_area
        - theta: for sctransform
    
    Returns:
    --------
    AnnData or None
        Returns normalized AnnData if inplace=False, else None
    
    Examples:
    ---------
    # Your existing code:
    sc.pp.normalize_total(adata, inplace=True, target_sum=1e4)
    
    # Replace with:
    normalize_spatial(adata, method='library_size', target_sum=1e4, inplace=True)
    
    # Or try other methods:
    normalize_spatial(adata, method='deseq2', inplace=True)
    normalize_spatial(adata, method='tmm', inplace=True)
    normalize_spatial(adata, method='cell_area', inplace=True)
    """
    
    # Handle inplace
    adata_norm = adata if inplace else adata.copy()
    
    # Store raw counts if not already stored
    if adata_norm.raw is None:
        adata_norm.raw = adata_norm.copy()
    
    # Apply selected normalization method
    if method == 'library_size':
        sc.pp.normalize_total(adata_norm, target_sum=target_sum, inplace=True)
        adata_norm.uns['normalization'] = {
            'method': 'library_size',
            'target_sum': target_sum
        }
    
    elif method == 'sctransform':
        _sctransform_normalization(adata_norm, **kwargs)
        adata_norm.uns['normalization'] = {
            'method': 'sctransform',
            'theta': kwargs.get('theta', 100)
        }
    
    elif method == 'deseq2':
        _deseq2_normalization(adata_norm)
        adata_norm.uns['normalization'] = {'method': 'deseq2'}
    
    elif method == 'tmm':
        _tmm_normalization(adata_norm, **kwargs)
        adata_norm.uns['normalization'] = {
            'method': 'tmm',
            'M_trim': kwargs.get('M_trim', 0.3),
            'A_trim': kwargs.get('A_trim', 0.05)
        }
    
    elif method == 'cell_area':
        _cell_area_normalization(adata_norm, **kwargs)
        adata_norm.uns['normalization'] = {
            'method': 'cell_area',
            'area_key': kwargs.get('area_key', 'cell_area')
        }
    
    elif method == 'none':
        adata_norm.uns['normalization'] = {'method': 'none'}
    
    else:
        raise ValueError(f"Unknown normalization method: {method}. "
                        f"Choose from: library_size, sctransform, deseq2, tmm, cell_area, none")
    
    return None if inplace else adata_norm


# Internal helper functions
def _sctransform_normalization(adata, theta=100, clip=None):
    """
    Internal: scTransform normalization
    """
    
    sc.experimental.pp.normalize_pearson_residuals(
        adata,
        theta=theta,
        clip=clip,
        inplace=True
    )


def _deseq2_normalization(adata):
    """
    Internal: DESeq2 normalization
    """
    
    if sparse.issparse(adata.X):
        counts = adata.X.toarray()
    else:
        counts = adata.X.copy()
    
    def geometric_mean_nonzero(x):
        x_nonzero = x[x > 0]
        if len(x_nonzero) == 0:
            return 0
        
        return gmean(x_nonzero)
    
    # Calculate geometric mean per gene
    gene_geom_means = np.apply_along_axis(geometric_mean_nonzero, 0, counts)
    
    # Calculate size factors per cell
    size_factors = np.zeros(counts.shape[0])
    
    for i in range(counts.shape[0]):
        mask = gene_geom_means > 0
        ratios = counts[i, mask] / gene_geom_means[mask]
        size_factors[i] = np.median(ratios[ratios > 0]) if np.any(ratios > 0) else 1.0
    
    # Normalize
    normalized_counts = counts / size_factors[:, np.newaxis]
    
    adata.X = normalized_counts
    adata.obs['size_factors_deseq2'] = size_factors


def _tmm_normalization(adata, ref_sample=None, M_trim=0.3, A_trim=0.05):
    """
    Internal: TMM normalization
    """
    
    if sparse.issparse(adata.X):
        counts = adata.X.toarray()
    else:
        counts = adata.X.copy()
    
    # Add pseudocount
    counts = counts + 1
    lib_sizes = counts.sum(axis=1)
    
    # Select reference
    if ref_sample is None:
        ref_sample = np.argsort(lib_sizes)[len(lib_sizes) // 2]
    
    ref_counts = counts[ref_sample, :]
    tmm_factors = np.ones(counts.shape[0])
    
    for i in range(counts.shape[0]):
        if i == ref_sample:
            continue
        
        # M and A values
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            M = np.log2((counts[i, :] / lib_sizes[i]) / 
                       (ref_counts / lib_sizes[ref_sample]))
            A = 0.5 * (np.log2(counts[i, :] / lib_sizes[i]) + 
                      np.log2(ref_counts / lib_sizes[ref_sample]))
        
        # Filter valid genes
        mask = (counts[i, :] > 0) & (ref_counts > 0) & np.isfinite(M) & np.isfinite(A)
        M = M[mask]
        A = A[mask]
        
        if len(M) == 0:
            continue
        
        # Trim
        M_sorted_idx = np.argsort(M)
        A_sorted_idx = np.argsort(A)
        
        n_keep = max(1, int(len(M) * (1 - 2 * M_trim)))
        M_keep_start = int(len(M) * M_trim)
        M_keep_idx = M_sorted_idx[M_keep_start:M_keep_start + n_keep]
        
        n_keep_A = max(1, int(len(A) * (1 - 2 * A_trim)))
        A_keep_start = int(len(A) * A_trim)
        A_keep_idx = A_sorted_idx[A_keep_start:A_keep_start + n_keep_A]
        
        keep_idx = np.intersect1d(M_keep_idx, A_keep_idx)
        
        if len(keep_idx) > 0:
            # Calculate weights
            counts_masked = counts[i, :][mask][keep_idx]
            ref_masked = ref_counts[mask][keep_idx]
            
            weights = (lib_sizes[ref_sample] - ref_masked) / \
                     (lib_sizes[ref_sample] * ref_masked) + \
                     (lib_sizes[i] - counts_masked) / \
                     (lib_sizes[i] * counts_masked)
            
            weights[weights <= 0] = 1e-10  # Avoid division by zero
            
            tmm_factors[i] = 2 ** np.average(M[keep_idx], weights=1/weights)
    
    # Normalize
    scaling_factors = tmm_factors * lib_sizes / np.mean(tmm_factors * lib_sizes)
    normalized_counts = (counts - 1) / scaling_factors[:, np.newaxis]
    
    adata.X = normalized_counts
    adata.obs['tmm_factors'] = tmm_factors
    adata.obs['scaling_factors_tmm'] = scaling_factors


def _cell_area_normalization(adata, area_key='cell_area'):
    """
    Internal: Cell area normalization
    """
    
    if area_key not in adata.obs.columns:
        # Estimate cell area from spatial coordinates
        if 'spatial' in adata.obsm:
            coords = adata.obsm['spatial']
            
            # Use local density as proxy for cell area
            nbrs = NearestNeighbors(n_neighbors=min(10, len(coords)), radius=50).fit(coords)
            distances, _ = nbrs.kneighbors(coords)
            cell_area = np.mean(distances, axis=1) ** 2
            
            adata.obs[area_key] = cell_area
            print(f"Estimated cell area from spatial coordinates (stored in obs['{area_key}'])")
            
        else:
            raise ValueError(f"No '{area_key}' in obs and no 'spatial' in obsm. "
                           f"Cannot estimate cell area.")
    
    area = adata.obs[area_key].values
    
    if sparse.issparse(adata.X):
        counts = adata.X.toarray()
        
    else:
        counts = adata.X.copy()
    
    # Normalize
    normalized_counts = counts / area[:, np.newaxis]
    adata.X = normalized_counts


# Convenience function to compare methods
def compare_normalizations(adata, methods=['library_size', 'deseq2', 'tmm'], 
                          target_sum=1e4, return_dict=False):
    """
    Compare multiple normalization methods
    
    Parameters:
    -----------
    adata : AnnData
        Input data
    methods : list
        List of normalization methods to compare
    target_sum : float
        Target sum for library_size method
    return_dict : bool
        If True, returns dict of AnnData objects. If False, returns concatenated AnnData.
    
    Returns:
    --------
    dict or AnnData
        Normalized data for comparison
    """
    
    results = {}
    
    for method in methods:
        print(f"Applying {method} normalization...")
        results[method] = normalize_spatial(
            adata, 
            method=method, 
            target_sum=target_sum, 
            inplace=False
        )
        results[method].obs['normalization_method'] = method
    
    if return_dict:
        return results
    
    else:
        # Concatenate for easy comparison
        adata_concat = ad.concat(results.values(), label='norm_method', keys=results.keys())
        
        return adata_concat
    

def load_core_data(metadata_path: str, zarr_dir: str) -> dict:
    """
    Load breast tissue cores from Zarr files and compute the
    cell-to-nucleus area ratio for each cell.

    This function:
      1. Reads a metadata CSV file that lists available tissue cores.
      2. Filters rows where `tissue_type` equals `"breast"`.
      3. For each selected core:
         * Reads the corresponding Zarr dataset from the provided directory.
         * Computes a new column `cell_nucleus_ratio` in the `.obs` table
           as `cell_area / nucleus_area`.

    Args:
        metadata_path (str):
            Path to a CSV file containing metadata for all tissue cores.
            The CSV must include at least the columns:
            - `tissue_type`: Tissue type of the core.
            - `ST_ID`: Unique identifier for each spatial core.
        zarr_dir (str):
            Path to the directory containing the Zarr files. Each breast
            core is expected to be stored as `raw_<ST_ID>.zarr`.

    Returns:
        dict:
            A dictionary mapping each breast core's `ST_ID` (str) to its
            loaded spatial data object. For each entry, the table
            `core_sdata[ST_ID]['table'].obs` contains an additional column
            `cell_nucleus_ratio`.

    Raises:
        FileNotFoundError:
            If the metadata CSV or any expected Zarr file does not exist.
        KeyError:
            If required columns (`tissue_type`, `ST_ID`) are missing from
            the metadata CSV.
        AttributeError:
            If a Zarr object does not provide the expected structure
            (e.g., missing `'table'` or `.obs`).
    """

    metadata = pd.read_csv(metadata_path)
    core_sdata = {}

    for _, row in tqdm(metadata.iterrows(), total=len(metadata)):
        if row.tissue_type == 'breast':
            st_id = row.ST_ID
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                print(zarr_dir + f"/{st_id}.zarr")
                if zarr_dir == "raw_cores":
                    core_sdata[st_id] = sd.read_zarr(zarr_dir + f"/raw_{st_id}.zarr")
                    
                else:
                    core_sdata[st_id] = sd.read_zarr(zarr_dir + f"/updated_raw_{st_id}.zarr")

    return core_sdata


def genename_to_ensg_mygeneinfo(gene_names):
    """
    Map gene symbols to Ensembl gene IDs using the MyGene.info API.

    This function queries MyGene.info with a list of gene symbols (e.g., "TP53", "BRCA1") 
    and retrieves their corresponding Ensembl gene identifiers (e.g., "ENSG00000141510").

    Args:
        gene_names (list[str]): 
            A list of gene symbols to query.

    Returns:
        dict[str, str | None]: 
            A dictionary mapping each input gene symbol to its corresponding 
            Ensembl gene ID. If a gene could not be matched, its value is `None`.

    Raises:
        HTTPError: If there is a network issue or API request failure.
        ValueError: If the query response from MyGene.info is malformed.
    """
    
    mg = mygene.MyGeneInfo()
    results = mg.querymany(gene_names, scopes='symbol', fields='ensembl.gene', species='human', returnall=True)
    gene_to_ensg = {}
    
    for res in results['out']:
        gene = res['query']
        ensembl = res.get('ensembl')
        if isinstance(ensembl, list):
            gene_to_ensg[gene] = ensembl[0]['gene']  
            
        elif isinstance(ensembl, dict):
            gene_to_ensg[gene] = ensembl['gene']
            
        else:
            gene_to_ensg[gene] = None 
    
    return gene_to_ensg


def genename_to_ensg(xenium_table):
    """
    Map gene symbols to Ensembl gene IDs from a Xenium data table.

    This function extracts the mapping between `gene_name` and `gene_id` 
    columns in a Xenium expression table (e.g., a pandas DataFrame or 
    similar structure) and returns a dictionary mapping gene symbols 
    to Ensembl IDs.

    Args:
        xenium_table (pandas.DataFrame): 
            A table containing at least two columns: 
            - 'gene_name': Gene symbols.
            - 'gene_id': Corresponding Ensembl gene IDs.

    Returns:
        dict[str, str]: 
            A dictionary mapping gene symbols to Ensembl gene IDs.
    """
    
    genes = list(xenium_table['gene_name'])
    ensg = list(xenium_table['gene_id'])

    gene_to_ensg = {}
    
    for k in range(len(genes)):
        gene_to_ensg[genes[k]] = ensg[k]
    
    return gene_to_ensg



def annotate_cells_with_marker_scores(adata, marker_dict, score_name='cell_type'):
    """
    Annotate cells based on marker gene scores.
    
    Parameters:
    -----------
    adata : AnnData
        Annotated data matrix with cells × genes
    marker_dict : dict
        Dictionary with cell types as keys and lists of marker genes as values
    score_name : str
        Name for the annotation column (default: 'cell_type')
    
    Returns:
    --------
    adata : AnnData
        Updated AnnData object with cell type annotations
    """
    
    print("=== Biomarker Scoring ===")
    
    score_columns = []
    
    # Score each cell type's marker genes
    for cell_type, markers in marker_dict.items():
        score_col = f"{cell_type}_score"
        
        # Filter markers that exist in the dataset
        available_markers = [gene for gene in markers if gene in adata.var_names]
        
        # Score genes if we have any available markers
        if available_markers:
            sc.tl.score_genes(adata, gene_list=available_markers, 
                            score_name=score_col, use_raw=False)
            score_columns.append(score_col)
            print(f"{cell_type:30s}: {len(available_markers):3d}/{len(markers):3d} markers")
    
    # Assign cell type based on highest score
    if score_columns:
        # Create a dataframe with all scores
        scores_df = adata.obs[score_columns].copy()
        scores_df.columns = [col.replace('_score', '') for col in score_columns]
        
        # Assign cell type with highest score
        adata.obs[score_name] = scores_df.idxmax(axis=1)
        
        # Store the maximum score for confidence
        adata.obs[f'{score_name}_confidence'] = scores_df.max(axis=1)
        
        # Calculate score differences (margin between top 2 scores)
        sorted_scores = np.sort(scores_df.values, axis=1)
        if sorted_scores.shape[1] >= 2:
            adata.obs[f'{score_name}_margin'] = sorted_scores[:, -1] - sorted_scores[:, -2]
        
        print("Biomarker predictions:")
        for ct, count in adata.obs[score_name].value_counts().head(5).items():
            pct = count / len(adata) * 100
            print(f"{ct:30s}: {count:5d} ({pct:5.2f}%)")
            
        if len(adata.obs[score_name].unique()) > 5:
            print(f" and {len(adata.obs[score_name].unique()) - 5} more cell types")
        
    return adata


def compare_and_reassign_cell_types(core_adata, biomarker_adata,
                                    target_cell_types=['T cell', 'B cell'],
                                    confidence_threshold=0.6,
                                    biomarker_confidence_threshold=0.3):
    """
    Compare CellTypist predictions with biomarker predictions for specific cell types.
    
    Parameters:
    -----------
    core_adata : AnnData
        Original data with CellTypist predictions
    biomarker_adata : AnnData
        Data with biomarker predictions
    target_cell_types : list
        Cell types to consider for reassignment
    confidence_threshold : float
        CellTypist confidence threshold
    biomarker_confidence_threshold : float
        Biomarker confidence threshold
        
    Returns:
    --------
    adata_refined : AnnData
        Refined annotations
    """
    
    # Create refined dataset (copy from original)
    adata_refined = core_adata.copy()
    adata_refined.obs['cell_type'] = core_adata.obs['cell_type'].astype(str)
    
    # Track changes
    n_changed = 0
    changes = []
    
    # Check each target cell type
    for cell_type in target_cell_types:
        # Get cells of this type with low CellTypist confidence
        mask = (
            (core_adata.obs['cell_type'] == cell_type) &
            (core_adata.obs['conf_score'] < confidence_threshold)
        )
        
        if mask.sum() == 0:
            continue
        
        # Get biomarker predictions for these cells
        biomarker_preds = biomarker_adata.obs.loc[mask, 'cell_type']
        biomarker_conf = biomarker_adata.obs.loc[mask, 'cell_type_confidence']
        
        # Reassign cells with high biomarker confidence
        high_biomarker_conf = biomarker_conf > biomarker_confidence_threshold

            
        cells_to_reassign = biomarker_preds[high_biomarker_conf].index
        
        if len(cells_to_reassign) > 0:
            # Perform reassignment
            adata_refined.obs.loc[cells_to_reassign, 'cell_type'] = biomarker_preds.loc[cells_to_reassign].values
            n_changed += len(cells_to_reassign)
            
            # Track changes
            for new_type in biomarker_preds.loc[cells_to_reassign].unique():
                count = (biomarker_preds.loc[cells_to_reassign] == new_type).sum()
                changes.append(f"{cell_type:25s} → {new_type:25s}: {count:4d} cells")
    
    # Convert back to categorical
    all_categories = sorted(adata_refined.obs['cell_type'].unique())
    adata_refined.obs['cell_type'] = pd.Categorical(
        adata_refined.obs['cell_type'],
        categories=all_categories
    )
    
    # Print summary
    print("Reassignment summary:")
    print(f"Target cell types: {', '.join(target_cell_types)}")
    print(f"Cells reassigned: {n_changed}")
    
    if changes:
        print("Changes made:")
        for change in changes:
            print(change)
    
    return adata_refined


def save_figure(filename, OUTPUT_DIR, dpi=300):
    """
    Save figure to output directory with consistent settings.
    """
    
    filepath = OUTPUT_DIR / filename
    plt.savefig(filepath, dpi=dpi, bbox_inches='tight')
    print(f"Saved: {filepath}")


def create_marker_dict(biomarker_df, palette):
    """
    Create marker dictionary from biomarker dataframe.
    """
    
    marker_dict = {}
    visualization_cell_types = []
    excluded_cell_types = []
    
    for cell_type in biomarker_df.columns:
        biomarkers = biomarker_df[biomarker_df[cell_type] == 1].index.tolist()
        marker_dict[cell_type] = biomarkers
        
        if cell_type in palette:
            visualization_cell_types.append(cell_type)
            print(f"{cell_type:30s}: {len(biomarkers):3d} markers")
            
        else:
            excluded_cell_types.append(cell_type)
            print(f"{cell_type:30s}: {len(biomarkers):3d} markers (not in palette)")
    
    return marker_dict, visualization_cell_types, excluded_cell_types


def plot_matrix_visualizations(adata, markers_df, groupby_column, OUTPUT_DIR):
    """
    Create matrix plots for gene expression by category and cell type.
    """
    
    # Matrix plot by category
    category_dict = markers_df.groupby('Category')['Gene_Symbol_Resolved'].apply(list).to_dict()
    fig, ax = plt.subplots(1, 1, figsize=(10, 5))
    sc.pl.matrixplot(adata, category_dict, groupby_column,
                     dendrogram=True, cmap="Blues", ax=ax, show=False)
    save_figure(f"genes_by_category_{groupby_column}.png", OUTPUT_DIR)
    
    # Matrix plot by cell type
    celltype_dict = markers_df.groupby('Cell_Type')['Gene_Symbol_Resolved'].apply(list).to_dict()
    fig, ax = plt.subplots(1, 1, figsize=(10, 5))
    sc.pl.matrixplot(adata, celltype_dict, groupby_column,
                     dendrogram=True, cmap="Blues", ax=ax, show=False)
    save_figure(f"genes_by_celltype_{groupby_column}.png", OUTPUT_DIR)


def plot_celltype_distribution(adata, column, OUTPUT_DIR, suffix="", palette=None):
    """
    Plot cell type distribution as stacked bar chart with consistent colors.
    """
    
    counts = adata.obs[column].value_counts()
    counts_df = counts.to_frame().T
    
    fig, ax = plt.subplots(1, 1, figsize=(6, 3))
    
    # Use provided palette or default to custom_palette_extended
    if palette is None:
        palette = get_custom_palette(extended=False)
    
    # Create color list matching the cell types in counts_df
    colors = [palette.get(ct, '#999999') for ct in counts_df.columns]
    
    counts_df.plot(kind='bar', stacked=True, color=colors, ax=ax)
    plt.legend(title='Cell Type', bbox_to_anchor=(1.05, 1), fontsize=6)
    plt.xticks([])
    plt.ylabel('Cells')
    plt.tight_layout()
    save_figure(f"celltype_distribution{suffix}.png", OUTPUT_DIR)


def save_confidence_statistics(adata, OUTPUT_DIR):
    """
    Calculate and save confidence statistics by cell type.
    """
    
    df = adata.obs[['conf_score', 'cell_type']].copy()
    mean_conf = df.groupby('cell_type')['conf_score'].mean().reset_index()
    mean_conf = mean_conf.sort_values('conf_score', ascending=False)
    mean_conf.to_csv(OUTPUT_DIR, index=False)
    
    print("CellTypist confidence by cell type:")
    for _, row in mean_conf.head(5).iterrows():
        print(f"{row['cell_type']:30s}: {row['conf_score']:.3f}")
        
    if len(mean_conf) > 5:
        print(f" and {len(mean_conf)-5} more")
    
    return mean_conf


def perform_qc_and_filtering(adata, min_counts=50):
    """
    Perform quality control and filtering on AnnData object.
    """
    
    # Calculate QC metrics
    top_genes = (10, 20, 50, 150) if len(adata.var_names) > 150 else (10, 20, 50)
    sc.pp.calculate_qc_metrics(adata, percent_top=top_genes, inplace=True)
    
    # Control probe statistics
    total_counts = adata.obs["total_counts"].sum()
    cprobes = (adata.obs["control_probe_counts"].sum() / total_counts * 100)
    cwords = (adata.obs["control_codeword_counts"].sum() / total_counts * 100)
    
    print(f"Control probe %: {cprobes:.2f}")
    print(f"Control codeword %: {cwords:.2f}")
    
    # Filter
    sc.pp.filter_cells(adata, min_counts=min_counts)
    sc.pp.filter_genes(adata, min_cells=0)
    adata.layers["counts"] = adata.X.copy()
    
    return adata


def normalize_data(adata, target_sum=1e4):
    """
    Normalize and log-transform data.
    """
    
    # Compare normalization methods
    result_norm = compare_normalizations(
        adata,
        methods=['library_size', 'cell_area', 'sctransform'],
        target_sum=target_sum,
        return_dict=True
    )
    
    # Apply normalization
    sc.pp.normalize_total(adata, inplace=True, target_sum=target_sum)
    sc.pp.log1p(adata)
    
    return adata, result_norm


def plot_celltype_spatial(adata, column='cell_type', title=None, inverted=False):
    """
    Create spatial plot of cell types.
    """
    
    adata.obs['x_global_px'] = adata.obsm['spatial'][:, 0]
    adata.obs['y_global_px'] = adata.obsm['spatial'][:, 1]
    
    plt.figure(figsize=(6, 5))
    if title:
        plt.title(title)
    
    g = sns.scatterplot(
        x="x_global_px",
        y="y_global_px",
        s=50,
        marker='.',
        data=adata.obs,
        hue=column,
        palette=get_custom_palette(extended=True)
    )
    
    if inverted:
        g.invert_yaxis()
    
    # Format legend
    handles, labels = g.get_legend_handles_labels()
    for h in handles:
        h.set_markersize(5)
    
    plt.legend(
        handles, labels,
        loc='upper right',
        bbox_to_anchor=(0.99, 0.99),
        fontsize=4,
        title='Cell Type',
        title_fontsize=6,
        ncol=1,
        frameon=True,
        framealpha=0.9,
        borderpad=0.3,
        labelspacing=0.3
    )
    
    g.set_ylabel("")
    g.set_xlabel("")
    plt.tight_layout()