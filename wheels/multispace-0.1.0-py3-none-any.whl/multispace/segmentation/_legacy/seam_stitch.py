#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
seam_stitch_pipeline.py
=======================
Unified orchestrator for the whole-slide Xenium seam-stitching workflow,
consolidating four previously separate scripts into ONE class:

    Phase 1  extract_seam_flow(i)      <- 2_seams_flow.py   (per-seam, SLURM array)
    Phase 2  generate_lattice_masks()  <- 3_seam_mask_generation.py
    Phase 3  run_merge()               <- 4_merge_masks_full.py
    Phase 4  run_proseg_wsi()          <- 5_proseg_wsi.py

Design notes
------------
* All configuration is loaded from a YAML file (default ./config.yml) at construction.
  Only `image_name` and `pixel_size_um` are fixed in code; everything data-, run-,
  environment-, or tuning-related lives in the YAML (paths, ROI, grid, factor, margin,
  missing patches, Cellpose/lattice/proseg params, per-phase QC, transcript filters).
* The per-seam Cellpose step (Phase 1) uses `Resegmentation_xenium`, which is
  inlined below (lifted verbatim from 2_seams_flow.py) - no external import. Its
  per-patch proseg path (run_proseg / proseg_wrapper) was removed; proseg now runs
  only at whole-slide level in Phase 4.
* Fixes applied (tagged `# FIX #n` at each site):
    #1  vertical-seam offset crash - offsets are now (y0//factor, x0//factor) for
        both seam orientations, so all 52 seam jobs produce flow files.
    #2  derive_shapes y-flip - replaced from_bounds (e=-1) with a translation-only
        transform; shapes share the y-down DS-pixel frame of labels/transcripts.
    #3  mixed coordinate frames - merged labels/shapes carry Scale([DS_UM,DS_UM]),
        so everything in the complete zarr is micron-global.
    #4  missing expression table - the per-tile proseg cell x gene matrices are now
        persisted and stitched (_assemble_proseg_table) into merged_proseg_wsi.h5ad,
        aligned to the final proseg_N ids (the analogue of reseg.py's table). The
        #4b counts_all.iloc crash is gone with the rewrite.

Run the whole thing in one process (e.g. in Spyder: just open this file and
press Run, or call SeamStitchPipeline("config.yml").run_all()):

    python seam_stitch_pipeline.py            # = run_all(): all phases in order
    python seam_stitch_pipeline.py all        # same

Or run phases independently (they have very different resource profiles; Phase 1
is a 52-job array, Phase 4 is a long single job). Config path defaults to
./config.yml, or set SEAM_CONFIG=path/to/config.yml:

    python seam_stitch_pipeline.py seam_flow <seam_index 0-51>
    python seam_stitch_pipeline.py lattice
    python seam_stitch_pipeline.py merge
    python seam_stitch_pipeline.py proseg
"""

import os
import sys
import gc
import glob
import gzip
import shutil
import subprocess
import time
import math
import logging
import warnings
import yaml
from datetime import datetime
from collections import OrderedDict
from pathlib import Path
from tqdm import tqdm

import numpy as np
import pandas as pd
import geopandas as gpd
import anndata as ad
import scanpy as sc
try:  # multispace patch: TensorFlow is only used to report / clear GPU state
    import tensorflow as tf
except ImportError:  # pragma: no cover
    tf = None
import torch

from PIL import Image
from shapely.geometry import Polygon
from shapely.affinity import scale, translate
from skimage.measure import label, regionprops, find_contours, regionprops_table
from skimage.transform import resize
from scipy.ndimage import distance_transform_edt
import scipy.sparse as sp
from scipy.sparse import csr_matrix

from cellpose import io, models, dynamics

import spatialdata as sd
from spatialdata import SpatialData
from spatialdata.models import Labels2DModel, ShapesModel, PointsModel, Image2DModel
from spatialdata.transformations import Affine
import dask.array as da
import dask.dataframe as dd
from dask.distributed import Client

from rasterio.features import shapes as rasterio_shapes
from rasterio.transform import Affine
import shapely.geometry
from shapely.geometry import box as shapely_box

warnings.filterwarnings("ignore")
os.environ.setdefault('PYTORCH_ALLOC_CONF', 'expandable_segments:True')


# ===================================================================== #
#  Per-patch / per-seam segmentation engine (inlined from 2_seams_flow) #
# ===================================================================== #

class Resegmentation_xenium:
    """Pipeline for spatial omics segmentation and data integration.

    This class encapsulates preprocessing, segmentation, mask filtering,
    shape/label creation, transcript assignment, and writing results
    back to a SpatialData Zarr file.
    
    Attributes:
        zarr_dir (str): Directory containing the input Zarr file.
        zarr_name (str): Name of the input Zarr file.
        output (str): Path to save preprocessed image output.
        factor_rescale (int): Factor by which to rescale coordinates between 
            segmentation and original resolution.
        image_name (str): Name of the image layer in SpatialData.
        label_name (str): Name for the output label layer.
        shape_name (str): Name for the output shape layer.
        point_name (str): Name of the point layer in SpatialData.
        sdata (sd.SpatialData): Loaded SpatialData object.
        image (PIL.Image): Preprocessed image for segmentation.
        masks (np.ndarray): Segmentation masks from Cellpose.
        flows (tuple): Flow outputs from Cellpose.
        styles (np.ndarray): Style outputs from Cellpose.
        gdf_polygons (gpd.GeoDataFrame): Polygon geometries for segmented cells.
        shapes_model (gpd.GeoDataFrame): SpatialData shapes model.
        labels_model (sd.models.Labels2DModel): SpatialData labels model.
        gdf_points (gpd.GeoDataFrame): Point geometries for transcripts.
        vdata (ad.AnnData): AnnData object containing gene expression matrix.
    """

    def __init__(self, zarr_dir: str,
                 zarr_name: str,
                 output: str,
                 factor_rescale: int,
                 image_name: str,
                 label_name: str,
                 shape_name: str,
                 point_name: str):
        """Initialize Resegmentation pipeline.
        
        Args:
            zarr_dir (str): Directory containing the input Zarr file.
            zarr_name (str): Name of the input Zarr file.
            output (str): Path to save preprocessed image output.
            factor_rescale (int): Rescaling factor between segmentation and 
                original resolution (e.g., 4 means segmentation is 4x smaller).
            image_name (str): Name of the image layer in SpatialData.
            label_name (str): Name for the output label layer.
            shape_name (str): Name for the output shape layer.
            point_name (str): Name of the point layer in SpatialData.
        """
        
        self.zarr_dir = zarr_dir
        self.zarr_name = zarr_name
        self.output = output
        self.factor_rescale = factor_rescale
        self.image_name = image_name
        self.label_name = label_name
        self.shape_name = shape_name
        self.point_name = point_name
        self.sdata = None
        self.image = None
        self.masks = None
        self.flows = None
        self.styles = None
        self.gdf_polygons = None
        self.shapes_model = None
        self.labels_model = None
        self.gdf_points = None
        self.vdata = None
        self.output_folder = "data/seams_masks"
        os.makedirs(self.output_folder, exist_ok=True)

    # ---------------- GPU UTILITIES ---------------- #

    @staticmethod
    def check_gpu():
        """Print Python environment, TensorFlow version, and GPU availability.
        
        Displays diagnostic information about the current Python environment
        and TensorFlow GPU configuration for debugging purposes.
        
        Prints:
            - Python executable path
            - TensorFlow version
            - List of available GPU devices
        """
        print("Python path:", sys.executable)
        if tf is not None:
            print("TensorFlow version:", tf.__version__)
            print("GPU available:", tf.config.list_physical_devices("GPU"))


    @staticmethod
    def clear_gpu_memory():
        """Clear TensorFlow GPU memory and trigger garbage collection.
        
        Clears the TensorFlow Keras session to free GPU memory and runs
        Python's garbage collector to free system memory. Useful between
        processing steps to prevent memory accumulation.
        
        Note:
            Errors during clearing are caught and printed but do not raise
            exceptions to allow continued execution.
        """
        
        try:
            if tf is not None and tf.config.list_physical_devices("GPU"):
                tf.keras.backend.clear_session()
            gc.collect()
        except Exception as e:
            print(f"Error clearing GPU memory: {e}")

    # ---------------- IMAGE PREPROCESS ---------------- #

    def preprocess_image(
        self,
        channel_names: list[str],
        channels_to_use: list[str] = ["Y", "U"],
    ):
        """Load and preprocess Zarr image for segmentation.
        
        Loads image data from SpatialData Zarr file, selects specified channels,
        applies contrast stretching, converts to 8-bit RGB format, and downscales
        for segmentation. The preprocessed image is saved to disk.
        
        Args:
            channel_names (list[str]): List of all channel names in the image 
                (e.g., ['R', 'G', 'B', 'Y', 'U']).
            channels_to_use (list[str], optional): List of channel names to use
                for segmentation. Defaults to ["Y", "U"].
        
        Returns:
            PIL.Image: Preprocessed RGB image ready for segmentation, downscaled
                by `factor_rescale`.
        
        Note:
            - Applies 2nd-98th percentile contrast stretching
            - Converts grayscale or 2-channel images to 3-channel RGB
            - Clears memory after preprocessing
            - Sets `self.image` attribute
        """
        
        zarr_path = os.path.join(self.zarr_dir, self.zarr_name)
        self.sdata = sd.read_zarr(zarr_path)

        img_xr = self.sdata.images[self.image_name]["scale0"].ds["image"]
        data_dask = img_xr.data 
        
        # detect order
        is_channel_first = False
        if hasattr(img_xr, 'dims') and img_xr.dims[0] == 'c':
            is_channel_first = True
            print("Detected Order: Channel First (c, y, x)")

        # setup slice
        step = int(self.factor_rescale)
        channel_indices = [channel_names.index(ch) for ch in channels_to_use]

        # apply slice
        if is_channel_first:
            # slice (C, Y, X) -> channels first, then step Y and X
            data_dask = data_dask[channel_indices, ::step, ::step]
        else:
            # slice (Y, X, C) -> step Y and X, then channels
            data_dask = data_dask[::step, ::step, channel_indices]

        print(f"Loading small chunk with step={step}...")

        # compute
        img = data_dask.compute()

        # transpose in RAM
        if is_channel_first:
            # (C, Y, X) -> (Y, X, C)
            img = img.transpose(1, 2, 0)

        # Contrast stretching
        p2, p98 = np.percentile(img, (2, 98))
        img_stretched = np.clip((img - p2) / (p98 - p2),
                                0, 1).astype(np.float32)

        # Convert to 8-bit
        img_8bit = (img_stretched * 255).astype(np.uint8)

        # Ensure 3-channel RGB
        if img_8bit.ndim == 3 and img_8bit.shape[-1] == 2:
            zero_channel = np.zeros_like(img_8bit[..., :1])
            img_8bit = np.concatenate([img_8bit, zero_channel], axis=-1)

        elif img_8bit.ndim == 3 and img_8bit.shape[-1] == 1:
            zero_channel = np.zeros_like(img_8bit[..., :1])
            img_8bit = np.concatenate(
                [img_8bit, zero_channel, zero_channel], axis=-1)

        elif img_8bit.ndim == 2:
            img_8bit = np.stack([img_8bit] * 3, axis=-1)

        seg_pil = Image.fromarray(img_8bit, mode="RGB")

        y_downscale = int(img_xr.shape[1]/self.factor_rescale)
        x_downscale = int(img_xr.shape[2]/self.factor_rescale)
        downscale = (y_downscale, x_downscale)

        # Resize for segmentation model
        seg_pil.thumbnail(downscale[::-1], Image.Resampling.LANCZOS)

        # Save if requested
        if self.output is not None:
            seg_pil.save(self.output)

        # Clean up memory
        for var_name in ['img_xr', 'img', 'img_8bit', 'zero_channel']:
            if var_name in globals():
                del globals()[var_name]

        self.clear_gpu_memory()

        self.image = seg_pil
        print("Preprocessing finished")

        return seg_pil

    # ---------------- SEGMENTATION ---------------- #

    def run_cellpose(
        self,
        model_type: str = "cyto3",
        gpu: bool = True,
        tile_overlap: float = 0.1,
        diameter: float or None = None,
        flow_threshold: float = 1,
        cellprob_threshold: float = -3,
    ):
        """Run Cellpose segmentation on the preprocessed image.
        
        Loads the preprocessed image and runs Cellpose segmentation model
        to generate cell masks. Saves masks to disk and clears GPU memory.
        
        Args:
            model_type (str, optional): Cellpose model type. Options include
                'cyto', 'cyto2', 'cyto3', 'nuclei'. Defaults to "cyto3".
            gpu (bool, optional): Whether to use GPU for inference. 
                Defaults to True.
            tile_overlap (float, optional): Overlap fraction between tiles
                for large images (0-1). Defaults to 0.1.
            diameter (float or None, optional): Expected cell diameter in pixels.
                If None, uses automatic diameter detection. Defaults to None.
            flow_threshold (float, optional): Flow error threshold for mask
                reconstruction. Higher values = more lenient. Defaults to 1.
            cellprob_threshold (float, optional): Cell probability threshold.
                Lower values = more permissive segmentation. Defaults to -3.
        
        Returns:
            tuple: Contains three elements:
                - masks (np.ndarray): Labeled segmentation masks (H, W).
                - flows (tuple): Flow field outputs from Cellpose.
                - styles (np.ndarray): Style vector outputs from Cellpose.
        
        Note:
            - Sets `self.masks`, `self.flows`, and `self.styles` attributes
            - Saves mask image as "mask.png"
            - Clears GPU memory after segmentation
        """
        
        img = io.imread(self.output)
        model = models.CellposeModel(model_type=model_type, gpu=gpu)

        self.masks, self.flows, self.styles = model.eval(
            img,
            diameter=diameter,
            tile_overlap=tile_overlap,
            flow_threshold=flow_threshold,
            cellprob_threshold=cellprob_threshold,
            batch_size=4
        )
        print("Cellpose segmentation finished")
        img = Image.fromarray(self.masks)
        img.save("mask.png")

        self.clear_gpu_memory()

        return self.masks, self.flows, self.styles

    # ---------------- MASKS & SHAPES ---------------- #

    @staticmethod
    def filter_cell_by_regionprops(
            seg_masks,
            max_eccentricity=None,
            min_area=0,
            min_absolute_area=100,
            max_area=None,
            min_solidity=None,
            max_solidity=None,
            min_extent=None,
            max_extent=None,
            min_compactness=None,
            max_convexity_deficit=None,
            max_perimeter_area_ratio=None,
            area_std_filter=None,
            save_debug=False,
            verbose=True):
        """Filter segmented cell masks by multiple morphological criteria.
        
        Analyzes region properties of segmented masks and filters cells based on
        shape metrics including area, eccentricity, solidity, extent, compactness,
        and convexity deficit. Provides detailed statistics and rejection reasons 
        when verbose mode is enabled.
        
        Args:
            seg_masks (np.ndarray): Input segmentation masks with integer labels.
            max_eccentricity (float, optional): Maximum eccentricity (elongation)
                threshold. Range: 0-1, where 0=circle, 1=line. Typical: 0.95.
                Defaults to None (no filtering).
            min_area (str or float, optional): Minimum area filter. Options:
                - 'median': Use median(areas) as threshold
                - 'median_div2': Use median(areas)/2 as threshold
                - 0-100: Use percentile of area distribution
                - Absolute value: Use as pixel count threshold
                Defaults to 'median_div2'.
            min_absolute_area (int, optional): Hard minimum area to remove 
                tiny artifacts regardless of distribution. Defaults to 50.
            max_area (float, optional): Maximum area threshold in pixels.
                Defaults to None (no filtering).
            min_solidity (float, optional): Minimum solidity (area/convex_area).
                Range: 0-1. Filters highly concave cells. Typical: 0.7-0.9.
                Defaults to None (no filtering).
            max_solidity (float, optional): Maximum solidity. Filters perfectly
                convex cells (unrealistic). Typical: 0.98-0.995. 
                Defaults to None (no filtering).
            min_extent (float, optional): Minimum extent (area/bounding_box_area).
                Range: 0-1. Filters sparse cells. Typical: 0.3-0.5.
                Defaults to None (no filtering).
            max_extent (float, optional): Maximum extent. Filters perfectly
                rectangular cells. Typical: 0.9-0.95.
                Defaults to None (no filtering).
            min_compactness (float, optional): Minimum compactness (Polsby-Popper).
                Compactness = 4π * area / perimeter². Range: 0-1, where 1=perfect circle.
                Filters irregular shapes. Typical: 0.5-0.7 for cells, half-moons ~0.3-0.5.
                Defaults to None (no filtering).
            max_convexity_deficit (float, optional): Maximum convexity deficit.
                Deficit = 1 - solidity = (convex_area - area) / convex_area.
                Range: 0-1, where 0=perfectly convex. Filters concave cells like half-moons.
                Typical: 0.10-0.20, half-moons ~0.25-0.50.
                Defaults to None (no filtering).
            max_perimeter_area_ratio (float, optional): Maximum perimeter/sqrt(area) ratio.
                Normalized perimeter measure. Filters cells with excessive perimeter.
                Typical cells: 3.5-5.0, irregular cells: >6.0.
                Defaults to None (no filtering).
            area_std_filter (float, optional): Remove area outliers beyond N
                standard deviations from mean. E.g., 3.0 removes outliers
                beyond 3σ. Defaults to None (no filtering).
            save_debug (bool, optional): Whether to save debug image 
                "cleaned_mask.png". Defaults to False.
            verbose (bool, optional): Whether to print filtering statistics
                and rejection breakdown. Defaults to True.
        
        Returns:
            np.ndarray: Cleaned and relabeled mask array with consecutive 
                integer labels starting from 1. Zero indicates background.
        
        Shape Metrics Explained:
            Solidity = area / convex_area
                - ~1.0: Very smooth, convex (circle, ellipse) - may be unrealistic
                - 0.7-0.9: Slightly irregular - typical realistic cells
                - <0.7: Highly concave/irregular - likely artifacts
            
            Extent = area / bounding_box_area
                - ~1.0: Fills bounding box (square, rectangle)
                - 0.5-0.8: Typical cell shapes
                - <0.3: Very sparse/thin - likely artifacts
            
            Eccentricity = elongation measure
                - 0: Perfect circle
                - 0.95: Very elongated
                - >0.95: Extremely elongated - may be artifacts
            
            Compactness = 4π * area / perimeter² (Polsby-Popper)
                - 1.0: Perfect circle
                - 0.6-0.8: Typical cells
                - <0.5: Irregular/elongated shapes (including half-moons)
            
            Convexity Deficit = 1 - solidity
                - 0: Perfectly convex
                - 0.05-0.15: Slight irregularity (normal cells)
                - >0.20: Significant concavity (half-moon cells, artifacts)
            
            Perimeter/Area Ratio = perimeter / sqrt(area)
                - 3.5-5.0: Typical cells
                - >6.0: Irregular perimeter (fragmented, concave cells)
        
        Note:
            - Uses vectorized operations for efficient relabeling
            - Prints detailed statistics when verbose=True
            - Returns empty mask if no regions pass filtering
            - New metrics (compactness, convexity deficit) are especially effective
              for removing half-moon/crescent-shaped cells
        """
        
        if verbose:
            print("Labeling connected components")

        labeled = label(seg_masks)

        if verbose:
            print(f"Extracting properties for {labeled.max()} regions")

        # Extract properties
        properties = ['label', 'area', 'eccentricity', 'perimeter']
        if min_solidity is not None or max_solidity is not None or max_convexity_deficit is not None:
            properties.append('solidity')
        if min_extent is not None or max_extent is not None:
            properties.append('extent')

        props = regionprops_table(labeled, properties=properties)

        n_regions = len(props['label'])
        if n_regions == 0:
            if verbose:
                print("No regions found")
            return np.zeros_like(seg_masks, dtype=np.int32)

        areas = props['area']
        perimeters = props['perimeter']

        # ========== CALCULATE NEW METRICS ==========

        # 1. Compactness (Polsby-Popper): 4π * area / perimeter²
        # Circle = 1.0, irregular shapes < 0.5
        # Add epsilon to avoid division by zero
        compactness = (4 * np.pi * areas) / (perimeters ** 2 + 1e-10)

        # 2. Convexity deficit: 1 - solidity
        # How much area is "missing" compared to convex hull
        convexity_deficit = None
        if 'solidity' in props:
            solidity = props['solidity']
            convexity_deficit = 1 - solidity

        # 3. Perimeter-to-area ratio (normalized by sqrt)
        # Normalized measure of perimeter complexity
        perimeter_area_ratio = perimeters / (np.sqrt(areas) + 1e-10)

        # Determine minimum area threshold
        if isinstance(min_area, str) and min_area == 'median':
            min_area_value = np.median(areas)
            threshold_type = "median"
        elif isinstance(min_area, str) and min_area == 'median_div2':
            min_area_value = np.median(areas)/2
            threshold_type = "median_div2"
        elif isinstance(min_area, (int, float)) and 0 <= min_area <= 100:
            min_area_value = np.percentile(areas, min_area)
            threshold_type = f"{min_area}th percentile"
        else:
            min_area_value = min_area
            threshold_type = "absolute"

        if verbose:

            print("SHAPE STATISTICS")
            print("Area:")
            print(f"Range: {areas.min():.1f} - {areas.max():.1f}")
            print(
                f"Mean: {areas.mean():.1f}, Median: {np.median(areas):.1f}, Std: {areas.std():.1f}")
            print("Eccentricity:")
            ecc = props['eccentricity']
            print(f"Range: {ecc.min():.3f} - {ecc.max():.3f}")
            print(f"Mean: {ecc.mean():.3f}, Median: {np.median(ecc):.3f}")
            print("Compactness (1.0=circle, <0.5=irregular):")
            print(
                f"Range: {compactness.min():.3f} - {compactness.max():.3f}")
            print(
                f"Mean: {compactness.mean():.3f}, Median: {np.median(compactness):.3f}")
            print(f"25th percentile: {np.percentile(compactness, 25):.3f}")
            print(f"10th percentile: {np.percentile(compactness, 10):.3f}")

            if 'solidity' in props:
                print("Solidity (convexity):")
                print(f"Range: {solidity.min():.3f} - {solidity.max():.3f}")
                print(
                    f"Mean: {solidity.mean():.3f}, Median: {np.median(solidity):.3f}")
                print("Convexity Deficit (0=convex, high=concave):")
                print(
                    f"Range: {convexity_deficit.min():.3f} - {convexity_deficit.max():.3f}")
                print(
                    f"Mean: {convexity_deficit.mean():.3f}, Median: {np.median(convexity_deficit):.3f}")
                print(
                    f"75th percentile: {np.percentile(convexity_deficit, 75):.3f}")
                print(
                    f"90th percentile: {np.percentile(convexity_deficit, 90):.3f}")

            print("Perimeter/√Area Ratio (typical: 3.5-5.0):")
            print(
                f"Range: {perimeter_area_ratio.min():.3f} - {perimeter_area_ratio.max():.3f}")
            print(
                f"Mean: {perimeter_area_ratio.mean():.3f}, Median: {np.median(perimeter_area_ratio):.3f}")
            print(
                f"75th percentile: {np.percentile(perimeter_area_ratio, 75):.3f}")
            print(
                f"90th percentile: {np.percentile(perimeter_area_ratio, 90):.3f}")

            if 'extent' in props:
                extent = props['extent']
                print("Extent (bbox filling):")
                print(f"Range: {extent.min():.3f} - {extent.max():.3f}")
                print(
                    f"Mean: {extent.mean():.3f}, Median: {np.median(extent):.3f}")

            print(f"Using {threshold_type} area threshold: {min_area_value:.1f}")

        # Build filter mask
        valid_mask = np.ones(n_regions, dtype=bool)
        rejection_reasons = {
            'tiny_artifacts': 0,
            'too_small': 0,
            'too_large': 0,
            'area_outliers': 0,
            'too_eccentric': 0,
            'too_convex': 0,
            'too_concave': 0,
            'too_sparse': 0,
            'too_rectangular': 0,
            'low_compactness': 0,
            'high_convexity_deficit': 0,
            'irregular_perimeter': 0
        }

        # 1. Remove tiny artifacts
        if min_absolute_area > 0:
            artifact_mask = areas >= min_absolute_area
            rejection_reasons['tiny_artifacts'] = (~artifact_mask).sum()
            valid_mask &= artifact_mask

        # 2. Apply relative area threshold
        small_mask = areas >= min_area_value
        rejection_reasons['too_small'] = (~small_mask & valid_mask).sum()
        valid_mask &= small_mask

        # 3. Remove very large regions
        if max_area is not None:
            large_mask = areas <= max_area
            rejection_reasons['too_large'] = (~large_mask & valid_mask).sum()
            valid_mask &= large_mask

        # 4. Remove area outliers
        if area_std_filter is not None:
            mean_area = areas.mean()
            std_area = areas.std()
            lower_bound = mean_area - area_std_filter * std_area
            upper_bound = mean_area + area_std_filter * std_area
            outlier_mask = (areas >= lower_bound) & (areas <= upper_bound)
            rejection_reasons['area_outliers'] = (
                ~outlier_mask & valid_mask).sum()
            valid_mask &= outlier_mask
            if verbose:
                print(
                    f"Area outlier bounds ({area_std_filter}σ): {lower_bound:.1f} - {upper_bound:.1f}")

        # 5. Apply eccentricity filter
        if max_eccentricity is not None:
            eccentric_mask = props['eccentricity'] <= max_eccentricity
            rejection_reasons['too_eccentric'] = (
                ~eccentric_mask & valid_mask).sum()
            valid_mask &= eccentric_mask
            if verbose:
                print(f"Max eccentricity threshold: {max_eccentricity:.3f}")

        # 6. Filter by solidity (convexity)
        if 'solidity' in props:
            # Remove too convex cells (unrealistically smooth)
            if max_solidity is not None:
                convex_mask = solidity <= max_solidity
                rejection_reasons['too_convex'] = (
                    ~convex_mask & valid_mask).sum()
                valid_mask &= convex_mask
                if verbose:
                    print(f"Max solidity (remove convex): {max_solidity:.3f}")

            # Remove too concave cells (artifacts)
            if min_solidity is not None:
                concave_mask = solidity >= min_solidity
                rejection_reasons['too_concave'] = (
                    ~concave_mask & valid_mask).sum()
                valid_mask &= concave_mask
                if verbose:
                    print(f"Min solidity (remove concave): {min_solidity:.3f}")

        # 7. Filter by extent (bounding box filling)
        if 'extent' in props:
            extent = props['extent']

            # Remove sparse/thin cells
            if min_extent is not None:
                sparse_mask = extent >= min_extent
                rejection_reasons['too_sparse'] = (
                    ~sparse_mask & valid_mask).sum()
                valid_mask &= sparse_mask
                if verbose:
                    print(f"Min extent (remove sparse): {min_extent:.3f}")

            # Remove perfectly rectangular cells
            if max_extent is not None:
                rect_mask = extent <= max_extent
                rejection_reasons['too_rectangular'] = (
                    ~rect_mask & valid_mask).sum()
                valid_mask &= rect_mask
                if verbose:
                    print(f"Max extent (remove rectangular): {max_extent:.3f}")

        # 8. Filter by compactness (CRITICAL for half-moon cells)
        if min_compactness is not None:
            compact_mask = compactness >= min_compactness
            rejection_reasons['low_compactness'] = (
                ~compact_mask & valid_mask).sum()
            valid_mask &= compact_mask
            if verbose:
                print(f"Min compactness threshold: {min_compactness:.3f}")

        # 9. Filter by convexity deficit (CRITICAL for half-moon cells)
        if max_convexity_deficit is not None and convexity_deficit is not None:
            deficit_mask = convexity_deficit <= max_convexity_deficit
            rejection_reasons['high_convexity_deficit'] = (
                ~deficit_mask & valid_mask).sum()
            valid_mask &= deficit_mask
            if verbose:
                print(
                    f"Max convexity deficit threshold: {max_convexity_deficit:.3f}")

        # 10. Filter by perimeter-area ratio
        if max_perimeter_area_ratio is not None:
            perimeter_mask = perimeter_area_ratio <= max_perimeter_area_ratio
            rejection_reasons['irregular_perimeter'] = (
                ~perimeter_mask & valid_mask).sum()
            valid_mask &= perimeter_mask
            if verbose:
                print(
                    f"Max perimeter/√area ratio: {max_perimeter_area_ratio:.3f}")

        n_valid = valid_mask.sum()

        if verbose:

            print(
                f"FILTERING RESULTS: {n_valid}/{n_regions} regions passed ({100*n_valid/n_regions:.1f}%)")

            if n_valid > 0:
                valid_areas = areas[valid_mask]
                valid_compactness = compactness[valid_mask]
                valid_perimeter_ratio = perimeter_area_ratio[valid_mask]

                print("Valid regions statistics:")
                print(
                    f"Area range: {valid_areas.min():.1f} - {valid_areas.max():.1f}")
                print(f"Mean area: {valid_areas.mean():.1f}")
                print(
                    f"Compactness range: {valid_compactness.min():.3f} - {valid_compactness.max():.3f}")
                print(
                    f"Perimeter ratio range: {valid_perimeter_ratio.min():.3f} - {valid_perimeter_ratio.max():.3f}")

                if 'solidity' in props:
                    valid_solidity = solidity[valid_mask]
                    valid_deficit = convexity_deficit[valid_mask]
                    print(
                        f"Solidity range: {valid_solidity.min():.3f} - {valid_solidity.max():.3f}")
                    print(
                        f"Convexity deficit range: {valid_deficit.min():.3f} - {valid_deficit.max():.3f}")

                if 'extent' in props:
                    valid_extent = extent[valid_mask]
                    print(
                        f"Extent range: {valid_extent.min():.3f} - {valid_extent.max():.3f}")

            print("Rejection breakdown:")
            total_rejected = n_regions - n_valid
            print(f"Total rejected: {total_rejected}")
            for reason, count in rejection_reasons.items():
                if count > 0:
                    pct = 100 * count / n_regions
                    print(
                        f"{reason.replace('_', ' ').title()}: {count} ({pct:.1f}%)")

        if n_valid == 0:
            if verbose:
                print("WARNING: No regions passed filtering criteria!")
            return np.zeros_like(seg_masks, dtype=np.int32)

        # Vectorized relabeling via lookup table
        valid_labels = props['label'][valid_mask]
        lut = np.zeros(labeled.max() + 1, dtype=np.int32)
        lut[valid_labels] = np.arange(1, n_valid + 1, dtype=np.int32)
        cleaned_mask = lut[labeled]

        if save_debug:
            from PIL import Image
            Image.fromarray(cleaned_mask).save("cleaned_mask.png")
            if verbose:
                print("Saved debug image: cleaned_mask.png")

        return cleaned_mask

    @staticmethod
    def masks_to_polygons(seg_masks, factor_rescale):
        """Convert segmentation masks into scaled polygons.
        
        Extracts contours from each labeled region in the segmentation mask,
        converts them to Shapely polygons, and rescales coordinates to match
        the original image resolution.
        
        Args:
            seg_masks (np.ndarray): Labeled segmentation masks where each 
                unique integer represents a different cell.
            factor_rescale (int): Factor by which to upscale polygon coordinates.
                E.g., if masks are 4x smaller than original, use factor_rescale=4.
        
        Returns:
            list[shapely.geometry.Polygon]: List of upscaled polygon geometries,
                one per valid segmented region. Invalid or empty polygons are
                excluded.
        
        Note:
            - Finds the longest contour for each region
            - Ensures contours are closed (first point = last point)
            - Buffers polygons by 0 to fix any self-intersections
            - If factor_rescale=0, no scaling is applied
        """
        
        upscale_polygons = []

        for region in regionprops(seg_masks):
            mask = (seg_masks == region.label).astype(int)
            contours = find_contours(np.array(mask))
            if contours:
                contour = max(contours, key=lambda x: len(x))

                # ensure the contour is closed (first point = last point)
                if not ((contour[0] == contour[-1]).all()):
                    contour = np.vstack([contour, contour[0]])
                poly = Polygon(contour[:, [1, 0]]).buffer(0)

                # only keep polygons that are valid and not empty
                if poly.is_valid and not poly.is_empty:
                    upscale_polygons.append(poly)

        h, w = seg_masks.shape

        if factor_rescale != 0:
            upscale_polygons = [scale(poly, xfact=factor_rescale, yfact=factor_rescale, origin=(
                0, 0)) for poly in upscale_polygons]

        return upscale_polygons


    @staticmethod
    def mirror_y0(geom):
        """Mirror a polygon geometry across the x-axis (y=0).
        
        Flips polygon coordinates vertically by negating y-values. Used to
        correct coordinate system orientation differences between image and
        spatial coordinate systems.
        
        Args:
            geom (shapely.geometry.Polygon or other): Input geometry to mirror.
        
        Returns:
            shapely.geometry: Mirrored geometry of the same type as input.
                If input is not a Polygon, returns input unchanged.
        
        Example:
            Point (x, y) becomes (x, -y)
        """
        
        return type(geom)([
            (x, -y) for x, y in geom.exterior.coords
        ]) if geom.geom_type == "Polygon" else geom


    def process_masks_to_shapes(self):
        """Filter masks, convert to polygons, and create shapes model.
        
        Applies morphological filtering to segmentation masks, converts filtered
        masks to polygon geometries, mirrors coordinates, and creates a 
        SpatialData-compatible shapes model with cell IDs.
        
        Returns:
            tuple: Contains three elements:
                - masks (np.ndarray): Filtered and relabeled segmentation masks.
                - gdf_polygons (gpd.GeoDataFrame): GeoDataFrame with cell_id and
                  geometry columns.
                - shapes_model (gpd.GeoDataFrame): SpatialData shapes model with
                  region names and geometries.
        
        Raises:
            RuntimeError: If no valid polygons are extracted from masks after
                filtering.
        
        Note:
            - Filters masks using `filter_cell_by_regionprops()`
            - Converts to polygons and upscales by `factor_rescale`
            - Mirrors y-coordinates and shifts to ensure all y >= 0
            - Sets `self.masks`, `self.gdf_polygons`, and `self.shapes_model`
        
        TODO:
            Optimize this function for better performance.
        """
        # multispace patch: this inlined copy carries the old transcript
        # mapping (y-flip + shift by the minimum transcript x / y), which
        # mis-assigns transcripts. SeamStitchPipeline only uses
        # preprocess_image() and run_cellpose() from this class, so the
        # transcript / table path is disabled here. Use
        # multispace.segmentation._legacy.reseg.Resegmentation_xenium instead.
        raise NotImplementedError(
            "Inlined Resegmentation_xenium.process_masks_to_shapes() in seam_stitch.py is disabled "
            "(known transcript-mapping bug). Use multispace.segmentation.resegment() "
            "or multispace.segmentation._legacy.reseg.Resegmentation_xenium.")
        
        # Filter masks
        self.masks = self.filter_cell_by_regionprops(self.masks)

        # Convert masks → polygons
        polygons = self.masks_to_polygons(self.masks, self.factor_rescale)

        if not polygons:
            raise RuntimeError(
                "No polygons extracted from mask — check your segmentation.")

        # Shapes
        shapes_df = gpd.GeoDataFrame({
            "geometry": polygons,
            "cell_id": [f"cell_{i+1}" for i in range(len(polygons))]
        })
        shapes_df.set_geometry("geometry", inplace=True)
        self.shapes_model = ShapesModel.parse(shapes_df)

        # Apply to GeoDataFrame
        self.shapes_model["geometry"] = self.shapes_model["geometry"].apply(
            self.mirror_y0)

        miny = self.shapes_model.total_bounds[1]
        # If miny < 0, shift upward
        if miny < 0:
            self.shapes_model["geometry"] = self.shapes_model["geometry"].apply(
                lambda g: translate(g, xoff=0, yoff=-miny))

        self.gdf_polygons = self.shapes_model[["cell_id", "geometry"]]

        return self.masks, self.gdf_polygons, self.shapes_model

    # ---------------- LABELS ---------------- #

    def process_labels(self):
        """Upscale masks and create Labels2DModel.
        
        Upscales the filtered segmentation masks to the original image resolution
        and creates a SpatialData-compatible Labels2DModel for visualization and
        further analysis.
        
        Returns:
            tuple: Contains two elements:
                - masks (np.ndarray): Original filtered masks (not upscaled).
                - labels_model (sd.models.Labels2DModel): Upscaled labels model
                  with name set to `self.label_name`.
        
        Note:
            - Uses nearest-neighbor interpolation (order=0) to preserve integer labels
            - Upscales by `factor_rescale` to match original image dimensions
            - Sets `self.labels_model` attribute with specified label name
        """
        rescale_size = tuple(
            map(lambda x: x * self.factor_rescale, self.masks.shape))
        masks_upscale = resize(
            self.masks,
            rescale_size,
            order=0,
            preserve_range=True,
            anti_aliasing=False,
        ).astype(np.int32)

        self.labels_model = Labels2DModel.parse(
            data=np.squeeze(masks_upscale),
            dims=("y", "x"),
        )
        self.labels_model.name = self.label_name

        return self.masks, self.labels_model

    # ---------------- POINTS & TABLES ---------------- #

    def process_points_and_tables(self):
        """Assign transcript points to segmented cells and build AnnData table.
        
        Loads transcript point data from SpatialData, applies coordinate 
        transformations, performs spatial join to assign transcripts to cells,
        builds a gene expression matrix, and creates an AnnData object.
        
        Returns:
            tuple: Contains two elements:
                - points_model (dd.DataFrame): Dask DataFrame of points with
                  transformed coordinates and cell assignments.
                - vdata (ad.AnnData): AnnData object containing:
                    - X: Gene expression count matrix (cells × genes)
                    - obs: Cell metadata with cell IDs
                    - var: Gene metadata with gene names
        
        Note:
            - Concatenates all point layers from SpatialData
            - Applies global transformation and FOV shift corrections
            - Uses spatial join with polygon geometries to assign transcripts
            - Creates cross-tabulated expression matrix via pd.crosstab
            - Clears memory after processing
            - Sets `self.gdf_points` and `self.vdata` attributes
        
        Warning:
            Assumes FOV size of 4256 pixels for shift correction. May need
            adjustment for different imaging systems.
        """
        # multispace patch: this inlined copy carries the old transcript
        # mapping (y-flip + shift by the minimum transcript x / y), which
        # mis-assigns transcripts. SeamStitchPipeline only uses
        # preprocess_image() and run_cellpose() from this class, so the
        # transcript / table path is disabled here. Use
        # multispace.segmentation._legacy.reseg.Resegmentation_xenium instead.
        raise NotImplementedError(
            "Inlined Resegmentation_xenium.process_points_and_tables() in seam_stitch.py is disabled "
            "(known transcript-mapping bug). Use multispace.segmentation.resegment() "
            "or multispace.segmentation._legacy.reseg.Resegmentation_xenium.")

        # Xenium pixel size
        pixel_size = 0.2125
        # Load points
        self.points_model = dd.concat(
            [self.sdata.points[x] for x in self.sdata.points.keys()], axis=0, ignore_index=False)
        points_df = self.points_model[[
            'x', 'y', 'feature_name', 'z', 'qv']].compute()
        points_df = points_df[points_df['qv']>=20]

        self.gdf_points = gpd.GeoDataFrame(
            points_df[['x', 'y', 'feature_name', 'z']],
            geometry=gpd.points_from_xy(x=points_df["x"], y=points_df["y"]),
            crs=self.gdf_polygons.crs)

        self.gdf_points['geometry'] = self.gdf_points['geometry'].apply(
            lambda geom: scale(geom, xfact=(1/pixel_size), yfact=-(1/pixel_size), origin=(0, 0)))

        minx, miny, maxx, maxy = self.gdf_points.total_bounds
        minx_new, miny_new, maxx_new, maxy_new = self.gdf_points.total_bounds
        self.gdf_points['geometry'] = self.gdf_points['geometry'].apply(
            lambda geom: translate(geom, xoff=-minx_new, yoff=-miny_new))
        self.gdf_points['x_updated'] = self.gdf_points['geometry'].apply(
            lambda geom: geom.x)
        self.gdf_points['y_updated'] = self.gdf_points['geometry'].apply(
            lambda geom: geom.y)

        # --- FIX: Re-number the rows so the index is 100% unique ---
        self.gdf_points = self.gdf_points.reset_index(drop=True)

        # Spatial join (assign transcripts to polygons)
        joined = gpd.sjoin(
            self.gdf_points,
            self.gdf_polygons[["cell_id", "geometry"]],
            how="left",
            predicate="within",
        )
        
        joined = joined[~joined.index.duplicated(keep='first')]

        self.gdf_points["cell_id"] = joined["cell_id"].values
        # Build expression matrix
        all_genes = self.gdf_points["feature_name"].unique().tolist()

        # Create a cross-tabulation of cell_id vs target
        cell_gene_matrix = pd.crosstab(
            self.gdf_points["cell_id"], self.gdf_points["feature_name"])

        # Ensure all genes appear as columns (even if missing in some cells)
        cell_gene_matrix = cell_gene_matrix.reindex(
            columns=all_genes, fill_value=0)

        # Convert to dict of OrderedDicts
        cell_gene_counts = {str(cell): OrderedDict(cell_gene_matrix.loc[cell].to_dict(
        )) for cell in tqdm(cell_gene_matrix.index, total=len(cell_gene_matrix.index))}
        df = pd.DataFrame.from_dict(
            cell_gene_counts, orient="index", columns=all_genes)
        df = df.reindex(columns=all_genes, fill_value=0)

        # Convert to AnnData
        self.vdata = ad.AnnData(X=df.values)
        self.vdata.obs_names = df.index
        self.vdata.var_names = df.columns
        self.vdata.obs["cells"] = self.vdata.obs_names
        self.vdata.var["genes"] = self.vdata.var_names

        # Clean up memory
        for var in (points_df,):
            try:
                del var
            except Exception:
                pass
        self.clear_gpu_memory()
        points_model_updated = dd.from_pandas(pd.merge(self.gdf_points[['x', 'y', 'feature_name', 'z', 'cell_id', 'x_updated', 'y_updated']], self.points_model[[
            'x', 'y', 'z', 'codeword_category', 'is_gene', 'transcript_id', 'codeword_index', 'fov_name', 'qv']].compute(),
            how="left",
            on=['x', 'y', 'z']),
            npartitions=self.points_model.npartitions)

        self.points_model = PointsModel.parse(points_model_updated)

        return self.points_model, self.vdata
    

    def process_xenium_adata(self, gene_list_path="gene_list_10X.csv"):
        """
        Process Xenium AnnData: compute QC metrics, remove controls, add missing genes
        
        Parameters:
        -----------
        adata : AnnData
            Input AnnData object
        gene_list_path : str
            Path to reference gene list CSV
        
        Returns:
        --------
        adata : AnnData
            Processed AnnData object
        """

        # Define control keywords
        keywords = {
            'control_probe': 'NegControlProbe',
            'genomic_control': 'Intergenic_Region',
            'control_codeword': 'NegControlCodeword',
            'unassigned_codeword': 'UnassignedCodeword',
            'deprecated_codeword': 'DeprecatedCodeword'
        }

        vdata = self.new_sdata.tables['table']
        print('vdata')
        print(vdata)
        cols_to_copy = ['TMA_ID', 'core_ID', 'metabric_ID',
                        'MB_Number', 'metallomics_ID'] #'ST_ID'
        available_cols = [c for c in cols_to_copy if c in self.sdata.tables['table'].obs.columns]
        
        if available_cols:
            print(f"Copying metadata columns: {available_cols}")
            info_core = self.sdata.tables['table'].obs[available_cols].iloc[0]
            for k in info_core.index:
                vdata.uns[k] = info_core.loc[k]
        else:
            print("Warning: Requested metadata not found. Skipping.")

        # obs['transcript_counts'] = np.array(new_sdata.tables['table'].X.sum(axis=1)).flatten()
        obs = vdata.obs

        # Filter shapes
        valid_cells = vdata.obs_names
        gdf_cells = self.new_sdata.shapes[self.shape_name].copy()
        gdf_cells_filtered = gdf_cells[gdf_cells['cell_id'].isin(valid_cells)]
        self.new_sdata.shapes[self.shape_name] = gdf_cells_filtered

        # Compute and attach cell area
        cells = self.new_sdata.shapes[self.shape_name]
        obs = vdata.obs.copy()
        obs['cell_area'] = cells.geometry.area.values

        if 'TMA_ID' in vdata.uns:
            obs['TMA_ID'] = vdata.uns['TMA_ID']
            
        if 'metabric_ID' in vdata.uns:
            obs['metabric_ID'] = vdata.uns['metabric_ID']
            
        centroids = cells.geometry.centroid
        vdata.obsm['spatial'] = np.column_stack([centroids.x, centroids.y])

        vdata.obs = obs

        print("=" * 60)
        print("PROCESSING XENIUM ANNDATA")
        print("=" * 60)
        print(f"Original shape: {vdata.shape}")

        # 1. Compute QC metrics
        print("1. Computing QC metrics")

        for metric_name, keyword in keywords.items():
            mask = vdata.var_names.str.contains(keyword, na=False, regex=False)
            counts = np.array(vdata[:, mask].X.sum(axis=1)).flatten()
            vdata.obs[f'{metric_name}_counts'] = counts
            print(f" {metric_name}_counts: {mask.sum()} features")

        # Identify all control features
        all_control_mask = pd.Series(False, index=vdata.var_names)
        for keyword in keywords.values():
            all_control_mask |= vdata.var_names.str.contains(
                keyword, na=False, regex=False)

        # Transcript counts (non-control genes)
        transcript_mask = ~all_control_mask
        vdata.obs['transcript_counts'] = np.array(
            vdata[:, transcript_mask].X.sum(axis=1)
        ).flatten()
        print(f" transcript_counts: {transcript_mask.sum()} features")

        # Total counts
        vdata.obs['total_counts'] = np.array(vdata.X.sum(axis=1)).flatten()

        # Summary stats
        print("   QC Metrics Summary:")
        qc_cols = ['control_probe_counts', 'genomic_control_counts',
                   'control_codeword_counts', 'unassigned_codeword_counts',
                   'deprecated_codeword_counts', 'transcript_counts', 'total_counts']
        print(vdata.obs[qc_cols].describe().loc[['mean', 'std', 'min', 'max']])

        # 2. Remove control features
        print("2. Removing control features")
        print(f" Control features: {all_control_mask.sum()}")
        print(f" Regular genes: {transcript_mask.sum()}")

        vdata = vdata[:, transcript_mask].copy()
        print(f" After removal: {vdata.shape}")

        # 3. Add missing genes
        print("3. Adding missing genes from reference")

        gene_list = pd.read_csv(gene_list_path)['gene_name'].tolist()
        print(f" Reference list: {len(gene_list)} genes")

        current_genes = set(vdata.var_names)
        missing_genes = [
            gene for gene in gene_list if gene not in current_genes]
        print(f" Missing genes: {len(missing_genes)}")

        if len(missing_genes) > 0:
            # Store original uns and other metadata
            original_uns = vdata.uns.copy()
            original_obsm = vdata.obsm.copy() if vdata.obsm.keys() else {}
            original_obsp = vdata.obsp.copy() if vdata.obsp.keys() else {}
            original_varm = vdata.varm.copy() if vdata.varm.keys() else {}
            original_varp = vdata.varp.copy() if vdata.varp.keys() else {}
            original_layers = {
                k: v for k, v in vdata.layers.items()} if vdata.layers.keys() else {}

            # Create zero matrix for missing genes
            missing_matrix = np.zeros((vdata.n_obs, len(missing_genes)))

            # Match the format of existing X matrix (sparse or dense)
            if hasattr(vdata.X, 'toarray'):  # If sparse
                missing_matrix = csr_matrix(missing_matrix)

             # Create var DataFrame matching existing structure
            missing_var = pd.DataFrame(index=missing_genes)
            # Copy column structure from existing var, fill with appropriate defaults
            for col in vdata.var.columns:
                if vdata.var[col].dtype == 'object' or vdata.var[col].dtype == 'string':
                    missing_var[col] = ''  # Empty string instead of NaN
                elif vdata.var[col].dtype == 'bool':
                    missing_var[col] = False
                else:
                    missing_var[col] = 0  # Numeric columns get 0

            missing_adata = sc.AnnData(
                X=missing_matrix,
                obs=vdata.obs.copy(),
                var=pd.DataFrame(index=missing_genes)
            )

            # Concatenate along gene axis (axis=1)
            vdata = sc.concat([vdata, missing_adata], axis=1,
                              join='outer', merge='same')

            # Clean up any remaining NaN values in var
            for col in vdata.var.columns:
                if vdata.var[col].dtype == 'object' or vdata.var[col].dtype == 'string':
                    vdata.var[col] = vdata.var[col].fillna('')
                elif vdata.var[col].dtype == 'bool':
                    vdata.var[col] = vdata.var[col].fillna(False)

            # Restore metadata
            vdata.uns = original_uns
            if original_obsm:
                vdata.obsm = original_obsm
            if original_obsp:
                vdata.obsp = original_obsp
            if original_varm:
                vdata.varm = original_varm
            if original_varp:
                vdata.varp = original_varp
            if original_layers:
                for key, value in original_layers.items():
                    # For layers, we need to add zeros for missing genes
                    if hasattr(value, 'toarray'):  # sparse
                        missing_layer = csr_matrix(
                            np.zeros((vdata.n_obs, len(missing_genes))))
                        vdata.layers[key] = sp.hstack([value, missing_layer])
                    else:  # dense
                        missing_layer = np.zeros(
                            (vdata.n_obs, len(missing_genes)))
                        vdata.layers[key] = np.hstack([value, missing_layer])

            print(f"After adding: {vdata.shape}")

        # 4. Reorder to match reference
        print("4. Reordering genes to match reference")
        genes_in_order = [
            gene for gene in gene_list if gene in vdata.var_names]

        if len(genes_in_order) != len(gene_list):
            print(
                f" WARNING: {len(gene_list) - len(genes_in_order)} genes from reference not found!")

        vdata = vdata[:, genes_in_order].copy()
        print("PROCESSING COMPLETE")
        print(f"Final shape: {vdata.shape}")
        print(f"Cells: {vdata.n_obs}")
        print(f"Genes: {vdata.n_vars}")

        self.new_sdata.tables['table'] = vdata

        return vdata
    

    # ---------------- SAVE ---------------- #

    def update_spatialdata(self, proseg_refinement=False, run_pipeline=True):

        """Save processed SpatialData into a new Zarr file.
        
        Executes the complete processing pipeline and writes all results to a
        new SpatialData Zarr file. Creates a new SpatialData object containing
        the original image, processed labels, shapes, points, and gene expression
        table.
        
        Returns:
            sd.SpatialData: New SpatialData object containing all processed layers:
                - images: Original image from input
                - labels: Upscaled segmentation masks
                - shapes: Cell polygon geometries
                - points: Transcript coordinates with cell assignments
                - tables: AnnData gene expression matrix
        
        Note:
            - Runs full pipeline: masks→shapes, labels, points→tables
            - Creates output path: "updated_{zarr_name}" in zarr_dir
            - Overwrites existing output if present
            - Closes any active Dask client
            - Clears GPU memory and deletes intermediate variables
            - Prints progress messages for each step
        
        Pipeline Steps:
            1. process_masks_to_shapes(): Filter and convert masks to polygons
            2. process_labels(): Upscale masks to full resolution
            3. process_points_and_tables(): Assign transcripts and create expression matrix
            4. Write all data to new Zarr file
        """
        # multispace patch: this inlined copy carries the old transcript
        # mapping (y-flip + shift by the minimum transcript x / y), which
        # mis-assigns transcripts. SeamStitchPipeline only uses
        # preprocess_image() and run_cellpose() from this class, so the
        # transcript / table path is disabled here. Use
        # multispace.segmentation._legacy.reseg.Resegmentation_xenium instead.
        raise NotImplementedError(
            "Inlined Resegmentation_xenium.update_spatialdata() in seam_stitch.py is disabled "
            "(known transcript-mapping bug). Use multispace.segmentation.resegment() "
            "or multispace.segmentation._legacy.reseg.Resegmentation_xenium.")
        
        if run_pipeline:
            self.process_masks_to_shapes()
            print("Masks to shapes finished")
            self.process_labels()
            print("Labels process finished")
            self.process_points_and_tables()
            print("Points and Tables process finished")

        self.new_sdata = sd.SpatialData()
        dst_path = os.path.join(
            self.output_folder, f"updated_{self.zarr_name}")

        # Images
        img = self.sdata.images[self.image_name]
        try:
            # if dask-backed
            self.new_sdata.images[self.image_name] = img.compute()
            
        except Exception:
            # already in memory
            self.new_sdata.images[self.image_name] = img.copy()

        # Labels
        lbl = self.labels_model
        try:
            self.new_sdata.labels[self.label_name] = lbl.compute()
            
        except Exception:
            self.new_sdata.labels[self.label_name] = lbl.copy()

        # Shapes
        shp = self.shapes_model
        try:
            self.new_sdata.shapes[self.shape_name] = shp.compute()
            
        except Exception:
            self.new_sdata.shapes[self.shape_name] = shp.copy()

        # Points
        try:
            transcripts_df = self.points_model.compute()
            transcripts_df = transcripts_df.dropna(subset=['cell_id']).copy()
            
            transcripts_df = transcripts_df.reset_index(drop=True)

            for col in transcripts_df.select_dtypes(include=['object', 'string']).columns:
                transcripts_df[col] = transcripts_df[col].astype('category')
                
            self.new_sdata.points[self.point_name] = PointsModel.parse(transcripts_df)
            
        except Exception as e:
            print(f"Warning: Could not compute points cleanly. Error: {e}")
            self.new_sdata.points[self.point_name] = self.points_model.copy()
        
        tbl = self.vdata.copy()
        print('tbl')
        print(tbl)

        # Remove NaN columns from obs and var
        tbl.obs = tbl.obs.loc[:, tbl.obs.columns.notna()]
        tbl.var = tbl.var.loc[:, tbl.var.columns.notna()]
        # Replace NaN index values with strings (AnnData requires non-NaN unique index)
        tbl.obs = tbl.obs.map(lambda x: "NA" if pd.isna(x) else x)
        tbl.var = tbl.var.map(lambda x: "NA" if pd.isna(x) else x)

        # Ensure indices are unique (AnnData requires unique obs/var names)
        tbl.obs.index = tbl.obs.index.map(
            lambda x: str(x) if pd.notna(x) else "unknown_obs")
        tbl.var.index = tbl.var.index.map(
            lambda x: str(x) if pd.notna(x) else "unknown_var")

        if not tbl.obs.index.is_unique:
            tbl.obs.index = pd.Index(
                [f"cell_{i}" for i in range(len(tbl.obs))])
            
        if not tbl.var.index.is_unique:
            tbl.var.index = pd.Index(
                [f"gene_{i}" for i in range(len(tbl.var))])

        self.new_sdata.tables['table'] = tbl

        self.process_xenium_adata()

        # Per-patch proseg refinement removed: proseg now runs at whole-slide
        # level in Phase 4 (SeamStitchPipeline.run_proseg_wsi). Flag is a no-op.
        if proseg_refinement:
            print("Note: per-patch proseg disabled; use run_proseg_wsi().")

        print("updated_data")

        try:
            client = Client.current()
            client.close()
            
        except ValueError:
            pass

        # Todo: update the following line when compatibility of spatialdata 0.6 ok
        # with other package. It will allow update_sdata_path argument to bypass
        # not self-contained issue when saving
        # new_sdata.write(dst_path, overwrite=True, update_sdata_path=False)
        self.new_sdata.write(dst_path, overwrite=True)
        print("Data saved")

        for var in (self.masks, self.flows, self.styles,
                    self.gdf_points, self.gdf_polygons):
            try:
                del var
            except Exception:
                pass
        self.clear_gpu_memory()

        return self.new_sdata


class SeamStitchPipeline:
    """End-to-end seam stitching: seam flows -> lattice masks -> merge -> proseg WSI."""

    def __init__(self, config_path="config.yml"):
        """Load all configuration from a YAML file. Only image_name and
        pixel_size_um are fixed in code; everything else comes from config_path."""
        with open(config_path) as f:
            cfg = yaml.safe_load(f)
        self.config_path = config_path
        self.cfg = cfg

        # ---- FIXED in code (deliberately not in the YAML) --------------------
        self.image_name    = "morphology_focus"
        self.pixel_size_um = 0.2125

        # ---- Paths -----------------------------------------------------------
        p = cfg["paths"]
        self.scratch_dir        = p["scratch_dir"]
        self.original_zarr_name = p["original_zarr_name"]
        data_dir                = p["data_dir"]
        self.proseg_bin         = p["proseg_bin"]

        self.xenium_zarr   = os.path.join(self.scratch_dir, "xenium_output",
                                          self.original_zarr_name)
        self.tx_parquet    = os.path.join(self.xenium_zarr, "points",
                                          "transcripts", "points.parquet")
        self.temp_crop_dir = os.path.join(self.scratch_dir, "resegmentation",
                                          "temp_crops_seams")

        self.seams_flows_dir      = os.path.join(data_dir, "seams_flows")
        self.seams_masks_dir      = os.path.join(data_dir, "seams_masks")
        self.lattice_path         = os.path.join(self.seams_masks_dir, "lattice_masks.npy")
        self.merged_dir           = os.path.join(data_dir, "merged")
        self.merged_npy           = os.path.join(self.merged_dir, "merged_masks.npy")
        self.merged_complete_zarr = os.path.join(self.merged_dir, "merged_complete.zarr")
        self.proseg_dir           = os.path.join(data_dir, "proseg_wsi")

        # ---- Geometry --------------------------------------------------------
        g = cfg["geometry"]
        # Full-res ROI is read from the zarr morphology image - the only source of
        # truth. No fallback: if the image cannot be read, construction fails.
        roi_h, roi_w = self._read_image_yx()
        self.ts(f"ROI from zarr image '{self.image_name}': "
                f"{roi_w} x {roi_h} (W x H) full-res px")
        self.WHOLE_ROI = {"xmin": 0, "ymin": 0, "width": roi_w, "height": roi_h}
        self.factor  = g["factor"]
        self.n_cols  = g["n_cols"]
        self.n_rows  = g["n_rows"]
        self.margin  = g["margin"]

        self.patch_w   = self.WHOLE_ROI["width"]  / self.n_cols
        self.patch_h   = self.WHOLE_ROI["height"] / self.n_rows
        self.pw_ds     = int(self.patch_w // self.factor)
        self.ph_ds     = int(self.patch_h // self.factor)
        self.margin_ds = self.margin // self.factor
        self.global_h  = int(self.WHOLE_ROI["height"] // self.factor) + 1
        self.global_w  = int(self.WHOLE_ROI["width"]  // self.factor) + 1

        # ---- Micron conversion ----------------------------------------------
        self.ds_um = self.pixel_size_um * self.factor

        # ---- Seam grid totals -----------------------------------------------
        self.total_H     = (self.n_rows - 1) * self.n_cols
        self.total_V     = self.n_rows * (self.n_cols - 1)
        self.total_seams = self.total_H + self.total_V

        # ---- Patch handling --------------------------------------------------
        pc = cfg["patches"]
        self.patches_dir            = pc["dir"]
        self.patch_filename_template = pc["filename_template"]
        self.patch_label_layer      = pc["label_layer"]
        self.missing_patches        = set(pc.get("missing", []) or [])
        self.all_patches = [i for i in range(self.n_cols * self.n_rows)
                            if i not in self.missing_patches]

        # ---- Merge dedup -----------------------------------------------------
        self.iou_threshold = cfg["merge"]["iou_threshold"]

        # ---- Cellpose (Phase 1) ---------------------------------------------
        cp = cfg["cellpose"]
        self.cellpose_model_type   = cp["model_type"]
        self.cellpose_diameter     = cp["diameter"]
        self.cellpose_tile_overlap = cp["tile_overlap"]
        self.cellpose_gpu          = cp["gpu"]
        self.cellpose_channels     = list(cp["channels"])

        # ---- Lattice compute_masks (Phase 2) --------------------------------
        lt = cfg["lattice"]
        self.lattice_niter              = lt["niter"]
        self.lattice_cellprob_threshold = lt["cellprob_threshold"]
        self.lattice_flow_threshold     = lt["flow_threshold"]
        self.lattice_device             = lt["device"]

        # ---- Whole-slide proseg tiling (Phase 4) ----------------------------
        wt = cfg["wsi_tiling"]
        self.wsi_x_ds = self.global_w
        self.wsi_y_ds = self.global_h
        self.core_ds  = wt["core"]
        self.halo_ds  = wt["halo"]

        # ---- Proseg parameters (passed to the proseg CLI as strings) --------
        pr = cfg["proseg"]
        self.proseg_samples        = str(pr["samples"])
        self.proseg_burnin_samples = str(pr["burnin_samples"])
        self.proseg_voxel_size     = str(pr["voxel_size"])
        self.proseg_burnin_size    = str(pr["burnin_voxel_size"])
        self.proseg_voxel_layers   = str(pr["voxel_layers"])
        self.proseg_nuclear_prob   = str(pr["nuclear_reassignment_prob"])
        self.proseg_diff_prob      = str(pr["diffusion_probability"])
        self.proseg_nthreads       = str(pr["nthreads"])

        # ---- Transcript filtering -------------------------------------------
        tr = cfg["transcripts"]
        self.qv_min    = tr["qv_min"]
        self.gene_only = tr["gene_only"]

        # ---- QC thresholds (per phase) --------------------------------------
        q = cfg["qc"]
        self.qc_derive   = q["derive_shapes"]
        self.qc_complete = q["complete_zarr"]
        qa = q["assemble"]
        self.min_area_um2           = qa["min_area_um2"]
        self.max_area_um2           = qa["max_area_um2"]
        self.assemble_min_convexity = qa["min_convexity"]
        self.max_aspect_ratio       = qa["max_aspect_ratio"]
        self.min_transcripts        = qa["min_transcripts"]

        # ---- Low-level IO ----------------------------------------------------
        io = cfg.get("io", {})
        self.zarr_chunks           = tuple(io.get("zarr_chunks", [4096, 4096]))
        self.pyramid_scale_factors = list(io.get("pyramid_scale_factors", [2, 2, 2, 2]))

        # ---- Make output dirs -----------------------------------------------
        for d in (self.seams_flows_dir, self.seams_masks_dir, self.merged_dir,
                  self.proseg_dir, os.path.join(self.proseg_dir, "shapes"),
                  os.path.join(self.proseg_dir, "logs")):
            os.makedirs(d, exist_ok=True)


    # ---------------- small utils ---------------- #

    @staticmethod
    def ts(label=""):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{now}] {label}", flush=True)

    # ---------------- ROI from data ---------------- #

    def _read_image_yx(self):
        """(height, width) of the full-res morphology image, read lazily from the
        zarr (spatialdata reads rasters as dask, so no pixel data is loaded)."""
        sdata = sd.read_zarr(self.xenium_zarr)
        arr = self._full_res_dataarray(sdata.images[self.image_name])
        sizes = dict(zip(arr.dims, arr.shape))
        return int(sizes["y"]), int(sizes["x"])

    @staticmethod
    def _full_res_dataarray(img):
        """Return the full-resolution (scale0) image DataArray, handling both
        single-scale (DataArray) and multiscale (DataTree / mapping of scales)
        elements. Used for both ROI sizing and pixel-space cropping."""
        import xarray as xr
        if isinstance(img, xr.DataArray):
            return img
        # multiscale: highest-resolution level = first scale key (scale0)
        node = img[list(img.keys())[0]]
        if isinstance(node, xr.DataArray):
            return node
        try:                                   # DataTree node: data var named 'image'
            return node["image"]
        except (KeyError, TypeError):
            pass
        if isinstance(node, xr.Dataset):
            return node[list(node.data_vars)[0]]
        if hasattr(node, "ds"):
            ds = node.ds
            return ds[list(ds.data_vars)[0]]
        if hasattr(node, "to_dataset"):
            ds = node.to_dataset()
            return ds[list(ds.data_vars)[0]]
        raise TypeError(f"Unsupported image element type: {type(img)}")

    # ============================================================= #
    #  PHASE 1 - per-seam flow extraction  (from 2_seams_flow.py)   #
    # ============================================================= #

    def _seam_crop_window(self, seam_index):
        """Return (x0, x1, y0, y1, name, row_boundary, col_boundary, kind)."""
        W, H = self.WHOLE_ROI['width'], self.WHOLE_ROI['height']
        pw, ph, m = self.patch_w, self.patch_h, self.margin
        if seam_index < self.total_H:
            row_boundary = seam_index // self.n_cols
            col_idx      = seam_index %  self.n_cols
            y_center = (row_boundary + 1) * ph
            y0 = max(0, y_center - m); y1 = min(H, y_center + m)
            x0 = max(0, col_idx * pw - m); x1 = min(W, (col_idx + 1) * pw + m)
            return x0, x1, y0, y1, f"seam_H_{seam_index:02d}", row_boundary, None, "H"
        else:
            v_index      = seam_index - self.total_H
            row_idx      = v_index // (self.n_cols - 1)
            col_boundary = v_index %  (self.n_cols - 1)
            x_center = (col_boundary + 1) * pw
            x0 = max(0, x_center - m); x1 = min(W, x_center + m)
            y0 = max(0, row_idx * ph - m); y1 = min(H, (row_idx + 1) * ph + m)
            return x0, x1, y0, y1, f"seam_V_{v_index:02d}", None, col_boundary, "V"

    def extract_seam_flow(self, seam_index):
        """Crop a boundary strip, run Cellpose, save flow fields (dP, cellprob, offsets).
        Computes NO masks - the lattice masks come from generate_lattice_masks()."""
        if seam_index >= self.total_seams:
            raise ValueError(f"seam_index {seam_index} out of range (0-{self.total_seams-1}).")

        os.makedirs(self.temp_crop_dir, exist_ok=True)
        x0, x1, y0, y1, name, _row_boundary, _col_boundary, kind = \
            self._seam_crop_window(seam_index)
        print(f"{kind}-seam {seam_index} ({name}): X[{x0:.0f}:{x1:.0f}] Y[{y0:.0f}:{y1:.0f}]")

        crop_name = f"{name}_{self.original_zarr_name}"
        crop_path = os.path.join(self.temp_crop_dir, crop_name)
        if os.path.exists(crop_path):
            shutil.rmtree(crop_path)

        full_sdata = sd.read_zarr(self.xenium_zarr)
        # Crop the image by PIXEL index (intrinsic coords), NOT bounding_box_query in
        # 'global'. The image may carry a translation/scale into 'global' (e.g. this
        # dataset sits at global y=52923, x=9047), so a pixel-valued global box would
        # miss it. Seam-flow only needs the image (Cellpose -> flows), so an image-only
        # pixel crop is sufficient and coordinate-system-agnostic.
        arr = self._full_res_dataarray(full_sdata.images[self.image_name])
        sub = arr.isel(y=slice(int(y0), int(y1)), x=slice(int(x0), int(x1)))
        # Parse the RAW array (not the DataArray): the source element carries a
        # transform in its metadata, which would (a) conflict with an explicit
        # transformations= arg and (b) re-introduce the global translation. Raw data
        # has no transform, so parse assigns a clean Identity. Preserve channel names
        # so the engine's channel selection still resolves (e.g. "DAPI").
        c_coords = list(arr.coords["c"].values) if "c" in arr.coords else None
        # Build the crop MULTISCALE (scale0, scale1, ...) because the engine's
        # preprocess_image reads images[name]["scale0"].ds["image"]; a single-scale
        # image has no "scale0" node.
        crop_img = Image2DModel.parse(
            sub.data, dims=tuple(arr.dims), c_coords=c_coords,
            scale_factors=self.pyramid_scale_factors)
        sdata_roi = SpatialData(images={self.image_name: crop_img})
        sdata_roi.write(crop_path)

        # The engine uses `output` as the preprocess->cellpose handoff file:
        # preprocess_image writes the prepared image there, run_cellpose reads it
        # back. So it must be a real, writable path (not None). Keep it per-seam in a
        # temp dir we create, and delete it afterwards.
        preview_dir = os.path.join(self.temp_crop_dir, "_preview")
        os.makedirs(preview_dir, exist_ok=True)
        output_png = os.path.join(preview_dir, f"dapi_{name}.png")

        reseg = Resegmentation_xenium(
            zarr_dir=self.temp_crop_dir, zarr_name=crop_name,
            output=output_png, factor_rescale=self.factor,
            image_name=self.image_name,
            label_name="cell_labels_seam", shape_name="cell_boundaries_seam",
            point_name="transcripts")
        reseg.output_folder = self.seams_masks_dir   # was hard-coded "data/seams_masks"
        os.makedirs(reseg.output_folder, exist_ok=True)

        reseg.check_gpu()
        reseg.preprocess_image(channel_names=self.cellpose_channels,
                               channels_to_use=self.cellpose_channels)
        reseg.run_cellpose(model_type=self.cellpose_model_type,
                           diameter=self.cellpose_diameter,
                           gpu=self.cellpose_gpu,
                           tile_overlap=self.cellpose_tile_overlap)

        print("Extracting cellpose flows for lattice stitching...")
        dP = reseg.flows[1]
        cellprob = reseg.flows[2]
        factor = reseg.factor_rescale

        # FIX #1: the crop's top-left corner, in DS pixels, is the placement offset for
        # BOTH horizontal and vertical seams. For H seams (row_boundary+1)*patch_h - margin
        # already equals y0; for V seams that expression was undefined (row_boundary is None).
        # generate_lattice_masks() places dP at [min_y:min_y+h, min_x:min_x+w], so the offset
        # must be the DS position of the crop origin = (y0//factor, x0//factor).
        y_offset_scaled = int(y0 // factor)
        x_offset_scaled = int(x0 // factor)
        offsets = np.array([y_offset_scaled, x_offset_scaled])

        os.makedirs(self.seams_flows_dir, exist_ok=True)
        np.save(os.path.join(self.seams_flows_dir, f"{name}_dP.npy"), dP)
        np.save(os.path.join(self.seams_flows_dir, f"{name}_cellprob.npy"), cellprob)
        np.save(os.path.join(self.seams_flows_dir, f"{name}_offsets.npy"), offsets)
        print(f"Saved flows + offsets to {self.seams_flows_dir}")

        if os.path.exists(crop_path):
            shutil.rmtree(crop_path)
        if os.path.exists(output_png):
            os.remove(output_png)
        if os.path.exists(reseg.output_folder) and not os.listdir(reseg.output_folder):
            os.rmdir(reseg.output_folder)
        print(f"Finished seam job {name}")

    # ============================================================= #
    #  PHASE 2 - global lattice masks  (from 3_seam_mask_generation)#
    # ============================================================= #

    def generate_lattice_masks(self):
        """Combine all seam flows on a global canvas (distance-weighted) and run a
        single global compute_masks -> data/seams_masks/lattice_masks.npy."""
        print("=== SEAM MASK GENERATION ===")
        torch.cuda.empty_cache()
        global_h, global_w = self.global_h, self.global_w

        print(f"\nPhase 1: Allocating global canvas ({global_h} x {global_w})...")
        global_dP       = np.zeros((2, global_h, global_w), dtype=np.float32)
        global_cellprob = np.zeros((global_h, global_w),    dtype=np.float32)
        global_weights  = np.zeros((global_h, global_w),    dtype=np.float32)

        offset_files = sorted(glob.glob(os.path.join(self.seams_flows_dir, "*_offsets.npy")))
        print(f"Found {len(offset_files)} seam flow files")
        if len(offset_files) != self.total_seams:
            print(f"WARNING: expected {self.total_seams}, got {len(offset_files)}")

        tile_dist_cache = {}
        for offset_file in offset_files:
            base     = offset_file.replace("_offsets.npy", "")
            offsets  = np.load(offset_file)
            dP       = np.load(f"{base}_dP.npy")
            cellprob = np.load(f"{base}_cellprob.npy")

            min_y, min_x = int(offsets[0]), int(offsets[1])
            _, h, w = dP.shape
            max_y = min(min_y + h, global_h)
            max_x = min(min_x + w, global_w)
            h_clip = max_y - min_y
            w_clip = max_x - min_x

            if (h, w) not in tile_dist_cache:
                padded = np.pad(np.ones((h, w), dtype=np.uint8), 1, mode='constant')
                d = distance_transform_edt(padded)[1:-1, 1:-1].astype(np.float32)
                d /= d.max()
                tile_dist_cache[(h, w)] = d
            dist_map = tile_dist_cache[(h, w)][:h_clip, :w_clip]

            dP_weighted = dP[:, :h_clip, :w_clip] * dist_map
            global_dP[:, min_y:max_y, min_x:max_x]    += dP_weighted
            global_cellprob[min_y:max_y, min_x:max_x] += cellprob[:h_clip, :w_clip] * dist_map
            global_weights[min_y:max_y, min_x:max_x]  += dist_map
            del dP, cellprob, dP_weighted

        print("Normalising...")
        valid = global_weights > 0
        for c in range(2):
            global_dP[c][valid] /= global_weights[valid]
        global_cellprob[valid]  /= global_weights[valid]
        global_cellprob[~valid]  = -10.0
        del global_weights

        print("\nPhase 2: Running compute_masks on global canvas...")
        device = torch.device(self.lattice_device)
        print(f"Using device: {device}")
        result = dynamics.compute_masks(
            global_dP, global_cellprob, niter=self.lattice_niter,
            cellprob_threshold=self.lattice_cellprob_threshold,
            flow_threshold=self.lattice_flow_threshold, do_3D=False, device=device)
        lattice_masks = np.array(result)
        print(f"Mask shape: {lattice_masks.shape}")
        print(f"Total cells: {lattice_masks.max()}")

        os.makedirs(self.seams_masks_dir, exist_ok=True)
        np.save(self.lattice_path, lattice_masks)
        print(f"Saved: {self.lattice_path}\n=== COMPLETE ===")


    def _patch_offset_ds(self, patch_index):
        N_COLS=self.n_cols; PATCH_H=self.patch_h; PATCH_W=self.patch_w; FACTOR=self.factor
        row = patch_index // N_COLS
        col = patch_index % N_COLS
        return int(row * PATCH_H // FACTOR), int(col * PATCH_W // FACTOR)

    def _patch_boundaries_ds(self, patch_index):
        N_COLS=self.n_cols; N_ROWS=self.n_rows; PH_DS=self.ph_ds; PW_DS=self.pw_ds
        patch_offset_ds=self._patch_offset_ds
        row = patch_index // N_COLS
        col = patch_index % N_COLS
        y_off, x_off = patch_offset_ds(patch_index)
        return {
            'top':    y_off          if row > 0           else None,
            'bottom': y_off + PH_DS  if row < N_ROWS - 1 else None,
            'left':   x_off          if col > 0           else None,
            'right':  x_off + PW_DS  if col < N_COLS - 1 else None,
        }

    def _seam_strip_edges_ds(self, seam_name):
        N_COLS=self.n_cols; PATCH_H=self.patch_h; PATCH_W=self.patch_w
        MARGIN=self.margin; FACTOR=self.factor; GLOBAL_H=self.global_h; GLOBAL_W=self.global_w
        if seam_name.startswith("seam_H_"):
            idx          = int(seam_name.split("_")[2])
            row_boundary = idx // N_COLS
            y_center     = (row_boundary + 1) * PATCH_H
            edge_a = max(0,        int((y_center - MARGIN) // FACTOR))
            edge_b = min(GLOBAL_H, int((y_center + MARGIN) // FACTOR))
            return edge_a, edge_b, 'y'
        else:
            v_idx        = int(seam_name.split("_")[2])
            col_boundary = v_idx % (N_COLS - 1)
            x_center     = (col_boundary + 1) * PATCH_W
            edge_a = max(0,        int((x_center - MARGIN) // FACTOR))
            edge_b = min(GLOBAL_W, int((x_center + MARGIN) // FACTOR))
            return edge_a, edge_b, 'x'

    def _seam_zone_ds(self, seam_name):
        GLOBAL_H=self.global_h; GLOBAL_W=self.global_w
        off = np.load(f"data/seams_flows/{seam_name}_offsets.npy")
        dP  = np.load(f"data/seams_flows/{seam_name}_dP.npy")
        y0, x0 = int(off[0]), int(off[1])
        _, h, w = dP.shape
        del dP
        return y0, min(y0 + h, GLOBAL_H), x0, min(x0 + w, GLOBAL_W)

    def _all_seam_names(self):
        N_ROWS=self.n_rows; N_COLS=self.n_cols
        names = []
        for i in range((N_ROWS - 1) * N_COLS):
            names.append(f"seam_H_{i:02d}")
        for i in range(N_ROWS * (N_COLS - 1)):
            names.append(f"seam_V_{i:02d}")
        return names

    def build_patch_canvas(self):
        FACTOR=self.factor; GLOBAL_H=self.global_h; GLOBAL_W=self.global_w
        ALL_PATCHES=self.all_patches; PATCHES_DIR=self.patches_dir
        patch_offset_ds=self._patch_offset_ds; patch_boundaries_ds=self._patch_boundaries_ds
        print("\n=== Phase 1: Building global patch canvas ===")
        canvas       = np.zeros((GLOBAL_H, GLOBAL_W), dtype=np.int32)
        patch_id_map = {}
        patch_bounds = {}
        id_offset    = 0

        for pi in tqdm(ALL_PATCHES, desc="Placing patches"):
            zarr_path = os.path.join(
                PATCHES_DIR,
                self.patch_filename_template.format(pi=pi)
            )
            if not os.path.exists(zarr_path):
                print(f"  WARNING: patch {pi:02d} not found, skipping")
                continue

            sdata    = sd.read_zarr(zarr_path)
            arr_full = sdata.labels[self.patch_label_layer].values.astype(np.int32)
            arr      = arr_full[::FACTOR, ::FACTOR]   # DS
            del arr_full, sdata

            y_off, x_off = patch_offset_ds(pi)
            h, w   = arr.shape
            y_max  = min(y_off + h, GLOBAL_H)
            x_max  = min(x_off + w, GLOBAL_W)
            h_clip = y_max - y_off
            w_clip = x_max - x_off
            arr_clip = arr[:h_clip, :w_clip]

            local_max = int(arr_clip.max())
            if local_max == 0:
                print(f"  Patch {pi:02d}: empty, skipping")
                del arr, arr_clip; gc.collect(); continue

            shifted = np.where(
                arr_clip > 0,
                arr_clip + id_offset,
                0
            ).astype(np.int32)

            canvas[y_off:y_max, x_off:x_max] = shifted

            for lid in range(1, local_max + 1):
                patch_id_map[lid + id_offset] = pi
            patch_bounds[pi] = patch_boundaries_ds(pi)
            id_offset += local_max

            del arr, arr_clip, shifted; gc.collect()

        print(f"Patch canvas: {id_offset} cells, "
              f"{(canvas > 0).sum()} foreground px")
        return canvas, patch_id_map, patch_bounds

    def _compute_pairwise_iou(self, orig_crop, seam_crop):
        IOU_THRESHOLD=self.iou_threshold
        both = (orig_crop > 0) & (seam_crop > 0)
        if not both.any():
            return []
        ov = orig_crop[both]; sv = seam_crop[both]
        pairs, counts = np.unique(
            np.stack([ov, sv], axis=1), axis=0, return_counts=True)
        oa = {o: int((orig_crop == o).sum()) for o in np.unique(ov)}
        sa = {s: int((seam_crop == s).sum()) for s in np.unique(sv)}
        out = []
        for (o, s), inter in zip(pairs, counts):
            union = oa[o] + sa[s] - inter
            iou   = inter / union if union > 0 else 0.0
            if iou >= IOU_THRESHOLD:
                out.append((int(o), int(s), float(iou)))
        return out

    def _get_centroids(self, crop):
        """
        Compute centroids for all cells in a crop in one vectorised pass.
        Much faster than calling np.where per cell.
        Returns dict: cell_id → (cy, cx) in crop-local coords.
        """
        if crop.max() == 0:
            return {}
        props = regionprops_table(crop, properties=['label', 'centroid'])
        return {
            int(label): (float(cy), float(cx))
            for label, cy, cx in zip(
                props['label'],
                props['centroid-0'],
                props['centroid-1'],
            )
        }

    def _dist_to_nearest_patch_boundary(self, cy, cx, boundaries):
        dists = []
        if boundaries['top']    is not None: dists.append(abs(cy - boundaries['top']))
        if boundaries['bottom'] is not None: dists.append(abs(cy - boundaries['bottom']))
        if boundaries['left']   is not None: dists.append(abs(cx - boundaries['left']))
        if boundaries['right']  is not None: dists.append(abs(cx - boundaries['right']))
        return min(dists) if dists else float('inf')

    def _dist_to_seam_edge(self, cy, cx, edge_a, edge_b, axis):
        if axis == 'y': return min(abs(cy - edge_a), abs(cy - edge_b))
        else:           return min(abs(cx - edge_a), abs(cx - edge_b))

    def deduplicate(self, patch_canvas, patch_id_map, patch_bounds, lattice_masks):
        all_seam_names=self._all_seam_names; seam_zone_ds=self._seam_zone_ds
        seam_strip_edges_ds=self._seam_strip_edges_ds
        compute_pairwise_iou=self._compute_pairwise_iou; get_centroids=self._get_centroids
        dist_to_nearest_patch_boundary=self._dist_to_nearest_patch_boundary
        dist_to_seam_edge=self._dist_to_seam_edge
        print("\n=== Phase 2: Deduplication ===")
        seam_canvas = lattice_masks.copy()
        stats = {'pairs': 0, 'patch_wins': 0, 'seam_wins': 0}

        for seam_name in tqdm(all_seam_names(), desc="Deduplicating"):
            off_path = f"data/seams_flows/{seam_name}_offsets.npy"
            if not os.path.exists(off_path): continue

            y0, y1, x0, x1      = seam_zone_ds(seam_name)
            edge_a, edge_b, axis = seam_strip_edges_ds(seam_name)

            orig_crop = patch_canvas[y0:y1, x0:x1].copy()
            seam_crop = seam_canvas[y0:y1,  x0:x1].copy()

            if orig_crop.max() == 0 or seam_crop.max() == 0:
                del orig_crop, seam_crop; continue

            pairs = compute_pairwise_iou(orig_crop, seam_crop)
            if not pairs:
                del orig_crop, seam_crop; continue

            stats['pairs'] += len(pairs)

            # Compute all centroids in one vectorised pass per crop
            orig_centroids = get_centroids(orig_crop)
            seam_centroids = get_centroids(seam_crop)

            orig_suppress = set()
            seam_suppress = set()

            for orig_id, seam_id, iou in pairs:
                o_local = orig_centroids.get(orig_id)
                s_local = seam_centroids.get(seam_id)
                if o_local is None or s_local is None:
                    continue

                gcy_o = o_local[0] + y0;  gcx_o = o_local[1] + x0
                gcy_s = s_local[0] + y0;  gcx_s = s_local[1] + x0

                p_idx     = patch_id_map.get(orig_id)
                orig_dist = (dist_to_nearest_patch_boundary(
                                 gcy_o, gcx_o, patch_bounds[p_idx])
                             if p_idx is not None else 0.0)
                seam_dist = dist_to_seam_edge(
                    gcy_s, gcx_s, edge_a, edge_b, axis)

                if orig_dist >= seam_dist:
                    seam_suppress.add(seam_id);  stats['patch_wins'] += 1
                else:
                    orig_suppress.add(orig_id);  stats['seam_wins']  += 1

            if orig_suppress:
                m = np.isin(patch_canvas[y0:y1, x0:x1], list(orig_suppress))
                patch_canvas[y0:y1, x0:x1][m] = 0
            if seam_suppress:
                m = np.isin(seam_canvas[y0:y1, x0:x1], list(seam_suppress))
                seam_canvas[y0:y1, x0:x1][m] = 0

            del orig_crop, seam_crop, orig_centroids, seam_centroids
            gc.collect()

        print(f"Pairs evaluated: {stats['pairs']}")
        print(f"Patch wins:      {stats['patch_wins']}")
        print(f"Seam wins:       {stats['seam_wins']}")
        return seam_canvas

    def merge_canvases(self, patch_canvas, seam_canvas):
        print("\n=== Phase 3: Merging ===")
        patch_max = int(patch_canvas.max())
        seam_nz   = seam_canvas > 0
        seam_canvas[seam_nz] += patch_max

        merged = patch_canvas.copy()
        fill   = (merged == 0) & seam_nz
        merged[fill] = seam_canvas[fill]

        print("Re-indexing to contiguous IDs...")
        uids  = np.unique(merged); uids = uids[uids > 0]
        remap = np.zeros(int(merged.max()) + 1, dtype=np.int32)
        for new_id, old_id in enumerate(uids, start=1):
            remap[old_id] = new_id
        merged = remap[merged]

        print(f"Total cells: {merged.max()}")
        return merged

    def derive_shapes(self, merged, chunk_rows=2000, overlap=100):
        """
        Derive pixel-accurate polygon boundaries from merged pixel canvas.
        Uses overlapping chunks - each chunk extends by overlap rows into
        neighbouring chunks. Only shapes whose centroid falls in the core
        (non-overlap) region are kept from each chunk, ensuring each cell
        appears complete in exactly one chunk. Changed from MultiPolygons.
        """
        GLOBAL_H = self.global_h; GLOBAL_W = self.global_w
        print("\n=== Phase 4: Deriving polygon shapes ===")
        print(f"  Array shape: {merged.shape}, dtype={merged.dtype}")
        print(f"  Overlapping chunks: chunk_rows={chunk_rows}, overlap={overlap}")

        n_chunks = (GLOBAL_H + chunk_rows - 1) // chunk_rows
        all_polys = []
        all_ids   = []
        seen_ids  = set()  # track which cell_ids have been collected

        for chunk_idx in tqdm(range(n_chunks), desc="Deriving shapes"):
            # Core region — where this chunk "owns" cells
            core_y0 = chunk_idx * chunk_rows
            core_y1 = min(core_y0 + chunk_rows, GLOBAL_H)

            # Extended region — adds overlap on both sides
            ext_y0 = max(0, core_y0 - overlap)
            ext_y1 = min(GLOBAL_H, core_y1 + overlap)

            crop = merged[ext_y0:ext_y1, :].astype(np.int32)

            # FIX #2: translation-only transform (unit y-scale, NO flip) so polygon
            # coords share the y-DOWN DS-pixel frame of the label canvas and transcripts.
            # from_bounds() gave e=-1, flipping y per chunk (offset depended on
            # ext_y0+ext_y1), which broke the centroid filter and the downstream
            # transcript-in-polygon join.
            transform = Affine.translation(0, ext_y0)

            for geom, val in rasterio_shapes(
                    crop,
                    mask=(crop > 0).astype(np.uint8),
                    transform=transform):
                if val == 0:
                    continue
                cell_id = int(val)

                # skip if already collected from a previous chunk
                if cell_id in seen_ids:
                    continue

                poly = shapely.geometry.shape(geom)
                if poly.is_empty:
                    continue

                # only keep if centroid falls in core region
                # ensures each cell is claimed by exactly one chunk
                cy = poly.centroid.y
                if not (core_y0 <= cy < core_y1):
                    continue

                all_polys.append(poly)
                all_ids.append(cell_id)
                seen_ids.add(cell_id)

            del crop; gc.collect()

        gdf = gpd.GeoDataFrame({'cell_id': all_ids}, geometry=all_polys, crs=None)
        print(f"Derived {len(gdf):,} cell polygons")

        # Verify no duplicates
        n_dupes = gdf['cell_id'].duplicated().sum()
        print(f"  Duplicate cell_ids: {n_dupes} (should be 0)")

        # Check geometry types
        geom_types = gdf.geometry.geom_type.value_counts().to_dict()
        print(f"  Geometry types: {geom_types}")

        # ── Shape quality filter ──────────────────────────────────────────────────
        print("Applying shape quality filters...")

        DS_UM = self.ds_um
        gdf['area_um2']     = gdf.geometry.area * (DS_UM ** 2)
        gdf['convexity']    = gdf.geometry.area / gdf.geometry.convex_hull.area
        bounds              = gdf.geometry.bounds
        gdf['bbox_w']       = bounds['maxx'] - bounds['minx']
        gdf['bbox_h']       = bounds['maxy'] - bounds['miny']
        gdf['aspect_ratio'] = (gdf[['bbox_w','bbox_h']].max(axis=1) /
                               gdf[['bbox_w','bbox_h']].min(axis=1).clip(0.1))

        n_before = len(gdf)
        qc = self.qc_derive
        mask = (
            (gdf['area_um2']     >= qc['min_area_um2'])   &
            (gdf['area_um2']     <= qc['max_area_um2'])   &
            (gdf['convexity']    >= qc['min_convexity'])  &
            (gdf['aspect_ratio'] <= qc['max_aspect_ratio'])
        )
        gdf = gdf[mask].copy().reset_index(drop=True)
        print(f"  Removed {n_before - len(gdf):,} shapes "
              f"({(n_before-len(gdf))/n_before*100:.1f}%)")
        print(f"  Remaining: {len(gdf):,} shapes")

        gdf = gdf[['cell_id', 'geometry']].copy()
        return gdf

    def compute_cell_stats(self, merged):
        FACTOR=self.factor
        print("\n=== Phase 5: Computing cell stats ===")
        props = regionprops_table(
            merged, properties=['label', 'area', 'centroid'])
        df = pd.DataFrame(props)
        df = df.rename(columns={'label': 'cell_id', 'area': 'area_px_ds'})

        if 'centroid-0' in df.columns:
            df = df.rename(columns={'centroid-0': 'centroid_y_ds',
                                     'centroid-1': 'centroid_x_ds'})
        elif 'centroid' in df.columns:
            df['centroid_y_ds'] = df['centroid'].apply(lambda v: v[0])
            df['centroid_x_ds'] = df['centroid'].apply(lambda v: v[1])
            df = df.drop(columns=['centroid'])

        df['centroid_y'] = df['centroid_y_ds'] * FACTOR
        df['centroid_x'] = df['centroid_x_ds'] * FACTOR
        df['area_px']    = df['area_px_ds'] * (FACTOR ** 2)

        print(f"Cell count: {len(df)}")
        print(f"Area (DS px) — median: {df['area_px_ds'].median():.0f}, "
              f"mean: {df['area_px_ds'].mean():.0f}")
        return df

    def save_spatialdata_zarr(self, merged, gdf):
        OUT_DIR=self.merged_dir; DS_UM=self.ds_um
        print("\n=== Phase 6: Saving spatialdata zarr ===")
        zarr_path = os.path.join(OUT_DIR, "merged_global.zarr")

        # FIX #3: map DS pixels -> microns (1 DS px = DS_UM um) so labels and shapes
        # share the micron-global frame used by cell_boundaries_filtered and the
        # transcripts in build_complete_zarr (previously Scale([2,2]) left these in
        # full-res-pixel space while points/filtered shapes were in microns).
        merged_da   = da.from_array(merged, chunks=self.zarr_chunks)
        labels_elem = Labels2DModel.parse(
            merged_da,
            dims=('y', 'x'),
            scale_factors=self.pyramid_scale_factors,
            transformations={'global': sd.transformations.Scale(
                [DS_UM, DS_UM], axes=('y', 'x'))},
        )
        shapes_elem = ShapesModel.parse(
            gdf,
            transformations={'global': sd.transformations.Scale(
                [DS_UM, DS_UM], axes=('y', 'x'))},
        )

        sdata = SpatialData(
            labels={'cell_labels_merged': labels_elem},
            shapes={'cell_boundaries_merged': shapes_elem},
        )
        sdata.write(zarr_path, overwrite=True)
        print(f"Saved: {zarr_path}")
        return zarr_path

    def build_complete_zarr(self, merged, gdf, df_stats):
        OUT_DIR=self.merged_dir; ts=self.ts
        # NOTE: coordinate frames are now unified to microns (FIX #3) - labels/shapes
        # from merged_global carry Scale([DS_UM,DS_UM]); filtered shapes and points are
        # microns + Identity. This table is the INTERMEDIATE (merged Cellpose) table;
        # the FINAL proseg table is built by _assemble_proseg_table (FIX #4).
        print("\n=== Phase 7: Building complete zarr ===")
        import scipy.sparse as sp_sci
        import anndata as ad
        from spatialdata.models import PointsModel, TableModel
        from spatialdata.transformations import Identity

        XENIUM_ZARR = self.xenium_zarr
        TX_PARQUET  = self.tx_parquet
        OUT_COMPLETE = self.merged_complete_zarr

        DS_UM = self.ds_um  # DS pixel to micron

        # ── 7a: Filter shapes ─────────────────────────────────────────────────────
        t = time.time()
        ts("  7a: Filtering shapes...")

        gdf_um = gdf.copy()
        gdf_um['geometry'] = gdf_um.geometry.affine_transform(
            [DS_UM, 0, 0, DS_UM, 0, 0])
        gdf_um = gdf_um.set_crs(None, allow_override=True)

        gdf_um['area_um2']     = gdf_um.geometry.area
        gdf_um['convexity']    = gdf_um.geometry.area / \
                                  gdf_um.geometry.convex_hull.area
        bounds                 = gdf_um.geometry.bounds
        gdf_um['bbox_w']       = bounds['maxx'] - bounds['minx']
        gdf_um['bbox_h']       = bounds['maxy'] - bounds['miny']
        gdf_um['aspect_ratio'] = gdf_um[['bbox_w','bbox_h']].max(axis=1) / \
                                  gdf_um[['bbox_w','bbox_h']].min(axis=1).clip(0.1)

        _qc = self.qc_complete
        MIN_AREA_UM2     = _qc['min_area_um2']
        MAX_AREA_UM2     = _qc['max_area_um2']
        MIN_CONVEXITY    = _qc['min_convexity']
        MAX_ASPECT_RATIO = _qc['max_aspect_ratio']

        n_before = len(gdf_um)
        mask = (
            (gdf_um['area_um2']     >= MIN_AREA_UM2)     &
            (gdf_um['area_um2']     <= MAX_AREA_UM2)     &
            (gdf_um['convexity']    >= MIN_CONVEXITY)    &
            (gdf_um['aspect_ratio'] <= MAX_ASPECT_RATIO)
        )
        gdf_filt = gdf_um[mask].copy().reset_index(drop=True)
        ts(f"    {n_before:,} → {len(gdf_filt):,} shapes after QC "
           f"({n_before - len(gdf_filt):,} removed)")

        del gdf_um; gc.collect()
        ts(f"    Done in {time.time()-t:.1f}s")

        # ── 7b: Load transcripts ──────────────────────────────────────────────────
        t = time.time()
        ts("  7b: Loading transcripts...")
        tx = pd.read_parquet(
            TX_PARQUET,
            columns=['x', 'y', 'z', 'feature_name', 'qv',
                     'is_gene', 'overlaps_nucleus', 'transcript_id'])
        if self.gene_only:
            tx = tx[tx['is_gene'] == True].copy()
        tx = tx[tx['qv'] >= self.qv_min].copy()
        ts(f"    Gene transcripts (QV>=20): {len(tx):,}")

        # ── 7c: Spatial join ──────────────────────────────────────────────────────
        t = time.time()
        ts("  7c: Spatial join transcripts → cells (may take 20-40 min)...")
        tx_gdf = gpd.GeoDataFrame(
            tx, geometry=gpd.points_from_xy(tx['x'], tx['y']), crs=None)
        del tx; gc.collect()

        joined = gpd.sjoin(
            tx_gdf,
            gdf_filt[['cell_id', 'geometry']],
            how='left',
            predicate='within')
        assigned = joined[joined['cell_id'].notna()].copy()
        ts(f"    Assigned: {len(assigned):,} / {len(joined):,} transcripts "
           f"({len(assigned)/len(joined)*100:.1f}%)")
        del tx_gdf, joined; gc.collect()
        ts(f"    Done in {time.time()-t:.1f}s")

        # ── 7d: Keep all assigned cells  ─────────────────
        t = time.time()
        ts("  7d: Keeping all cells with >=1 transcript...")
        tx_counts = assigned.groupby('cell_id').size()
        valid_cells  = tx_counts[tx_counts >= 1].index
        gdf_final    = gdf_filt[gdf_filt['cell_id'].isin(valid_cells)].copy()
        gdf_final    = gdf_final.reset_index(drop=True)
        assigned_v   = assigned[assigned['cell_id'].isin(valid_cells)].copy()
        ts(f"    Cells with >=1 transcript: {len(gdf_final):,}")
        del gdf_filt; gc.collect()
        ts(f"    Done in {time.time()-t:.1f}s")

        # ── 7e: Build count matrix ────────────────────────────────────────────────
        t = time.time()
        ts("  7e: Building cell × gene count matrix...")
        genes    = sorted(assigned_v['feature_name'].unique())    
        assigned_cell_ids = set(assigned_v['cell_id'].astype(int).unique())
        shape_cell_ids    = set(gdf_final['cell_id'].astype(int).unique())
        cell_ids          = sorted(assigned_cell_ids & shape_cell_ids)

        assigned_v = assigned_v[
            assigned_v['cell_id'].astype(int).isin(set(cell_ids))].copy()
        ts(f"    Intersection: {len(cell_ids):,} cells in both transcripts and shapes")
        ts(f"    Dropped: {len(assigned_cell_ids - shape_cell_ids):,} transcript-only cells")
        ts(f"    Dropped: {len(shape_cell_ids - assigned_cell_ids):,} shape-only cells")

        n_cells  = len(cell_ids)
        n_genes  = len(genes)
        ts(f"    {n_cells:,} cells × {n_genes:,} genes")

        cell_idx = {c: i for i, c in enumerate(cell_ids)}
        gene_idx = {g: i for i, g in enumerate(genes)}

        # drop rows where cell_id does not map
        assigned_v = assigned_v.copy()
        assigned_v['row_idx'] = assigned_v['cell_id'].astype(int).map(cell_idx)
        assigned_v = assigned_v[assigned_v['row_idx'].notna()].copy()
        assigned_v['col_idx'] = assigned_v['feature_name'].map(gene_idx)

        rows = assigned_v['row_idx'].astype(int).values
        cols = assigned_v['col_idx'].astype(int).values
        X    = sp_sci.csr_matrix(
            (np.ones(len(rows), dtype=np.float32), (rows, cols)),
            shape=(n_cells, n_genes))
        del rows, cols; gc.collect()
        ts(f"    Matrix shape: {X.shape}, nnz={X.nnz}")
        ts(f"    Done in {time.time()-t:.1f}s")

        # ── 7f: Build AnnData ─────────────────────────────────────────────────────
        t = time.time()
        ts("  7f: Building AnnData table...")

        gdf_final_aligned = gdf_final[
            gdf_final['cell_id'].astype(int).isin(cell_ids)].copy()
        gdf_final_aligned['cell_id_int'] = gdf_final_aligned['cell_id'].astype(int)
        gdf_final_aligned = gdf_final_aligned.set_index('cell_id_int').loc[cell_ids]
        gdf_final_aligned = gdf_final_aligned.reset_index(drop=True)

        ts(f"    Aligned shapes: {len(gdf_final_aligned):,} (matrix: {n_cells:,})")
        assert len(gdf_final_aligned) == n_cells, \
            f"Still mismatched: {len(gdf_final_aligned)} vs {n_cells}"

        obs = pd.DataFrame({
            'cell_id':        [str(c) for c in cell_ids],
            'n_transcripts':  np.array(X.sum(axis=1)).flatten().astype(int),
            'area_um2':       gdf_final_aligned['area_um2'].values
                              if 'area_um2' in gdf_final_aligned.columns
                              else np.nan,
            'convexity':      gdf_final_aligned['convexity'].values
                              if 'convexity' in gdf_final_aligned.columns
                              else np.nan,
            'aspect_ratio':   gdf_final_aligned['aspect_ratio'].values
                              if 'aspect_ratio' in gdf_final_aligned.columns
                              else np.nan,
            'region':         'cell_boundaries_filtered',
        }, index=[str(c) for c in cell_ids])
        obs['region'] = obs['region'].astype('category')

        var   = pd.DataFrame(index=genes)
        adata = ad.AnnData(X=X, obs=obs, var=var)
        adata.obs_names = [str(c) for c in cell_ids]
        adata.var_names = genes
        ts(f"    AnnData: {adata.shape}")
        ts(f"    n_transcripts: min={obs['n_transcripts'].min()}, "
           f"median={obs['n_transcripts'].median():.0f}, "
           f"max={obs['n_transcripts'].max()}")
        del X; gc.collect()
        ts(f"    Done in {time.time()-t:.1f}s")

        # ── 7g: Prepare spatialdata elements ──────────────────────────────────────
        t = time.time()
        ts("  7g: Preparing spatialdata elements...")

        # Shapes — filtered, in microns
        shapes_sd = ShapesModel.parse(
            gdf_final_aligned[['geometry']].copy())

        # Points — all QV>=20 gene transcripts
        tx_pts = pd.read_parquet(
            TX_PARQUET,
            columns=['x', 'y', 'z', 'feature_name', 'qv',
                     'is_gene', 'transcript_id'])
        if self.gene_only:
            tx_pts = tx_pts[tx_pts['is_gene'] == True].copy()
        tx_pts = tx_pts[tx_pts['qv'] >= self.qv_min].copy()
        tx_pts = tx_pts.rename(columns={'feature_name': 'gene'})
        tx_pts['transcript_id'] = tx_pts['transcript_id'].astype(str)
        tx_pts = tx_pts.reset_index(drop=True)
        points_sd = PointsModel.parse(
            tx_pts,
            coordinates={'x': 'x', 'y': 'y', 'z': 'z'},
            feature_key='gene',
            instance_key='transcript_id',
            transformations={'global': Identity()})
        del tx_pts; gc.collect()

        # Table
        table_sd = TableModel.parse(
            adata,
            region='cell_boundaries_filtered',
            region_key='region',
            instance_key='cell_id')

        # Labels — reuse existing merged labels
        ts("  Loading existing labels from merged zarr...")
        existing = sd.read_zarr(os.path.join(OUT_DIR, "merged_global.zarr"))
        labels_elem = existing.labels['cell_labels_merged']
        ts(f"    Done in {time.time()-t:.1f}s")

        # ── 7h: Write complete zarr ───────────────────────────────────────────────
        t = time.time()
        ts(f"  7h: Writing complete zarr to {OUT_COMPLETE}...")
        sdata_complete = sd.SpatialData(
            labels={'cell_labels_merged':       labels_elem},
            shapes={
                'cell_boundaries_merged':   existing.shapes['cell_boundaries_merged'],
                'cell_boundaries_filtered': shapes_sd,
            },
            points={'transcripts': points_sd},
            tables={'table':       table_sd},
        )
        if os.path.exists(OUT_COMPLETE):
            import shutil
            shutil.rmtree(OUT_COMPLETE)
        sdata_complete.write(OUT_COMPLETE)
        ts(f"  Saved: {OUT_COMPLETE}")

        ts("  Summary:")
        ts(f"    Input shapes:    {len(gdf):,}")
        ts(f"    After QC:        {len(gdf_final):,}")
        ts(f"    Cells (>=1 tx):  {n_cells:,}")
        ts(f"    Genes:           {n_genes}")
        ts(f"    Transcripts:     {len(assigned):,} assigned")
        ts(f"    Done in {time.time()-t:.1f}s")

    def ds_to_um(self, ds_val):
        DS_UM=self.ds_um
        return ds_val * DS_UM

    def build_tile_grid(self, wsi_x, wsi_y, core_size, halo_size):
        """
        Build list of tile dicts covering the full slide.
        core_bounds: (x0, y0, x1, y1) 
        tile_bounds: (x0, y0, x1, y1) - expanded by halo for Proseg
        """
        n_cols = math.ceil(wsi_x / core_size)
        n_rows = math.ceil(wsi_y / core_size)
        tiles  = []

        for row in range(n_rows):
            for col in range(n_cols):
                cx0 = col * core_size
                cx1 = min((col + 1) * core_size, wsi_x)
                cy0 = row * core_size
                cy1 = min((row + 1) * core_size, wsi_y)

                tx0 = max(0,     cx0 - halo_size)
                tx1 = min(wsi_x, cx1 + halo_size)
                ty0 = max(0,     cy0 - halo_size)
                ty1 = min(wsi_y, cy1 + halo_size)

                tiles.append({
                    'row': row, 'col': col,
                    'core': (cx0, cy0, cx1, cy1),
                    'tile': (tx0, ty0, tx1, ty1),
                })

        print(f"Tile grid: {n_cols} cols x {n_rows} rows = {len(tiles)} tiles")
        return tiles, n_cols, n_rows

    def _crop_transcripts(self, pts_df, tx0_um, ty0_um, tx1_um, ty1_um):
        mask = (
            (pts_df['x'] >= tx0_um) & (pts_df['x'] < tx1_um) &
            (pts_df['y'] >= ty0_um) & (pts_df['y'] < ty1_um)
        )
        return pts_df[mask].copy()

    def _crop_masks(self, merged, tx0, ty0, tx1, ty1):
        crop = merged[ty0:ty1, tx0:tx1].copy()
        uids = np.unique(crop); uids = uids[uids > 0]
        if len(uids) == 0:
            return crop
        remap = np.zeros(int(crop.max()) + 1, dtype=np.int32)
        for new_id, old_id in enumerate(uids, start=1):
            remap[old_id] = new_id
        return remap[crop]

    def _save_npy_gz(self, arr, path):
        tmp = path.replace('.npy.gz', '.npy')
        np.save(tmp, arr)
        with open(tmp, 'rb') as f_in, gzip.open(path, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
        os.remove(tmp)

    def _tile_already_done(self, row, col):
        OUT_DIR=self.proseg_dir
        """Check if tile parquet already exists (allows resuming interrupted runs)"""
        out_parquet = os.path.join(OUT_DIR, "shapes", f"tile_{row}x{col}.parquet")
        return os.path.exists(out_parquet)

    def run_proseg_tile(self, tile, merged, pts_df, tile_idx, n_tiles):
        OUT_DIR=self.proseg_dir; ts=self.ts; DS_UM=self.ds_um
        PROSEG_BIN=self.proseg_bin
        PROSEG_SAMPLES=self.proseg_samples; PROSEG_BURNIN_SAMPLES=self.proseg_burnin_samples
        PROSEG_VOXEL_SIZE=self.proseg_voxel_size; PROSEG_BURNIN_SIZE=self.proseg_burnin_size
        PROSEG_VOXEL_LAYERS=self.proseg_voxel_layers; PROSEG_NUCLEAR_PROB=self.proseg_nuclear_prob
        PROSEG_DIFF_PROB=self.proseg_diff_prob; PROSEG_NTHREADS=self.proseg_nthreads
        ds_to_um=self.ds_to_um; tile_already_done=self._tile_already_done
        crop_transcripts=self._crop_transcripts; crop_masks=self._crop_masks
        save_npy_gz=self._save_npy_gz
        row, col   = tile['row'], tile['col']
        tx0, ty0, tx1, ty1 = tile['tile']
        cx0, cy0, cx1, cy1 = tile['core']

        # Resume support — skip completed tiles
        if tile_already_done(row, col):
            ts(f"  Tile {tile_idx+1}/{n_tiles} (r{row}c{col}): already done — skipping")
            return os.path.join(OUT_DIR, "shapes", f"tile_{row}x{col}.parquet")

        ts(f"  Tile {tile_idx+1}/{n_tiles} (r{row}c{col}): "
           f"tile DS x[{tx0}:{tx1}] y[{ty0}:{ty1}], "
           f"core DS x[{cx0}:{cx1}] y[{cy0}:{cy1}]")

        tx0_um = ds_to_um(tx0); tx1_um = ds_to_um(tx1)
        ty0_um = ds_to_um(ty0); ty1_um = ds_to_um(ty1)

        # Crop transcripts
        tx_crop = crop_transcripts(pts_df, tx0_um, ty0_um, tx1_um, ty1_um)
        if len(tx_crop) == 0:
            ts(f"    No transcripts in tile — skipping")
            return None
        ts(f"    Transcripts: {len(tx_crop):,}")

        # Crop masks
        mask_crop = crop_masks(merged, tx0, ty0, tx1, ty1)
        n_cells_in_mask = np.unique(mask_crop[mask_crop > 0]).shape[0]
        ts(f"    Mask cells: {n_cells_in_mask}")

        # Remap transcript cell_id to merged Cellpose IDs
        tx_crop = tx_crop.copy()
        col_px  = ((tx_crop["x"].values / DS_UM) - tx0).astype(int).clip(
                    0, mask_crop.shape[1] - 1)
        row_px  = ((tx_crop["y"].values / DS_UM) - ty0).astype(int).clip(
                    0, mask_crop.shape[0] - 1)
        tx_crop["cell_id"] = mask_crop[row_px, col_px]
        n_assigned   = (tx_crop["cell_id"] > 0).sum()
        n_unassigned = (tx_crop["cell_id"] == 0).sum()
        ts(f"    Assigned to merged cells: {n_assigned:,} | unassigned: {n_unassigned:,}")

        # Working directory
        tile_dir      = os.path.join(OUT_DIR, f"tile_{row}x{col}")
        os.makedirs(tile_dir, exist_ok=True)

        tx_csv_path   = os.path.join(tile_dir, "transcripts.csv")
        mask_npy_path = os.path.join(tile_dir, "cellpose_masks.npy.gz")
        out_zarr_path = os.path.join(tile_dir, "proseg_out.zarr")

        # Save transcripts and masks
        tx_out = tx_crop[["x", "y", "z", "feature_name", "cell_id"]].copy()
        tx_out.to_csv(tx_csv_path, index=False)
        save_npy_gz(mask_crop.astype(np.uint32), mask_npy_path)
        del mask_crop; gc.collect()

        # Proseg affine transforms
        x_offset_um = ds_to_um(tx0)
        y_offset_um = ds_to_um(ty0)

        cmd = [
            PROSEG_BIN, tx_csv_path,
            "-x", "x",
            "-y", "y",
            "-z", "z",
            "--gene-column",           "feature_name",
            "--cell-id-column",        "cell_id",
            "--cell-id-unassigned",    "0",
            "--cellpose-masks",        mask_npy_path,
            "--cellpose-x-transform",  str(DS_UM), "0", str(x_offset_um),
            "--cellpose-y-transform",  "0", str(DS_UM), str(y_offset_um),
            "--samples",               PROSEG_SAMPLES,
            "--burnin-samples",        PROSEG_BURNIN_SAMPLES,
            "--voxel-size",            PROSEG_VOXEL_SIZE,
            "--burnin-voxel-size",     PROSEG_BURNIN_SIZE,
            "--voxel-layers",          PROSEG_VOXEL_LAYERS,
            "--nuclear-reassignment-prob", PROSEG_NUCLEAR_PROB,
            "--diffusion-probability",     PROSEG_DIFF_PROB,
            "--nthreads",              PROSEG_NTHREADS,
            "--output-spatialdata",    out_zarr_path,
            "--overwrite",
        ]

        # Log proseg stderr to per-tile log file
        log_path = os.path.join(OUT_DIR, "logs", f"tile_{row}x{col}.log")
        ts(f"    Running Proseg... (log: {log_path})")
        t_tile = time.time()

        with open(log_path, 'w') as log_f:
            result = subprocess.run(
                cmd, stdout=log_f, stderr=subprocess.STDOUT, text=True)

        tile_elapsed = time.time() - t_tile
        if result.returncode != 0:
            ts(f"    ERROR: Proseg failed for tile {tile_idx+1} "
               f"(r{row}c{col}) after {tile_elapsed:.0f}s — see {log_path}")
            return None
        ts(f"    Proseg complete in {tile_elapsed:.0f}s")

        # Load refined shapes
        shapes_parquet = os.path.join(
            out_zarr_path, "shapes", "cell_boundaries", "shapes.parquet")
        if not os.path.exists(shapes_parquet):
            ts(f"    WARNING: no shapes parquet found")
            return None

        gdf = gpd.read_parquet(shapes_parquet)
        ts(f"    Raw shapes from Proseg: {len(gdf):,}")

        # Centroid rule — keep only cells whose centroid is in the core region
        cx0_um = ds_to_um(cx0); cx1_um = ds_to_um(cx1)
        cy0_um = ds_to_um(cy0); cy1_um = ds_to_um(cy1)

        centroids = gdf.geometry.centroid
        keep_mask = (
            (centroids.x >= cx0_um) & (centroids.x < cx1_um) &
            (centroids.y >= cy0_um) & (centroids.y < cy1_um)
        )
        gdf_kept = gdf[keep_mask].copy()
        gdf_kept['tile_row'] = row
        gdf_kept['tile_col'] = col
        ts(f"    Kept after centroid rule: {len(gdf_kept):,} / {len(gdf):,}")

        # ---- FIX #4: persist the proseg expression matrix for the kept cells ----
        # proseg writes tables/table as an AnnData whose obs rows align 1:1 with the
        # shapes parquet rows. We keep the same cells (orig_idx) so the matrix matches
        # gdf_kept row-for-row, tag each with a stable key (row:col:local_idx), and save
        # a per-tile .h5ad. assemble_tiles() stitches these into one cell x gene table
        # on the FINAL proseg segmentation (the analogue of reseg.py's table).
        gdf_kept = gdf_kept.reset_index(drop=True)
        gdf_kept['local_idx'] = np.arange(len(gdf_kept), dtype=np.int64)
        orig_idx = np.where(keep_mask.values)[0]
        try:
            import anndata as ad
            adata_tile = ad.read_zarr(os.path.join(
                tile_dir, "proseg_out.zarr", "tables", "table"))
            if adata_tile.n_obs != len(gdf):
                raise ValueError(
                    f"proseg table rows ({adata_tile.n_obs}) != shapes ({len(gdf)})")

            adata_kept = adata_tile[orig_idx].copy()
            adata_kept.obs['tile_row']  = row
            adata_kept.obs['tile_col']  = col
            adata_kept.obs['local_idx'] = np.arange(adata_kept.n_obs, dtype=np.int64)
            adata_kept.obs_names = [f"{row}:{col}:{i}" for i in range(adata_kept.n_obs)]

            if 'transcript_count' in adata_kept.obs.columns:
                tcount = adata_kept.obs['transcript_count'].to_numpy()
            elif 'cell_count' in adata_kept.obs.columns:
                tcount = adata_kept.obs['cell_count'].to_numpy()
            else:                                   # FIX #4b: row-sum X (no .iloc on ndarray)
                tcount = np.asarray(adata_kept.X.sum(axis=1)).ravel()
            gdf_kept['transcript_count'] = tcount

            tables_dir = os.path.join(OUT_DIR, "tables")
            os.makedirs(tables_dir, exist_ok=True)
            adata_kept.write_h5ad(os.path.join(tables_dir, f"tile_{row}x{col}.h5ad"))
            ts(f"    Saved expression matrix: {adata_kept.n_obs:,} cells "
               f"x {adata_kept.n_vars:,} genes")
            del adata_tile, adata_kept
        except Exception as e:
            ts(f"    WARNING: could not load proseg expression table ({e})")
            gdf_kept['transcript_count'] = np.nan

        # Save tile shapes — NO filtering yet
        out_parquet = os.path.join(OUT_DIR, "shapes", f"tile_{row}x{col}.parquet")
        gdf_kept.to_parquet(out_parquet)
        ts(f"    Saved: {out_parquet} ({len(gdf_kept):,} cells)")

        # Cleanup tile inputs
        if os.path.exists(tx_csv_path):
            os.remove(tx_csv_path)
        if os.path.exists(mask_npy_path):
            os.remove(mask_npy_path)

        del tx_crop, gdf, gdf_kept; gc.collect()
        return out_parquet

    def assemble_tiles(self):
        OUT_DIR=self.proseg_dir; ts=self.ts
        MIN_AREA_UM2=self.min_area_um2; MAX_AREA_UM2=self.max_area_um2
        MIN_CONVEXITY=self.assemble_min_convexity; MAX_ASPECT_RATIO=self.max_aspect_ratio
        MIN_TRANSCRIPTS=self.min_transcripts
        """
        Concatenate all tile outputs.
        Filtering is applied LAST — in this order:
          1. Shape quality: convexity, area, aspect ratio
          2. Transcript count: >= MIN_TRANSCRIPTS

        All cells are retained through tiling — nothing is dropped until here.
        """
        shape_files = sorted(glob.glob(
            os.path.join(OUT_DIR, "shapes", "tile_*.parquet")))
        if not shape_files:
            ts("No tile outputs found to assemble")
            return None

        ts(f"Assembling {len(shape_files)} tile outputs...")
        gdfs = []
        for sf in shape_files:
            gdf_tile = gpd.read_parquet(sf)
            gdfs.append(gdf_tile)

        merged_gdf = pd.concat(gdfs, ignore_index=True)
        del gdfs; gc.collect()
        ts(f"Total cells before filtering: {len(merged_gdf):,}")

        # ── Filter 1: Shape quality ───────────────────────────────────────────────
        ts("Applying shape quality filters...")

        merged_gdf['area_um2']     = merged_gdf.geometry.area
        merged_gdf['convexity']    = (merged_gdf.geometry.area /
                                      merged_gdf.geometry.convex_hull.area)
        bounds                     = merged_gdf.geometry.bounds
        merged_gdf['bbox_w']       = bounds['maxx'] - bounds['minx']
        merged_gdf['bbox_h']       = bounds['maxy'] - bounds['miny']
        merged_gdf['aspect_ratio'] = (
            merged_gdf[['bbox_w','bbox_h']].max(axis=1) /
            merged_gdf[['bbox_w','bbox_h']].min(axis=1).clip(lower=0.1))

        n_before = len(merged_gdf)
        shape_mask = (
            (merged_gdf['area_um2']     >= MIN_AREA_UM2)     &
            (merged_gdf['area_um2']     <= MAX_AREA_UM2)     &
            (merged_gdf['convexity']    >= MIN_CONVEXITY)    &
            (merged_gdf['aspect_ratio'] <= MAX_ASPECT_RATIO)
        )
        merged_gdf = merged_gdf[shape_mask].copy()
        ts(f"  After shape filter: {len(merged_gdf):,} "
           f"({n_before - len(merged_gdf):,} removed, "
           f"{(n_before-len(merged_gdf))/n_before*100:.1f}%)")

        # Report shape metric distributions
        ts(f"  Area:         mean={merged_gdf['area_um2'].mean():.1f} µm², "
           f"median={merged_gdf['area_um2'].median():.1f} µm²")
        ts(f"  Convexity:    mean={merged_gdf['convexity'].mean():.3f}")
        ts(f"  Aspect ratio: mean={merged_gdf['aspect_ratio'].mean():.2f}")

        # ── Filter 2: Transcript count ────────────────────────────────────────────
        ts(f"Applying transcript count filter (>={MIN_TRANSCRIPTS})...")
        n_before = len(merged_gdf)

        if 'transcript_count' in merged_gdf.columns:
            has_count  = merged_gdf['transcript_count'].notna()
            count_mask = (
                merged_gdf['transcript_count'].fillna(0) >= MIN_TRANSCRIPTS)
            merged_gdf = merged_gdf[count_mask].copy()
            ts(f"  After transcript filter: {len(merged_gdf):,} "
               f"({n_before - len(merged_gdf):,} removed)")
            ts(f"  Transcript count: "
               f"mean={merged_gdf['transcript_count'].mean():.1f}, "
               f"median={merged_gdf['transcript_count'].median():.0f}, "
               f"max={merged_gdf['transcript_count'].max():.0f}")
        else:
            ts("  WARNING: no transcript_count column — skipping count filter")

        # Drop helper columns before saving
        drop_cols = ['bbox_w', 'bbox_h']
        merged_gdf = merged_gdf.drop(
            columns=[c for c in drop_cols if c in merged_gdf.columns])

        # Assign globally unique contiguous cell IDs
        merged_gdf = merged_gdf.reset_index(drop=True)
        merged_gdf['cell_id'] = [f"proseg_{i+1}" for i in range(len(merged_gdf))]

        ts(f"Final cell count: {len(merged_gdf):,}")

        # Save filtered result
        out_path = os.path.join(OUT_DIR, "merged_proseg_wsi.parquet")
        merged_gdf.to_parquet(out_path)
        ts(f"Saved → {out_path}")

        # FIX #4: build the cell x gene expression table on the FINAL proseg cells
        self._assemble_proseg_table(merged_gdf)

        # Save cell stats summary
        stats = pd.DataFrame({
            'n_cells':          [len(merged_gdf)],
            'mean_area_um2':    [merged_gdf['area_um2'].mean()],
            'median_area_um2':  [merged_gdf['area_um2'].median()],
            'mean_convexity':   [merged_gdf['convexity'].mean()],
            'mean_tx_count':    [merged_gdf['transcript_count'].mean()
                                 if 'transcript_count' in merged_gdf.columns
                                 else np.nan],
            'median_tx_count':  [merged_gdf['transcript_count'].median()
                                 if 'transcript_count' in merged_gdf.columns
                                 else np.nan],
        })
        stats.to_csv(os.path.join(OUT_DIR, "cell_stats.csv"), index=False)
        ts(f"Saved → {OUT_DIR}/cell_stats.csv")

        return merged_gdf

    def _assemble_proseg_table(self, merged_gdf):
        """FIX #4: stitch the per-tile proseg expression matrices into ONE
        cell x gene table aligned to the final proseg_N cell_ids.

        Each surviving cell is keyed by (tile_row, tile_col, local_idx), which
        matches the obs_names written per tile in run_proseg_tile. This is the
        analogue of reseg.py's final table, but built on the whole-slide proseg
        segmentation rather than the per-patch one. Written as merged_proseg_wsi.h5ad.
        """
        import anndata as ad
        OUT_DIR = self.proseg_dir; ts = self.ts
        tables_dir = os.path.join(OUT_DIR, "tables")
        h5ads = sorted(glob.glob(os.path.join(tables_dir, "tile_*.h5ad")))
        if not h5ads:
            ts("  No per-tile proseg tables found - skipping expression table")
            return None
        if not {'tile_row', 'tile_col', 'local_idx'}.issubset(merged_gdf.columns):
            ts("  merged_gdf lacks tile keys - skipping expression table")
            return None

        ts(f"  Assembling expression table from {len(h5ads)} tile tables...")
        adata_all = ad.concat([ad.read_h5ad(f) for f in h5ads],
                              join='outer', index_unique=None)
        gc.collect()

        def _key(df):
            return (df['tile_row'].astype(int).astype(str) + ':' +
                    df['tile_col'].astype(int).astype(str) + ':' +
                    df['local_idx'].astype(int).astype(str)).to_numpy()

        want = merged_gdf.reset_index(drop=True).copy()
        want_key = _key(want)
        pos = pd.Series(np.arange(adata_all.n_obs), index=adata_all.obs_names.to_numpy())
        found = pd.Series(want_key).map(pos)

        n_missing = int(found.isna().sum())
        if n_missing:
            ts(f"  WARNING: {n_missing:,}/{len(want):,} final cells had no "
               f"matching tile-table row (kept the rest)")

        matched_rows = found.notna().to_numpy()
        keep_pos = found.dropna().astype(int).to_numpy()
        adata_final = adata_all[keep_pos].copy()

        matched = want.loc[matched_rows].reset_index(drop=True)
        adata_final.obs = adata_final.obs.reset_index(drop=True)
        adata_final.obs['cell_id']         = matched['cell_id'].to_numpy()
        adata_final.obs['area_um2']        = matched['area_um2'].to_numpy()
        if 'transcript_count' in matched.columns:
            adata_final.obs['transcript_count'] = matched['transcript_count'].to_numpy()
        adata_final.obs_names = matched['cell_id'].to_numpy()

        out_h5ad = os.path.join(OUT_DIR, "merged_proseg_wsi.h5ad")
        adata_final.write_h5ad(out_h5ad)
        ts(f"  Saved expression table -> {out_h5ad} "
           f"({adata_final.n_obs:,} cells x {adata_final.n_vars:,} genes)")
        return adata_final

    # ============================================================= #
    #  PHASE 3 orchestrator  (from 4_merge_masks_full.py __main__)  #
    # ============================================================= #

    def run_merge(self):
        ts = self.ts
        ts("START")
        ts("Phase 1 start - building patch canvas")
        patch_canvas, patch_id_map, patch_bounds = self.build_patch_canvas()
        ts("Phase 1 complete")

        ts("Loading lattice masks")
        lattice = np.load(self.lattice_path)
        assert lattice.shape == (self.global_h, self.global_w), \
            f"Unexpected lattice shape: {lattice.shape}"
        print(f"Lattice: {lattice.max()} seam cells")
        ts("Lattice loaded")

        ts("Phase 2 start - deduplication")
        seam_canvas = self.deduplicate(patch_canvas, patch_id_map, patch_bounds, lattice)
        del lattice; gc.collect()
        ts("Phase 2 complete")

        ts("Phase 3 start - merging")
        merged = self.merge_canvases(patch_canvas, seam_canvas)
        del patch_canvas, seam_canvas; gc.collect()
        ts("Phase 3 complete")

        np.save(self.merged_npy, merged)
        print(f"Saved: {self.merged_npy}")
        ts("merged_masks.npy saved")

        ts("Phase 4 start - deriving shapes")
        gdf = self.derive_shapes(merged)
        gdf.to_parquet(os.path.join(self.merged_dir, "merged_shapes.parquet"))
        print("Saved: merged_shapes.parquet")
        ts("Phase 4 complete")

        ts("Phase 5 start - cell stats")
        df_stats = self.compute_cell_stats(merged)
        df_stats.to_csv(os.path.join(self.merged_dir, "merged_cell_stats.csv"), index=False)
        print("Saved: merged_cell_stats.csv")
        ts("Phase 5 complete")

        ts("Phase 6 start - saving spatialdata zarr")
        self.save_spatialdata_zarr(merged, gdf)
        ts("Phase 6 complete")

        ts("Phase 7 start - building complete zarr")
        self.build_complete_zarr(merged, gdf, df_stats)
        ts("Phase 7 complete")

    # ============================================================= #
    #  PHASE 4 orchestrator  (from 5_proseg_wsi.py __main__)        #
    # ============================================================= #

    def run_proseg_wsi(self):
        ts = self.ts
        t0 = time.time()
        ts("=== PROSEG WSI START ===")
        ts(f"Full slide: {self.wsi_x_ds} x {self.wsi_y_ds} DS px = "
           f"{self.ds_to_um(self.wsi_x_ds):.0f} x {self.ds_to_um(self.wsi_y_ds):.0f} um")

        tiles, n_cols, n_rows = self.build_tile_grid(
            self.wsi_x_ds, self.wsi_y_ds, self.core_ds, self.halo_ds)
        ts(f"Estimated runtime: ~{len(tiles) * 13 / 60:.1f}h "
           f"at ~13 min/tile ({len(tiles)} tiles)")

        # NOTE: only these 5 columns are loaded, so the qv / is_gene guards below
        # are no-ops in the original. Preserved faithfully.
        ts("Loading transcripts (whole slide)...")
        pts_df = pd.read_parquet(
            self.tx_parquet, columns=['x', 'y', 'z', 'feature_name', 'cell_id'])
        ts(f"Loaded {len(pts_df):,} transcripts")
        if 'qv' in pts_df.columns:
            pts_df = pts_df[pts_df['qv'] >= self.qv_min].copy()
            ts(f"After QV>=20 filter: {len(pts_df):,}")
        if 'is_gene' in pts_df.columns:
            pts_df = pts_df[pts_df['is_gene'] == True].copy()
            ts(f"After is_gene filter: {len(pts_df):,}")

        ts("Loading merged masks (mmap)...")
        merged = np.load(self.merged_npy, mmap_mode='r')
        ts(f"Merged masks: {merged.shape}")

        results = []
        for i, tile in enumerate(tiles):
            out = self.run_proseg_tile(tile, merged, pts_df, i, len(tiles))
            if out:
                results.append(out)
            if (i + 1) % 10 == 0:
                elapsed = time.time() - t0
                rate    = elapsed / (i + 1)
                remain  = rate * (len(tiles) - i - 1)
                ts(f"Progress: {i+1}/{len(tiles)} tiles done | "
                   f"elapsed={elapsed/3600:.1f}h | remaining~{remain/3600:.1f}h")

        ts(f"\nCompleted {len(results)}/{len(tiles)} tiles successfully")
        ts("\n=== Assembling and filtering ===")
        self.assemble_tiles()
        elapsed = time.time() - t0
        ts(f"=== COMPLETE - {elapsed/3600:.2f}h ({elapsed:.1f}s) ===")
        ts(f"Output: {self.proseg_dir}/merged_proseg_wsi.parquet")

    # ============================================================= #
    #  Full pipeline (single process) - convenient for Spyder       #
    # ============================================================= #

    def run_all(self, seams=True):
        """Run the whole pipeline end-to-end in one process.

        Order: Phase 1 (all seam flows, sequential) -> Phase 2 (lattice) ->
        Phase 3 (merge) -> Phase 4 (proseg WSI). On a cluster you would normally
        run Phase 1 as a 52-job array instead; pass seams=False to skip Phase 1
        and reuse seam flows already on disk.
        """
        t0 = time.time()
        self.ts("================  FULL PIPELINE START  ================")
        if seams:
            self.ts(f"PHASE 1/4: seam flows ({self.total_seams} seams)")
            for i in range(self.total_seams):
                self.ts(f"  --- seam {i + 1}/{self.total_seams} ---")
                self.extract_seam_flow(i)
        else:
            self.ts("PHASE 1/4: skipped (seams=False) - reusing existing seam flows")

        self.ts("PHASE 2/4: lattice masks")
        self.generate_lattice_masks()

        self.ts("PHASE 3/4: merge")
        self.run_merge()

        self.ts("PHASE 4/4: proseg WSI")
        self.run_proseg_wsi()

        self.ts(f"================  FULL PIPELINE COMPLETE  "
                f"({(time.time() - t0) / 3600:.2f}h)  ================")


# ===================================================================== #
#  Entry point                                                          #
#  - Spyder / notebook / "Run file" (no arguments): runs the FULL       #
#    pipeline end-to-end (all seams -> lattice -> merge -> proseg).      #
#  - Command line / SLURM: pass a stage to run a single phase:          #
#       python seam_stitch_pipeline.py seam_flow 0                      #
#       python seam_stitch_pipeline.py lattice | merge | proseg         #
#       python seam_stitch_pipeline.py all       (same as no argument)  #
#  Config: edit CONFIG_PATH below, or set the SEAM_CONFIG env var.      #
# ===================================================================== #

if __name__ == "__main__":
    # Edit this path, or set the SEAM_CONFIG environment variable.
    CONFIG_PATH = os.environ.get("SEAM_CONFIG", "config.yml")
    pipe = SeamStitchPipeline(config_path=CONFIG_PATH)

    # No argument (Spyder "Run file") -> run everything. A stage name runs one phase.
    stage = sys.argv[1] if len(sys.argv) > 1 else "all"

    if stage == "all":
        pipe.run_all()
    elif stage == "seam_flow":
        idx = int(sys.argv[2]) if len(sys.argv) > 2 else 0
        pipe.extract_seam_flow(idx)
    elif stage == "lattice":
        pipe.generate_lattice_masks()
    elif stage == "merge":
        pipe.run_merge()
    elif stage == "proseg":
        pipe.run_proseg_wsi()
    else:
        print("Usage: python seam_stitch_pipeline.py "
              "[all | seam_flow <i> | lattice | merge | proseg]")
        sys.exit(1)