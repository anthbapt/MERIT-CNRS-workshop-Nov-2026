#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# =============================================================================
#
# reseg_tools — helpers used by reseg_workflow.py.
#
# The original CosMx pipeline (Resegmentation_cosmx in reseg.py) was designed
# around a single stitched mosaic image named 'Stitched' that already had a
# global affine attached to it. The TMA-core zarrs produced by
# splitting_cosmx_updated.py instead carry per-FOV elements ('1_image',
# '2_image', …, '<n>_image' plus matching '*_labels', '*_points', '*_shapes')
# and no stitched image at all. This module bridges the two.
#
# stitch_cosmx_core(sdata, output_zarr_path) takes a per-FOV SpatialData and
# produces a stitched SpatialData with:
#   - 'Stitched'  Image2DModel  : mosaic of all FOV images, with a global
#                                 affine that follows the same convention as
#                                 the per-FOV affines (y-flipped, translation
#                                 set to the canvas left/top corner)
#   - 'points'    DaskDataFrame : concatenation of all per-FOV points. The
#                                 x_global_px / y_global_px columns are
#                                 already in slide-world coordinates, so they
#                                 stay untouched.
#   - 'tables/table' : preserved as-is.
#
# Per-FOV labels and shapes are intentionally dropped — Resegmentation_cosmx
# generates new ones from the cellpose pass on the stitched image.
#
# =============================================================================
import os
import numpy as np
import dask.dataframe as dd
import spatialdata as sd
from spatialdata.models import Image2DModel
from spatialdata.transformations import Affine, Identity


def _resolve_image(img_obj):
    """Return the underlying xarray.DataArray for an sdata image element.

    Spatialdata returns single-scale images as plain xarray.DataArray and
    multiscale images as DataTree; handle both transparently.
    """
    try:
        # multiscale: img_obj["scale0"].ds["image"]
        return img_obj["scale0"].ds["image"]
    except (KeyError, TypeError):
        return img_obj


def _affine_translation(img_xr):
    """Pull (x_off, y_off) from an FOV image's global affine.

    The per-FOV affine has the structure (axes c,y,x → c,x,y):
        [1  0  0  0    ]
        [0  ~0 1  x_off]   (output_x = local_x + x_off)
        [0 -1  0  y_off]   (output_y = y_off - local_y)
        [0  0  0  1    ]
    so columns 3 of rows 1 and 2 hold the world-x and world-y of local (0,0).
    """
    affine = img_xr.attrs["transform"]["global"]
    matrix = affine.matrix
    return float(matrix[1, 3]), float(matrix[2, 3])


def stitch_cosmx_core(sdata, output_zarr_path=None, overwrite=True):
    """Stitch a per-FOV CosMx SpatialData into a single mosaic.

    Args:
        sdata: SpatialData with elements named '<n>_image', '<n>_labels',
            '<n>_points', '<n>_shapes' (n = FOV id, integer-prefixed).
        output_zarr_path: If given, the stitched SpatialData is also written
            to this path and re-loaded fresh from disk (so the returned
            object's lazy handles point at the new file rather than the
            input). If None, the stitched object is returned in-memory only.
        overwrite: Whether to overwrite output_zarr_path if it exists.

    Returns:
        spatialdata.SpatialData with one 'Stitched' image, one 'points'
        element, and the preserved 'table'.
    """
    # ---- 1. Discover FOVs and their affines --------------------------- #
    fov_ids = sorted(
        int(k.split("_image")[0])
        for k in sdata.images.keys()
        if k.endswith("_image") and k.split("_image")[0].isdigit()
    )
    if not fov_ids:
        raise RuntimeError(
            "No FOV images found in sdata — expected keys like '1_image'."
        )

    fov_meta = {}
    for fov_id in fov_ids:
        img_xr = _resolve_image(sdata.images[f"{fov_id}_image"])
        x_off, y_off = _affine_translation(img_xr)
        fov_meta[fov_id] = {
            "x_off": x_off,
            "y_off": y_off,
            "shape": tuple(img_xr.shape),  # (c, h, w)
            "image": img_xr,
        }

    # ---- 2. Compute canvas geometry ----------------------------------- #
    n_channels = next(iter(fov_meta.values()))["shape"][0]
    dtype = next(iter(fov_meta.values()))["image"].dtype
    fov_h = max(meta["shape"][1] for meta in fov_meta.values())
    fov_w = max(meta["shape"][2] for meta in fov_meta.values())

    x_offs = [meta["x_off"] for meta in fov_meta.values()]
    y_offs = [meta["y_off"] for meta in fov_meta.values()]
    min_x_off = min(x_offs)
    max_x_right = max(x_offs) + fov_w        # right edge of canvas in world x
    max_y_off = max(y_offs)                  # top edge of canvas in world y
    min_y_bottom = min(y_offs) - fov_h       # bottom edge of canvas in world y

    canvas_w = int(round(max_x_right - min_x_off))
    canvas_h = int(round(max_y_off - min_y_bottom))

    print(
        f"  Stitching {len(fov_ids)} FOVs into a "
        f"{n_channels}×{canvas_h}×{canvas_w} mosaic ({dtype})"
    )

    # ---- 3. Allocate canvas and blit FOVs ----------------------------- #
    # Canvas is in image-coord pixel space (y_down, top=row 0). Each FOV is
    # placed at canvas_y = max_y_off - fov_y_off (so the topmost FOV in world
    # coords lands at canvas row 0), canvas_x = fov_x_off - min_x_off.
    canvas = np.zeros((n_channels, canvas_h, canvas_w), dtype=dtype)
    for fov_id, meta in fov_meta.items():
        h, w = meta["shape"][1], meta["shape"][2]
        cx = int(round(meta["x_off"] - min_x_off))
        cy = int(round(max_y_off - meta["y_off"]))
        data = meta["image"].data
        arr = data.compute() if hasattr(data, "compute") else np.asarray(data)
        canvas[:, cy : cy + h, cx : cx + w] = arr

    # ---- 4. Build the global affine for 'Stitched' -------------------- #
    # Same convention as per-FOV affines: maps (c, y_local, x_local) →
    # (c, x_world, y_world) with y flipped:
    #     out_x = in_x + min_x_off
    #     out_y = max_y_off - in_y
    affine_4x4 = np.array(
        [
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, min_x_off],
            [0.0, -1.0, 0.0, max_y_off],
            [0.0, 0.0, 0.0, 1.0],
        ]
    )
    transform = Affine(
        affine_4x4,
        input_axes=("c", "y", "x"),
        output_axes=("c", "x", "y"),
    )
    stitched_image = Image2DModel.parse(
        canvas,
        dims=("c", "y", "x"),
        transformations={"global": transform},
    )

    # ---- 5. Concatenate per-FOV points -------------------------------- #
    # dd.concat drops the spatialdata `attrs` dict that holds the transform,
    # which makes spatialdata 0.4's SpatialData(...) validator reject the
    # frame. We can't use PointsModel.parse(..., coordinates={"x": ...}) here
    # because that rewrites the dataframe to have plain "x"/"y" axis columns
    # — but Resegmentation_cosmx.process_points_and_tables explicitly reads
    # the 'x_global_px' / 'y_global_px' columns and would break. Instead,
    # restore the minimum attrs the validator requires, leaving the
    # column layout untouched. The downstream code overwrites these attrs
    # with the proper Stitched-derived affine.
    point_keys = list(sdata.points.keys())
    if point_keys:
        merged_points = dd.concat(
            [sdata.points[k] for k in point_keys],
            axis=0,
            ignore_index=False,
        )
        # Mirror the attrs structure produced by PointsModel.parse without
        # going through it. The original per-FOV points were validated at
        # write time, so this just re-decorates the merged frame.
        first_attrs = sdata.points[point_keys[0]].attrs
        feature_key = (
            first_attrs.get("spatialdata_attrs", {}).get("feature_key", "target")
        )
        # multispace patch: spatialdata >= 0.8 forbids assigning a dict to
        # .attrs on dask frames; update the accessor in place instead.
        merged_points.attrs.update({
            "transform": {"global": Identity()},
            "spatialdata_attrs": {"feature_key": feature_key},
        })
    else:
        merged_points = None

    # ---- 6. Assemble the new SpatialData ----------------------------- #
    images = {"Stitched": stitched_image}
    points = {"points": merged_points} if merged_points is not None else {}
    tables = {}
    if "table" in sdata.tables:
        tables["table"] = sdata.tables["table"]

    new_sdata = sd.SpatialData(images=images, points=points, tables=tables)

    if output_zarr_path is not None:
        if os.path.exists(output_zarr_path) and not overwrite:
            raise FileExistsError(
                f"{output_zarr_path} exists and overwrite=False"
            )
        new_sdata.write(output_zarr_path, overwrite=overwrite)
        # Re-load from disk so downstream consumers (Resegmentation_cosmx)
        # get fresh lazy handles into the new file rather than holding
        # references back into the original per-FOV zarr.
        new_sdata = sd.read_zarr(output_zarr_path)

    return new_sdata
