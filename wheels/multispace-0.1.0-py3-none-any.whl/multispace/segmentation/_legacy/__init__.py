"""Original resegmentation code (CosMx / Xenium classes, Proseg wrapper, Atera seam-stitch), kept as-is apart from the patches marked "multispace patch"."""
