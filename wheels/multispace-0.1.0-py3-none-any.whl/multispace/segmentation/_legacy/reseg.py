#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# multispace: legacy resegmentation classes.
# Base: reseg_2.py (most recent shared version). Every change made for
# multispace is marked "multispace patch"; see docs/planning/
# package_integration_decisions.md for the full list and the tests that cover it.
import os
import sys
import gc
import shutil
import logging
import numpy as np
import pandas as pd
import geopandas as gpd
import anndata as ad
from PIL import Image
from collections import OrderedDict
from shapely.geometry import Polygon, MultiPolygon
from shapely.affinity import scale, translate
from skimage.measure import label, regionprops, find_contours
from skimage.measure import regionprops_table
from scipy.ndimage import find_objects
from skimage.transform import resize
try:  # multispace patch: TensorFlow is only used to report / clear GPU state
    import tensorflow as tf
except ImportError:  # pragma: no cover
    tf = None
from dask.distributed import Client
from cellpose import io, models
import spatialdata as sd
from spatialdata.models import Labels2DModel, ShapesModel, PointsModel
import dask.dataframe as dd
from tqdm import tqdm
from spatialdata.transformations import Affine
import scanpy as sc
import scipy.sparse as sp
from scipy.sparse import csr_matrix
from pathlib import Path
from .proseg_wrapper import (
    run_proseg_refinement,
    fix_zarr_metadata,
    validate_and_parse_components,
    create_integrated_spatialdata,
    fix_anndata_table,
    load_proseg_components,
    create_visualizations,
    generate_comparison_statistics,
    export_data
)

# =============================================================================
# multispace patches — shared helpers
# =============================================================================
# Pixel convention used below: "corner" coordinates, i.e. pixel (row r, col c)
# covers [c, c+1) x [r, r+1). This is the convention of the transcript
# coordinates (Xenium microns / pixel size, CosMx canvas pixels) and of
# spatialdata centroids. skimage.find_contours returns pixel-*centre* index
# coordinates, hence the +0.5 when polygons are built from masks.

def _load_gene_list(gene_list_path, current_genes):
    """Reference gene order, or the current genes when no reference is given
    (the Xenium methods used to require gene_list_10X.csv in the cwd)."""
    if gene_list_path is not None and os.path.exists(gene_list_path):
        return pd.read_csv(gene_list_path)['gene_name'].tolist()
    print(" No reference gene list - keeping the panel's genes as they are")
    return list(current_genes)


def _points_to_image_px(points_el, image_el, xy, coordinate_system="global",
                        fallback_pixel_size=0.2125):
    """Map point coordinates (the points element's own units, microns for
    Xenium) to the image's pixel grid through the SpatialData transforms:
        image_px = inv(T_image->cs) @ T_points->cs @ xy
    Replaces the old "divide by 0.2125, then subtract the minimum transcript
    x / y" logic, which displaced every transcript by the tissue margin.
    Falls back to xy / fallback_pixel_size (no shift) if the two elements share
    no coordinate system."""
    from spatialdata.transformations import get_transformation

    try:
        tp = get_transformation(points_el, to_coordinate_system=coordinate_system)
        ti = get_transformation(image_el, to_coordinate_system=coordinate_system)
        tp = np.asarray(tp.to_affine_matrix(input_axes=("x", "y"), output_axes=("x", "y")), dtype=float)
        ti = np.asarray(ti.to_affine_matrix(input_axes=("x", "y"), output_axes=("x", "y")), dtype=float)
    except Exception as err:  # no shared coordinate system
        logging.getLogger(__name__).warning(
            "Cannot relate points and image through '%s' (%s); assuming %.4f um/px and a shared origin.",
            coordinate_system, err, fallback_pixel_size)
        return np.asarray(xy, dtype=float) / fallback_pixel_size
    m = np.linalg.inv(ti) @ tp
    return np.asarray(xy, dtype=float) @ m[:2, :2].T + m[:2, 2]


def _image_transforms(image_el):
    """Transforms of the segmented image, so shapes / labels drawn in its pixel
    grid land in the same place in every coordinate system (cropped cores too)."""
    from spatialdata.transformations import get_transformation

    try:
        return dict(get_transformation(image_el, get_all=True))
    except Exception:
        return None


def _upscale_xy(obj):
    """(sx, sy): full-resolution pixels per segmentation pixel.

    The segmentation input is resized to int(H / factor) x int(W / factor), so
    the true ratio is H / h' (not exactly ``factor`` when H is not a multiple
    of it). Falls back to factor_rescale when the shapes are unknown."""
    full = getattr(obj, "_full_shape", None)
    masks = getattr(obj, "masks", None)
    if full is not None and masks is not None:
        h, w = np.squeeze(np.asarray(masks)).shape
        return full[1] / w, full[0] / h
    f = float(obj.factor_rescale) if obj.factor_rescale else 1.0
    return f, f


def _upscale_labels(obj):
    """Nearest-neighbour upscale of the masks to exactly the image's shape."""
    full = getattr(obj, "_full_shape", None)
    target = full if full is not None else tuple(int(s * obj.factor_rescale) for s in obj.masks.shape)
    return resize(obj.masks, target, order=0, preserve_range=True, anti_aliasing=False).astype(np.int32)


def _attach_join(gdf_points, joined, label=""):
    """cell_id per transcript from a left sjoin: keep the first match when a
    transcript falls in overlapping polygons, and re-align on the index rather
    than trusting sjoin row order."""
    n_rows = len(joined)
    joined = joined[~joined.index.duplicated(keep='first')]
    if n_rows != len(joined):
        print(f"Resolved {n_rows - len(joined):,} transcripts matching multiple "
              f"overlapping polygons{label} (kept first)")
    return joined.loc[gdf_points.index, "cell_id"].to_numpy()


def _sparse_counts(assigned, gene_col, shape_cell_ids):
    """cells x genes CSR matrix from transcripts with a cell_id (memory scales
    with non-zeros, not cells x genes). Rows: cells with >= 1 transcript that
    also have a shape."""
    assigned = assigned[assigned["cell_id"].notna() & assigned[gene_col].notna()].copy()
    assigned[gene_col] = assigned[gene_col].astype(str)
    cell_ids = sorted(set(assigned["cell_id"].unique()) & set(shape_cell_ids))
    genes = sorted(assigned[gene_col].unique())
    assigned = assigned[assigned["cell_id"].isin(set(cell_ids))]
    cell_idx = {c: i for i, c in enumerate(cell_ids)}
    gene_idx = {g: i for i, g in enumerate(genes)}
    rows = assigned["cell_id"].map(cell_idx).to_numpy(dtype=int)
    cols = assigned[gene_col].map(gene_idx).to_numpy(dtype=int)
    X = csr_matrix((np.ones(len(rows), dtype=np.float32), (rows, cols)),
                   shape=(len(cell_ids), len(genes)))
    X.sum_duplicates()
    return X, [str(c) for c in cell_ids], genes


class Resegmentation_cosmx:
    """Pipeline for spatial omics segmentation and data integration.

    This class encapsulates preprocessing, segmentation, mask filtering,
    shape/label creation, transcript assignment, and writing results
    back to a SpatialData Zarr file.
    
    Attributes:
        zarr_dir (str): Directory containing the input Zarr file.
        zarr_name (str): Name of the input Zarr file.
        output (str): Path to save preprocessed image output.
        factor_rescale (int): Factor by which to rescale coordinates between 
            segmentation and original resolution.
        image_name (str): Name of the image layer in SpatialData.
        label_name (str): Name for the output label layer.
        shape_name (str): Name for the output shape layer.
        point_name (str): Name of the point layer in SpatialData.
        sdata (sd.SpatialData): Loaded SpatialData object.
        image (PIL.Image): Preprocessed image for segmentation.
        masks (np.ndarray): Segmentation masks from Cellpose.
        flows (tuple): Flow outputs from Cellpose.
        styles (np.ndarray): Style outputs from Cellpose.
        gdf_polygons (gpd.GeoDataFrame): Polygon geometries for segmented cells.
        shapes_model (gpd.GeoDataFrame): SpatialData shapes model.
        labels_model (sd.models.Labels2DModel): SpatialData labels model.
        gdf_points (gpd.GeoDataFrame): Point geometries for transcripts.
        vdata (ad.AnnData): AnnData object containing gene expression matrix.
    """

    def __init__(self, zarr_dir: str,
                 zarr_name: str,
                 output: str,
                 factor_rescale: int,
                 image_name: str,
                 label_name: str,
                 shape_name: str,
                 point_name: str):
        """Initialize Resegmentation pipeline.
        
        Args:
            zarr_dir (str): Directory containing the input Zarr file.
            zarr_name (str): Name of the input Zarr file.
            output (str): Path to save preprocessed image output.
            factor_rescale (int): Rescaling factor between segmentation and 
                original resolution (e.g., 4 means segmentation is 4x smaller).
            image_name (str): Name of the image layer in SpatialData.
            label_name (str): Name for the output label layer.
            shape_name (str): Name for the output shape layer.
            point_name (str): Name of the point layer in SpatialData.
        """
        
        self.zarr_dir = zarr_dir
        self.zarr_name = zarr_name
        self.output = output
        self.factor_rescale = factor_rescale
        self.image_name = image_name
        self.label_name = label_name
        self.shape_name = shape_name
        self.point_name = point_name
        self.sdata = None
        self.image = None
        self.masks = None
        self.flows = None
        self.styles = None
        self.gdf_polygons = None
        self.shapes_model = None
        self.labels_model = None
        self.gdf_points = None
        self.vdata = None
        self.output_folder = "updated_" + zarr_dir
        os.makedirs(self.output_folder, exist_ok=True)

    # ---------------- GPU UTILITIES ---------------- #

    @staticmethod
    def check_gpu():
        """Print Python environment, TensorFlow version, and GPU availability.
        
        Displays diagnostic information about the current Python environment
        and TensorFlow GPU configuration for debugging purposes.
        
        Prints:
            - Python executable path
            - TensorFlow version
            - List of available GPU devices
        """
        print("Python path:", sys.executable)
        if tf is not None:
            print("TensorFlow version:", tf.__version__)
            print("GPU available:", tf.config.list_physical_devices("GPU"))


    @staticmethod
    def clear_gpu_memory():
        """Clear TensorFlow GPU memory and trigger garbage collection.
        
        Clears the TensorFlow Keras session to free GPU memory and runs
        Python's garbage collector to free system memory. Useful between
        processing steps to prevent memory accumulation.
        
        Note:
            Errors during clearing are caught and printed but do not raise
            exceptions to allow continued execution.
        """
        
        try:
            if tf is not None and tf.config.list_physical_devices("GPU"):
                tf.keras.backend.clear_session()
            gc.collect()
        except Exception as e:
            print(f"Error clearing GPU memory: {e}")

    # ---------------- IMAGE PREPROCESS ---------------- #

    def preprocess_image(
        self,
        channel_names: list[str],
        channels_to_use: list[str] = ["Y", "U"],
        lower_percentile: float = 1.0,
        upper_percentile: float = 99.8,
        per_channel: bool = True,
        gamma: float = 0.7,
        clahe: bool = True,
        clahe_clip_limit: float = 2.0,
        clahe_tile_grid_size: int = 8,
    ):
        """Load and preprocess Zarr image for segmentation.

        Loads image data from SpatialData Zarr file, selects specified channels,
        applies contrast stretching, converts to 8-bit RGB format, and downscales
        for segmentation. The preprocessed image is saved to disk.

        Args:
            channel_names (list[str]): List of all channel names in the image
                (e.g., ['R', 'G', 'B', 'Y', 'U']).
            channels_to_use (list[str], optional): List of channel names to use
                for segmentation. Defaults to ["Y", "U"].
            lower_percentile (float, optional): Lower percentile for contrast
                stretching. Pixels below this percentile clip to black.
                Defaults to 1.0.
            upper_percentile (float, optional): Upper percentile for contrast
                stretching. Pixels above this percentile saturate to white.
                For sparse fluorescence (CosMx) push higher (99.5–99.9); for
                dense morphology (Xenium) the original 98 also works.
                Defaults to 99.8.
            per_channel (bool, optional): If True, compute percentiles
                independently per channel (recommended for fluorescence where
                channels have very different dynamic ranges). If False, use a
                single global percentile across all channels (the original
                behavior). Defaults to True.
            gamma (float, optional): Power-law correction applied AFTER
                stretching (output = input ** gamma). gamma < 1 brightens
                mid-tones (lifts dim cells out of the noise floor); gamma > 1
                darkens them. Defaults to 0.7 — a mild lift well-suited to
                CosMx where many genuine cells sit at low percentiles.
            clahe (bool, optional): If True, run Contrast-Limited Adaptive
                Histogram Equalization on each channel after gamma. CLAHE
                normalizes contrast in local tiles, so a dim corner of the
                tissue gets boosted to roughly the same dynamic range as a
                bright vessel — exactly what cellpose wants for uniform
                segmentation across heterogeneous FOVs. Defaults to True.
            clahe_clip_limit (float, optional): Maximum contrast amplification
                per CLAHE tile. Higher = stronger local contrast (and more
                noise). Typical 1.5–4.0. Defaults to 2.0.
            clahe_tile_grid_size (int, optional): CLAHE tile grid is
                (clahe_tile_grid_size × clahe_tile_grid_size). Smaller =
                more aggressive local equalization. Defaults to 8.

        Returns:
            PIL.Image: Preprocessed RGB image ready for segmentation, downscaled
                by `factor_rescale`.

        Note:
            - Converts grayscale or 2-channel images to 3-channel RGB
            - Clears memory after preprocessing
            - Sets `self.image` attribute
        """

        zarr_path = os.path.join(self.zarr_dir, self.zarr_name)
        self.sdata = sd.read_zarr(zarr_path)

        # [FIX] CosMx FOV images are single-scale, so spatialdata returns a
        # plain xarray.DataArray rather than a multiscale DataTree indexed by
        # "scale0". Handle both forms — multiscale (Xenium-like, where
        # `.["scale0"].ds["image"]` is the documented access pattern) and
        # single-scale (CosMx, where the DataArray IS the image). Without
        # this, `core.images['1_image']['scale0']` raises KeyError: 'scale0'
        # from xarray's DataArray._getitem_coord.
        img_obj = self.sdata.images[self.image_name]
        try:
            img_xr = img_obj["scale0"].ds["image"]
        except (KeyError, TypeError):
            img_xr = img_obj  # already a DataArray
        img = img_xr.transpose("y", "x", "c").data.compute()  # (H, W, C)

        # Map channels
        channel_indices = [channel_names.index(ch) for ch in channels_to_use]
        img = img[..., channel_indices]

        # Contrast stretching. [FIX] Default upper percentile bumped to 99.8
        # (was 98) and per-channel computation is now the default. CosMx IF
        # is mostly black background with sparse bright cells; using a single
        # global 98th percentile clipped the bright cell bodies to pure white
        # and washed out cell-shape detail. Per-channel percentiles preserve
        # the relative dynamic range of each input channel.
        if per_channel and img.ndim == 3:
            img_stretched = np.empty_like(img, dtype=np.float32)
            for c in range(img.shape[-1]):
                lo, hi = np.percentile(
                    img[..., c], (lower_percentile, upper_percentile)
                )
                if hi <= lo:
                    img_stretched[..., c] = 0.0
                else:
                    img_stretched[..., c] = np.clip(
                        (img[..., c].astype(np.float32) - lo) / (hi - lo),
                        0,
                        1,
                    )
        else:
            lo, hi = np.percentile(img, (lower_percentile, upper_percentile))
            img_stretched = np.clip(
                (img.astype(np.float32) - lo) / max(hi - lo, 1e-9), 0, 1
            )

        # [FIX] Gamma correction lifts mid-tones (gamma < 1 brightens dim
        # cells without re-saturating bright ones, since the [0,1] endpoints
        # are fixed by x ** g for any g > 0).
        if gamma is not None and gamma != 1.0:
            img_stretched = np.clip(img_stretched, 0.0, 1.0) ** float(gamma)

        # Convert to 8-bit
        img_8bit = (img_stretched * 255).astype(np.uint8)

        # [FIX] CLAHE per channel. CosMx tissue is heterogeneous across FOVs
        # — a bright vessel in one corner and dim stroma in another make it
        # impossible to pick a single global percentile that does justice to
        # both. CLAHE equalizes contrast inside (clahe_tile_grid_size)^2
        # local tiles, so cellpose sees uniformly-contrasted cells across
        # the whole mosaic. Skipped silently if cv2 is not installed.
        if clahe and img_8bit.ndim == 3:
            try:
                import cv2

                clahe_op = cv2.createCLAHE(
                    clipLimit=float(clahe_clip_limit),
                    tileGridSize=(int(clahe_tile_grid_size), int(clahe_tile_grid_size)),
                )
                for c in range(img_8bit.shape[-1]):
                    img_8bit[..., c] = clahe_op.apply(img_8bit[..., c])
            except ImportError:
                print(
                    "  CLAHE skipped: opencv (cv2) not installed. "
                    "`pip install opencv-python-headless` to enable."
                )

        # Ensure 3-channel RGB
        if img_8bit.ndim == 3 and img_8bit.shape[-1] == 2:
            zero_channel = np.zeros_like(img_8bit[..., :1])
            img_8bit = np.concatenate([img_8bit, zero_channel], axis=-1)

        elif img_8bit.ndim == 3 and img_8bit.shape[-1] == 1:
            zero_channel = np.zeros_like(img_8bit[..., :1])
            img_8bit = np.concatenate(
                [img_8bit, zero_channel, zero_channel], axis=-1)

        elif img_8bit.ndim == 2:
            img_8bit = np.stack([img_8bit] * 3, axis=-1)

        seg_pil = Image.fromarray(img_8bit, mode="RGB")

        y_downscale = int(img_xr.shape[1]/self.factor_rescale)
        x_downscale = int(img_xr.shape[2]/self.factor_rescale)
        downscale = (y_downscale, x_downscale)
        self._full_shape = (int(img_xr.shape[1]), int(img_xr.shape[2]))  # multispace patch: exact upscale

        # Resize for segmentation model
        seg_pil = seg_pil.resize((x_downscale, y_downscale), Image.Resampling.LANCZOS)  # [FIX] thumbnail() preserves aspect ratio and may not produce exact target dims

        # Save if requested
        if self.output is not None:
            seg_pil.save(self.output)

        # Clean up the large intermediate arrays before returning.
        # [FIX] The previous loop tested `var_name in globals()`, but these are
        # *local* variables, so the check was always False and nothing was
        # freed. Delete the large locals directly. (img_xr is a lazy xarray
        # handle; the heavy buffers are img and img_8bit.)
        del img, img_8bit

        self.clear_gpu_memory()

        self.image = seg_pil
        print("Preprocessing finished")

        return seg_pil

    # ---------------- SEGMENTATION ---------------- #

    def run_cellpose(
        self,
        model_type: str = "cyto3",
        gpu: bool = True,
        tile_overlap: float = 0.1,
        diameter: float or None = None,
        flow_threshold: float = 1,
        cellprob_threshold: float = -3,
    ):
        """Run Cellpose segmentation on the preprocessed image.
        
        Loads the preprocessed image and runs Cellpose segmentation model
        to generate cell masks. Saves masks to disk and clears GPU memory.
        
        Args:
            model_type (str, optional): Cellpose model type. Options include
                'cyto', 'cyto2', 'cyto3', 'nuclei'. Defaults to "cyto3".
            gpu (bool, optional): Whether to use GPU for inference. 
                Defaults to True.
            tile_overlap (float, optional): Overlap fraction between tiles
                for large images (0-1). Defaults to 0.1.
            diameter (float or None, optional): Expected cell diameter in pixels.
                If None, uses automatic diameter detection. Defaults to None.
            flow_threshold (float, optional): Flow error threshold for mask
                reconstruction. Higher values = more lenient. Defaults to 1.
            cellprob_threshold (float, optional): Cell probability threshold.
                Lower values = more permissive segmentation. Defaults to -3.
        
        Returns:
            tuple: Contains three elements:
                - masks (np.ndarray): Labeled segmentation masks (H, W).
                - flows (tuple): Flow field outputs from Cellpose.
                - styles (np.ndarray): Style vector outputs from Cellpose.
        
        Note:
            - Sets `self.masks`, `self.flows`, and `self.styles` attributes
            - Saves mask image as "mask.png"
            - Clears GPU memory after segmentation
        """
        
        img = io.imread(self.output)
        model = models.CellposeModel(model_type=model_type, gpu=gpu)

        self.masks, self.flows, self.styles = model.eval(
            img,
            diameter=diameter,
            tile_overlap=tile_overlap,
            flow_threshold=flow_threshold,
            cellprob_threshold=cellprob_threshold,
        )
        print("Cellpose segmentation finished")
        img = Image.fromarray(self.masks)
        img.save("mask.png")

        self.clear_gpu_memory()

        return self.masks, self.flows, self.styles

    # ---------------- MASKS & SHAPES ---------------- #

    @staticmethod
    def filter_cell_by_regionprops(
            seg_masks,
            max_eccentricity=None,
            min_area='median_div2',
            min_absolute_area=50,
            max_area=None,
            min_solidity=None,
            max_solidity=None,
            min_extent=None,
            max_extent=None,
            min_compactness=None,
            max_convexity_deficit=0.20,
            max_perimeter_area_ratio=None,
            area_std_filter=None,
            save_debug=False,
            verbose=True):
        """Filter segmented cell masks by multiple morphological criteria.
        
        Analyzes region properties of segmented masks and filters cells based on
        shape metrics including area, eccentricity, solidity, extent, compactness,
        and convexity deficit. Provides detailed statistics and rejection reasons 
        when verbose mode is enabled.
        
        Args:
            seg_masks (np.ndarray): Input segmentation masks with integer labels.
            max_eccentricity (float, optional): Maximum eccentricity (elongation)
                threshold. Range: 0-1, where 0=circle, 1=line. Typical: 0.95.
                Defaults to None (no filtering).
            min_area (str or float, optional): Minimum area filter. Options:
                - 'median': Use median(areas) as threshold
                - 'median_div2': Use median(areas)/2 as threshold
                - 0-100: Use percentile of area distribution
                - Absolute value: Use as pixel count threshold
                Defaults to 'median_div2'.
            min_absolute_area (int, optional): Hard minimum area to remove 
                tiny artifacts regardless of distribution. Defaults to 50.
            max_area (float, optional): Maximum area threshold in pixels.
                Defaults to None (no filtering).
            min_solidity (float, optional): Minimum solidity (area/convex_area).
                Range: 0-1. Filters highly concave cells. Typical: 0.7-0.9.
                Defaults to None (no filtering).
            max_solidity (float, optional): Maximum solidity. Filters perfectly
                convex cells (unrealistic). Typical: 0.98-0.995. 
                Defaults to None (no filtering).
            min_extent (float, optional): Minimum extent (area/bounding_box_area).
                Range: 0-1. Filters sparse cells. Typical: 0.3-0.5.
                Defaults to None (no filtering).
            max_extent (float, optional): Maximum extent. Filters perfectly
                rectangular cells. Typical: 0.9-0.95.
                Defaults to None (no filtering).
            min_compactness (float, optional): Minimum compactness (Polsby-Popper).
                Compactness = 4π * area / perimeter². Range: 0-1, where 1=perfect circle.
                Filters irregular shapes. Typical: 0.5-0.7 for cells, half-moons ~0.3-0.5.
                Defaults to None (no filtering).
            max_convexity_deficit (float, optional): Maximum convexity deficit.
                Deficit = 1 - solidity = (convex_area - area) / convex_area.
                Range: 0-1, where 0=perfectly convex. Filters concave cells like half-moons.
                Typical: 0.10-0.20, half-moons ~0.25-0.50.
                Defaults to None (no filtering).
            max_perimeter_area_ratio (float, optional): Maximum perimeter/sqrt(area) ratio.
                Normalized perimeter measure. Filters cells with excessive perimeter.
                Typical cells: 3.5-5.0, irregular cells: >6.0.
                Defaults to None (no filtering).
            area_std_filter (float, optional): Remove area outliers beyond N
                standard deviations from mean. E.g., 3.0 removes outliers
                beyond 3σ. Defaults to None (no filtering).
            save_debug (bool, optional): Whether to save debug image 
                "cleaned_mask.png". Defaults to False.
            verbose (bool, optional): Whether to print filtering statistics
                and rejection breakdown. Defaults to True.
        
        Returns:
            np.ndarray: Cleaned and relabeled mask array with consecutive 
                integer labels starting from 1. Zero indicates background.
        
        Shape Metrics Explained:
            Solidity = area / convex_area
                - ~1.0: Very smooth, convex (circle, ellipse) - may be unrealistic
                - 0.7-0.9: Slightly irregular - typical realistic cells
                - <0.7: Highly concave/irregular - likely artifacts
            
            Extent = area / bounding_box_area
                - ~1.0: Fills bounding box (square, rectangle)
                - 0.5-0.8: Typical cell shapes
                - <0.3: Very sparse/thin - likely artifacts
            
            Eccentricity = elongation measure
                - 0: Perfect circle
                - 0.95: Very elongated
                - >0.95: Extremely elongated - may be artifacts
            
            Compactness = 4π * area / perimeter² (Polsby-Popper)
                - 1.0: Perfect circle
                - 0.6-0.8: Typical cells
                - <0.5: Irregular/elongated shapes (including half-moons)
            
            Convexity Deficit = 1 - solidity
                - 0: Perfectly convex
                - 0.05-0.15: Slight irregularity (normal cells)
                - >0.20: Significant concavity (half-moon cells, artifacts)
            
            Perimeter/Area Ratio = perimeter / sqrt(area)
                - 3.5-5.0: Typical cells
                - >6.0: Irregular perimeter (fragmented, concave cells)
        
        Note:
            - Uses vectorized operations for efficient relabeling
            - Prints detailed statistics when verbose=True
            - Returns empty mask if no regions pass filtering
            - New metrics (compactness, convexity deficit) are especially effective
              for removing half-moon/crescent-shaped cells
        """
        
        if verbose:
            print("Labeling connected components")

        labeled = label(seg_masks)

        if verbose:
            print(f"Extracting properties for {labeled.max()} regions")

        # Extract properties
        properties = ['label', 'area', 'eccentricity', 'perimeter']
        if min_solidity is not None or max_solidity is not None or max_convexity_deficit is not None:
            properties.append('solidity')
        if min_extent is not None or max_extent is not None:
            properties.append('extent')

        props = regionprops_table(labeled, properties=properties)

        n_regions = len(props['label'])
        if n_regions == 0:
            if verbose:
                print("No regions found")
            return np.zeros_like(seg_masks, dtype=np.int32)

        areas = props['area']
        perimeters = props['perimeter']

        # ========== CALCULATE NEW METRICS ==========

        # 1. Compactness (Polsby-Popper): 4π * area / perimeter²
        # Circle = 1.0, irregular shapes < 0.5
        # [FIX] Guard against zero perimeter instead of adding an epsilon.
        # skimage returns perimeter == 0 for 1-2 pixel regions, so the old
        # `perimeters**2 + 1e-10` denominator gave those a compactness of ~1e11.
        # That is the source of the nonsensical
        #   "Compactness Range: 0.156 - 251327412287.183 / Mean: 1847081716.858"
        # line in the log: a handful of degenerate specks dragging the mean up
        # by eleven orders of magnitude, which makes the printed distribution
        # useless for choosing a threshold. Such regions are not compact, so
        # score them 0 and let the area filter reject them on its own terms.
        _safe_perim2 = np.where(perimeters > 0, perimeters ** 2, 1.0)
        compactness = np.where(
            perimeters > 0, (4 * np.pi * areas) / _safe_perim2, 0.0)

        # 2. Convexity deficit: 1 - solidity
        # How much area is "missing" compared to convex hull
        convexity_deficit = None
        if 'solidity' in props:
            solidity = props['solidity']
            convexity_deficit = 1 - solidity

        # 3. Perimeter-to-area ratio (normalized by sqrt)
        # Normalized measure of perimeter complexity
        perimeter_area_ratio = perimeters / (np.sqrt(areas) + 1e-10)

        # Determine minimum area threshold
        if isinstance(min_area, str) and min_area == 'median':
            min_area_value = np.median(areas)
            threshold_type = "median"
        elif isinstance(min_area, str) and min_area == 'median_div2':
            min_area_value = np.median(areas)/2
            threshold_type = "median_div2"
        elif isinstance(min_area, (int, float)) and 0 <= min_area <= 100:
            min_area_value = np.percentile(areas, min_area)
            threshold_type = f"{min_area}th percentile"
        else:
            min_area_value = min_area
            threshold_type = "absolute"

        if verbose:
            print("SHAPE STATISTICS")
            print("Area:")
            print(f"Range: {areas.min():.1f} - {areas.max():.1f}")
            print(
                f"Mean: {areas.mean():.1f}, Median: {np.median(areas):.1f}, Std: {areas.std():.1f}")
            print("Eccentricity:")
            ecc = props['eccentricity']
            print(f"Range: {ecc.min():.3f} - {ecc.max():.3f}")
            print(f"Mean: {ecc.mean():.3f}, Median: {np.median(ecc):.3f}")
            print("Compactness (1.0=circle, <0.5=irregular):")
            print(
                f"Range: {compactness.min():.3f} - {compactness.max():.3f}")
            print(
                f"Mean: {compactness.mean():.3f}, Median: {np.median(compactness):.3f}")
            print(f"25th percentile: {np.percentile(compactness, 25):.3f}")
            print(f"10th percentile: {np.percentile(compactness, 10):.3f}")

            if 'solidity' in props:
                print("Solidity (convexity):")
                print(f"Range: {solidity.min():.3f} - {solidity.max():.3f}")
                print(
                    f"Mean: {solidity.mean():.3f}, Median: {np.median(solidity):.3f}")
                print("Convexity Deficit (0=convex, high=concave):")
                print(
                    f"Range: {convexity_deficit.min():.3f} - {convexity_deficit.max():.3f}")
                print(
                    f"Mean: {convexity_deficit.mean():.3f}, Median: {np.median(convexity_deficit):.3f}")
                print(
                    f"75th percentile: {np.percentile(convexity_deficit, 75):.3f}")
                print(
                    f"90th percentile: {np.percentile(convexity_deficit, 90):.3f}")

            print("Perimeter/√Area Ratio (typical: 3.5-5.0):")
            print(
                f"Range: {perimeter_area_ratio.min():.3f} - {perimeter_area_ratio.max():.3f}")
            print(
                f"Mean: {perimeter_area_ratio.mean():.3f}, Median: {np.median(perimeter_area_ratio):.3f}")
            print(
                f"75th percentile: {np.percentile(perimeter_area_ratio, 75):.3f}")
            print(
                f"90th percentile: {np.percentile(perimeter_area_ratio, 90):.3f}")

            if 'extent' in props:
                extent = props['extent']
                print("Extent (bbox filling):")
                print(f"Range: {extent.min():.3f} - {extent.max():.3f}")
                print(
                    f"Mean: {extent.mean():.3f}, Median: {np.median(extent):.3f}")

            print(
                f"Using {threshold_type} area threshold: {min_area_value:.1f}")

        # Build filter mask
        valid_mask = np.ones(n_regions, dtype=bool)
        rejection_reasons = {
            'tiny_artifacts': 0,
            'too_small': 0,
            'too_large': 0,
            'area_outliers': 0,
            'too_eccentric': 0,
            'too_convex': 0,
            'too_concave': 0,
            'too_sparse': 0,
            'too_rectangular': 0,
            'low_compactness': 0,
            'high_convexity_deficit': 0,
            'irregular_perimeter': 0
        }

        # 1. Remove tiny artifacts
        if min_absolute_area > 0:
            artifact_mask = areas >= min_absolute_area
            rejection_reasons['tiny_artifacts'] = (~artifact_mask).sum()
            valid_mask &= artifact_mask

        # 2. Apply relative area threshold
        small_mask = areas >= min_area_value
        rejection_reasons['too_small'] = (~small_mask & valid_mask).sum()
        valid_mask &= small_mask

        # 3. Remove very large regions
        if max_area is not None:
            large_mask = areas <= max_area
            rejection_reasons['too_large'] = (~large_mask & valid_mask).sum()
            valid_mask &= large_mask

        # 4. Remove area outliers
        if area_std_filter is not None:
            mean_area = areas.mean()
            std_area = areas.std()
            lower_bound = mean_area - area_std_filter * std_area
            upper_bound = mean_area + area_std_filter * std_area
            outlier_mask = (areas >= lower_bound) & (areas <= upper_bound)
            rejection_reasons['area_outliers'] = (
                ~outlier_mask & valid_mask).sum()
            valid_mask &= outlier_mask
            if verbose:
                print(
                    f"Area outlier bounds ({area_std_filter}σ): {lower_bound:.1f} - {upper_bound:.1f}")

        # 5. Apply eccentricity filter
        if max_eccentricity is not None:
            eccentric_mask = props['eccentricity'] <= max_eccentricity
            rejection_reasons['too_eccentric'] = (
                ~eccentric_mask & valid_mask).sum()
            valid_mask &= eccentric_mask
            if verbose:
                print(f"Max eccentricity threshold: {max_eccentricity:.3f}")

        # 6. Filter by solidity (convexity)
        if 'solidity' in props:
            # Remove too convex cells (unrealistically smooth)
            if max_solidity is not None:
                convex_mask = solidity <= max_solidity
                rejection_reasons['too_convex'] = (
                    ~convex_mask & valid_mask).sum()
                valid_mask &= convex_mask
                if verbose:
                    print(f"Max solidity (remove convex): {max_solidity:.3f}")

            # Remove too concave cells (artifacts)
            if min_solidity is not None:
                concave_mask = solidity >= min_solidity
                rejection_reasons['too_concave'] = (
                    ~concave_mask & valid_mask).sum()
                valid_mask &= concave_mask
                if verbose:
                    print(f"Min solidity (remove concave): {min_solidity:.3f}")

        # 7. Filter by extent (bounding box filling)
        if 'extent' in props:
            extent = props['extent']

            # Remove sparse/thin cells
            if min_extent is not None:
                sparse_mask = extent >= min_extent
                rejection_reasons['too_sparse'] = (
                    ~sparse_mask & valid_mask).sum()
                valid_mask &= sparse_mask
                if verbose:
                    print(f"Min extent (remove sparse): {min_extent:.3f}")

            # Remove perfectly rectangular cells
            if max_extent is not None:
                rect_mask = extent <= max_extent
                rejection_reasons['too_rectangular'] = (
                    ~rect_mask & valid_mask).sum()
                valid_mask &= rect_mask
                if verbose:
                    print(f"Max extent (remove rectangular): {max_extent:.3f}")

        # 8. Filter by compactness (CRITICAL for half-moon cells)
        if min_compactness is not None:
            compact_mask = compactness >= min_compactness
            rejection_reasons['low_compactness'] = (
                ~compact_mask & valid_mask).sum()
            valid_mask &= compact_mask
            if verbose:
                print(f"Min compactness threshold: {min_compactness:.3f}")

        # 9. Filter by convexity deficit (CRITICAL for half-moon cells)
        if max_convexity_deficit is not None and convexity_deficit is not None:
            deficit_mask = convexity_deficit <= max_convexity_deficit
            rejection_reasons['high_convexity_deficit'] = (
                ~deficit_mask & valid_mask).sum()
            valid_mask &= deficit_mask
            if verbose:
                print(
                    f"Max convexity deficit threshold: {max_convexity_deficit:.3f}")

        # 10. Filter by perimeter-area ratio
        if max_perimeter_area_ratio is not None:
            perimeter_mask = perimeter_area_ratio <= max_perimeter_area_ratio
            rejection_reasons['irregular_perimeter'] = (
                ~perimeter_mask & valid_mask).sum()
            valid_mask &= perimeter_mask
            if verbose:
                print(
                    f"Max perimeter/√area ratio: {max_perimeter_area_ratio:.3f}")

        n_valid = valid_mask.sum()

        if verbose:

            print(
                f"FILTERING RESULTS: {n_valid}/{n_regions} regions passed ({100*n_valid/n_regions:.1f}%)")

            if n_valid > 0:
                valid_areas = areas[valid_mask]
                valid_compactness = compactness[valid_mask]
                valid_perimeter_ratio = perimeter_area_ratio[valid_mask]

                print("Valid regions statistics:")
                print(
                    f"Area range: {valid_areas.min():.1f} - {valid_areas.max():.1f}")
                print(f"Mean area: {valid_areas.mean():.1f}")
                print(
                    f"Compactness range: {valid_compactness.min():.3f} - {valid_compactness.max():.3f}")
                print(
                    f"Perimeter ratio range: {valid_perimeter_ratio.min():.3f} - {valid_perimeter_ratio.max():.3f}")

                if 'solidity' in props:
                    valid_solidity = solidity[valid_mask]
                    valid_deficit = convexity_deficit[valid_mask]
                    print(
                        f"Solidity range: {valid_solidity.min():.3f} - {valid_solidity.max():.3f}")
                    print(
                        f"Convexity deficit range: {valid_deficit.min():.3f} - {valid_deficit.max():.3f}")

                if 'extent' in props:
                    valid_extent = extent[valid_mask]
                    print(
                        f"Extent range: {valid_extent.min():.3f} - {valid_extent.max():.3f}")

            print("Rejection breakdown:")
            total_rejected = n_regions - n_valid
            print(f"Total rejected: {total_rejected}")
            for reason, count in rejection_reasons.items():
                if count > 0:
                    pct = 100 * count / n_regions
                    print(
                        f"{reason.replace('_', ' ').title()}: {count} ({pct:.1f}%)")

        if n_valid == 0:
            if verbose:
                print("WARNING: No regions passed filtering criteria!")
            return np.zeros_like(seg_masks, dtype=np.int32)

        # Vectorized relabeling via lookup table
        valid_labels = props['label'][valid_mask]
        lut = np.zeros(labeled.max() + 1, dtype=np.int32)
        lut[valid_labels] = np.arange(1, n_valid + 1, dtype=np.int32)
        cleaned_mask = lut[labeled]

        if save_debug:
            from PIL import Image
            Image.fromarray(cleaned_mask).save("cleaned_mask.png")
            if verbose:
                print("Saved debug image: cleaned_mask.png")

        return cleaned_mask


    @staticmethod
    def masks_to_polygons(seg_masks, factor_rescale, return_labels=False, scale_xy=None):
        """Convert segmentation masks into scaled polygons.

        Extracts contours from each labeled region in the segmentation mask,
        converts them to Shapely polygons, and rescales coordinates to match
        the original image resolution.

        Args:
            seg_masks (np.ndarray): Labeled segmentation masks where each
                unique integer represents a different cell.
            factor_rescale (int): Factor by which to upscale polygon coordinates.
                E.g., if masks are 4x smaller than original, use factor_rescale=4.
            return_labels (bool): If True, also return the mask label each
                polygon came from, so callers can keep cell_id in sync with
                the label image.
            scale_xy (tuple, optional): multispace patch. Exact (sx, sy)
                full-resolution pixels per mask pixel. When given, polygons
                are returned in full-resolution *corner* coordinates,
                x = (col + 0.5) * sx, y = (row + 0.5) * sy, which removes the
                ~(factor/2) px up-left bias and the rounding drift of the
                plain ``coords * factor`` upscale.

        Returns:
            list[shapely.geometry.Polygon], or (polygons, labels) if
            return_labels=True. Invalid or empty polygons are excluded.

        Note:
            - Finds the longest contour for each region
            - Ensures contours are closed (first point = last point)
            - Buffers only invalid polygons (buffer(0) is expensive)
            - If factor_rescale=0, no scaling is applied

        [PERF] This was the pipeline's dominant cost. The previous
        implementation looped over regionprops(seg_masks) and, for every
        region, evaluated `(seg_masks == region.label)` and then ran
        find_contours over the WHOLE mask array. That is O(n_regions x H x W):
        on this dataset (~86k regions on a stitched mosaic) that is ~86,000
        full-image comparisons plus ~86,000 full-image contour traversals,
        which is where the hours went.

        We now use scipy.ndimage.find_objects to get every label's bounding-box
        slice in a single pass, then do the comparison and contour extraction on
        that small crop only. Total work drops to roughly O(H x W + sum of bbox
        areas) - proportional to the image rather than image x cells. Three
        smaller wins on top: the rescale factor is folded into the contour
        coordinates instead of rebuilding every polygon through shapely's
        scale(), buffer(0) is applied only when a polygon is actually invalid,
        and the crop is uint8 rather than a full int64 array.
        """

        polygons = []
        labels = []

        # One pass over the array to get every label's bounding box. Index i
        # of the result corresponds to label i+1; None means that label is
        # absent (filter_cell_by_regionprops relabels consecutively, so gaps
        # are rare, but they are possible).
        slices = find_objects(seg_masks)

        # Fold the upscale into the coordinates rather than re-deriving every
        # polygon through shapely.affinity.scale afterwards.
        sf = float(factor_rescale) if factor_rescale != 0 else 1.0

        for idx, sl in enumerate(slices):
            if sl is None:
                continue
            lab = idx + 1

            # Crop to the bounding box and isolate this label. Padding by one
            # pixel guarantees find_contours sees a closed boundary even for
            # regions touching the crop edge (previously guaranteed only
            # because the whole image was passed in).
            sub = (seg_masks[sl] == lab)
            padded = np.pad(sub, 1).astype(np.uint8, copy=False)

            contours = find_contours(padded, 0.5)
            if not contours:
                continue
            contour = max(contours, key=len)
            if len(contour) < 4:
                # Fewer than 4 points cannot form a valid ring.
                continue

            # ensure the contour is closed (first point = last point)
            if not ((contour[0] == contour[-1]).all()):
                contour = np.vstack([contour, contour[0]])

            # Undo the 1px pad, shift the crop back to its global position, and
            # convert (row, col) -> (x, y) == (col, row). Identical geometry to
            # the old contour[:, [1, 0]], just computed on the crop.
            rows = contour[:, 0] - 1.0 + sl[0].start
            cols = contour[:, 1] - 1.0 + sl[1].start
            if scale_xy is not None:
                poly = Polygon(np.column_stack([(cols + 0.5) * scale_xy[0],
                                                (rows + 0.5) * scale_xy[1]]))
            else:
                poly = Polygon(np.column_stack([cols * sf, rows * sf]))

            # buffer(0) repairs self-intersections but is a full geometry
            # operation; most contours are already valid, so only pay for it
            # when it is needed.
            if not poly.is_valid:
                poly = poly.buffer(0)
                # buffer(0) on a pinched ring can split it into a MultiPolygon.
                # The old code kept that as-is, producing mixed geometry types
                # downstream; keep the largest part instead.
                if isinstance(poly, MultiPolygon):
                    if poly.is_empty:
                        continue
                    poly = max(poly.geoms, key=lambda g: g.area)

            if poly.is_valid and not poly.is_empty:
                polygons.append(poly)
                labels.append(lab)

        if return_labels:
            return polygons, labels
        return polygons


    @staticmethod
    def mirror_y0(geom):
        """Mirror a polygon geometry across the x-axis (y=0).
        
        Flips polygon coordinates vertically by negating y-values. Used to
        correct coordinate system orientation differences between image and
        spatial coordinate systems.
        
        Args:
            geom (shapely.geometry.Polygon or other): Input geometry to mirror.
        
        Returns:
            shapely.geometry: Mirrored geometry of the same type as input.
                If input is not a Polygon, returns input unchanged.
        
        Example:
            Point (x, y) becomes (x, -y)
        """
        
        return type(geom)([
            (x, -y) for x, y in geom.exterior.coords
        ]) if geom.geom_type == "Polygon" else geom


    def process_masks_to_shapes(self):
        """Filter masks, convert to polygons, and create shapes model.
        
        Applies morphological filtering to segmentation masks, converts filtered
        masks to polygon geometries, mirrors coordinates, and creates a 
        SpatialData-compatible shapes model with cell IDs.
        
        Returns:
            tuple: Contains three elements:
                - masks (np.ndarray): Filtered and relabeled segmentation masks.
                - gdf_polygons (gpd.GeoDataFrame): GeoDataFrame with cell_id and
                  geometry columns.
                - shapes_model (gpd.GeoDataFrame): SpatialData shapes model with
                  region names and geometries.
        
        Raises:
            RuntimeError: If no valid polygons are extracted from masks after
                filtering.
        
        Note:
            - Filters masks using `filter_cell_by_regionprops()`
            - Converts to polygons and upscales by `factor_rescale`
            - Mirrors y-coordinates and shifts to ensure all y >= 0
            - Sets `self.masks`, `self.gdf_polygons`, and `self.shapes_model`
        
        TODO:
            Optimize this function for better performance.
        """
        
        # Filter masks
        self.masks = self.filter_cell_by_regionprops(self.masks)

        # Convert masks → polygons
        polygons, poly_labels = self.masks_to_polygons(
            self.masks, self.factor_rescale, return_labels=True,
            scale_xy=_upscale_xy(self))

        if not polygons:
            raise RuntimeError(
                "No polygons extracted from mask — check your segmentation.")

        # [FIX] cell_id now follows the mask label the polygon actually came
        # from, instead of its position in the list. Previously this was
        # f"cell_{i+1}" over the SURVIVING polygons, so a single dropped region
        # (no contour found, or an invalid ring) shifted the id of every
        # subsequent cell by one - silently de-synchronising
        # gdf_polygons.cell_id from the label image that process_labels writes,
        # and therefore from everything downstream that ties shapes to labels.
        # When nothing is dropped the output is byte-identical to before, so
        # this only changes behaviour in the cases that were already wrong.
        n_labels = int(self.masks.max())
        n_dropped = n_labels - len(polygons)
        if n_dropped > 0:
            print(f"{n_dropped:,}/{n_labels:,} mask labels produced no valid "
                  f"polygon; cell_id follows the label image, not list position")

        # Shapes
        shapes_df = gpd.GeoDataFrame({
            "geometry": polygons,
            "cell_id": [f"cell_{lab}" for lab in poly_labels]
        })
        shapes_df.set_geometry("geometry", inplace=True)
        self.shapes_model = ShapesModel.parse(shapes_df)

        # [FIX] mirror_y0 and the subsequent shift removed.
        # Cellpose masks are produced in y-down pixel space (row 0 = top of image),
        # which is the same convention as matplotlib imshow and SpatialData images.
        # Negating y-coordinates (mirror_y0) followed by a shift to positive y
        # is equivalent to a vertical mirror — causing shapes to appear at the wrong
        # vertical position when overlaid on the IF image.
        # contour[:,[1,0]] already handles (row,col)→(x,y) correctly; no further
        # coordinate manipulation is needed.

        self.gdf_polygons = self.shapes_model[["cell_id", "geometry"]]

        return self.masks, self.gdf_polygons, self.shapes_model

    # ---------------- LABELS ---------------- #

    def process_labels(self):
        """Upscale masks and create Labels2DModel.
        
        Upscales the filtered segmentation masks to the original image resolution
        and creates a SpatialData-compatible Labels2DModel for visualization and
        further analysis.
        
        Returns:
            tuple: Contains two elements:
                - masks (np.ndarray): Original filtered masks (not upscaled).
                - labels_model (sd.models.Labels2DModel): Upscaled labels model
                  with name set to `self.label_name`.
        
        Note:
            - Uses nearest-neighbor interpolation (order=0) to preserve integer labels
            - Upscales by `factor_rescale` to match original image dimensions
            - Sets `self.labels_model` attribute with specified label name
        """
        
        # multispace patch: upscale to exactly the image's shape (was
        # masks.shape * factor, up to factor-1 px short of the image).
        masks_upscale = _upscale_labels(self)

        self.labels_model = Labels2DModel.parse(
            data=np.squeeze(masks_upscale),
            dims=("y", "x"),
        )
        self.labels_model.name = self.label_name

        return self.masks, self.labels_model

    # ---------------- POINTS & TABLES ---------------- #

    def _resolve_orientation(self, x, y, orient="auto",
                             subsample=200000, min_improvement=0.10):
        """Decide whether transcripts must be x/y-flipped to match the shapes.

        Tests the four flip candidates (none / flip_y / flip_x / both) on a
        subsample by mirroring about the polygon bounding box and counting how
        many cells stay empty after a spatial join. Returns (flip_x, flip_y).

        Args:
            x, y (np.ndarray): transformed transcript coordinates.
            orient (str): 'auto' to detect, or one of 'as-is'/'none',
                'flip_y', 'flip_x', 'flip_x+flip_y'/'flip_xy' to force.
            subsample (int): max transcripts used for detection (speed).
            min_improvement (float): in 'auto' mode, only override 'as-is' if a
                flip lowers the empty-cell fraction by at least this much
                (absolute, e.g. 0.10 = 10 percentage points). Guards against
                spurious flips on genuinely sparse data.
        """
        forced = {
            "as-is": (False, False), "none": (False, False),
            "flip_y": (False, True), "flip_x": (True, False),
            "flip_x+flip_y": (True, True), "flip_xy": (True, True),
        }
        check_only = str(orient).lower() == "check"  # multispace patch
        if orient is not None and str(orient).lower() not in ("auto", "check"):
            key = str(orient).lower()
            if key not in forced:
                raise ValueError(
                    f"orient must be 'auto' or one of {list(forced)}, "
                    f"got {orient!r}")
            fx, fy = forced[key]
            print(f"[orientation] forced '{orient}' -> "
                  f"flip_x={fx}, flip_y={fy}")
            return fx, fy

        n = len(x)
        if subsample and n > subsample:
            idx = np.random.default_rng(0).choice(n, subsample, replace=False)
            xs, ys = x[idx], y[idx]
        else:
            xs, ys = x, y

        xmin, ymin, xmax, ymax = self.gdf_polygons.total_bounds
        xc, yc = xmin + xmax, ymin + ymax
        n_cells = self.gdf_polygons["cell_id"].nunique()
        poly = self.gdf_polygons[["cell_id", "geometry"]]

        def _empty_frac(xx, yy):
            pts = gpd.GeoDataFrame(
                geometry=gpd.points_from_xy(xx, yy), crs=self.gdf_polygons.crs)
            j = gpd.sjoin(pts, poly, how="left", predicate="within")
            nonempty = j.loc[j["cell_id"].notna(), "cell_id"].nunique()
            return 1.0 - nonempty / n_cells

        candidates = {
            (False, False): (xs, ys),
            (False, True): (xs, yc - ys),
            (True, False): (xc - xs, ys),
            (True, True): (xc - xs, yc - ys),
        }
        empties = {}
        print("[orientation] testing flip candidates "
              f"(subsample={len(xs):,} transcripts):")
        for (fx, fy), (xx, yy) in candidates.items():
            empties[(fx, fy)] = _empty_frac(xx, yy)
            print(f"    flip_x={fx!s:5} flip_y={fy!s:5} -> "
                  f"empty cells {100*empties[(fx, fy)]:5.1f}%")

        # --- registration diagnostics ------------------------------------
        # Compare the polygon bbox with the transcript bbox (robust 1/99 pct).
        # A large scale ratio != 1 or a big centre offset means the
        # translation-only transform left a residual mis-registration that no
        # flip can fix. We also report the empty fraction after a robust
        # bbox-affine alignment (flip + per-axis rescale + translate): if that
        # is far lower than the best plain flip, the residual empties are a
        # registration problem (fixable via a proper inverse-affine transform),
        # not genuine empty cells.
        best = min(empties, key=empties.get)
        registration_issue = False  # multispace patch: reported in check mode
        fx_b, fy_b = best
        bx = (xc - xs) if fx_b else xs
        by = (yc - ys) if fy_b else ys
        px1, px99 = np.percentile(bx, [1, 99])
        py1, py99 = np.percentile(by, [1, 99])
        poly_w, poly_h = (xmax - xmin), (ymax - ymin)
        tx_w, tx_h = (px99 - px1), (py99 - py1)
        print("[orientation] registration check (best flip "
              f"flip_x={fx_b}, flip_y={fy_b}):")
        print(f"    polygon bbox   x[{xmin:.0f},{xmax:.0f}] "
              f"y[{ymin:.0f},{ymax:.0f}]  (w={poly_w:.0f}, h={poly_h:.0f})")
        print(f"    transcript bbox x[{px1:.0f},{px99:.0f}] "
              f"y[{py1:.0f},{py99:.0f}]  (w={tx_w:.0f}, h={tx_h:.0f})  [1-99 pct]")
        if tx_w > 0 and tx_h > 0:
            print(f"    scale ratio poly/tx: x={poly_w/tx_w:.3f}, "
                  f"y={poly_h/tx_h:.3f}  (≈1.0 means scale OK)")
            ax = xmin + (bx - px1) / tx_w * poly_w
            ay = ymin + (by - py1) / tx_h * poly_h
            aligned_empty = _empty_frac(ax, ay)
            print(f"    empty cells after robust bbox-affine align: "
                  f"{100*aligned_empty:.1f}%  "
                  f"(vs {100*empties[best]:.1f}% plain flip)")
            if aligned_empty < empties[best] - 0.10:
                registration_issue = True
                print("    => residual empties are a REGISTRATION issue "
                      "(translation/scale), not genuine. A full inverse-affine "
                      "transform is needed; share the global affine matrix.")
            else:
                print("    => bbox alignment does not help much; remaining "
                      "empties are likely genuine (sparse capture / spurious "
                      "segmentations).")
        # -----------------------------------------------------------------

        asis = empties[(False, False)]
        if check_only:
            if best != (False, False) and empties[best] < asis - min_improvement:
                print(f"[orientation] WARNING: flip_x={best[0]}, flip_y={best[1]} "
                      f"would fit much better (empty {100*asis:.1f}% -> "
                      f"{100*empties[best]:.1f}%). The input may not follow the "
                      f"stitch_cosmx_core convention; check before trusting counts. "
                      f"No flip applied (orient='check').")
            elif registration_issue:
                print(f"[orientation] WARNING: transcripts and cells do not line up "
                      f"well under the stitched-image transform (a bounding-box "
                      f"alignment fits better). The input may not follow the "
                      f"stitch_cosmx_core convention; check before trusting counts. "
                      f"No flip applied (orient='check').")
            else:
                print(f"[orientation] check OK: as-is fits best "
                      f"(empty {100*asis:.1f}%). No flip applied.")
            return (False, False)
        if best != (False, False) and empties[best] < asis - min_improvement:
            print(f"[orientation] AUTO-CORRECT -> flip_x={best[0]}, "
                  f"flip_y={best[1]} (empty {100*asis:.1f}% -> "
                  f"{100*empties[best]:.1f}%). Pass orient='as-is' to disable.")
            return best
        print(f"[orientation] no flip applied (as-is empty {100*asis:.1f}%; "
              f"no candidate beats it by >={100*min_improvement:.0f}pp).")
        return (False, False)

    def diagnose_cellpose_coverage(self, subsample=500000):
        """Transform-free check of how many cellpose cells contain transcripts.

        Maps RAW transcript global-px coordinates straight onto the cellpose
        mask raster (`self.masks`) by a robust 1/99-percentile bounding-box fit,
        trying all 8 flip/transpose orientations, and reports the best coverage.
        This bypasses the global-affine transform, the polygon conversion AND
        the sjoin, so it isolates the segmentation itself.

        Interpretation:
            - best coverage high (>~85%): the masks are fine; the main pipeline
              is losing assignments in the transform / polygon step.
            - best coverage still ~50%: the empty cells are largely real
              (sparse capture / spurious IF segmentations).

        Call after `process_masks_to_shapes()` (so `self.masks` is the filtered
        masks). Caveat: the bbox fit assumes the transcript field and the
        imaged/segmented area roughly coincide; a hard crop offset between the
        morphology image and the transcript mosaic can still bias it.
        """
        masks = np.squeeze(np.asarray(self.masks))
        if masks.ndim != 2:
            raise ValueError(f"expected 2D masks, got shape {masks.shape}")
        H, W = masks.shape
        labels = np.unique(masks)
        labels = labels[labels != 0]
        n_cells = labels.size
        if n_cells == 0:
            print("[cellpose-coverage] no labelled cells in self.masks")
            return None

        pts = dd.concat(
            [self.sdata.points[k] for k in self.sdata.points.keys()],
            axis=0, ignore_index=True)
        xy = pts[['x_global_px', 'y_global_px']].compute()
        x = xy['x_global_px'].to_numpy(dtype=float)
        y = xy['y_global_px'].to_numpy(dtype=float)
        if subsample and x.size > subsample:
            idx = np.random.default_rng(0).choice(
                x.size, subsample, replace=False)
            x, y = x[idx], y[idx]

        def coverage(xx, yy):
            x1, x99 = np.percentile(xx, [1, 99])
            y1, y99 = np.percentile(yy, [1, 99])
            if x99 <= x1 or y99 <= y1:
                return 0.0, 0
            col = np.round((xx - x1) / (x99 - x1) * (W - 1)).astype(int)
            row = np.round((yy - y1) / (y99 - y1) * (H - 1)).astype(int)
            m = (col >= 0) & (col < W) & (row >= 0) & (row < H)
            hit = masks[row[m], col[m]]
            hit = hit[hit != 0]
            n_hit = np.unique(hit).size
            return n_hit / n_cells, n_hit

        xmin, xmax = x.min(), x.max()
        ymin, ymax = y.min(), y.max()
        print(f"[cellpose-coverage] masks {H}x{W}, {n_cells:,} cellpose cells, "
              f"{x.size:,} transcripts (raw global-px, no transform)")
        best = None
        for tpose in (False, True):
            for fx in (False, True):
                for fy in (False, True):
                    xx = (xmin + xmax - x) if fx else x
                    yy = (ymin + ymax - y) if fy else y
                    if tpose:
                        xx, yy = yy, xx
                    frac, n_hit = coverage(xx, yy)
                    print(f"    transpose={tpose!s:5} flip_x={fx!s:5} "
                          f"flip_y={fy!s:5} -> {100*frac:5.1f}% cells covered "
                          f"({n_hit:,}/{n_cells:,})")
                    if best is None or frac > best[0]:
                        best = (frac, tpose, fx, fy)
        # NB: on a near-regular tiling a flip just maps cells onto other cells,
        # so the coverage COUNT barely changes across orientations. This metric
        # therefore estimates the *ceiling* on coverage (max cells reachable by
        # any transcript under a best-fit alignment); it does NOT identify the
        # correct flip — use the [orientation] block for that, which preserves
        # the cloud shape. The ceiling is what answers "is the empty fraction
        # real?".
        print(f"[cellpose-coverage] COVERAGE CEILING: {100*best[0]:.1f}% of "
              f"cells reachable under best-fit alignment.")
        if best[0] > 0.85:
            print("    => the segmentation can be ~fully covered, so the main "
                  "pipeline's empty cells come from the transform/polygon step "
                  "(registration), NOT from the segmentation. Fix the transform.")
        elif best[0] < 0.6:
            print("    => even a forced best-fit alignment cannot cover much "
                  "more than the pipeline already does: the empty cells are "
                  "largely REAL (sparse capture / spurious IF segmentations). "
                  "No coordinate fix will recover them.")
        else:
            print("    => intermediate ceiling: a mix of recoverable "
                  "registration loss and genuinely empty cells.")
        return best

    def process_points_and_tables(self, orient="check",
                                  orient_subsample=200000,
                                  orient_min_improvement=0.10):
        """Assign transcript points to segmented cells and build AnnData table.
        
        Loads transcript point data from SpatialData, applies coordinate 
        transformations, performs spatial join to assign transcripts to cells,
        builds a gene expression matrix, and creates an AnnData object.
        
        Returns:
            tuple: Contains two elements:
                - points_model (dd.DataFrame): Dask DataFrame of points with
                  transformed coordinates and cell assignments.
                - vdata (ad.AnnData): AnnData object containing:
                    - X: Gene expression count matrix (cells × genes)
                    - obs: Cell metadata with cell IDs
                    - var: Gene metadata with gene names
        
        Note:
            - Concatenates all point layers from SpatialData
            - Applies global transformation and FOV shift corrections
            - Uses spatial join with polygon geometries to assign transcripts
            - Creates cross-tabulated expression matrix via pd.crosstab
            - Clears memory after processing
            - Sets `self.gdf_points` and `self.vdata` attributes
        
        Warning:
            Assumes FOV size of 4256 pixels for shift correction. May need
            adjustment for different imaging systems.
        """
        
        # ---------------- LOAD TRANSCRIPTS (SINGLE MATERIALISATION) --------
        # [PERF] This method used to call .compute() four times: once for the
        # base columns, twice more to pull back the dask-assigned transformed
        # x/y, and a fourth time at the end to inject cell_id. Dask caches
        # nothing between calls, so the concat (+ assign, + mirror) graph was
        # re-executed from scratch each time — on a multi-FOV mosaic that is
        # four full passes over every transcript. We now materialise the
        # concatenated frame exactly once and do all coordinate work in
        # pandas/numpy. This also collapses the parallel pandas `points_df` /
        # dask `points_model` representations into one, which removes the
        # "dask .assign() rejects a raw numpy array" workaround that the
        # orientation flip previously needed.
        points_dask = dd.concat(
            [self.sdata.points[x] for x in self.sdata.points.keys()],
            axis=0, ignore_index=False)
        n_partitions = points_dask.npartitions

        # [FIX] Reset the index immediately after the concat. dd.concat is
        # called with ignore_index=False, so every per-FOV point layer keeps
        # its own 0..n index and the concatenated frame carries duplicate
        # index labels. gpd.sjoin propagates the left-hand index into its
        # result, so those duplicates make it impossible to align the join
        # back onto the points positionally — silently scrambling cell_id
        # assignment, or raising a length error, once more than one FOV is
        # present. Ported from the xenium path, which hit the same issue.
        points_df = points_dask.compute().reset_index(drop=True)

        # [FIX] Read the stitched image's global affine from whichever name
        # the user supplied (was hard-coded to 'Stitched'). Handle both
        # single-scale DataArray and multiscale DataTree.
        stitched_obj = self.sdata.images[self.image_name]
        try:
            stitched_xr = stitched_obj["scale0"].ds["image"]
        except (KeyError, TypeError):
            stitched_xr = stitched_obj
        transform = stitched_xr.attrs['transform']['global'].matrix[1:4, 1:4]
        # Build the attrs dict up front and attach it to the rebuilt dask
        # frame at the end of the method (a plain pandas frame has no
        # spatialdata attrs to hang these on in the meantime).
        from spatialdata.transformations import Identity as _Identity
        # multispace patch: the *_transformed columns are canvas pixels, i.e.
        # identity to the canvas (the old 3x3 slice of the (c,y,x)->(c,x,y)
        # affine, relabelled as x,y -> x,y, did not describe them).
        points_attrs = {
            'transform': {
                'global': _Identity(),
                'global_only_labels': _Identity(),
            },
            'spatialdata_attrs': {
                'feature_key': 'target', 'instance_key': 'cell_id',
            },
        }

        # multispace patch: map slide-world (x_global_px, y_global_px) into
        # stitched-canvas pixels (y-down, the frame of the Cellpose polygons)
        # with the inverse of the stitched image's own affine. For the affine
        # written by stitch_cosmx_core this is exactly
        #     x_canvas = x_world - x_off,   y_canvas = y_off - y_world
        # (the 2025-05-08 fix in the HPC copy). The translation-only arithmetic
        # used here before, y - (y_off - canvas_h) = canvas_h - row, mirrored
        # the transcripts; the automatic flip that followed mirrored them back
        # about the cells' bounding box instead of the canvas, leaving a
        # residual shift of (top margin - bottom margin).
        _m = np.asarray(
            stitched_xr.attrs['transform']['global'].to_affine_matrix(
                input_axes=("x", "y"), output_axes=("x", "y")),
            dtype=float)
        _inv = np.linalg.inv(_m)
        _wx = points_df['x_global_px'].to_numpy(dtype=float)
        _wy = points_df['y_global_px'].to_numpy(dtype=float)
        points_df['x_global_px_transformed'] = _wx * _inv[0, 0] + _wy * _inv[0, 1] + _inv[0, 2]
        points_df['y_global_px_transformed'] = _wx * _inv[1, 0] + _wy * _inv[1, 1] + _inv[1, 2]

        # Orientation: with the exact mapping no flip is needed. The default
        # orient="check" still runs the flip test as a diagnostic and warns if
        # a flip would fit much better (a sign that the input does not follow
        # the stitch_cosmx_core convention), but never changes the data.
        # Pass orient="auto" for the old behaviour or force a flip explicitly.
        flip_x, flip_y = self._resolve_orientation(
            points_df['x_global_px_transformed'].to_numpy(dtype=float),
            points_df['y_global_px_transformed'].to_numpy(dtype=float),
            orient=orient,
            subsample=orient_subsample,
            min_improvement=orient_min_improvement,
        )
        if flip_x or flip_y:
            xmin, ymin, xmax, ymax = self.gdf_polygons.total_bounds
            if flip_x:
                points_df['x_global_px_transformed'] = (
                    xmin + xmax) - points_df['x_global_px_transformed']
            if flip_y:
                points_df['y_global_px_transformed'] = (
                    ymin + ymax) - points_df['y_global_px_transformed']

        self.gdf_points = gpd.GeoDataFrame(
            points_df[['x_global_px_transformed',
                       'y_global_px_transformed', 'target', 'z_raw']],
            geometry=gpd.points_from_xy(
                x=points_df["x_global_px_transformed"], y=points_df["y_global_px_transformed"]),
            crs=self.gdf_polygons.crs,
        )

        # Spatial join (assign transcripts to polygons)
        joined = gpd.sjoin(
            self.gdf_points,
            self.gdf_polygons[["cell_id", "geometry"]],
            how="left",
            predicate="within",
        )
        # [FIX] A transcript sitting inside two overlapping polygons produces
        # one join row per match, so `joined` can be longer than gdf_points and
        # the old positional `.values` assignment would raise (or, worse,
        # mis-align). Cellpose polygons are usually disjoint, but the
        # regionprops filtering and the polygonisation tolerance can leave
        # slivers of overlap, so this is not hypothetical. Keep the first match
        # per transcript, matching the xenium path's behaviour.
        n_join_rows = len(joined)
        joined = joined[~joined.index.duplicated(keep='first')]
        if n_join_rows != len(joined):
            print(f"Resolved {n_join_rows - len(joined):,} transcripts "
                  f"matching multiple overlapping polygons (kept first)")

        # [FIX] Reindex onto gdf_points rather than relying on sjoin preserving
        # left-hand row order. how='left' guarantees every left index survives,
        # so this is a pure reorder and cannot introduce NaNs of its own.
        self.gdf_points["cell_id"] = joined.loc[
            self.gdf_points.index, "cell_id"].to_numpy()

        # ---------------- BUILD EXPRESSION MATRIX (SPARSE) ----------------
        # [UPDATED] Replaced the dense pd.crosstab + dict-of-OrderedDicts
        # construction with the sparse CSR build used in SeamStitchPipeline.
        # The old approach materialised a full dense cells × genes DataFrame
        # and then iterated over it row-by-row in Python (one OrderedDict per
        # cell), so both memory and runtime scaled with cells × genes — fine
        # for a single TMA core but prohibitive for a whole-slide CosMx mosaic.
        # Here each transcript is mapped directly to (row, col) integer indices
        # and assembled into a scipy.sparse.csr_matrix in one shot, so memory
        # scales with the number of non-zero entries rather than cells × genes.

        # 1. Keep only transcripts that landed inside a cell. The spatial join
        #    above used how="left", so unassigned transcripts carry NaN cell_id.
        assigned = self.gdf_points[["cell_id", "target"]].copy()
        assigned = assigned[assigned["cell_id"].notna()]

        # 2. Drop transcripts with a missing/non-string gene name (control or
        #    blank codewords can arrive as NaN); mixing NaN with strings breaks
        #    sorted() and they cannot index a gene column.
        _n_before = len(assigned)
        assigned = assigned[assigned["target"].notna()].copy()
        assigned["target"] = assigned["target"].astype(str)
        if len(assigned) != _n_before:
            print(
                f"Dropped {_n_before - len(assigned):,} transcripts with no gene name")

        # 3. Intersect cells that have transcripts with cells that have shapes,
        #    so the count-matrix rows align 1:1 with the polygon geometries.
        #    NB: reseg cell_id is a STRING label ("cell_N"), so — unlike the
        #    SeamStitchPipeline, which uses integer cell ids — we do NOT cast
        #    to int anywhere here.
        assigned_cell_ids = set(assigned["cell_id"].unique())
        shape_cell_ids = set(self.gdf_polygons["cell_id"].unique())
        cell_ids = sorted(assigned_cell_ids & shape_cell_ids)
        genes = sorted(assigned["target"].unique())

        assigned = assigned[assigned["cell_id"].isin(set(cell_ids))].copy()
        print(
            f"Intersection: {len(cell_ids):,} cells in both transcripts and shapes")
        print(
            f"Dropped: {len(assigned_cell_ids - shape_cell_ids):,} transcript-only cells")
        print(
            f"Dropped: {len(shape_cell_ids - assigned_cell_ids):,} shape-only cells")

        n_cells = len(cell_ids)
        n_genes = len(genes)
        print(f"{n_cells:,} cells × {n_genes:,} genes")

        # 4. Map each transcript to its (row, col) position and build the CSR.
        cell_idx = {c: i for i, c in enumerate(cell_ids)}
        gene_idx = {g: i for i, g in enumerate(genes)}
        assigned["row_idx"] = assigned["cell_id"].map(cell_idx)
        assigned = assigned[assigned["row_idx"].notna()].copy()
        assigned["col_idx"] = assigned["target"].map(gene_idx)

        rows = assigned["row_idx"].astype(int).values
        cols = assigned["col_idx"].astype(int).values
        X = csr_matrix(
            (np.ones(len(rows), dtype=np.float32), (rows, cols)),
            shape=(n_cells, n_genes))
        print(f"Matrix shape: {X.shape}, nnz={X.nnz}")

        # 5. Build the AnnData with a sparse X. obs/var keep the same "cells"
        #    and "genes" columns the rest of the CosMx pipeline expects, and
        #    obs_names/var_names stay as the cell_id strings and gene names.
        obs = pd.DataFrame(
            {
                "cells": [str(c) for c in cell_ids],
                "n_transcripts": np.asarray(X.sum(axis=1)).flatten().astype(int),
            },
            index=[str(c) for c in cell_ids],
        )
        var = pd.DataFrame({"genes": genes}, index=genes)
        self.vdata = ad.AnnData(X=X, obs=obs, var=var)
        self.vdata.obs_names = [str(c) for c in cell_ids]
        self.vdata.var_names = genes

        # [REMOVED] The old "clean up memory" block did
        #     for var in (points_df,): del var
        # which only deleted the loop variable, never the DataFrame — it freed
        # nothing. It also shadowed the `var` DataFrame built for the AnnData a
        # few lines above, which was harmless only because AnnData had already
        # been constructed. points_df is needed for the writeback below anyway.
        self.clear_gpu_memory()

        # [PROSEG-COSMX] Attach the spatial-join assignments and rebuild the
        # dask frame. points_df is the full concatenated transcript table (all
        # original CosMx columns, e.g. fov / cell_ID / CellComp, plus the
        # FOV-corrected x/y_global_px_transformed), so every column the input
        # carried survives into the output — nothing is projected away.
        #
        # gdf_points was built from points_df and both carry the same
        # reset 0..N-1 index, so this positional attach is sound. We assert it
        # rather than assume it: a silent mismatch here would mis-assign every
        # transcript downstream, and proseg would inherit the damage.
        if len(points_df) != len(self.gdf_points):
            raise RuntimeError(
                f"Transcript/geometry row count diverged: points_df has "
                f"{len(points_df):,} rows, gdf_points has "
                f"{len(self.gdf_points):,}. cell_id cannot be attached "
                f"positionally."
            )
        points_df["cell_id"] = self.gdf_points["cell_id"].to_numpy()

        # Rebuild the dask frame once, from the single materialised pandas
        # frame. We deliberately keep the dataframe shape parallel to xenium's
        # points_model to keep proseg_wrapper agnostic.
        points_model_updated = dd.from_pandas(
            points_df, npartitions=n_partitions
        )
        points_model_updated.attrs.update(points_attrs)  # multispace patch: spatialdata >= 0.8
        self.points_model = points_model_updated

        return self.points_model, self.vdata

    # ---------------- COSMX-SPECIFIC ANNDATA POSTPROCESSING ---------------- #

    def process_cosmx_adata(self, gene_list_path=None):
        """Run QC + control-feature removal on the cosmx AnnData.

        Mirrors process_xenium_adata in Resegmentation_xenium but with
        defaults that make sense for CosMx:
          - control feature keywords are CosMx-typical (SystemControl,
            Negative, FalseCode); if none of them match the panel the
            corresponding count columns just stay at 0 — nothing is
            erroneously dropped.
          - the per-core metadata copy from self.sdata.tables['table'] is
            done generically (no hard-coded TMA/metabric column list) so it
            works whether or not the input zarr ships such a table.
          - gene_list_path is optional. If not provided (or missing on disk)
            the gene-set normalization step is skipped.

        Operates on self.new_sdata.tables['table'] in place.
        """

        # CosMx-typical control feature naming
        keywords = {
            'system_control': 'SystemControl',
            'negative_probe': 'Negative',
            'false_code': 'FalseCode',
        }

        vdata = self.new_sdata.tables['table']
        print("PROCESSING COSMX ANNDATA")
        print(f"Original shape: {vdata.shape}")

        # Optional: copy any per-core metadata from input sdata's table.uns / obs.
        # [FIX] Explicitly skip 'spatialdata_attrs' during the uns copy — its
        # region_key / region / instance_key fields describe the *source*
        # table's per-FOV layout (region_key='fov_labels',
        # region=['1_labels', ..., '<n>_labels'], instance_key='cell_ID') and
        # are invalid for the stitched output, where labels/shapes live under
        # a single name and obs has 'cells', not 'cell_ID'. Keeping them
        # makes the next `tables['table'] = vdata` assignment fail spatialdata's
        # TableModel validator with KeyError-style ValueErrors. We rewrite a
        # correct spatialdata_attrs further below.
        if 'table' in self.sdata.tables:
            try:
                src_uns = self.sdata.tables['table'].uns
                for k in list(src_uns.keys()):
                    if k == 'spatialdata_attrs':
                        continue
                    vdata.uns[k] = src_uns[k]
            except Exception:
                pass

            try:
                obs_row = self.sdata.tables['table'].obs.iloc[0]
                for k in obs_row.index:
                    vdata.uns[k] = obs_row.loc[k]
            except Exception:
                pass

        # [FIX] Build a fresh spatialdata_attrs matching the stitched output:
        # one region (the cellpose shapes), region_key column added to obs,
        # instance_key pointing at the existing 'cells' column. Without this,
        # the table is silently un-linked from the shapes/labels in
        # SpatialData and downstream sdata.tables[...] queries can't resolve
        # cell_id → region.
        if self.shape_name in self.new_sdata.shapes:
            region_name = self.shape_name
        elif self.label_name in self.new_sdata.labels:
            region_name = self.label_name
        else:
            region_name = None

        if region_name is not None and 'cells' in vdata.obs.columns:
            if 'region' not in vdata.obs.columns:
                vdata.obs['region'] = region_name
                vdata.obs['region'] = vdata.obs['region'].astype('category')
            vdata.uns['spatialdata_attrs'] = {
                'region': [region_name],
                'region_key': 'region',
                'instance_key': 'cells',
            }

        # Filter shapes to valid cells (cosmx: shape_name from self.shape_name)
        valid_cells = vdata.obs_names
        if self.shape_name in self.new_sdata.shapes:
            gdf_cells = self.new_sdata.shapes[self.shape_name].copy()
            gdf_cells_filtered = gdf_cells[gdf_cells['cell_id'].isin(valid_cells)]
            self.new_sdata.shapes[self.shape_name] = gdf_cells_filtered

            cells = self.new_sdata.shapes[self.shape_name]
            obs = vdata.obs.copy()
            obs['cell_area'] = cells.geometry.area.values
            centroids = cells.geometry.centroid
            vdata.obsm['spatial'] = np.column_stack([centroids.x, centroids.y])
            vdata.obs = obs

        # QC metrics
        print("1. Computing QC metrics")
        for metric_name, keyword in keywords.items():
            mask = vdata.var_names.str.contains(keyword, na=False, regex=False)
            counts = np.array(vdata[:, mask].X.sum(axis=1)).flatten()
            vdata.obs[f'{metric_name}_counts'] = counts
            print(f" {metric_name}_counts: {mask.sum()} features")

        all_control_mask = pd.Series(False, index=vdata.var_names)
        for keyword in keywords.values():
            all_control_mask |= vdata.var_names.str.contains(
                keyword, na=False, regex=False)

        transcript_mask = ~all_control_mask
        vdata.obs['transcript_counts'] = np.array(
            vdata[:, transcript_mask].X.sum(axis=1)
        ).flatten()
        vdata.obs['total_counts'] = np.array(vdata.X.sum(axis=1)).flatten()

        # Remove control features
        print("2. Removing control features")
        print(f" Control features: {all_control_mask.sum()}")
        print(f" Regular genes: {transcript_mask.sum()}")
        vdata = vdata[:, transcript_mask].copy()
        print(f" After removal: {vdata.shape}")

        # 3. Optional reference-gene normalization
        if gene_list_path is not None and os.path.exists(gene_list_path):
            print(f"3. Adding missing genes from reference {gene_list_path}")
            gene_list = pd.read_csv(gene_list_path)['gene_name'].tolist()
            current_genes = set(vdata.var_names)
            missing_genes = [g for g in gene_list if g not in current_genes]

            if len(missing_genes) > 0:
                original_uns = vdata.uns.copy()
                original_obsm = vdata.obsm.copy() if vdata.obsm.keys() else {}

                missing_matrix = np.zeros((vdata.n_obs, len(missing_genes)))
                if hasattr(vdata.X, 'toarray'):
                    missing_matrix = csr_matrix(missing_matrix)

                missing_var = pd.DataFrame(index=missing_genes)
                for col in vdata.var.columns:
                    if vdata.var[col].dtype == 'object' or vdata.var[col].dtype == 'string':
                        missing_var[col] = ''
                    elif vdata.var[col].dtype == 'bool':
                        missing_var[col] = False
                    else:
                        missing_var[col] = 0

                missing_adata = sc.AnnData(
                    X=missing_matrix,
                    obs=vdata.obs.copy(),
                    var=missing_var
                )

                vdata = sc.concat(
                    [vdata, missing_adata],
                    axis=1, join='outer', merge='same'
                )

                vdata.uns = original_uns
                if original_obsm:
                    vdata.obsm = original_obsm

            genes_in_order = [g for g in gene_list if g in vdata.var_names]
            vdata = vdata[:, genes_in_order].copy()

        else:
            print("3. Skipping reference-gene normalization "
                  "(gene_list_path missing)")

        self.new_sdata.tables['table'] = vdata
        print("COSMX ANNDATA PROCESSING COMPLETE")
        print(f" Final shape: {vdata.shape}")

        return vdata

    # ---------------- PROSEG REFINEMENT ---------------- #

    def run_proseg(self,
                   samples=1000,
                   voxel_size=0.5,
                   voxel_layers=2,
                   nuclear_reassignment_prob=0.2,
                   diffusion_probability=0.2,
                   num_threads=12,
                   proseg_binary=None,
                   gene_list_path=None):
        """Run the full Proseg refinement pipeline on a CosMx run.

        Mirrors Resegmentation_xenium.run_proseg, but feeds the proseg
        binary the CosMx-flavoured transcript columns:
          x_global_px_transformed / y_global_px_transformed / z_raw / target.

        After refinement it:
          1. fixes the proseg-zarr metadata
          2. loads the refined components
          3. validates / parses them
          4. integrates them with the cellpose-segmented data
          5. produces visualizations + comparison stats
          6. exports CSV/GeoJSON/Shapefile outputs
          7. runs CosMx-specific QC on the refined AnnData

        Returns the integrated SpatialData object.
        """

        # Set up logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.log = logging.getLogger(__name__)
        self.log.info("Starting Proseg Refinement Pipeline for CosMx Data")

        # [FIX] Resolve the proseg binary at call time. Previous default
        # was a hard-coded "/users/k2481276/.cargo/bin/proseg" — wrong case
        # ('users' vs 'Users') and machine-specific. Prefer in this order:
        #   1) explicit proseg_binary argument
        #   2) `proseg` discoverable via shutil.which (PATH)
        #   3) ~/.cargo/bin/proseg (default cargo install location)
        # The first one that resolves to an executable file wins.
        if proseg_binary is None:
            import shutil
            on_path = shutil.which("proseg")
            cargo_default = os.path.expanduser("~/.cargo/bin/proseg")
            if on_path:
                proseg_binary = on_path
            elif os.path.isfile(cargo_default) and os.access(cargo_default, os.X_OK):
                proseg_binary = cargo_default
            else:
                raise RuntimeError(
                    "Could not locate the proseg binary. Install with "
                    "`cargo install proseg` (which places it at "
                    "~/.cargo/bin/proseg) and either ensure ~/.cargo/bin "
                    "is on your PATH, or pass proseg_binary='<absolute path>' "
                    "to run_proseg(...)."
                )
        self.log.info(f"Using proseg binary: {proseg_binary}")

        # Source SpatialData (already populated in update_spatialdata)
        sdata = self.new_sdata

        # Get transcripts from points (must include the cosmx-transformed
        # coordinates and cell_id columns produced by process_points_and_tables)
        transcripts_df = sdata.points[self.point_name].compute()

        required_cols = [
            "x_global_px_transformed", "y_global_px_transformed",
            "z_raw", "target", "cell_id",
        ]
        missing = [c for c in required_cols if c not in transcripts_df.columns]
        if missing:
            raise ValueError(
                f"Cosmx transcripts dataframe is missing columns required "
                f"for Proseg: {missing}. Make sure process_points_and_tables "
                f"ran before run_proseg."
            )

        # Make sure cell_id is JSON/CSV-safe for proseg (it expects a value
        # for unassigned transcripts — we use 0 like xenium does).
        transcripts_df = transcripts_df.copy()
        transcripts_df["cell_id"] = transcripts_df["cell_id"].fillna(0)

        # Define output paths
        output_path = Path("proseg_output.zarr")
        output_integrated_path = Path("integrated_proseg_output.zarr")

        # Run Proseg refinement
        self.log.info("Running Proseg refinement (cosmx columns)")
        output_path = run_proseg_refinement(
            transcripts_df=transcripts_df,
            output_path=str(output_path),
            proseg_binary=proseg_binary,
            x_col="x_global_px_transformed",
            y_col="y_global_px_transformed",
            z_col="z_raw",
            gene_col="target",
            cell_id_col="cell_id",
            samples=samples,
            voxel_size=voxel_size,
            voxel_layers=voxel_layers,
            nuclear_reassignment_prob=nuclear_reassignment_prob,
            diffusion_probability=diffusion_probability,
            num_threads=num_threads,
            overwrite=True,
            logger=self.log,
        )

        # Fix metadata
        self.log.info("Fixing zarr metadata")
        fix_zarr_metadata(output_path, self.log)

        self.log.info("Fixing AnnData table")
        fix_anndata_table(output_path, self.log)

        # Load Proseg components
        self.log.info("Loading Proseg components")
        refined_shapes_gdf, adata_proseg, refined_transcripts_df = \
            load_proseg_components(output_path, self.log)

        # Validate and parse components
        self.log.info("Validating and parsing components")
        refined_sdata, adata_sanitized, refined_shapes_parsed, instance_key = \
            validate_and_parse_components(
                output_path, refined_shapes_gdf, adata_proseg, self.log
            )

        # Create integrated SpatialData. proseg_wrapper accesses the
        # original points/shapes by literal key ("transcripts" / "shapes"),
        # which matches the cosmx workflow's point_name/shape_name defaults.
        self.log.info("Creating integrated SpatialData")
        integrated_sdata = create_integrated_spatialdata(
            sdata,
            output_path,
            refined_shapes_parsed,
            adata_sanitized,
            instance_key,
            transcripts_df,
            refined_transcripts_df,
            self.log,
        )

        # Visualizations
        self.log.info("Creating visualizations")
        create_visualizations(integrated_sdata, refined_shapes_gdf, self.log)

        # Comparison statistics
        self.log.info("Generating comparison statistics")
        generate_comparison_statistics(
            sdata, refined_sdata, integrated_sdata, self.log)

        # Exports
        self.log.info("Exporting data to various formats")
        export_data(
            refined_shapes_gdf,
            adata_proseg,
            refined_transcripts_df,
            self.log,
        )

        # Reload integrated zarr and run cosmx-specific QC on the refined adata
        self.log.info("Reloading integrated SpatialData for final processing")
        self.integrated_sdata = sd.read_zarr(output_path)

        self.log.info("Processing refined AnnData with CosMx-specific QC")
        self.process_cosmx_adata_proseg(gene_list_path=gene_list_path)

        # Save updated integrated SpatialData
        self.log.info("Saving updated integrated SpatialData")
        if output_integrated_path.exists():
            shutil.rmtree(output_integrated_path)
        self.integrated_sdata.write(output_integrated_path)

        self.log.info("Proseg Refinement Pipeline Complete!")

        return self.integrated_sdata

    def process_cosmx_adata_proseg(self, gene_list_path=None):
        """CosMx counterpart of process_xenium_adata_proseg.

        Runs QC and (optionally) gene-list normalization on
        self.integrated_sdata.tables['table_refined'], using cosmx
        control-feature keywords. Behaves like process_cosmx_adata: copies
        any uns metadata from 'table_original' if present and skips the
        gene reference step when gene_list_path is missing.
        """

        keywords = {
            'system_control': 'SystemControl',
            'negative_probe': 'Negative',
            'false_code': 'FalseCode',
        }

        adata = self.integrated_sdata.tables['table_refined']
        print("PROCESSING PROSEG-REFINED COSMX ANNDATA")
        print(f"Original shape: {adata.shape}")

        # Copy metadata from table_original (best-effort, generic copy).
        # [FIX] Skip 'spatialdata_attrs' — that came from the cellpose-derived
        # table where instance_key='cells' (a column we explicitly added).
        # The proseg-refined adata has integer obs_names but no 'cells'
        # column, so applying the cellpose attrs would fail validation. We
        # rebuild a correct spatialdata_attrs further below.
        if 'table_original' in self.integrated_sdata.tables:
            try:
                src_uns = self.integrated_sdata.tables['table_original'].uns
                for k in list(src_uns.keys()):
                    if k == 'spatialdata_attrs':
                        continue
                    adata.uns[k] = src_uns[k]
            except Exception:
                pass

        # Compute spatial metrics from refined cell boundaries if available
        cells = None
        if 'cell_boundaries_refined' in self.integrated_sdata.shapes:
            cells = self.integrated_sdata.shapes['cell_boundaries_refined']
        elif self.shape_name in self.integrated_sdata.shapes:
            cells = self.integrated_sdata.shapes[self.shape_name]

        if cells is not None:
            try:
                # Proseg's adata uses integer cell ids in obs_names
                valid_cells = adata.obs_names.astype(int)
                cells_filtered = cells[cells.index.isin(valid_cells)]
                adata.obs['cell_area'] = cells_filtered.geometry.area.values
                centroids = cells_filtered.geometry.centroid
                adata.obsm['spatial'] = np.column_stack(
                    [centroids.x, centroids.y]
                )
            except Exception as e:
                self.log.warning(
                    f"Could not compute refined spatial metrics: {e}"
                )

        # QC metrics
        print("1. Computing QC metrics")
        for metric_name, keyword in keywords.items():
            mask = adata.var_names.str.contains(keyword, na=False, regex=False)
            counts = np.array(adata[:, mask].X.sum(axis=1)).flatten()
            adata.obs[f'{metric_name}_counts'] = counts

        all_control_mask = pd.Series(False, index=adata.var_names)
        for keyword in keywords.values():
            all_control_mask |= adata.var_names.str.contains(
                keyword, na=False, regex=False)

        transcript_mask = ~all_control_mask
        adata.obs['transcript_counts'] = np.array(
            adata[:, transcript_mask].X.sum(axis=1)
        ).flatten()
        adata.obs['total_counts'] = np.array(adata.X.sum(axis=1)).flatten()

        # Remove control features
        print("2. Removing control features")
        adata = adata[:, transcript_mask].copy()
        print(f" After removal: {adata.shape}")

        # 3. Optional reference-gene normalization
        if gene_list_path is not None and os.path.exists(gene_list_path):
            print(f"3. Adding missing genes from reference {gene_list_path}")
            gene_list = pd.read_csv(gene_list_path)['gene_name'].tolist()
            current_genes = set(adata.var_names)
            missing_genes = [g for g in gene_list if g not in current_genes]

            if len(missing_genes) > 0:
                original_uns = adata.uns.copy()
                original_obsm = adata.obsm.copy() if adata.obsm.keys() else {}

                missing_matrix = np.zeros((adata.n_obs, len(missing_genes)))
                if hasattr(adata.X, 'toarray'):
                    missing_matrix = csr_matrix(missing_matrix)

                missing_var = pd.DataFrame(index=missing_genes)
                for col in adata.var.columns:
                    if adata.var[col].dtype == 'object' or adata.var[col].dtype == 'string':
                        missing_var[col] = ''
                    elif adata.var[col].dtype == 'bool':
                        missing_var[col] = False
                    else:
                        missing_var[col] = 0

                missing_adata = sc.AnnData(
                    X=missing_matrix,
                    obs=adata.obs.copy(),
                    var=missing_var
                )

                adata = ad.concat(
                    [adata, missing_adata],
                    axis=1, join='outer', merge='same'
                )

                adata.uns = original_uns
                if original_obsm:
                    adata.obsm = original_obsm

            genes_in_order = [g for g in gene_list if g in adata.var_names]
            adata = adata[:, genes_in_order].copy()

        else:
            print("3. Skipping reference-gene normalization "
                  "(gene_list_path missing)")

        # [FIX] Build a spatialdata_attrs that matches the proseg-refined
        # output before re-assigning the table. Proseg's adata has integer
        # cell ids in obs_names with no 'cells' column, so we add one
        # (mirroring what process_cosmx_adata does for the cellpose table)
        # and point the validator at it. region defaults to
        # 'cell_boundaries_refined' since that's the shapes element the
        # proseg integration writes; falls back to self.shape_name if not
        # present.
        if 'cells' not in adata.obs.columns:
            adata.obs['cells'] = adata.obs_names.astype(str)

        if 'cell_boundaries_refined' in self.integrated_sdata.shapes:
            refined_region = 'cell_boundaries_refined'
        elif self.shape_name in self.integrated_sdata.shapes:
            refined_region = self.shape_name
        else:
            refined_region = None

        if refined_region is not None:
            if 'region' not in adata.obs.columns:
                adata.obs['region'] = refined_region
                adata.obs['region'] = adata.obs['region'].astype('category')
            adata.uns['spatialdata_attrs'] = {
                'region': [refined_region],
                'region_key': 'region',
                'instance_key': 'cells',
            }

        self.integrated_sdata.tables['table_refined'] = adata
        print("COSMX PROSEG ANNDATA PROCESSING COMPLETE")
        print(f" Final shape: {adata.shape}")

        return adata

    # ---------------- SAVE ---------------- #

    def update_spatialdata(self, proseg_refinement=True):
        """Save processed SpatialData into a new Zarr file (cosmx).

        Mirrors Resegmentation_xenium.update_spatialdata: runs the full
        re-segmentation pipeline, writes the cleaned-up SpatialData to
        ``self.output_folder/updated_{zarr_name}`` and (optionally) runs
        Proseg refinement on top of the cellpose result.

        Args:
            proseg_refinement (bool, optional): If True, run Proseg after
                process_cosmx_adata (default). Set to False to write only
                the cellpose-segmented SpatialData.

        Pipeline Steps:
            1. process_masks_to_shapes() – filter masks and build polygons
            2. process_labels() – upscale masks to full resolution
            3. process_points_and_tables() – assign transcripts and build
               AnnData; injects cell_id back into points_model so Proseg
               can read transcript-cell assignments
            4. Build self.new_sdata (image / labels / shapes / points /
               table) with the same robustness logic as the xenium class
            5. process_cosmx_adata() – CosMx QC + control-feature removal
            6. (optional) run_proseg() – CosMx-flavoured Proseg refinement
            7. Write self.new_sdata to disk
        """
        self.process_masks_to_shapes()
        print("Masks to shapes finished")
        self.process_labels()
        print("Labels process finished")
        self.process_points_and_tables()
        print("Points and Tables process finished")

        self.new_sdata = sd.SpatialData()
        # [FIX] Write into self.output_folder instead of self.zarr_dir, so we
        # never overwrite the input zarr. Matches Resegmentation_xenium.
        dst_path = os.path.join(
            self.output_folder, f"updated_{self.zarr_name}")

        # Images
        img = self.sdata.images[self.image_name]
        try:
            self.new_sdata.images[self.image_name] = img.compute()
        except Exception:
            self.new_sdata.images[self.image_name] = img.copy() if hasattr(
                img, "copy") else img

        # Labels
        lbl = self.labels_model
        try:
            self.new_sdata.labels[self.label_name] = lbl.compute()
        except Exception:
            self.new_sdata.labels[self.label_name] = lbl.copy() if hasattr(
                lbl, "copy") else lbl

        # Shapes
        shp = self.shapes_model
        try:
            self.new_sdata.shapes[self.shape_name] = shp.compute()
        except Exception:
            self.new_sdata.shapes[self.shape_name] = shp.copy() if hasattr(
                shp, "copy") else shp

        # Points: drop transcripts that did not land in any cell, then store
        # a valid PointsModel element.
        # [FIX] spatialdata rejects a bare DataFrame here: a raw pandas frame
        # raises "TypeError: Unsupported type ...DataFrame", and a dask frame
        # whose .attrs lost 'transform' (dropna/copy strip it) raises
        # "ValueError: ... does not contain 'transform'". We rebuild the
        # element with PointsModel.parse().
        #
        # Canonical x/y are set to the canvas-local *transformed* coordinates
        # (x/y_global_px_transformed) — the same space the shapes and labels
        # live in (identity transform) and the space the transcript->cell
        # spatial join used, so saved transcripts overlay their assigned cells.
        # We COPY into x/y rather than passing coordinates={...} so the
        # x/y_global_px_transformed columns survive in the table: run_proseg()
        # reads them back by name (x_col/y_col), and the coordinates= form
        # would rename them away.
        pts = self.points_model
        try:
            pts_filtered = pts.dropna(subset=['cell_id'])
        except Exception:
            pts_filtered = pts

        transcripts_df = pts_filtered.compute()
        transcripts_df = transcripts_df[
            transcripts_df['cell_id'].notna()].reset_index(drop=True)
        transcripts_df['x'] = transcripts_df['x_global_px_transformed']
        transcripts_df['y'] = transcripts_df['y_global_px_transformed']

        self.new_sdata.points[self.point_name] = PointsModel.parse(
            transcripts_df,
            feature_key='target',
            instance_key='cell_id',
        )

        # Tables: clean NaN columns / values / indices before storing
        tbl = self.vdata.copy()
        tbl.obs = tbl.obs.loc[:, tbl.obs.columns.notna()]
        tbl.var = tbl.var.loc[:, tbl.var.columns.notna()]
        tbl.obs = tbl.obs.map(lambda x: "NA" if pd.isna(x) else x)
        tbl.var = tbl.var.map(lambda x: "NA" if pd.isna(x) else x)
        tbl.obs.index = tbl.obs.index.map(
            lambda x: str(x) if pd.notna(x) else "unknown_obs")
        tbl.var.index = tbl.var.index.map(
            lambda x: str(x) if pd.notna(x) else "unknown_var")

        if not tbl.obs.index.is_unique:
            tbl.obs.index = pd.Index(
                [f"cell_{i}" for i in range(len(tbl.obs))])
        if not tbl.var.index.is_unique:
            tbl.var.index = pd.Index(
                [f"gene_{i}" for i in range(len(tbl.var))])

        self.new_sdata.tables['table'] = tbl

        # CosMx-specific QC + control-feature removal on the original adata
        self.process_cosmx_adata()

        # Optional Proseg refinement step (writes proseg_output.zarr and
        # integrated_proseg_output.zarr to the working directory; the
        # workflow then moves them into the per-core output folder).
        if proseg_refinement is True:
            self.run_proseg()

        try:
            client = Client.current()
            client.close()
        except ValueError:
            pass

        self.new_sdata.write(dst_path, overwrite=True)
        print("Data saved")

        for var in (self.masks, self.flows, self.styles,
                    self.gdf_points, self.gdf_polygons):
            try:
                del var
            except Exception:
                pass
        self.clear_gpu_memory()

        return self.new_sdata


class Resegmentation_xenium:
    """Pipeline for spatial omics segmentation and data integration.

    This class encapsulates preprocessing, segmentation, mask filtering,
    shape/label creation, transcript assignment, and writing results
    back to a SpatialData Zarr file.
    
    Attributes:
        zarr_dir (str): Directory containing the input Zarr file.
        zarr_name (str): Name of the input Zarr file.
        output (str): Path to save preprocessed image output.
        factor_rescale (int): Factor by which to rescale coordinates between 
            segmentation and original resolution.
        image_name (str): Name of the image layer in SpatialData.
        label_name (str): Name for the output label layer.
        shape_name (str): Name for the output shape layer.
        point_name (str): Name of the point layer in SpatialData.
        sdata (sd.SpatialData): Loaded SpatialData object.
        image (PIL.Image): Preprocessed image for segmentation.
        masks (np.ndarray): Segmentation masks from Cellpose.
        flows (tuple): Flow outputs from Cellpose.
        styles (np.ndarray): Style outputs from Cellpose.
        gdf_polygons (gpd.GeoDataFrame): Polygon geometries for segmented cells.
        shapes_model (gpd.GeoDataFrame): SpatialData shapes model.
        labels_model (sd.models.Labels2DModel): SpatialData labels model.
        gdf_points (gpd.GeoDataFrame): Point geometries for transcripts.
        vdata (ad.AnnData): AnnData object containing gene expression matrix.
    """

    def __init__(self, zarr_dir: str,
                 zarr_name: str,
                 output: str,
                 factor_rescale: int,
                 image_name: str,
                 label_name: str,
                 shape_name: str,
                 point_name: str):
        """Initialize Resegmentation pipeline.
        
        Args:
            zarr_dir (str): Directory containing the input Zarr file.
            zarr_name (str): Name of the input Zarr file.
            output (str): Path to save preprocessed image output.
            factor_rescale (int): Rescaling factor between segmentation and 
                original resolution (e.g., 4 means segmentation is 4x smaller).
            image_name (str): Name of the image layer in SpatialData.
            label_name (str): Name for the output label layer.
            shape_name (str): Name for the output shape layer.
            point_name (str): Name of the point layer in SpatialData.
        """
        
        self.zarr_dir = zarr_dir
        self.zarr_name = zarr_name
        self.output = output
        self.factor_rescale = factor_rescale
        self.image_name = image_name
        self.label_name = label_name
        self.shape_name = shape_name
        self.point_name = point_name
        self.sdata = None
        self.image = None
        self.masks = None
        self.flows = None
        self.styles = None
        self.gdf_polygons = None
        self.shapes_model = None
        self.labels_model = None
        self.gdf_points = None
        self.vdata = None
        self.output_folder = "updated_" + zarr_dir
        os.makedirs(self.output_folder, exist_ok=True)

    # ---------------- GPU UTILITIES ---------------- #

    @staticmethod
    def check_gpu():
        """Print Python environment, TensorFlow version, and GPU availability.
        
        Displays diagnostic information about the current Python environment
        and TensorFlow GPU configuration for debugging purposes.
        
        Prints:
            - Python executable path
            - TensorFlow version
            - List of available GPU devices
        """
        print("Python path:", sys.executable)
        if tf is not None:
            print("TensorFlow version:", tf.__version__)
            print("GPU available:", tf.config.list_physical_devices("GPU"))


    @staticmethod
    def clear_gpu_memory():
        """Clear TensorFlow GPU memory and trigger garbage collection.
        
        Clears the TensorFlow Keras session to free GPU memory and runs
        Python's garbage collector to free system memory. Useful between
        processing steps to prevent memory accumulation.
        
        Note:
            Errors during clearing are caught and printed but do not raise
            exceptions to allow continued execution.
        """
        
        try:
            if tf is not None and tf.config.list_physical_devices("GPU"):
                tf.keras.backend.clear_session()
            gc.collect()
        except Exception as e:
            print(f"Error clearing GPU memory: {e}")

    # ---------------- IMAGE PREPROCESS ---------------- #

    def preprocess_image(
        self,
        channel_names: list[str],
        channels_to_use: list[str] = ["Y", "U"],
    ):
        """Load and preprocess Zarr image for segmentation.
        
        Loads image data from SpatialData Zarr file, selects specified channels,
        applies contrast stretching, converts to 8-bit RGB format, and downscales
        for segmentation. The preprocessed image is saved to disk.
        
        Args:
            channel_names (list[str]): List of all channel names in the image 
                (e.g., ['R', 'G', 'B', 'Y', 'U']).
            channels_to_use (list[str], optional): List of channel names to use
                for segmentation. Defaults to ["Y", "U"].
        
        Returns:
            PIL.Image: Preprocessed RGB image ready for segmentation, downscaled
                by `factor_rescale`.
        
        Note:
            - Applies 2nd-98th percentile contrast stretching
            - Converts grayscale or 2-channel images to 3-channel RGB
            - Clears memory after preprocessing
            - Sets `self.image` attribute
        """
        
        zarr_path = os.path.join(self.zarr_dir, self.zarr_name)
        self.sdata = sd.read_zarr(zarr_path)

        img_xr = self.sdata.images[self.image_name]["scale0"].ds["image"]
        img = img_xr.transpose("y", "x", "c").data.compute()  # (H, W, C)

        # Map channels
        channel_indices = [channel_names.index(ch) for ch in channels_to_use]
        img = img[..., channel_indices]

        # Contrast stretching
        p2, p98 = np.percentile(img, (2, 98))
        img_stretched = np.clip((img - p2) / (p98 - p2),
                                0, 1).astype(np.float32)

        # Convert to 8-bit
        img_8bit = (img_stretched * 255).astype(np.uint8)

        # Ensure 3-channel RGB
        if img_8bit.ndim == 3 and img_8bit.shape[-1] == 2:
            zero_channel = np.zeros_like(img_8bit[..., :1])
            img_8bit = np.concatenate([img_8bit, zero_channel], axis=-1)

        elif img_8bit.ndim == 3 and img_8bit.shape[-1] == 1:
            zero_channel = np.zeros_like(img_8bit[..., :1])
            img_8bit = np.concatenate(
                [img_8bit, zero_channel, zero_channel], axis=-1)

        elif img_8bit.ndim == 2:
            img_8bit = np.stack([img_8bit] * 3, axis=-1)

        seg_pil = Image.fromarray(img_8bit, mode="RGB")

        y_downscale = int(img_xr.shape[1]/self.factor_rescale)
        x_downscale = int(img_xr.shape[2]/self.factor_rescale)
        downscale = (y_downscale, x_downscale)
        self._full_shape = (int(img_xr.shape[1]), int(img_xr.shape[2]))  # multispace patch: exact upscale

        # Resize for segmentation model
        seg_pil = seg_pil.resize((x_downscale, y_downscale), Image.Resampling.LANCZOS)  # [FIX] thumbnail() preserves aspect ratio and may not produce exact target dims

        # Save if requested
        if self.output is not None:
            seg_pil.save(self.output)

        # multispace patch (ported from the CosMx class): the old loop tested
        # `var_name in globals()` for *local* variables and freed nothing.
        del img, img_8bit

        self.clear_gpu_memory()

        self.image = seg_pil
        print("Preprocessing finished")

        return seg_pil

    # ---------------- SEGMENTATION ---------------- #

    def run_cellpose(
        self,
        model_type: str = "cyto3",
        gpu: bool = True,
        tile_overlap: float = 0.1,
        diameter: float or None = None,
        flow_threshold: float = 1,
        cellprob_threshold: float = -3,
    ):
        """Run Cellpose segmentation on the preprocessed image.
        
        Loads the preprocessed image and runs Cellpose segmentation model
        to generate cell masks. Saves masks to disk and clears GPU memory.
        
        Args:
            model_type (str, optional): Cellpose model type. Options include
                'cyto', 'cyto2', 'cyto3', 'nuclei'. Defaults to "cyto3".
            gpu (bool, optional): Whether to use GPU for inference. 
                Defaults to True.
            tile_overlap (float, optional): Overlap fraction between tiles
                for large images (0-1). Defaults to 0.1.
            diameter (float or None, optional): Expected cell diameter in pixels.
                If None, uses automatic diameter detection. Defaults to None.
            flow_threshold (float, optional): Flow error threshold for mask
                reconstruction. Higher values = more lenient. Defaults to 1.
            cellprob_threshold (float, optional): Cell probability threshold.
                Lower values = more permissive segmentation. Defaults to -3.
        
        Returns:
            tuple: Contains three elements:
                - masks (np.ndarray): Labeled segmentation masks (H, W).
                - flows (tuple): Flow field outputs from Cellpose.
                - styles (np.ndarray): Style vector outputs from Cellpose.
        
        Note:
            - Sets `self.masks`, `self.flows`, and `self.styles` attributes
            - Saves mask image as "mask.png"
            - Clears GPU memory after segmentation
        """
        
        img = io.imread(self.output)
        model = models.CellposeModel(model_type=model_type, gpu=gpu)

        self.masks, self.flows, self.styles = model.eval(
            img,
            diameter=diameter,
            tile_overlap=tile_overlap,
            flow_threshold=flow_threshold,
            cellprob_threshold=cellprob_threshold,
        )
        print("Cellpose segmentation finished")
        img = Image.fromarray(self.masks)
        img.save("mask.png")

        self.clear_gpu_memory()

        return self.masks, self.flows, self.styles

    # ---------------- MASKS & SHAPES ---------------- #

    @staticmethod
    def filter_cell_by_regionprops(
            seg_masks,
            max_eccentricity=None,
            min_area=0,
            min_absolute_area=100,
            max_area=None,
            min_solidity=None,
            max_solidity=None,
            min_extent=None,
            max_extent=None,
            min_compactness=None,
            max_convexity_deficit=None,
            max_perimeter_area_ratio=None,
            area_std_filter=None,
            save_debug=False,
            verbose=True):
        """Filter segmented cell masks by multiple morphological criteria.
        
        Analyzes region properties of segmented masks and filters cells based on
        shape metrics including area, eccentricity, solidity, extent, compactness,
        and convexity deficit. Provides detailed statistics and rejection reasons 
        when verbose mode is enabled.
        
        Args:
            seg_masks (np.ndarray): Input segmentation masks with integer labels.
            max_eccentricity (float, optional): Maximum eccentricity (elongation)
                threshold. Range: 0-1, where 0=circle, 1=line. Typical: 0.95.
                Defaults to None (no filtering).
            min_area (str or float, optional): Minimum area filter. Options:
                - 'median': Use median(areas) as threshold
                - 'median_div2': Use median(areas)/2 as threshold
                - 0-100: Use percentile of area distribution
                - Absolute value: Use as pixel count threshold
                Defaults to 'median_div2'.
            min_absolute_area (int, optional): Hard minimum area to remove 
                tiny artifacts regardless of distribution. Defaults to 50.
            max_area (float, optional): Maximum area threshold in pixels.
                Defaults to None (no filtering).
            min_solidity (float, optional): Minimum solidity (area/convex_area).
                Range: 0-1. Filters highly concave cells. Typical: 0.7-0.9.
                Defaults to None (no filtering).
            max_solidity (float, optional): Maximum solidity. Filters perfectly
                convex cells (unrealistic). Typical: 0.98-0.995. 
                Defaults to None (no filtering).
            min_extent (float, optional): Minimum extent (area/bounding_box_area).
                Range: 0-1. Filters sparse cells. Typical: 0.3-0.5.
                Defaults to None (no filtering).
            max_extent (float, optional): Maximum extent. Filters perfectly
                rectangular cells. Typical: 0.9-0.95.
                Defaults to None (no filtering).
            min_compactness (float, optional): Minimum compactness (Polsby-Popper).
                Compactness = 4π * area / perimeter². Range: 0-1, where 1=perfect circle.
                Filters irregular shapes. Typical: 0.5-0.7 for cells, half-moons ~0.3-0.5.
                Defaults to None (no filtering).
            max_convexity_deficit (float, optional): Maximum convexity deficit.
                Deficit = 1 - solidity = (convex_area - area) / convex_area.
                Range: 0-1, where 0=perfectly convex. Filters concave cells like half-moons.
                Typical: 0.10-0.20, half-moons ~0.25-0.50.
                Defaults to None (no filtering).
            max_perimeter_area_ratio (float, optional): Maximum perimeter/sqrt(area) ratio.
                Normalized perimeter measure. Filters cells with excessive perimeter.
                Typical cells: 3.5-5.0, irregular cells: >6.0.
                Defaults to None (no filtering).
            area_std_filter (float, optional): Remove area outliers beyond N
                standard deviations from mean. E.g., 3.0 removes outliers
                beyond 3σ. Defaults to None (no filtering).
            save_debug (bool, optional): Whether to save debug image 
                "cleaned_mask.png". Defaults to False.
            verbose (bool, optional): Whether to print filtering statistics
                and rejection breakdown. Defaults to True.
        
        Returns:
            np.ndarray: Cleaned and relabeled mask array with consecutive 
                integer labels starting from 1. Zero indicates background.
        
        Shape Metrics Explained:
            Solidity = area / convex_area
                - ~1.0: Very smooth, convex (circle, ellipse) - may be unrealistic
                - 0.7-0.9: Slightly irregular - typical realistic cells
                - <0.7: Highly concave/irregular - likely artifacts
            
            Extent = area / bounding_box_area
                - ~1.0: Fills bounding box (square, rectangle)
                - 0.5-0.8: Typical cell shapes
                - <0.3: Very sparse/thin - likely artifacts
            
            Eccentricity = elongation measure
                - 0: Perfect circle
                - 0.95: Very elongated
                - >0.95: Extremely elongated - may be artifacts
            
            Compactness = 4π * area / perimeter² (Polsby-Popper)
                - 1.0: Perfect circle
                - 0.6-0.8: Typical cells
                - <0.5: Irregular/elongated shapes (including half-moons)
            
            Convexity Deficit = 1 - solidity
                - 0: Perfectly convex
                - 0.05-0.15: Slight irregularity (normal cells)
                - >0.20: Significant concavity (half-moon cells, artifacts)
            
            Perimeter/Area Ratio = perimeter / sqrt(area)
                - 3.5-5.0: Typical cells
                - >6.0: Irregular perimeter (fragmented, concave cells)
        
        Note:
            - Uses vectorized operations for efficient relabeling
            - Prints detailed statistics when verbose=True
            - Returns empty mask if no regions pass filtering
            - New metrics (compactness, convexity deficit) are especially effective
              for removing half-moon/crescent-shaped cells
        """
        
        if verbose:
            print("Labeling connected components")

        labeled = label(seg_masks)

        if verbose:
            print(f"Extracting properties for {labeled.max()} regions")

        # Extract properties
        properties = ['label', 'area', 'eccentricity', 'perimeter']
        if min_solidity is not None or max_solidity is not None or max_convexity_deficit is not None:
            properties.append('solidity')
        if min_extent is not None or max_extent is not None:
            properties.append('extent')

        props = regionprops_table(labeled, properties=properties)

        n_regions = len(props['label'])
        if n_regions == 0:
            if verbose:
                print("No regions found")
            return np.zeros_like(seg_masks, dtype=np.int32)

        areas = props['area']
        perimeters = props['perimeter']

        # ========== CALCULATE NEW METRICS ==========

        # 1. Compactness (Polsby-Popper): 4π * area / perimeter²
        # Circle = 1.0, irregular shapes < 0.5
        # Add epsilon to avoid division by zero
        # multispace patch (ported from the CosMx class): 1-2 px regions have
        # perimeter 0, which gave compactness ~1e11 and a useless log summary.
        _safe_perim2 = np.where(perimeters > 0, perimeters ** 2, 1.0)
        compactness = np.where(
            perimeters > 0, (4 * np.pi * areas) / _safe_perim2, 0.0)

        # 2. Convexity deficit: 1 - solidity
        # How much area is "missing" compared to convex hull
        convexity_deficit = None
        if 'solidity' in props:
            solidity = props['solidity']
            convexity_deficit = 1 - solidity

        # 3. Perimeter-to-area ratio (normalized by sqrt)
        # Normalized measure of perimeter complexity
        perimeter_area_ratio = perimeters / (np.sqrt(areas) + 1e-10)

        # Determine minimum area threshold
        if isinstance(min_area, str) and min_area == 'median':
            min_area_value = np.median(areas)
            threshold_type = "median"
        elif isinstance(min_area, str) and min_area == 'median_div2':
            min_area_value = np.median(areas)/2
            threshold_type = "median_div2"
        elif isinstance(min_area, (int, float)) and 0 <= min_area <= 100:
            min_area_value = np.percentile(areas, min_area)
            threshold_type = f"{min_area}th percentile"
        else:
            min_area_value = min_area
            threshold_type = "absolute"

        if verbose:

            print("SHAPE STATISTICS")
            print("Area:")
            print(f"Range: {areas.min():.1f} - {areas.max():.1f}")
            print(
                f"Mean: {areas.mean():.1f}, Median: {np.median(areas):.1f}, Std: {areas.std():.1f}")
            print("Eccentricity:")
            ecc = props['eccentricity']
            print(f"Range: {ecc.min():.3f} - {ecc.max():.3f}")
            print(f"Mean: {ecc.mean():.3f}, Median: {np.median(ecc):.3f}")
            print("Compactness (1.0=circle, <0.5=irregular):")
            print(
                f"Range: {compactness.min():.3f} - {compactness.max():.3f}")
            print(
                f"Mean: {compactness.mean():.3f}, Median: {np.median(compactness):.3f}")
            print(f"25th percentile: {np.percentile(compactness, 25):.3f}")
            print(f"10th percentile: {np.percentile(compactness, 10):.3f}")

            if 'solidity' in props:
                print("Solidity (convexity):")
                print(f"Range: {solidity.min():.3f} - {solidity.max():.3f}")
                print(
                    f"Mean: {solidity.mean():.3f}, Median: {np.median(solidity):.3f}")
                print("Convexity Deficit (0=convex, high=concave):")
                print(
                    f"Range: {convexity_deficit.min():.3f} - {convexity_deficit.max():.3f}")
                print(
                    f"Mean: {convexity_deficit.mean():.3f}, Median: {np.median(convexity_deficit):.3f}")
                print(
                    f"75th percentile: {np.percentile(convexity_deficit, 75):.3f}")
                print(
                    f"90th percentile: {np.percentile(convexity_deficit, 90):.3f}")

            print("Perimeter/√Area Ratio (typical: 3.5-5.0):")
            print(
                f"Range: {perimeter_area_ratio.min():.3f} - {perimeter_area_ratio.max():.3f}")
            print(
                f"Mean: {perimeter_area_ratio.mean():.3f}, Median: {np.median(perimeter_area_ratio):.3f}")
            print(
                f"75th percentile: {np.percentile(perimeter_area_ratio, 75):.3f}")
            print(
                f"90th percentile: {np.percentile(perimeter_area_ratio, 90):.3f}")

            if 'extent' in props:
                extent = props['extent']
                print("Extent (bbox filling):")
                print(f"Range: {extent.min():.3f} - {extent.max():.3f}")
                print(
                    f"Mean: {extent.mean():.3f}, Median: {np.median(extent):.3f}")

            print("Using {threshold_type} area threshold: {min_area_value:.1f}")

        # Build filter mask
        valid_mask = np.ones(n_regions, dtype=bool)
        rejection_reasons = {
            'tiny_artifacts': 0,
            'too_small': 0,
            'too_large': 0,
            'area_outliers': 0,
            'too_eccentric': 0,
            'too_convex': 0,
            'too_concave': 0,
            'too_sparse': 0,
            'too_rectangular': 0,
            'low_compactness': 0,
            'high_convexity_deficit': 0,
            'irregular_perimeter': 0
        }

        # 1. Remove tiny artifacts
        if min_absolute_area > 0:
            artifact_mask = areas >= min_absolute_area
            rejection_reasons['tiny_artifacts'] = (~artifact_mask).sum()
            valid_mask &= artifact_mask

        # 2. Apply relative area threshold
        small_mask = areas >= min_area_value
        rejection_reasons['too_small'] = (~small_mask & valid_mask).sum()
        valid_mask &= small_mask

        # 3. Remove very large regions
        if max_area is not None:
            large_mask = areas <= max_area
            rejection_reasons['too_large'] = (~large_mask & valid_mask).sum()
            valid_mask &= large_mask

        # 4. Remove area outliers
        if area_std_filter is not None:
            mean_area = areas.mean()
            std_area = areas.std()
            lower_bound = mean_area - area_std_filter * std_area
            upper_bound = mean_area + area_std_filter * std_area
            outlier_mask = (areas >= lower_bound) & (areas <= upper_bound)
            rejection_reasons['area_outliers'] = (
                ~outlier_mask & valid_mask).sum()
            valid_mask &= outlier_mask
            if verbose:
                print(
                    f"Area outlier bounds ({area_std_filter}σ): {lower_bound:.1f} - {upper_bound:.1f}")

        # 5. Apply eccentricity filter
        if max_eccentricity is not None:
            eccentric_mask = props['eccentricity'] <= max_eccentricity
            rejection_reasons['too_eccentric'] = (
                ~eccentric_mask & valid_mask).sum()
            valid_mask &= eccentric_mask
            if verbose:
                print(f"Max eccentricity threshold: {max_eccentricity:.3f}")

        # 6. Filter by solidity (convexity)
        if 'solidity' in props:
            # Remove too convex cells (unrealistically smooth)
            if max_solidity is not None:
                convex_mask = solidity <= max_solidity
                rejection_reasons['too_convex'] = (
                    ~convex_mask & valid_mask).sum()
                valid_mask &= convex_mask
                if verbose:
                    print(f"Max solidity (remove convex): {max_solidity:.3f}")

            # Remove too concave cells (artifacts)
            if min_solidity is not None:
                concave_mask = solidity >= min_solidity
                rejection_reasons['too_concave'] = (
                    ~concave_mask & valid_mask).sum()
                valid_mask &= concave_mask
                if verbose:
                    print(f"Min solidity (remove concave): {min_solidity:.3f}")

        # 7. Filter by extent (bounding box filling)
        if 'extent' in props:
            extent = props['extent']

            # Remove sparse/thin cells
            if min_extent is not None:
                sparse_mask = extent >= min_extent
                rejection_reasons['too_sparse'] = (
                    ~sparse_mask & valid_mask).sum()
                valid_mask &= sparse_mask
                if verbose:
                    print(f"Min extent (remove sparse): {min_extent:.3f}")

            # Remove perfectly rectangular cells
            if max_extent is not None:
                rect_mask = extent <= max_extent
                rejection_reasons['too_rectangular'] = (
                    ~rect_mask & valid_mask).sum()
                valid_mask &= rect_mask
                if verbose:
                    print(f"Max extent (remove rectangular): {max_extent:.3f}")

        # 8. Filter by compactness (CRITICAL for half-moon cells)
        if min_compactness is not None:
            compact_mask = compactness >= min_compactness
            rejection_reasons['low_compactness'] = (
                ~compact_mask & valid_mask).sum()
            valid_mask &= compact_mask
            if verbose:
                print(f"Min compactness threshold: {min_compactness:.3f}")

        # 9. Filter by convexity deficit (CRITICAL for half-moon cells)
        if max_convexity_deficit is not None and convexity_deficit is not None:
            deficit_mask = convexity_deficit <= max_convexity_deficit
            rejection_reasons['high_convexity_deficit'] = (
                ~deficit_mask & valid_mask).sum()
            valid_mask &= deficit_mask
            if verbose:
                print(
                    f"Max convexity deficit threshold: {max_convexity_deficit:.3f}")

        # 10. Filter by perimeter-area ratio
        if max_perimeter_area_ratio is not None:
            perimeter_mask = perimeter_area_ratio <= max_perimeter_area_ratio
            rejection_reasons['irregular_perimeter'] = (
                ~perimeter_mask & valid_mask).sum()
            valid_mask &= perimeter_mask
            if verbose:
                print(
                    f"Max perimeter/√area ratio: {max_perimeter_area_ratio:.3f}")

        n_valid = valid_mask.sum()

        if verbose:

            print(
                f"FILTERING RESULTS: {n_valid}/{n_regions} regions passed ({100*n_valid/n_regions:.1f}%)")

            if n_valid > 0:
                valid_areas = areas[valid_mask]
                valid_compactness = compactness[valid_mask]
                valid_perimeter_ratio = perimeter_area_ratio[valid_mask]

                print("Valid regions statistics:")
                print(
                    f"Area range: {valid_areas.min():.1f} - {valid_areas.max():.1f}")
                print(f"Mean area: {valid_areas.mean():.1f}")
                print(
                    f"Compactness range: {valid_compactness.min():.3f} - {valid_compactness.max():.3f}")
                print(
                    f"Perimeter ratio range: {valid_perimeter_ratio.min():.3f} - {valid_perimeter_ratio.max():.3f}")

                if 'solidity' in props:
                    valid_solidity = solidity[valid_mask]
                    valid_deficit = convexity_deficit[valid_mask]
                    print(
                        f"Solidity range: {valid_solidity.min():.3f} - {valid_solidity.max():.3f}")
                    print(
                        f"Convexity deficit range: {valid_deficit.min():.3f} - {valid_deficit.max():.3f}")

                if 'extent' in props:
                    valid_extent = extent[valid_mask]
                    print(
                        f"Extent range: {valid_extent.min():.3f} - {valid_extent.max():.3f}")

            print("Rejection breakdown:")
            total_rejected = n_regions - n_valid
            print(f"Total rejected: {total_rejected}")
            for reason, count in rejection_reasons.items():
                if count > 0:
                    pct = 100 * count / n_regions
                    print(
                        f"{reason.replace('_', ' ').title()}: {count} ({pct:.1f}%)")

        if n_valid == 0:
            if verbose:
                print("WARNING: No regions passed filtering criteria!")
            return np.zeros_like(seg_masks, dtype=np.int32)

        # Vectorized relabeling via lookup table
        valid_labels = props['label'][valid_mask]
        lut = np.zeros(labeled.max() + 1, dtype=np.int32)
        lut[valid_labels] = np.arange(1, n_valid + 1, dtype=np.int32)
        cleaned_mask = lut[labeled]

        if save_debug:
            from PIL import Image
            Image.fromarray(cleaned_mask).save("cleaned_mask.png")
            if verbose:
                print("Saved debug image: cleaned_mask.png")

        return cleaned_mask

    @staticmethod
    def masks_to_polygons(seg_masks, factor_rescale, return_labels=False, scale_xy=None):
        """Convert segmentation masks into scaled polygons.

        Extracts contours from each labeled region in the segmentation mask,
        converts them to Shapely polygons, and rescales coordinates to match
        the original image resolution.

        Args:
            seg_masks (np.ndarray): Labeled segmentation masks where each
                unique integer represents a different cell.
            factor_rescale (int): Factor by which to upscale polygon coordinates.
                E.g., if masks are 4x smaller than original, use factor_rescale=4.
            return_labels (bool): If True, also return the mask label each
                polygon came from, so callers can keep cell_id in sync with
                the label image.
            scale_xy (tuple, optional): multispace patch. Exact (sx, sy)
                full-resolution pixels per mask pixel. When given, polygons
                are returned in full-resolution *corner* coordinates,
                x = (col + 0.5) * sx, y = (row + 0.5) * sy, which removes the
                ~(factor/2) px up-left bias and the rounding drift of the
                plain ``coords * factor`` upscale.

        Returns:
            list[shapely.geometry.Polygon], or (polygons, labels) if
            return_labels=True. Invalid or empty polygons are excluded.

        Note:
            - Finds the longest contour for each region
            - Ensures contours are closed (first point = last point)
            - Buffers only invalid polygons (buffer(0) is expensive)
            - If factor_rescale=0, no scaling is applied

        [PERF] This was the pipeline's dominant cost. The previous
        implementation looped over regionprops(seg_masks) and, for every
        region, evaluated `(seg_masks == region.label)` and then ran
        find_contours over the WHOLE mask array. That is O(n_regions x H x W):
        on this dataset (~86k regions on a stitched mosaic) that is ~86,000
        full-image comparisons plus ~86,000 full-image contour traversals,
        which is where the hours went.

        We now use scipy.ndimage.find_objects to get every label's bounding-box
        slice in a single pass, then do the comparison and contour extraction on
        that small crop only. Total work drops to roughly O(H x W + sum of bbox
        areas) - proportional to the image rather than image x cells. Three
        smaller wins on top: the rescale factor is folded into the contour
        coordinates instead of rebuilding every polygon through shapely's
        scale(), buffer(0) is applied only when a polygon is actually invalid,
        and the crop is uint8 rather than a full int64 array.
        """

        polygons = []
        labels = []

        # One pass over the array to get every label's bounding box. Index i
        # of the result corresponds to label i+1; None means that label is
        # absent (filter_cell_by_regionprops relabels consecutively, so gaps
        # are rare, but they are possible).
        slices = find_objects(seg_masks)

        # Fold the upscale into the coordinates rather than re-deriving every
        # polygon through shapely.affinity.scale afterwards.
        sf = float(factor_rescale) if factor_rescale != 0 else 1.0

        for idx, sl in enumerate(slices):
            if sl is None:
                continue
            lab = idx + 1

            # Crop to the bounding box and isolate this label. Padding by one
            # pixel guarantees find_contours sees a closed boundary even for
            # regions touching the crop edge (previously guaranteed only
            # because the whole image was passed in).
            sub = (seg_masks[sl] == lab)
            padded = np.pad(sub, 1).astype(np.uint8, copy=False)

            contours = find_contours(padded, 0.5)
            if not contours:
                continue
            contour = max(contours, key=len)
            if len(contour) < 4:
                # Fewer than 4 points cannot form a valid ring.
                continue

            # ensure the contour is closed (first point = last point)
            if not ((contour[0] == contour[-1]).all()):
                contour = np.vstack([contour, contour[0]])

            # Undo the 1px pad, shift the crop back to its global position, and
            # convert (row, col) -> (x, y) == (col, row). Identical geometry to
            # the old contour[:, [1, 0]], just computed on the crop.
            rows = contour[:, 0] - 1.0 + sl[0].start
            cols = contour[:, 1] - 1.0 + sl[1].start
            if scale_xy is not None:
                poly = Polygon(np.column_stack([(cols + 0.5) * scale_xy[0],
                                                (rows + 0.5) * scale_xy[1]]))
            else:
                poly = Polygon(np.column_stack([cols * sf, rows * sf]))

            # buffer(0) repairs self-intersections but is a full geometry
            # operation; most contours are already valid, so only pay for it
            # when it is needed.
            if not poly.is_valid:
                poly = poly.buffer(0)
                # buffer(0) on a pinched ring can split it into a MultiPolygon.
                # The old code kept that as-is, producing mixed geometry types
                # downstream; keep the largest part instead.
                if isinstance(poly, MultiPolygon):
                    if poly.is_empty:
                        continue
                    poly = max(poly.geoms, key=lambda g: g.area)

            if poly.is_valid and not poly.is_empty:
                polygons.append(poly)
                labels.append(lab)

        if return_labels:
            return polygons, labels
        return polygons


    @staticmethod
    def mirror_y0(geom):
        """Mirror a polygon geometry across the x-axis (y=0).
        
        Flips polygon coordinates vertically by negating y-values. Used to
        correct coordinate system orientation differences between image and
        spatial coordinate systems.
        
        Args:
            geom (shapely.geometry.Polygon or other): Input geometry to mirror.
        
        Returns:
            shapely.geometry: Mirrored geometry of the same type as input.
                If input is not a Polygon, returns input unchanged.
        
        Example:
            Point (x, y) becomes (x, -y)
        """
        
        return type(geom)([
            (x, -y) for x, y in geom.exterior.coords
        ]) if geom.geom_type == "Polygon" else geom


    def process_masks_to_shapes(self):
        """Filter masks, convert to polygons, and create shapes model.
        
        Applies morphological filtering to segmentation masks, converts filtered
        masks to polygon geometries, mirrors coordinates, and creates a 
        SpatialData-compatible shapes model with cell IDs.
        
        Returns:
            tuple: Contains three elements:
                - masks (np.ndarray): Filtered and relabeled segmentation masks.
                - gdf_polygons (gpd.GeoDataFrame): GeoDataFrame with cell_id and
                  geometry columns.
                - shapes_model (gpd.GeoDataFrame): SpatialData shapes model with
                  region names and geometries.
        
        Raises:
            RuntimeError: If no valid polygons are extracted from masks after
                filtering.
        
        Note:
            - Filters masks using `filter_cell_by_regionprops()`
            - Converts to polygons and upscales by `factor_rescale`
            - Mirrors y-coordinates and shifts to ensure all y >= 0
            - Sets `self.masks`, `self.gdf_polygons`, and `self.shapes_model`
        
        TODO:
            Optimize this function for better performance.
        """
        
        # Filter masks
        self.masks = self.filter_cell_by_regionprops(self.masks)

        # Convert masks → polygons
        # multispace patch: fast polygonisation, exact upscale, and cell_id
        # taken from the mask label (was list position, which drifted from the
        # label image whenever a region was dropped).
        polygons, poly_labels = self.masks_to_polygons(
            self.masks, self.factor_rescale, return_labels=True,
            scale_xy=_upscale_xy(self))

        if not polygons:
            raise RuntimeError(
                "No polygons extracted from mask — check your segmentation.")

        # Shapes
        shapes_df = gpd.GeoDataFrame({
            "geometry": polygons,
            "cell_id": [f"cell_{lab}" for lab in poly_labels]
        })
        shapes_df.set_geometry("geometry", inplace=True)
        self.shapes_model = ShapesModel.parse(
            shapes_df, transformations=_image_transforms(self.sdata.images[self.image_name]))

        # [FIX] mirror_y0 and the subsequent shift removed.
        # Cellpose masks are produced in y-down pixel space (row 0 = top of image),
        # which is the same convention as matplotlib imshow and SpatialData images.
        # Negating y-coordinates (mirror_y0) followed by a shift to positive y
        # is equivalent to a vertical mirror — causing shapes to appear at the wrong
        # vertical position when overlaid on the IF image.
        # contour[:,[1,0]] already handles (row,col)→(x,y) correctly; no further
        # coordinate manipulation is needed.

        self.gdf_polygons = self.shapes_model[["cell_id", "geometry"]]

        return self.masks, self.gdf_polygons, self.shapes_model

    # ---------------- LABELS ---------------- #

    def process_labels(self):
        """Upscale masks and create Labels2DModel.
        
        Upscales the filtered segmentation masks to the original image resolution
        and creates a SpatialData-compatible Labels2DModel for visualization and
        further analysis.
        
        Returns:
            tuple: Contains two elements:
                - masks (np.ndarray): Original filtered masks (not upscaled).
                - labels_model (sd.models.Labels2DModel): Upscaled labels model
                  with name set to `self.label_name`.
        
        Note:
            - Uses nearest-neighbor interpolation (order=0) to preserve integer labels
            - Upscales by `factor_rescale` to match original image dimensions
            - Sets `self.labels_model` attribute with specified label name
        """
        # multispace patch: upscale to exactly the image's shape (was
        # masks.shape * factor, up to factor-1 px short of the image).
        masks_upscale = _upscale_labels(self)

        self.labels_model = Labels2DModel.parse(
            data=np.squeeze(masks_upscale),
            dims=("y", "x"),
            transformations=_image_transforms(self.sdata.images[self.image_name]),
        )
        self.labels_model.name = self.label_name

        return self.masks, self.labels_model

    # ---------------- POINTS & TABLES ---------------- #

    def process_points_and_tables(self, min_qv=20):
        """Assign transcripts to the new cells and build the count matrix.

        multispace rewrite (Xenium), combining the CosMx improvements of
        reseg_2.py with the coordinate fix:

        * transcripts are mapped onto the morphology image with the SpatialData
          transforms (points -> global -> image pixels) instead of
          ``/ 0.2125`` followed by a shift by the minimum transcript x / y,
          which displaced every transcript by the tissue margin;
        * the concatenated transcripts are materialised once and re-indexed
          0..N-1 (several points elements carry duplicate index labels);
        * the spatial join keeps the first match when a transcript falls in
          overlapping polygons and is re-aligned on the index;
        * cell_id is attached positionally to that single frame, replacing the
          old merge on float x / y / z, which duplicated rows whenever two
          transcripts shared coordinates;
        * the count matrix is built sparse.

        Columns ``x_updated`` / ``y_updated`` hold image-pixel coordinates
        (used by run_proseg); the original ``x`` / ``y`` (microns) are kept.
        """
        points_dask = dd.concat(
            [self.sdata.points[x] for x in self.sdata.points.keys()],
            axis=0, ignore_index=False)
        n_partitions = points_dask.npartitions
        points_df = points_dask.compute().reset_index(drop=True)
        if min_qv is not None and 'qv' in points_df.columns:
            points_df = points_df[points_df['qv'] >= min_qv].reset_index(drop=True)

        px = _points_to_image_px(
            self.sdata.points[self.point_name], self.sdata.images[self.image_name],
            points_df[['x', 'y']].to_numpy(dtype=float))
        points_df['x_updated'] = px[:, 0]
        points_df['y_updated'] = px[:, 1]

        self.gdf_points = gpd.GeoDataFrame(
            points_df[['x', 'y', 'feature_name', 'x_updated', 'y_updated']
                      + (['z'] if 'z' in points_df.columns else [])],
            geometry=gpd.points_from_xy(x=px[:, 0], y=px[:, 1]),
            crs=self.gdf_polygons.crs)

        joined = gpd.sjoin(
            self.gdf_points,
            self.gdf_polygons[["cell_id", "geometry"]],
            how="left",
            predicate="within",
        )
        self.gdf_points["cell_id"] = _attach_join(self.gdf_points, joined)

        X, cell_ids, genes = _sparse_counts(
            self.gdf_points[["cell_id", "feature_name"]], "feature_name",
            self.gdf_polygons["cell_id"].unique())
        print(f"{len(cell_ids):,} cells x {len(genes):,} genes (nnz={X.nnz:,}); "
              f"{int(self.gdf_points['cell_id'].notna().sum()):,}/{len(self.gdf_points):,} "
              f"transcripts assigned")
        obs = pd.DataFrame({"cells": cell_ids,
                            "n_transcripts": np.asarray(X.sum(axis=1)).ravel().astype(int)},
                           index=cell_ids)
        var = pd.DataFrame({"genes": genes}, index=genes)
        self.vdata = ad.AnnData(X=X, obs=obs, var=var)
        self.clear_gpu_memory()

        points_df["cell_id"] = self.gdf_points["cell_id"].to_numpy()
        from spatialdata.transformations import get_transformation as _gt
        self._points_transforms = dict(_gt(self.sdata.points[self.point_name], get_all=True))
        self.points_model = PointsModel.parse(
            dd.from_pandas(points_df, npartitions=max(1, n_partitions)),
            feature_key='feature_name', transformations=self._points_transforms)
        return self.points_model, self.vdata
    

    def process_xenium_adata(self, gene_list_path="gene_list_10X.csv"):
        """
        Process Xenium AnnData: compute QC metrics, remove controls, add missing genes
        
        Parameters:
        -----------
        adata : AnnData
            Input AnnData object
        gene_list_path : str
            Path to reference gene list CSV
        
        Returns:
        --------
        adata : AnnData
            Processed AnnData object
        """

        # Define control keywords
        keywords = {
            'control_probe': 'NegControlProbe',
            'genomic_control': 'Intergenic_Region',
            'control_codeword': 'NegControlCodeword',
            'unassigned_codeword': 'UnassignedCodeword',
            'deprecated_codeword': 'DeprecatedCodeword'
        }

        vdata = self.new_sdata.tables['table']
        print('vdata')
        print(vdata)
        # multispace patch: METABRIC sample columns are copied only when present.
        _src_obs = self.sdata.tables['table'].obs if 'table' in self.sdata.tables else pd.DataFrame()
        cols_to_copy = [c for c in ['TMA_ID', 'core_ID', 'metabric_ID',
                        'MB_Number', 'metallomics_ID'] if c in _src_obs.columns]
        info_core = _src_obs[cols_to_copy].iloc[0] if cols_to_copy and len(_src_obs) else pd.Series(dtype=object)
        for k in info_core.index:
            vdata.uns[k] = info_core.loc[k]

        # obs['transcript_counts'] = np.array(new_sdata.tables['table'].X.sum(axis=1)).flatten()
        obs = vdata.obs

        # Filter shapes
        valid_cells = vdata.obs_names
        gdf_cells = self.new_sdata.shapes[self.shape_name].copy()
        gdf_cells_filtered = gdf_cells[gdf_cells['cell_id'].isin(valid_cells)]
        self.new_sdata.shapes[self.shape_name] = gdf_cells_filtered

        # Compute and attach cell area
        cells = self.new_sdata.shapes[self.shape_name]
        obs = vdata.obs.copy()
        obs['cell_area'] = cells.geometry.area.values
        for _k in ('TMA_ID', 'metabric_ID'):
            if _k in vdata.uns:
                obs[_k] = vdata.uns[_k]
        centroids = cells.geometry.centroid
        vdata.obsm['spatial'] = np.column_stack([centroids.x, centroids.y])

        vdata.obs = obs

        print("=" * 60)
        print("PROCESSING XENIUM ANNDATA")
        print("=" * 60)
        print(f"Original shape: {vdata.shape}")

        # 1. Compute QC metrics
        print("1. Computing QC metrics")

        for metric_name, keyword in keywords.items():
            mask = vdata.var_names.str.contains(keyword, na=False, regex=False)
            counts = np.array(vdata[:, mask].X.sum(axis=1)).flatten()
            vdata.obs[f'{metric_name}_counts'] = counts
            print(f" {metric_name}_counts: {mask.sum()} features")

        # Identify all control features
        all_control_mask = pd.Series(False, index=vdata.var_names)
        for keyword in keywords.values():
            all_control_mask |= vdata.var_names.str.contains(
                keyword, na=False, regex=False)

        # Transcript counts (non-control genes)
        transcript_mask = ~all_control_mask
        vdata.obs['transcript_counts'] = np.array(
            vdata[:, transcript_mask].X.sum(axis=1)
        ).flatten()
        print(f" transcript_counts: {transcript_mask.sum()} features")

        # Total counts
        vdata.obs['total_counts'] = np.array(vdata.X.sum(axis=1)).flatten()

        # Summary stats
        print("   QC Metrics Summary:")
        qc_cols = ['control_probe_counts', 'genomic_control_counts',
                   'control_codeword_counts', 'unassigned_codeword_counts',
                   'deprecated_codeword_counts', 'transcript_counts', 'total_counts']
        print(vdata.obs[qc_cols].describe().loc[['mean', 'std', 'min', 'max']])

        # 2. Remove control features
        print("2. Removing control features")
        print(f" Control features: {all_control_mask.sum()}")
        print(f" Regular genes: {transcript_mask.sum()}")

        vdata = vdata[:, transcript_mask].copy()
        print(f" After removal: {vdata.shape}")

        # 3. Add missing genes
        print("3. Adding missing genes from reference")

        gene_list = _load_gene_list(gene_list_path, vdata.var_names)
        print(f" Reference list: {len(gene_list)} genes")

        current_genes = set(vdata.var_names)
        missing_genes = [
            gene for gene in gene_list if gene not in current_genes]
        print(f" Missing genes: {len(missing_genes)}")

        if len(missing_genes) > 0:
            # Store original uns and other metadata
            original_uns = vdata.uns.copy()
            original_obsm = vdata.obsm.copy() if vdata.obsm.keys() else {}
            original_obsp = vdata.obsp.copy() if vdata.obsp.keys() else {}
            original_varm = vdata.varm.copy() if vdata.varm.keys() else {}
            original_varp = vdata.varp.copy() if vdata.varp.keys() else {}
            original_layers = {
                k: v for k, v in vdata.layers.items()} if vdata.layers.keys() else {}

            # Create zero matrix for missing genes
            missing_matrix = np.zeros((vdata.n_obs, len(missing_genes)))

            # Match the format of existing X matrix (sparse or dense)
            if hasattr(vdata.X, 'toarray'):  # If sparse
                missing_matrix = csr_matrix(missing_matrix)

             # Create var DataFrame matching existing structure
            missing_var = pd.DataFrame(index=missing_genes)
            # Copy column structure from existing var, fill with appropriate defaults
            for col in vdata.var.columns:
                if vdata.var[col].dtype == 'object' or vdata.var[col].dtype == 'string':
                    missing_var[col] = ''  # Empty string instead of NaN
                elif vdata.var[col].dtype == 'bool':
                    missing_var[col] = False
                else:
                    missing_var[col] = 0  # Numeric columns get 0

            missing_adata = sc.AnnData(
                X=missing_matrix,
                obs=vdata.obs.copy(),
                var=pd.DataFrame(index=missing_genes)
            )

            # Concatenate along gene axis (axis=1)
            vdata = sc.concat([vdata, missing_adata], axis=1,
                              join='outer', merge='same')

            # Clean up any remaining NaN values in var
            for col in vdata.var.columns:
                if vdata.var[col].dtype == 'object' or vdata.var[col].dtype == 'string':
                    vdata.var[col] = vdata.var[col].fillna('')
                elif vdata.var[col].dtype == 'bool':
                    vdata.var[col] = vdata.var[col].fillna(False)

            # Restore metadata
            vdata.uns = original_uns
            if original_obsm:
                vdata.obsm = original_obsm
            if original_obsp:
                vdata.obsp = original_obsp
            if original_varm:
                vdata.varm = original_varm
            if original_varp:
                vdata.varp = original_varp
            if original_layers:
                for key, value in original_layers.items():
                    # For layers, we need to add zeros for missing genes
                    if hasattr(value, 'toarray'):  # sparse
                        missing_layer = csr_matrix(
                            np.zeros((vdata.n_obs, len(missing_genes))))
                        vdata.layers[key] = sp.hstack([value, missing_layer])
                    else:  # dense
                        missing_layer = np.zeros(
                            (vdata.n_obs, len(missing_genes)))
                        vdata.layers[key] = np.hstack([value, missing_layer])

            print(f"After adding: {vdata.shape}")

        # 4. Reorder to match reference
        print("4. Reordering genes to match reference")
        genes_in_order = [
            gene for gene in gene_list if gene in vdata.var_names]

        if len(genes_in_order) != len(gene_list):
            print(
                f" WARNING: {len(gene_list) - len(genes_in_order)} genes from reference not found!")

        vdata = vdata[:, genes_in_order].copy()
        print("PROCESSING COMPLETE")
        print(f"Final shape: {vdata.shape}")
        print(f"Cells: {vdata.n_obs}")
        print(f"Genes: {vdata.n_vars}")

        self.new_sdata.tables['table'] = vdata

        return vdata
    

    def run_proseg(self, 
                   samples=1000, 
                   voxel_size=0.5, 
                   voxel_layers=2, 
                   nuclear_reassignment_prob=0.2, 
                   diffusion_probability=0.2, 
                   num_threads=12,):
        """
        Run complete Proseg refinement pipeline for Xenium spatial transcriptomics data.
        
        This method:
        1. Loads SpatialData and extracts components
        2. Runs Proseg refinement
        3. Fixes metadata and validates components
        4. Creates integrated SpatialData with original and refined data
        5. Generates visualizations and comparison statistics
        6. Exports results in multiple formats
        7. Processes final AnnData with Xenium-specific QC
        
        Returns
        -------
        tuple
            (integrated_sdata, adata_refined, comparison, output_files, exported_files)
        """
        
        # Set up logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.log = logging.getLogger(__name__)
        self.log.info("Starting Proseg Refinement Pipeline for Xenium Data")

        # Extract components from existing SpatialData (already loaded in self.new_sdata)
        self.log.info("Extracting components from SpatialData")
        sdata = self.new_sdata
        
        # Get transcripts from points
        transcripts_df = sdata.points[self.point_name].compute()

        # Define output paths
        output_path = Path("proseg_output.zarr")
        output_integrated_path = Path("integrated_proseg_output.zarr")

        # [FIX] Same resolution as the cosmx class — prefer PATH then
        # ~/.cargo/bin/proseg, fail with a useful error if neither resolves.
        import shutil
        _xenium_proseg = (
            shutil.which("proseg")
            or os.path.expanduser("~/.cargo/bin/proseg")
        )
        if not (os.path.isfile(_xenium_proseg) and os.access(_xenium_proseg, os.X_OK)):
            raise RuntimeError(
                "Could not locate the proseg binary. Install with "
                "`cargo install proseg` and ensure ~/.cargo/bin is on PATH."
            )

        # Run Proseg refinement
        self.log.info(f"Running Proseg refinement (binary: {_xenium_proseg})")
        output_path = run_proseg_refinement(
            transcripts_df=transcripts_df,
            output_path=str(output_path),
            proseg_binary=_xenium_proseg,
            x_col="x_updated",
            y_col="y_updated",
            z_col="z",
            gene_col="feature_name",
            cell_id_col="cell_id",
            samples=samples,
            voxel_size=voxel_size,
            voxel_layers=voxel_layers,
            nuclear_reassignment_prob=nuclear_reassignment_prob,
            diffusion_probability=diffusion_probability,
            num_threads=num_threads,
            overwrite=True,
            logger=self.log
        )

        # Fix metadata
        self.log.info("Fixing zarr metadata")
        fix_zarr_metadata(output_path, self.log)

        self.log.info("Fixing AnnData table")
        fix_anndata_table(output_path, self.log)

        # Load Proseg components
        self.log.info("Loading Proseg components")
        refined_shapes_gdf, adata_proseg, refined_transcripts_df = load_proseg_components(
            output_path, self.log
        )

        # Validate and parse components
        self.log.info("Validating and parsing components")
        refined_sdata, adata_sanitized, refined_shapes_parsed, instance_key = validate_and_parse_components(
            output_path, refined_shapes_gdf, adata_proseg, self.log
        )

        # Create integrated SpatialData
        self.log.info("Creating integrated SpatialData")
        integrated_sdata = create_integrated_spatialdata(
            sdata,
            output_path,
            refined_shapes_parsed,
            adata_sanitized,
            instance_key,
            transcripts_df,
            refined_transcripts_df,
            self.log
        )

        # Create visualizations
        self.log.info("Creating visualizations")
        create_visualizations(integrated_sdata, refined_shapes_gdf, self.log)

        # Generate comparison statistics
        self.log.info("Generating comparison statistics")
        generate_comparison_statistics(
            sdata, refined_sdata, integrated_sdata, self.log)

        # Export data
        self.log.info("Exporting data to various formats")
        export_data(
            refined_shapes_gdf,
            adata_proseg,
            refined_transcripts_df,
            self.log
        )
        
        print("EXPORTED!!!")
        # Reload and process final data
        self.log.info("Reloading integrated SpatialData for final processing")
        self.integrated_sdata = sd.read_zarr(output_path)

        # Process with Xenium-specific processing
        self.log.info("Processing refined AnnData with Xenium-specific QC")
        self.process_xenium_adata_proseg()

        # Save updated integrated SpatialData
        self.log.info("Saving updated integrated SpatialData")
        if output_integrated_path.exists():
            shutil.rmtree(output_integrated_path)
        self.integrated_sdata.write(output_integrated_path)

        self.log.info("Proseg Refinement Pipeline Complete!")

        return self.integrated_sdata


    def process_xenium_adata_proseg(self, gene_list_path="gene_list_10X.csv"):
        """
        Process Proseg-refined Xenium AnnData: compute QC metrics, remove controls, add missing genes.
        
        This is an adapted version of process_xenium_adata for Proseg-refined data.
        
        Parameters
        ----------
        adata : AnnData
            Input refined AnnData object from Proseg
        gene_list_path : str, optional
            Path to reference gene list CSV. Defaults to "gene_list_10X.csv".
        
        Returns
        -------
        adata : AnnData
            Processed AnnData object with QC metrics and standardized gene set
        """
        
        # Define control keywords
        keywords = {
            'control_probe': 'NegControlProbe',
            'genomic_control': 'Intergenic_Region',
            'control_codeword': 'NegControlCodeword',
            'unassigned_codeword': 'UnassignedCodeword',
            'deprecated_codeword': 'DeprecatedCodeword'
        }
        
        adata = self.integrated_sdata.tables['table_refined']
        print("PROCESSING PROSEG-REFINED XENIUM ANNDATA")
        print(f"Original shape: {adata.shape}")

        self.log.info("Copying metadata from original SpatialData")

        if 'table' in self.integrated_sdata.tables:
            info_core = self.integrated_sdata.tables['table_original'].uns.keys()
            for k in info_core:
                adata.obs[k] = self.integrated_sdata.tables['table_original'].uns[k]

        # Get cell geometries and compute spatial metrics
        self.log.info("Computing cell areas and centroids")
        
        # Note: For Proseg data, shapes are in 'cell_boundaries_refined'
        if hasattr(self, 'new_sdata') and 'cell_boundaries_refined' in self.integrated_sdata.shapes:
            cells = self.integrated_sdata.shapes['cell_boundaries_refined']

        elif self.shape_name in self.integrated_sdata.shapes:
            cells = self.integrated_sdata.shapes[self.shape_name]

        else:
            self.log.warning("No cell shapes found, skipping spatial metrics")
            cells = None
    
        if cells is not None:
            # Filter to valid cells in adata
            valid_cells = adata.obs_names.astype(int)
            cells_filtered = cells[cells.index.isin(valid_cells)]
            # Compute metrics
            adata.obs['cell_area'] = cells_filtered.geometry.area.values
            centroids = cells_filtered.geometry.centroid
            adata.obsm['spatial'] = np.column_stack([centroids.x, centroids.y])
            
        # 1. Compute QC metrics
        print("1. Computing QC metrics")

        for metric_name, keyword in keywords.items():
            mask = adata.var_names.str.contains(keyword, na=False, regex=False)
            counts = np.array(adata[:, mask].X.sum(axis=1)).flatten()
            adata.obs[f'{metric_name}_counts'] = counts
            print(f"{metric_name}_counts: {mask.sum()} features")

        # Identify all control features
        all_control_mask = pd.Series(False, index=adata.var_names)
        for keyword in keywords.values():
            all_control_mask |= adata.var_names.str.contains(
                keyword, na=False, regex=False)

        # Transcript counts (non-control genes)
        transcript_mask = ~all_control_mask
        adata.obs['transcript_counts'] = np.array(
            adata[:, transcript_mask].X.sum(axis=1)
        ).flatten()
        print(f"transcript_counts: {transcript_mask.sum()} features")

        # Total counts
        adata.obs['total_counts'] = np.array(adata.X.sum(axis=1)).flatten()

        # Summary stats
        print("QC Metrics Summary:")
        qc_cols = ['control_probe_counts', 'genomic_control_counts',
                   'control_codeword_counts', 'unassigned_codeword_counts',
                   'deprecated_codeword_counts', 'transcript_counts', 'total_counts']
        print(adata.obs[qc_cols].describe().loc[['mean', 'std', 'min', 'max']])

        # 2. Remove control features
        print("2. Removing control features")
        print(f"Control features: {all_control_mask.sum()}")
        print(f"Regular genes: {transcript_mask.sum()}")
        adata = adata[:, transcript_mask].copy()
        print(f"After removal: {adata.shape}")

        # 3. Add missing genes
        print("3. Adding missing genes from reference")
        gene_list = _load_gene_list(gene_list_path, adata.var_names)
        print(f"Reference list: {len(gene_list)} genes")
        current_genes = set(adata.var_names)
        missing_genes = [
            gene for gene in gene_list if gene not in current_genes]
        print(f"Missing genes: {len(missing_genes)}")

        if len(missing_genes) > 0:
            # Store original metadata
            original_uns = adata.uns.copy()
            original_obsm = adata.obsm.copy() if adata.obsm.keys() else {}
            original_obsp = adata.obsp.copy() if adata.obsp.keys() else {}
            original_varm = adata.varm.copy() if adata.varm.keys() else {}
            original_varp = adata.varp.copy() if adata.varp.keys() else {}
            original_layers = {
                k: v for k, v in adata.layers.items()} if adata.layers.keys() else {}

            # Create zero matrix for missing genes
            missing_matrix = np.zeros((adata.n_obs, len(missing_genes)))

            # Match the format of existing X matrix (sparse or dense)
            if hasattr(adata.X, 'toarray'):  # If sparse
                missing_matrix = csr_matrix(missing_matrix)

            # Create var DataFrame
            missing_var = pd.DataFrame(index=missing_genes)
            for col in adata.var.columns:
                if adata.var[col].dtype == 'object' or adata.var[col].dtype == 'string':
                    missing_var[col] = ''

                elif adata.var[col].dtype == 'bool':
                    missing_var[col] = False

                else:
                    missing_var[col] = 0

            missing_adata = sc.AnnData(
                X=missing_matrix,
                obs=adata.obs.copy(),
                var=missing_var
            )

            # Concatenate
            adata = ad.concat([adata, missing_adata], axis=1,
                              join='outer', merge='same')

            # Clean up NaN values
            for col in adata.var.columns:
                if adata.var[col].dtype == 'object' or adata.var[col].dtype == 'string':
                    adata.var[col] = adata.var[col].fillna('')

                elif adata.var[col].dtype == 'bool':
                    adata.var[col] = adata.var[col].fillna(False)

            # Restore metadata
            adata.uns = original_uns
            if original_obsm:
                adata.obsm = original_obsm

            if original_obsp:
                adata.obsp = original_obsp

            if original_varm:
                adata.varm = original_varm

            if original_varp:
                adata.varp = original_varp

            if original_layers:
                for key, value in original_layers.items():
                    if hasattr(value, 'toarray'):  # sparse
                        missing_layer = csr_matrix(
                            np.zeros((adata.n_obs, len(missing_genes))))
                        adata.layers[key] = sp.hstack([value, missing_layer])

                    else:  # dense
                        missing_layer = np.zeros(
                            (adata.n_obs, len(missing_genes)))
                        adata.layers[key] = np.hstack([value, missing_layer])

            print(f"After adding: {adata.shape}")

        # 4. Reorder to match reference
        print("4. Reordering genes to match reference")
        genes_in_order = [
            gene for gene in gene_list if gene in adata.var_names]

        if len(genes_in_order) != len(gene_list):
            print(
                f"WARNING: {len(gene_list) - len(genes_in_order)} genes from reference not found!")

        adata = adata[:, genes_in_order].copy()

        print("PROCESSING COMPLETE")
        print(f"Final shape: {adata.shape}")
        print(f"Cells: {adata.n_obs}")
        print(f"Genes: {adata.n_vars}")
        
        self.integrated_sdata.tables['table_refined'] = adata

        return adata

    # ---------------- SAVE ---------------- #

    def update_spatialdata(self, proseg_refinement=True):
        """Save processed SpatialData into a new Zarr file.
        
        Executes the complete processing pipeline and writes all results to a
        new SpatialData Zarr file. Creates a new SpatialData object containing
        the original image, processed labels, shapes, points, and gene expression
        table.
        
        Returns:
            sd.SpatialData: New SpatialData object containing all processed layers:
                - images: Original image from input
                - labels: Upscaled segmentation masks
                - shapes: Cell polygon geometries
                - points: Transcript coordinates with cell assignments
                - tables: AnnData gene expression matrix
        
        Note:
            - Runs full pipeline: masks→shapes, labels, points→tables
            - Creates output path: "updated_{zarr_name}" in zarr_dir
            - Overwrites existing output if present
            - Closes any active Dask client
            - Clears GPU memory and deletes intermediate variables
            - Prints progress messages for each step
        
        Pipeline Steps:
            1. process_masks_to_shapes(): Filter and convert masks to polygons
            2. process_labels(): Upscale masks to full resolution
            3. process_points_and_tables(): Assign transcripts and create expression matrix
            4. Write all data to new Zarr file
        """
        
        self.process_masks_to_shapes()
        print("Masks to shapes finished")
        self.process_labels()
        print("Labels process finished")
        self.process_points_and_tables()
        print("Points and Tables process finished")

        self.new_sdata = sd.SpatialData()
        dst_path = os.path.join(
            self.output_folder, f"updated_{self.zarr_name}")

        # Images
        img = self.sdata.images[self.image_name]
        try:
            # if dask-backed
            self.new_sdata.images[self.image_name] = img.compute()
            
        except Exception:
            # already in memory
            self.new_sdata.images[self.image_name] = img.copy()

        # Labels
        lbl = self.labels_model
        try:
            self.new_sdata.labels[self.label_name] = lbl.compute()
            
        except Exception:
            self.new_sdata.labels[self.label_name] = lbl.copy()

        # Shapes
        shp = self.shapes_model
        try:
            self.new_sdata.shapes[self.shape_name] = shp.compute()
            
        except Exception:
            self.new_sdata.shapes[self.shape_name] = shp.copy()

        # Points
        # [FIX] spatialdata's points element MUST be built with
        # PointsModel.parse(). Assigning a raw pandas DataFrame raises
        # "TypeError: Unsupported type ...DataFrame", and assigning a dask
        # DataFrame whose .attrs no longer has 'transform' (dropna/copy strip
        # it) raises "ValueError: ... does not contain 'transform'".
        # The xenium points_model already carries canonical x/y columns (set in
        # process_points_and_tables), so we re-parse WITHOUT a coordinates=
        # mapping — that keeps the x_updated/y_updated columns that run_proseg()
        # reads back by name (x_col='x_updated', y_col='y_updated').
        pts_filtered = self.points_model.dropna(subset=['cell_id'])
        transcripts_df = pts_filtered.compute()
        transcripts_df = transcripts_df[
            transcripts_df['cell_id'].notna()].reset_index(drop=True)

        self.new_sdata.points[self.point_name] = PointsModel.parse(
            transcripts_df,
            feature_key='feature_name',
            instance_key='cell_id',
            transformations=getattr(self, "_points_transforms", None),
        )

        tbl = self.vdata.copy()
        print('tbl')
        print(tbl)

        # Remove NaN columns from obs and var
        tbl.obs = tbl.obs.loc[:, tbl.obs.columns.notna()]
        tbl.var = tbl.var.loc[:, tbl.var.columns.notna()]
        # Replace NaN index values with strings (AnnData requires non-NaN unique index)
        tbl.obs = tbl.obs.map(lambda x: "NA" if pd.isna(x) else x)
        tbl.var = tbl.var.map(lambda x: "NA" if pd.isna(x) else x)

        # Ensure indices are unique (AnnData requires unique obs/var names)
        tbl.obs.index = tbl.obs.index.map(
            lambda x: str(x) if pd.notna(x) else "unknown_obs")
        tbl.var.index = tbl.var.index.map(
            lambda x: str(x) if pd.notna(x) else "unknown_var")

        if not tbl.obs.index.is_unique:
            tbl.obs.index = pd.Index(
                [f"cell_{i}" for i in range(len(tbl.obs))])
            
        if not tbl.var.index.is_unique:
            tbl.var.index = pd.Index(
                [f"gene_{i}" for i in range(len(tbl.var))])

        self.new_sdata.tables['table'] = tbl

        self.process_xenium_adata()

        if proseg_refinement == True:
            self.run_proseg()

        print("updated_data")

        try:
            client = Client.current()
            client.close()
            
        except ValueError:
            pass

        # Todo: update the following line when compatibility of spatialdata 0.6 ok
        # with other package. It will allow update_sdata_path argument to bypass
        # not self-contained issue when saving
        # new_sdata.write(dst_path, overwrite=True, update_sdata_path=False)
        self.new_sdata.write(dst_path, overwrite=True)
        print("Data saved")

        for var in (self.masks, self.flows, self.styles,
                    self.gdf_points, self.gdf_polygons):
            try:
                del var
            except Exception:
                pass
        self.clear_gpu_memory()

        return self.new_sdata
