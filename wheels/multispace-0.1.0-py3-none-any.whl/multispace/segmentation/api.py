"""Module 2 — resegmentation (Cellpose, optional Proseg refinement).

The tested platform implementations are kept as they are in
:mod:`multispace.segmentation._legacy` (``Resegmentation_xenium``,
``Resegmentation_cosmx`` and the Atera ``SeamStitchPipeline``) and driven
through one entry point, :func:`resegment`. The wrapper:

* runs the legacy class in an isolated working directory (the legacy code
  writes ``updated_*`` folders and proseg outputs relative to the current
  directory);
* reads its output back and merges it into the pipeline object under the
  contract names: ``labels['cell_labels_reseg']``,
  ``shapes['cell_boundaries_reseg']`` and the new ``tables['table']`` (the
  previous table is kept as ``tables['table_original']``);
* restores the working directory and torch device settings afterwards.
"""
from __future__ import annotations

import contextlib
import logging
import os
from collections.abc import Sequence
from pathlib import Path
from typing import Literal

import numpy as np
import pandas as pd

from .._sdata import ContractError, get_meta, record_step, replace_table, require
from ..constants import Attrs, Keys, Platform

logger = logging.getLogger(__name__)

__all__ = ["resegment", "resegment_atera", "check_atera_origin"]

#: Default channel layout per platform (positional names used by the legacy code).
DEFAULT_CHANNELS = {
    Platform.COSMX: dict(channel_names=["B", "G", "Y", "R", "U"], channels_to_use=["Y", "U"]),
    Platform.XENIUM: dict(channel_names=None, channels_to_use=None),
}


@contextlib.contextmanager
def _in_dir(path: Path):
    prev = Path.cwd()
    path.mkdir(parents=True, exist_ok=True)
    os.chdir(path)
    try:
        yield path
    finally:
        os.chdir(prev)


@contextlib.contextmanager
def _torch_device(device: str):
    """Force CPU (the legacy workflow monkey-patched MPS away on Apple Silicon)."""
    if device != "cpu":
        yield
        return
    torch = require("torch", "seg")
    mps = torch.backends.mps
    saved = (mps.is_available, mps.is_built)
    os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
    mps.is_available = lambda: False  # type: ignore[assignment]
    mps.is_built = lambda: False  # type: ignore[assignment]
    try:
        torch.set_default_device("cpu")
        yield
    finally:
        mps.is_available, mps.is_built = saved


def _channel_names(sdata, image: str) -> list[str]:
    el = sdata.images[image]
    try:
        da_ = el["scale0"].ds["image"]
    except (KeyError, TypeError):
        da_ = el
    return [str(c) for c in da_.coords["c"].values]


def resegment(
    sdata,
    *,
    zarr_path: str | Path,
    platform: str | None = None,
    workdir: str | Path | None = None,
    image: str = Keys.MORPHOLOGY,
    points: str = Keys.TRANSCRIPTS,
    channel_names: Sequence[str] | None = None,
    channels_to_use: Sequence[str] | None = None,
    factor_rescale: int = 4,
    cellpose: dict | None = None,
    proseg: bool | dict = False,
    gene_list_path: str | Path | None = None,
    cell_filter: dict | None = None,
    preprocess: dict | None = None,
    orientation: str = "check",
    device: Literal["auto", "cpu"] = "auto",
):
    """Re-segment cells and replace the active table.

    Parameters
    ----------
    sdata
        Pipeline SpatialData (updated in place and returned).
    zarr_path
        On-disk copy of ``sdata`` that the legacy code reads (the pipeline
        writes a checkpoint before this step).
    platform
        ``"xenium"`` or ``"cosmx"``; defaults to the platform recorded at import.
        For ``"atera"`` use :func:`resegment_atera`.
    channel_names, channels_to_use
        Image channel names and the [membrane/cytoplasm, nucleus] pair given to
        Cellpose. Defaults: CosMx ``B,G,Y,R,U`` → ``Y,U``; Xenium → the image's
        own channel names, first two channels.
    factor_rescale
        Segmentation runs on the image downscaled by this factor.
    cellpose
        kwargs for ``run_cellpose`` (``model_type``, ``gpu``, ``diameter``,
        ``flow_threshold``, ``cellprob_threshold``, ``tile_overlap``).
    proseg
        ``True`` or a dict of ``run_proseg`` kwargs to refine boundaries with
        Proseg (requires the ``proseg`` binary on PATH).
    gene_list_path
        Optional reference gene list (CSV with ``gene_name``) to pad/reorder genes.
    cell_filter
        Options for the morphological cell filter applied after Cellpose
        (``filter_cell_by_regionprops``), e.g. ``{"min_absolute_area": 30,
        "max_convexity_deficit": 0.30}`` (the TRIBUTE/HPC settings). Defaults:
        CosMx 50 / 0.20; Xenium 100 / none.
    preprocess
        Extra options for ``preprocess_image``. CosMx: ``lower_percentile``,
        ``upper_percentile``, ``per_channel``, ``gamma``, ``clahe``,
        ``clahe_clip_limit``, ``clahe_tile_grid_size`` (CLAHE needs opencv).
    orientation
        CosMx only. ``"check"`` (default): transcripts are mapped with the
        exact inverse of the stitched image transform; the flip test runs as a
        diagnostic and only warns. ``"auto"``: old behaviour (apply the best
        flip). ``"as-is"``: skip the test.
    device
        ``"cpu"`` forces CPU torch (Apple Silicon MPS workaround).
    """
    import spatialdata as sd

    platform = (platform or get_meta(sdata).get(Attrs.PLATFORM) or "").lower()
    if platform == Platform.ATERA:
        raise ValueError("Atera uses the seam-stitch workflow: call resegment_atera(sdata, config_path=...).")
    if platform not in (Platform.XENIUM, Platform.COSMX):
        raise ValueError(f"Resegmentation supports 'xenium' and 'cosmx' (got '{platform}').")
    if image not in sdata.images or points not in sdata.points:
        raise ContractError(f"Resegmentation needs images['{image}'] and points['{points}'].")

    zarr_path = Path(zarr_path).resolve()
    if not zarr_path.exists():
        raise FileNotFoundError(f"{zarr_path} does not exist; write the SpatialData to disk first.")
    workdir = Path(workdir or zarr_path.parent / "work" / "resegmentation").resolve()

    defaults = DEFAULT_CHANNELS[platform]
    channel_names = list(channel_names or defaults["channel_names"] or _channel_names(sdata, image))
    channels_to_use = list(channels_to_use or defaults["channels_to_use"] or channel_names[:2])

    from ._legacy import reseg as legacy  # heavy: cellpose, torch

    base = legacy.Resegmentation_cosmx if platform == Platform.COSMX else legacy.Resegmentation_xenium
    cls = _configured(base, gene_list_path, proseg if isinstance(proseg, dict) else {}, cell_filter or {},
                      orientation if platform == Platform.COSMX else None)
    use_proseg = bool(proseg)
    with _torch_device(device), _in_dir(workdir):
        # the legacy classes read <zarr_dir>/<zarr_name> and write updated_<zarr_dir>/
        link_dir = Path("input")
        link_dir.mkdir(exist_ok=True)
        link = link_dir / zarr_path.name
        if link.is_symlink() or link.exists():
            link.unlink()
        link.symlink_to(zarr_path, target_is_directory=True)

        runner = cls(
            zarr_dir=str(link_dir), zarr_name=zarr_path.name, output="segmentation_input.png",
            factor_rescale=factor_rescale, image_name=image, label_name=Keys.CELL_LABELS_RESEG,
            shape_name=Keys.CELL_BOUNDARIES_RESEG, point_name=points,
        )
        runner.preprocess_image(channel_names=channel_names, channels_to_use=channels_to_use,
                                **(preprocess or {}))
        runner.run_cellpose(**(cellpose or {}))
        runner.update_spatialdata(proseg_refinement=use_proseg)

        out_zarr = workdir / f"updated_{link_dir}" / f"updated_{zarr_path.name}"
        result = sd.read_zarr(str(out_zarr))
        refined = sd.read_zarr(str(workdir / "integrated_proseg_output.zarr")) if use_proseg else None

    _merge_result(sdata, result, refined)
    record_step(sdata, "resegmentation", {
        "platform": platform, "factor_rescale": factor_rescale, "channels_to_use": channels_to_use,
        "cellpose": cellpose or {}, "proseg": proseg, "cell_filter": cell_filter or {},
        "preprocess": preprocess or {}, "orientation": orientation if platform == Platform.COSMX else None,
        "workdir": str(workdir)})
    return sdata


def _configured(base, gene_list_path, proseg_kwargs: dict, cell_filter: dict | None = None,
                orientation: str | None = None):
    """Subclass of a legacy class that passes our options to the calls the
    legacy code makes without arguments (gene list, proseg settings, cell filter)."""
    import inspect

    cell_filter = dict(cell_filter or {})
    if cell_filter:
        fvalid = set(inspect.signature(base.filter_cell_by_regionprops).parameters) - {"seg_masks", "self"}
        bad = set(cell_filter) - fvalid
        if bad:
            raise TypeError(f"Unknown cell_filter options {sorted(bad)}; valid: {sorted(fvalid)}")

    gl = str(gene_list_path) if gene_list_path else None
    valid = set(inspect.signature(base.run_proseg).parameters) - {"self"}
    unknown = set(proseg_kwargs) - valid
    if unknown:
        raise TypeError(f"Unknown proseg options {sorted(unknown)}; valid: {sorted(valid)}")
    ns = {"run_proseg": lambda self, **kw: base.run_proseg(self, **{**proseg_kwargs, **kw})}
    for name in ("process_cosmx_adata", "process_cosmx_adata_proseg",
                 "process_xenium_adata", "process_xenium_adata_proseg"):
        if hasattr(base, name):
            ns[name] = (lambda n: lambda self, gene_list_path=gl: getattr(base, n)(self, gene_list_path))(name)
    if orientation is not None and "orient" in inspect.signature(base.process_points_and_tables).parameters:
        ns["process_points_and_tables"] = lambda self, **kw: base.process_points_and_tables(
            self, **{"orient": orientation, **kw})
    if cell_filter:
        ns["filter_cell_by_regionprops"] = staticmethod(
            lambda seg_masks, **kw: base.filter_cell_by_regionprops(seg_masks, **{**cell_filter, **kw}))
    return type(f"Configured{base.__name__}", (base,), ns)


def _merge_result(sdata, result, refined=None) -> None:
    """Copy resegmentation outputs into the pipeline object (contract names)."""
    from spatialdata.models import TableModel

    if Keys.CELL_LABELS_RESEG in result.labels:
        sdata.labels[Keys.CELL_LABELS_RESEG] = result.labels[Keys.CELL_LABELS_RESEG]
    shapes = result.shapes[Keys.CELL_BOUNDARIES_RESEG]
    table = result.tables[Keys.TABLE]
    if refined is not None and "table_refined" in refined.tables:
        table = refined.tables["table_refined"]
        if "cell_boundaries_refined" in refined.shapes:
            shapes = refined.shapes["cell_boundaries_refined"]
    table = table.copy()
    # The legacy code keeps cell ids in a 'cell_id' column and a positional
    # index on the shapes; index the shapes by cell id (as the Xenium reader
    # does) so table rows and geometries join.
    if "cell_id" in getattr(shapes, "columns", []):
        ids = shapes["cell_id"].astype(str)
        if ids.is_unique and not shapes.index.astype(str).equals(pd.Index(ids)):
            import geopandas as gpd
            from spatialdata.models import ShapesModel
            from spatialdata.transformations import get_transformation

            transforms = get_transformation(shapes, get_all=True)
            gdf = gpd.GeoDataFrame(shapes.drop(columns="geometry"), geometry=shapes.geometry.values)
            gdf.index = pd.Index(ids.to_numpy(), name=None)
            gdf.attrs = {}
            shapes = ShapesModel.parse(gdf, transformations=transforms)
    sdata.shapes[Keys.CELL_BOUNDARIES_RESEG] = shapes

    # Annotate the new shapes so spatialdata joins / plots work.
    attrs = table.uns.get("spatialdata_attrs", {})
    instance_key = attrs.get("instance_key") or ("cell_id" if "cell_id" in table.obs else None)
    if instance_key is None:
        table.obs["cell_id"] = table.obs_names.astype(str)
        instance_key = "cell_id"
    table.obs[instance_key] = table.obs[instance_key].astype(str)
    table.uns.pop("spatialdata_attrs", None)
    table.obs["region"] = Keys.CELL_BOUNDARIES_RESEG
    table.obs["region"] = table.obs["region"].astype("category")
    table = TableModel.parse(table, region=Keys.CELL_BOUNDARIES_RESEG, region_key="region",
                             instance_key=instance_key)
    replace_table(sdata, table)


def resegment_atera(sdata, *, config_path: str | Path, phases: str = "all"):
    """Run the Atera whole-slide seam-stitch workflow and merge its output.

    ``config_path`` is the YAML read by ``SeamStitchPipeline`` (paths, ROI grid,
    Cellpose / lattice / proseg parameters). ``phases="all"`` runs every phase in
    this process; on HPC run the phases as separate jobs
    (``python -m multispace.segmentation._legacy.seam_stitch <phase>``) and call
    this with ``phases="none"`` to only merge the finished output.
    """
    import spatialdata as sd

    from ._legacy.seam_stitch import SeamStitchPipeline

    pipe = SeamStitchPipeline(str(config_path))
    check_atera_origin(pipe.xenium_zarr, pixel_size_um=pipe.pixel_size_um, image=pipe.image_name)
    if phases == "all":
        pipe.run_all()
    elif phases != "none":
        raise ValueError("phases must be 'all' or 'none'")
    done = sd.read_zarr(pipe.merged_complete_zarr)
    renamed = sd.SpatialData(
        labels={Keys.CELL_LABELS_RESEG: done.labels["cell_labels_merged"]},
        shapes={Keys.CELL_BOUNDARIES_RESEG: done.shapes.get("cell_boundaries_filtered",
                                                            done.shapes["cell_boundaries_merged"])},
        tables={Keys.TABLE: done.tables["table"]},
    )
    _merge_result(sdata, renamed)
    record_step(sdata, "resegmentation", {"platform": Platform.ATERA, "config": str(config_path)})
    return sdata


def check_atera_origin(zarr_path, *, pixel_size_um: float = 0.2125, image: str = Keys.MORPHOLOGY,
                       points: str = Keys.TRANSCRIPTS, n: int = 2000, tol_px: float = 1.0):
    """Guard for the Atera seam-stitch workflow.

    SeamStitchPipeline places transcripts on the label image with
    ``x_um / DS_UM - tile_origin``, i.e. it assumes transcript microns and the
    morphology image share the same origin and pixel size. This compares that
    assumption with the SpatialData transforms on a sample of transcripts and
    raises if they disagree by more than ``tol_px`` pixels (e.g. an image
    carrying a translation into ``global`` that the transcripts do not share).
    """
    import spatialdata as sd

    from ._legacy.reseg import _points_to_image_px

    s = sd.read_zarr(str(zarr_path), selection=("images", "points"))
    if image not in s.images or points not in s.points:
        logger.warning("Atera origin check skipped: '%s' or '%s' not in %s", image, points, zarr_path)
        return None
    sample = s.points[points][["x", "y"]].head(n)
    xy = sample.to_numpy(dtype=float)
    exact = _points_to_image_px(s.points[points], s.images[image], xy)
    assumed = xy / pixel_size_um
    err = float(np.abs(exact - assumed).max()) if len(xy) else 0.0
    if err > tol_px:
        raise ValueError(
            f"Atera origin check failed: transcripts placed as x/{pixel_size_um} would be off by up to "
            f"{err:.1f} px from where the SpatialData transforms put them (image/points transforms differ, "
            f"e.g. a translation on the image). The seam-stitch pipeline would mis-assign transcripts.")
    logger.info("Atera origin check OK (max deviation %.3f px)", err)
    return err
