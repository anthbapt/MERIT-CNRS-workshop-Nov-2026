"""Module 8 — visualisation across modules (one figure per step, saved by the pipeline)."""
from .overview import plot_cells, plot_regions, plot_registration, plot_segmentation, save_overview

__all__ = ["plot_registration", "plot_cells", "plot_segmentation", "plot_regions", "save_overview"]
