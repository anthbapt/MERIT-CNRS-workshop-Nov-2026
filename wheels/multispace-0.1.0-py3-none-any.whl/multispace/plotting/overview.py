"""Module 8 — visualisation of every step on the shared SpatialData.

All functions return a matplotlib Figure (no ``plt.show``) so they work in
notebooks and in the pipeline, which saves them with :func:`save_overview`.
Module-specific diagnostics stay in their packages
(:mod:`multispace.celltyping.plotting`, :mod:`multispace.analysis.spatial_features.plotting`).
"""
from __future__ import annotations

import logging
from pathlib import Path

import numpy as np

from .._sdata import ensure_spatial, get_meta
from ..constants import Attrs, Keys, Obs

logger = logging.getLogger(__name__)

__all__ = ["plot_registration", "plot_cells", "plot_segmentation", "plot_regions", "save_overview"]


def _plt():
    import matplotlib.pyplot as plt

    return plt


def _norm(img):
    lo, hi = np.nanpercentile(img, (1, 99.5))
    return np.clip((img - lo) / (hi - lo + 1e-12), 0, 1)


def _scatter(ax, xy, values, *, categorical: bool, s: float, title: str, cmap="viridis"):
    plt = _plt()
    ok = np.isfinite(xy).all(1)
    xy, values = xy[ok], np.asarray(values)[ok]
    if categorical:
        cats = sorted(set(map(str, values)))
        colors = plt.get_cmap("tab20" if len(cats) > 10 else "tab10")
        for i, c in enumerate(cats):
            m = values.astype(str) == c
            ax.scatter(xy[m, 0], xy[m, 1], s=s, color=colors(i % colors.N), label=c, linewidths=0)
        ax.legend(markerscale=max(1, 12 / max(s, 0.1)), fontsize=7, frameon=False, loc="center left",
                  bbox_to_anchor=(1.0, 0.5))
    else:
        sc = ax.scatter(xy[:, 0], xy[:, 1], c=values.astype(float), s=s, cmap=cmap, linewidths=0)
        ax.figure.colorbar(sc, ax=ax, shrink=0.6)
    ax.set_aspect("equal")
    ax.invert_yaxis()
    ax.set_title(title)
    ax.set_xticks([])
    ax.set_yticks([])


def plot_cells(sdata, color: str = Obs.CELL_TYPE, *, table: str = Keys.TABLE, s: float = 1.0, ax=None):
    """Cell centroids in ``global`` coloured by an obs column (categorical or numeric)."""
    plt = _plt()
    adata = sdata.tables[table]
    xy = ensure_spatial(sdata, table)
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 6))
    vals = adata.obs[color]
    categorical = not np.issubdtype(np.asarray(vals).dtype, np.number) or vals.dtype.name == "category"
    _scatter(ax, xy, vals.to_numpy(), categorical=categorical, s=s, title=color)
    return ax.figure


def plot_registration(sdata, moving: str, fixed: str = Keys.MORPHOLOGY, *, max_side: int = 1500,
                      fixed_channel=0, moving_channel=None, ax=None):
    """Magenta (moving, registered) / green (fixed) overlay in the fixed image frame."""
    from skimage.transform import AffineTransform, warp

    from ..registration.api import _to_global_matrix, working_array

    plt = _plt()
    modality = get_meta(sdata).get("images", {}).get(moving, {}).get("modality")
    f_ws, (ffy, ffx) = working_array(sdata.images[fixed], max_side, channels=fixed_channel)
    m_ws, (mfy, mfx) = working_array(sdata.images[moving], max_side, channels=moving_channel,
                                     rgb_to_gray=modality == "he", invert=modality == "he")
    T_f = _to_global_matrix(sdata.images[fixed], Keys.COORDINATE_SYSTEM) @ np.diag([ffx, ffy, 1])
    T_m = _to_global_matrix(sdata.images[moving], Keys.COORDINATE_SYSTEM) @ np.diag([mfx, mfy, 1])
    m_to_f = np.linalg.inv(T_f) @ T_m  # moving working px → fixed working px
    warped = warp(m_ws, AffineTransform(matrix=m_to_f).inverse, output_shape=f_ws.shape, order=1, cval=0)
    rgb = np.dstack([_norm(warped), _norm(f_ws), _norm(warped)])
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 7))
    ax.imshow(rgb)
    rec = get_meta(sdata).get(Attrs.REGISTRATION, {}).get(moving, {})
    ax.set_title(f"{moving} (magenta) on {fixed} (green) — {rec.get('method', 'unregistered')}")
    ax.set_axis_off()
    return ax.figure


def plot_segmentation(sdata, shapes: str = Keys.CELL_BOUNDARIES_RESEG, *, image: str | None = Keys.MORPHOLOGY,
                      bbox: tuple[float, float, float, float] | None = None, max_cells: int = 20000, ax=None):
    """Cell outlines in ``global`` (optionally over the morphology image).

    ``bbox = (xmin, ymin, xmax, ymax)`` in global units zooms into a window.
    """
    from spatialdata import transform

    plt = _plt()
    gdf = transform(sdata.shapes[shapes], to_coordinate_system=Keys.COORDINATE_SYSTEM)
    if bbox is not None:
        gdf = gdf.cx[bbox[0]:bbox[2], bbox[1]:bbox[3]]
    if len(gdf) > max_cells:
        gdf = gdf.sample(max_cells, random_state=0)
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 7))
    if image is not None and image in sdata.images:
        _draw_image(ax, sdata, image, bbox)
    gdf.boundary.plot(ax=ax, linewidth=0.3, color="#ff4f9a")
    ax.set_aspect("equal")
    if bbox is not None:
        ax.set_xlim(bbox[0], bbox[2])
        ax.set_ylim(bbox[3], bbox[1])
    elif not ax.yaxis_inverted():
        ax.invert_yaxis()
    ax.set_title(f"{shapes} ({len(sdata.shapes[shapes])} cells)")
    ax.set_axis_off()
    return ax.figure


def _draw_image(ax, sdata, image, bbox=None, max_side=2000):
    from ..registration.api import _to_global_matrix, working_array

    img, (fy, fx) = working_array(sdata.images[image], max_side, channels=0)
    T = _to_global_matrix(sdata.images[image], Keys.COORDINATE_SYSTEM) @ np.diag([fx, fy, 1])
    if abs(T[0, 1]) > 1e-9 or abs(T[1, 0]) > 1e-9:
        logger.info("Image '%s' is rotated/sheared in global; background skipped.", image)
        return
    h, w = img.shape
    x0, y0 = T[0, 2], T[1, 2]
    x1, y1 = x0 + T[0, 0] * w, y0 + T[1, 1] * h
    ax.imshow(_norm(img), cmap="gray", extent=(x0, x1, y1, y0))


def plot_regions(sdata, regions: str = Keys.REGIONS, *, table: str = Keys.TABLE, s: float = 1.0, ax=None):
    """Region polygons with cells coloured by their assigned tissue region."""
    from spatialdata import transform

    plt = _plt()
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 6))
    adata = sdata.tables[table]
    if Obs.TISSUE_REGION in adata.obs:
        _scatter(ax, ensure_spatial(sdata, table), adata.obs[Obs.TISSUE_REGION].to_numpy(),
                 categorical=True, s=s, title=Obs.TISSUE_REGION)
    gdf = transform(sdata.shapes[regions], to_coordinate_system=Keys.COORDINATE_SYSTEM)
    gdf.boundary.plot(ax=ax, color="black", linewidth=0.8)
    ax.set_aspect("equal")
    if not ax.yaxis_inverted():
        ax.invert_yaxis()
    return ax.figure


def save_overview(sdata, out_dir: str | Path, *, dpi: int = 150) -> dict[str, Path]:
    """Save every overview figure the object's current state allows."""
    import matplotlib

    matplotlib.use("Agg", force=False)
    plt = _plt()
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    jobs = []
    for name in get_meta(sdata).get(Attrs.REGISTRATION, {}):
        if name in sdata.images:
            fixed = get_meta(sdata)[Attrs.REGISTRATION][name].get("fixed", Keys.MORPHOLOGY)
            jobs.append((f"registration_{name}", lambda n=name, f=fixed: plot_registration(sdata, n, f)))
    if Keys.CELL_BOUNDARIES_RESEG in sdata.shapes:
        jobs.append(("segmentation", lambda: plot_segmentation(sdata)))
    if Keys.REGIONS in sdata.shapes:
        jobs.append(("regions", lambda: plot_regions(sdata)))
    table = sdata.tables.get(Keys.TABLE)
    if table is not None:
        for col in (Obs.CELL_TYPE, Obs.CNV_SCORE, Obs.CNV_CLUSTER, "niche"):
            if col in table.obs:
                jobs.append((f"cells_{col}", lambda c=col: plot_cells(sdata, c)))
    saved = {}
    for name, make in jobs:
        try:
            fig = make()
            path = out_dir / f"{name}.png"
            fig.savefig(path, dpi=dpi, bbox_inches="tight")
            plt.close(fig)
            saved[name] = path
        except Exception as err:
            logger.warning("Figure '%s' failed: %s", name, err)
    return saved
