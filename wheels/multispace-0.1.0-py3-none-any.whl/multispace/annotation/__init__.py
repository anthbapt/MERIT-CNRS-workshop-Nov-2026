"""Module 5 — tissue region annotation on H&E / IF and transfer to cells."""
from .regions import add_regions, assign_regions, read_regions, regions_from_mask

__all__ = ["read_regions", "regions_from_mask", "add_regions", "assign_regions"]
