"""Module 5 — tissue region annotation (tumour, stroma, ...) from H&E / IF.

First version: regions are drawn elsewhere (QuPath, napari, a classifier) and
imported here, then transferred to cells.

* :func:`read_regions` — QuPath / any GeoJSON → ``shapes['regions']``.
* :func:`regions_from_mask` — integer mask (array or labels element) → polygons.
* :func:`assign_regions` — label each cell with the region containing its
  centroid (``obs['tissue_region']``) and its signed distance to the nearest
  region border (negative inside).

Polygons drawn on a registered image (e.g. H&E in its own pixel space) take
that image's transforms, so they land in ``global`` correctly.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

import numpy as np
import pandas as pd

from .._sdata import ContractError, ensure_spatial, get_table, record_step
from ..constants import Keys, Obs

logger = logging.getLogger(__name__)

__all__ = ["read_regions", "regions_from_mask", "add_regions", "assign_regions"]

#: Property names searched (in order) for a region's class in GeoJSON features.
_LABEL_FIELDS = ("classification", "class", "label", "name", "objectType")


def _feature_label(props: dict) -> str:
    for key in _LABEL_FIELDS:
        val = props.get(key)
        if isinstance(val, dict):  # QuPath: {"name": "Tumor", "color": [...]}
            val = val.get("name")
        if isinstance(val, str) and val:
            return val
    return "region"


def read_regions(path: str | Path, *, label_field: str | None = None):
    """Read region polygons from GeoJSON (QuPath export works as-is).

    Returns a GeoDataFrame with ``name`` (region class) and ``geometry``.
    Points/lines are dropped; multipolygons are kept.
    """
    import geopandas as gpd
    from shapely.geometry import shape

    data = json.loads(Path(path).read_text())
    feats = data["features"] if data.get("type") == "FeatureCollection" else (
        data if isinstance(data, list) else [data])
    rows = []
    for f in feats:
        geom = shape(f["geometry"])
        if geom.geom_type not in ("Polygon", "MultiPolygon") or geom.is_empty:
            continue
        props = f.get("properties") or {}
        name = props.get(label_field) if label_field else _feature_label(props)
        if isinstance(name, dict):
            name = name.get("name")
        rows.append({"name": str(name), "geometry": geom.buffer(0) if not geom.is_valid else geom})
    if not rows:
        raise ValueError(f"No polygon features in {path}.")
    return gpd.GeoDataFrame(rows, geometry="geometry")


def regions_from_mask(mask, names: dict[int, str] | None = None):
    """Polygons from an integer mask (0 = background) or a labels element."""
    import geopandas as gpd
    from shapely.geometry import shape

    from .._sdata import require

    rfeatures = require("rasterio.features", "annotation")

    arr = np.asarray(mask.data.compute() if hasattr(mask, "data") and hasattr(mask.data, "compute") else mask)
    arr = arr.astype(np.int32)
    rows = []
    for geom, val in rfeatures.shapes(arr, mask=arr > 0):
        rows.append({"value": int(val), "geometry": shape(geom)})
    gdf = gpd.GeoDataFrame(rows, geometry="geometry").dissolve(by="value", as_index=False)
    gdf["name"] = gdf["value"].map(lambda v: (names or {}).get(v, f"region_{v}"))
    return gdf[["name", "geometry"]]


def add_regions(sdata, regions, *, name: str = Keys.REGIONS, drawn_on: str | None = None,
                overwrite: bool = True):
    """Store region polygons as ``sdata.shapes[name]``.

    Parameters
    ----------
    regions
        GeoDataFrame (from :func:`read_regions` / :func:`regions_from_mask`) or a
        path to a GeoJSON file.
    drawn_on
        Image the polygons were drawn on (their coordinates are that image's
        pixels). They inherit its transforms, so a registered H&E annotation
        lands in ``global``. ``None`` = coordinates already in ``global``.
    """
    from spatialdata.models import ShapesModel
    from spatialdata.transformations import Identity, get_transformation

    if isinstance(regions, (str, Path)):
        regions = read_regions(regions)
    if name in sdata.shapes and not overwrite:
        raise ValueError(f"shapes['{name}'] exists")
    if drawn_on is None:
        transforms = {Keys.COORDINATE_SYSTEM: Identity()}
    else:
        if drawn_on not in sdata.images:
            raise ContractError(f"No image '{drawn_on}' to take the region transform from.")
        transforms = dict(get_transformation(sdata.images[drawn_on], get_all=True))
        if Keys.COORDINATE_SYSTEM not in transforms:
            logger.warning("Image '%s' is not registered to '%s' yet; register it before assign_regions().",
                           drawn_on, Keys.COORDINATE_SYSTEM)
    gdf = regions.reset_index(drop=True)
    sdata.shapes[name] = ShapesModel.parse(gdf, transformations=transforms)
    record_step(sdata, f"add_regions:{name}", {"drawn_on": drawn_on, "n_regions": len(gdf),
                                              "classes": sorted(map(str, gdf["name"].unique()))})
    return sdata


def assign_regions(sdata, *, regions: str = Keys.REGIONS, table: str = Keys.TABLE,
                   column: str = Obs.TISSUE_REGION, outside: str = "outside",
                   distance_to: str | list[str] | None = None):
    """Label each cell with the region that contains its centroid.

    Overlaps resolve to the smallest containing polygon (e.g. a tumour bud
    drawn inside a stroma area). Also writes ``tissue_region_border_distance``:
    distance (global units) from each cell to the border of the regions named
    in ``distance_to`` (default: all regions), negative inside them.
    """
    import geopandas as gpd
    from spatialdata import transform

    if regions not in sdata.shapes:
        raise ContractError(f"No shapes['{regions}']; run add_regions() first.")
    poly = transform(sdata.shapes[regions], to_coordinate_system=Keys.COORDINATE_SYSTEM)
    poly = gpd.GeoDataFrame(poly[["name", "geometry"]].copy(), geometry="geometry")
    poly["_area"] = poly.area

    adata = get_table(sdata, table)
    xy = ensure_spatial(sdata, table)
    cells = gpd.GeoDataFrame({"_i": np.arange(len(xy))}, geometry=gpd.points_from_xy(xy[:, 0], xy[:, 1]))
    hit = gpd.sjoin(cells, poly, how="left", predicate="within")
    hit = hit.sort_values("_area").drop_duplicates("_i").sort_values("_i")
    labels = hit["name"].fillna(outside).to_numpy()
    cats = sorted(set(poly["name"])) + ([outside] if outside not in set(poly["name"]) else [])
    adata.obs[column] = pd.Categorical(labels, categories=cats)

    sel = poly if distance_to is None else poly[poly["name"].isin([distance_to] if isinstance(distance_to, str) else distance_to)]
    if len(sel):
        union = sel.union_all() if hasattr(sel, "union_all") else sel.unary_union
        border = union.boundary
        d = cells.geometry.distance(border).to_numpy()
        inside = cells.geometry.within(union).to_numpy()
        adata.obs[Obs.DIST_TO_REGION_BORDER] = np.where(inside, -d, d)
    counts = adata.obs[column].value_counts().to_dict()
    record_step(sdata, "assign_regions", {"regions": regions, "column": column}, counts=counts)
    return sdata
