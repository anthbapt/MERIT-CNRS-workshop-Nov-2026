"""Module 7 — spatial analysis (whole image, per region or per grid tile).

``run_spatial_analysis`` is the pipeline entry point. The full notebook port
lives in :mod:`multispace.analysis.spatial_features` (``pip install 'multispace[analysis]'``).
"""
from .api import DEFAULT_SECTIONS, SECTIONS, add_grid, pseudobulk, run_spatial_analysis

__all__ = ["run_spatial_analysis", "add_grid", "pseudobulk", "SECTIONS", "DEFAULT_SECTIONS"]
