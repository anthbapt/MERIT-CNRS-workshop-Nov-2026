"""Topographical Correlation Map (TCM) — spatially-resolved cross-PCF."""
from __future__ import annotations

import numpy as np
from matplotlib.path import Path
from scipy.ndimage import gaussian_filter
from scipy.spatial import cKDTree

from .. import config


def topographical_correlation_map(A: np.ndarray, B: np.ndarray, roi_poly,
                                  radius_of_interest: float = config.TCM_RADIUS,
                                  kernel_sigma: float = 60.0,
                                  mesh_step: float = 15.0,
                                  max_corr_threshold: float = 5.0) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute the TCM between A (source) and B (target) populations."""
    bounds = roi_poly.bounds
    xs = np.arange(bounds[0], bounds[2] + mesh_step, mesh_step)
    ys = np.arange(bounds[1], bounds[3] + mesh_step, mesh_step)
    xx, yy = np.meshgrid(xs, ys)
    mesh = np.column_stack([xx.ravel(), yy.ravel()])

    roi_path = Path(np.array(roi_poly.exterior.coords))
    inside = roi_path.contains_points(mesh)

    area = roi_poly.area
    lam_B = len(B) / area
    expect = lam_B * np.pi * radius_of_interest ** 2

    tree_A = cKDTree(A)
    tree_B = cKDTree(B)
    counts_A = tree_A.query_ball_point(mesh, radius_of_interest, return_length=True).astype(float)
    counts_B = tree_B.query_ball_point(mesh, radius_of_interest, return_length=True).astype(float)

    with np.errstate(divide="ignore", invalid="ignore"):
        score = np.where(expect > 0, counts_B / expect - 1.0, 0.0)
    weighted = score * counts_A

    score_grid = weighted.reshape(xx.shape)
    weight_grid = counts_A.reshape(xx.shape)
    inside_grid = inside.reshape(xx.shape)
    score_grid[~inside_grid] = 0.0
    weight_grid[~inside_grid] = 0.0

    sigma_px = kernel_sigma / mesh_step
    score_sm = gaussian_filter(score_grid, sigma=sigma_px)
    weight_sm = gaussian_filter(weight_grid, sigma=sigma_px)

    with np.errstate(divide="ignore", invalid="ignore"):
        tcm = np.where(weight_sm > 0, score_sm / weight_sm, np.nan)
    tcm[~inside_grid] = np.nan
    tcm = np.clip(tcm, -max_corr_threshold, max_corr_threshold)
    return tcm, xx, yy


def get_pair_by_auc(auc_mat: np.ndarray, types: list[str],
                    mode: str = "max") -> tuple[str, str]:
    """Pick the cell-type pair with extreme AUC (max → attraction; min → repulsion).

    Identical logic to the notebook's ``_get_pair_by_auc``.  Note that the
    package computes AUC from the **edge-corrected** cross-K (Ripley isotropic),
    while the notebook uses the **uncorrected** estimator (Cell 164).  This
    means the top pair may differ between the two — both are valid; the
    edge-corrected version is statistically preferable near tissue boundaries.
    """
    mat = auc_mat.copy()
    np.fill_diagonal(mat, np.nan)
    idx = (np.unravel_index(np.nanargmax(mat), mat.shape) if mode == "max"
           else np.unravel_index(np.nanargmin(mat), mat.shape))
    return types[idx[0]], types[idx[1]]


# Backward-compat alias matching the notebook's private name
_get_pair_by_auc = get_pair_by_auc
