"""Morisita-Horn index of spatial distribution similarity."""
from __future__ import annotations

import numpy as np
import pandas as pd


def morisita_horn_index(coords: np.ndarray, labels: np.ndarray, roi_poly,
                        quadrat_size: float = 150.0,
                        min_observations: int = 5) -> pd.DataFrame:
    """Morisita-Horn matrix on a regular quadrat grid."""
    labels = np.asarray(labels)
    unique_types = np.unique(labels)
    n_types = len(unique_types)
    label_to_idx = {l: i for i, l in enumerate(unique_types)}

    bounds = roi_poly.bounds
    xs = np.arange(bounds[0], bounds[2], quadrat_size)
    ys = np.arange(bounds[1], bounds[3], quadrat_size)

    rows = []
    for x0 in xs:
        for y0 in ys:
            x1, y1 = x0 + quadrat_size, y0 + quadrat_size
            in_q = ((coords[:, 0] >= x0) & (coords[:, 0] < x1)
                    & (coords[:, 1] >= y0) & (coords[:, 1] < y1))
            if in_q.sum() < min_observations:
                continue
            row = np.zeros(n_types)
            for ic in np.where(in_q)[0]:
                row[label_to_idx[labels[ic]]] += 1
            rows.append(row)
    if len(rows) < 2:
        raise ValueError(f"Only {len(rows)} non-empty quadrats; reduce quadrat_size or min_observations.")

    M = np.array(rows, dtype=float)
    N = M.sum(axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        lam = np.where(N > 0, (M ** 2).sum(axis=0) / N ** 2, 0.0)

    MH = np.zeros((n_types, n_types))
    for i in range(n_types):
        for j in range(n_types):
            denom = (lam[i] + lam[j]) * N[i] * N[j]
            MH[i, j] = (2 * (M[:, i] * M[:, j]).sum() / denom) if denom > 0 else np.nan
    return pd.DataFrame(MH, index=list(unique_types), columns=list(unique_types))
