"""Persistent homology (Vietoris-Rips) for cell-type point clouds."""
from __future__ import annotations

import numpy as np
import pandas as pd
from ripser import ripser
from scipy.spatial.distance import pdist, squareform

from .. import config


def vietoris_rips(pts_type: np.ndarray, max_dimension: int = config.PERSISTENCE_MAX_DIM,
                  max_distance: float | None = None,
                  subsample: int = 800,
                  seed: int = config.RANDOM_SEED):
    """Vietoris-Rips persistence diagrams. Returns list of arrays per dimension."""
    pts_type = np.asarray(pts_type, float)
    if len(pts_type) > subsample:
        rng = np.random.default_rng(seed)
        pts_type = pts_type[rng.choice(len(pts_type), subsample, replace=False)]
    D = squareform(pdist(pts_type))
    thresh = max_distance if max_distance is not None else float(D.max())
    return ripser(D, maxdim=max_dimension, thresh=thresh, distance_matrix=True)["dgms"]


def vectorise_persistence(dgms) -> tuple[np.ndarray, list[str]]:
    """Vectorise persistence diagrams into per-dimension scalar features."""
    vec, names = [], []
    for dim, dgm in enumerate(dgms):
        finite = dgm[~np.isinf(dgm[:, 1])]
        pers = (finite[:, 1] - finite[:, 0]) if len(finite) else np.array([0.0])
        pcts = (np.percentile(pers, [10, 25, 50, 75, 90])
                if len(pers) > 1 else np.zeros(5))
        if pers.sum() > 0:
            entropy = float(-np.sum((pers / pers.sum()) * np.log(pers / pers.sum() + 1e-12)))
        else:
            entropy = 0.0
        vec.extend([float(pers.mean()), float(pers.std()), *map(float, pcts), len(finite), entropy])
        names.extend([
            f"H{dim}_mean", f"H{dim}_std",
            f"H{dim}_p10", f"H{dim}_p25", f"H{dim}_p50",
            f"H{dim}_p75", f"H{dim}_p90",
            f"H{dim}_count", f"H{dim}_entropy",
        ])
    return np.array(vec), names


def persistence_per_celltype(coords: np.ndarray, labels_arr: np.ndarray,
                             unique_labels: np.ndarray, top_types: list[str],
                             max_distance: float = 200.0,
                             subsample: int = 600,
                             min_cells: int = 20) -> tuple[dict, pd.DataFrame]:
    """Run Vietoris-Rips per cell type and return (diagrams, feature DataFrame)."""
    diagrams: dict = {}
    vectors: dict = {}
    feat_names: list[str] = []
    for t in top_types:
        P = coords[unique_labels[labels_arr] == t]
        if len(P) < min_cells:
            continue
        dgms = vietoris_rips(P, max_distance=max_distance, subsample=subsample)
        diagrams[t] = dgms
        v, feat_names = vectorise_persistence(dgms)
        vectors[t] = v
    df = (pd.DataFrame(vectors, index=feat_names).T
          if vectors else pd.DataFrame())
    return diagrams, df
