"""MuSpAn-style spatial methods: TCM, wPCF, APT, QCM, Morisita-Horn, persistence, SWD, ANNI."""
