"""Weighted Pair Correlation Function (wPCF) — mark-aware cross-PCF."""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree


def weighted_pcf(A: np.ndarray, B: np.ndarray, marks_B: np.ndarray,
                 support: np.ndarray,
                 annulus_width: float | None = None,
                 n_mark_bins: int = 10,
                 mark_min: float | None = None,
                 mark_max: float | None = None,
                 roi_poly=None) -> tuple[np.ndarray, np.ndarray]:
    """wPCF(r, m): co-localisation of B-cells with mark m around A at radius r."""
    marks_B = np.asarray(marks_B, float)
    if annulus_width is None:
        annulus_width = support[1] - support[0] if len(support) > 1 else support[0]

    if mark_min is None:
        mark_min = float(marks_B.min())
    if mark_max is None:
        mark_max = float(marks_B.max())
    mark_edges = np.linspace(mark_min, mark_max, n_mark_bins + 1)
    mark_centres = 0.5 * (mark_edges[:-1] + mark_edges[1:])
    mark_width = mark_edges[1] - mark_edges[0]

    n_A, n_B = len(A), len(B)
    area = (roi_poly.area if roi_poly is not None else
            (A[:, 0].max() - A[:, 0].min()) * (A[:, 1].max() - A[:, 1].min()))
    lam_B = n_B / area

    tree = cKDTree(B)
    wpcf = np.zeros((n_mark_bins, len(support)))

    for k, r_mid in enumerate(support):
        r_inner = max(0.0, r_mid - annulus_width / 2)
        r_outer = r_mid + annulus_width / 2
        annulus_area = np.pi * (r_outer ** 2 - r_inner ** 2)
        outer_idx = tree.query_ball_point(A, r_outer)
        inner_idx = tree.query_ball_point(A, r_inner)

        for m_bin in range(n_mark_bins):
            centre = mark_centres[m_bin]

            def tri(m, c=centre):
                return np.maximum(0.0, 1.0 - np.abs(m - c) / mark_width)

            total = 0.0
            for i in range(n_A):
                in_annulus = np.setdiff1d(outer_idx[i], inner_idx[i])
                if len(in_annulus) == 0:
                    continue
                total += tri(marks_B[in_annulus]).sum()

            mean_w = tri(marks_B).mean()
            expected = n_A * lam_B * annulus_area * mean_w
            wpcf[m_bin, k] = total / expected if expected > 0 else np.nan
    return wpcf, mark_centres
