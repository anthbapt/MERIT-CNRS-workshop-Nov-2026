"""Sliced Wasserstein Distance and Average Nearest Neighbour Index (ANNI)."""
from __future__ import annotations

import numpy as np
import ot
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import norm as scipy_norm

from .. import config


def sliced_wasserstein_distance(pts_A: np.ndarray, pts_B: np.ndarray,
                                n_projections: int = config.SWD_N_PROJECTIONS,
                                seed: int = config.RANDOM_SEED,
                                subsample: int = 1000) -> float:
    """Sliced Wasserstein distance between two 2-D point clouds (POT)."""
    rng = np.random.default_rng(seed)

    def _sub(P):
        if len(P) > subsample:
            return P[rng.choice(len(P), subsample, replace=False)]
        return P

    A = _sub(np.asarray(pts_A, float))
    B = _sub(np.asarray(pts_B, float))
    a = np.ones(len(A)) / len(A)
    b = np.ones(len(B)) / len(B)
    return float(ot.sliced_wasserstein_distance(
        A, B, a, b, n_projections=n_projections, seed=int(seed),
    ))


def pairwise_swd(coords: np.ndarray, labels_arr: np.ndarray,
                 unique_labels: np.ndarray, top_types: list[str],
                 min_cells: int = 30) -> pd.DataFrame:
    """All-pairs SWD matrix on the chosen cell types."""
    n = len(top_types)
    M = np.full((n, n), np.nan)
    pts_by = {t: coords[unique_labels[labels_arr] == t] for t in top_types}
    for i, ta in enumerate(top_types):
        A = pts_by[ta]
        if len(A) < min_cells:
            continue
        for j, tb in enumerate(top_types):
            if i == j:
                M[i, j] = 0.0
                continue
            B = pts_by[tb]
            if len(B) < min_cells:
                continue
            M[i, j] = sliced_wasserstein_distance(A, B)
    return pd.DataFrame(M, index=top_types, columns=top_types)


def average_nearest_neighbour_index(pts_type: np.ndarray, area: float,
                                    k: int = 1) -> tuple[float, float, float, float, float]:
    """Clark & Evans ANNI with z-score and two-tailed p-value."""
    n = len(pts_type)
    if n < 3:
        nan = float("nan")
        return nan, nan, nan, nan, nan
    tree = cKDTree(pts_type)
    dists, _ = tree.query(pts_type, k=k + 1)
    r_obs = float(dists[:, k].mean())
    density = n / area
    r_exp = 0.5 / np.sqrt(density)
    SE = 0.26136 / np.sqrt(n * density)
    anni = r_obs / r_exp
    z = (r_obs - r_exp) / SE
    p = 2 * scipy_norm.sf(abs(z))
    return float(anni), float(z), float(p), r_obs, float(r_exp)


def anni_per_celltype(coords: np.ndarray, labels_arr: np.ndarray,
                      unique_labels: np.ndarray, top_types: list[str],
                      area: float) -> pd.DataFrame:
    """Per-cell-type ANNI with significance and pattern label."""
    rows = []
    for t in top_types:
        P = coords[unique_labels[labels_arr] == t]
        if len(P) < 3:
            continue
        anni, z, p, r_obs, r_exp = average_nearest_neighbour_index(P, area)
        if anni < 1 and p < 0.05:
            pattern = "Clustered"
        elif anni > 1 and p < 0.05:
            pattern = "Dispersed"
        else:
            pattern = "Random"
        rows.append({
            "Cell type": t, "n": len(P),
            "r_obs": round(r_obs, 2), "r_exp": round(r_exp, 2),
            "ANNI": round(anni, 3), "z-score": round(z, 3),
            "p-value": round(p, 4), "Pattern": pattern,
        })
    return pd.DataFrame(rows).set_index("Cell type")
