"""Quadrat Correlation Matrix (QCM) — partial correlations of cell-type counts."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests

from .. import config


def _build_count_matrix(coords, labels, label_to_idx, n_types,
                        xs, ys, quadrat_size, min_observations) -> np.ndarray:
    rows = []
    for x0 in xs:
        for y0 in ys:
            x1, y1 = x0 + quadrat_size, y0 + quadrat_size
            in_q = ((coords[:, 0] >= x0) & (coords[:, 0] < x1)
                    & (coords[:, 1] >= y0) & (coords[:, 1] < y1))
            if in_q.sum() < min_observations:
                continue
            row = np.zeros(n_types)
            for ic in np.where(in_q)[0]:
                row[label_to_idx[labels[ic]]] += 1
            rows.append(row)
    return np.array(rows, dtype=float) if rows else np.empty((0, n_types))


def _partial_corr(M: np.ndarray, n_types: int, transform: str | None) -> np.ndarray:
    if transform == "sqrt":
        M = np.sqrt(M)
    elif transform == "log":
        M = np.log1p(M)
    std = M.std(axis=0)
    good = std > 1e-8
    Mg = M[:, good]
    if Mg.shape[1] < 2:
        return np.full((n_types, n_types), np.nan)
    cov = np.cov(Mg.T)
    try:
        prec = np.linalg.inv(cov + 1e-6 * np.eye(len(cov)))
    except np.linalg.LinAlgError:
        return np.full((n_types, n_types), np.nan)
    d = np.sqrt(np.diag(prec))
    with np.errstate(divide="ignore", invalid="ignore"):
        pc = -prec / np.outer(d, d)
    np.fill_diagonal(pc, 1.0)
    full = np.full((n_types, n_types), np.nan)
    idx_good = np.where(good)[0]
    for ii, gi in enumerate(idx_good):
        for jj, gj in enumerate(idx_good):
            full[gi, gj] = pc[ii, jj]
    return full


def quadrat_correlation_matrix(coords: np.ndarray, labels: np.ndarray,
                               roi_poly,
                               quadrat_size: float = config.QCM_QUADRAT_SIZE,
                               n_shuffles: int = 1000,
                               alpha: float = 0.05,
                               min_observations: int = 15,
                               transform: str | None = None,
                               seed: int = config.RANDOM_SEED) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, np.ndarray]:
    """QCM SES, BH-corrected p, significance mask, and raw count matrix."""
    labels = np.asarray(labels)
    unique_types, type_counts = np.unique(labels, return_counts=True)
    keep = unique_types[type_counts >= min_observations]
    mask = np.isin(labels, keep)
    coords_f = coords[mask]
    labels_f = labels[mask]
    n_types = len(keep)
    label_to_idx = {l: i for i, l in enumerate(keep)}

    bounds = roi_poly.bounds
    xs = np.arange(bounds[0], bounds[2], quadrat_size)
    ys = np.arange(bounds[1], bounds[3], quadrat_size)

    obs_mat = _build_count_matrix(coords_f, labels_f, label_to_idx, n_types,
                                  xs, ys, quadrat_size, min_observations)
    if obs_mat.shape[0] < 3:
        raise ValueError(f"Only {obs_mat.shape[0]} non-empty quadrats; reduce quadrat_size or min_observations.")

    C_obs = _partial_corr(obs_mat, n_types, transform)

    rng = np.random.default_rng(seed)
    label_idx = np.array([label_to_idx[l] for l in labels_f])
    null_C = np.zeros((n_shuffles, n_types, n_types))
    for s in range(n_shuffles):
        shuffled_lbl = keep[rng.permutation(label_idx)]
        null_mat = _build_count_matrix(coords_f, shuffled_lbl, label_to_idx,
                                       n_types, xs, ys, quadrat_size, min_observations)
        if null_mat.shape[0] < 3:
            null_C[s] = np.nan
            continue
        null_C[s] = _partial_corr(null_mat, n_types, transform)

    nm = np.nanmean(null_C, axis=0)
    ns = np.nanstd(null_C, axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        SES = np.where(ns > 0, (C_obs - nm) / ns, np.nan)

    # BH correction over the full flattened SES matrix (matches notebook
    # cell 297). NaN entries are mapped to p = 1 prior to correction.
    flat_z = SES.flatten()
    flat_p = np.where(np.isnan(flat_z), 1.0, 2 * norm.sf(np.abs(flat_z)))
    _, p_corr_flat, _, _ = multipletests(flat_p, alpha=alpha, method="fdr_bh")
    p_corr = p_corr_flat.reshape(SES.shape)
    sig = (p_corr < alpha) & ~np.isnan(SES)

    keep_list = list(keep)
    return (
        pd.DataFrame(SES, index=keep_list, columns=keep_list),
        pd.DataFrame(p_corr, index=keep_list, columns=keep_list),
        pd.DataFrame(sig, index=keep_list, columns=keep_list),
        obs_mat,
    )
