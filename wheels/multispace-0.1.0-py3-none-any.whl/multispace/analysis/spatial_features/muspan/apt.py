"""Adjacency Permutation Test (APT) on a Delaunay or KNN spatial graph."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial import Delaunay, cKDTree
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests

from .. import config


def adjacency_permutation_test(coords: np.ndarray, labels: np.ndarray,
                               n_perms: int = config.APT_N_PERMS,
                               alpha: float = 0.05,
                               network_type: str = "Delaunay",
                               k_knn: int = 8,
                               transform: str | None = None,
                               min_observations: int = 15,
                               seed: int = config.RANDOM_SEED) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Adjacency permutation test (network-level neighbourhood enrichment)."""
    labels = np.asarray(labels)
    unique, counts = np.unique(labels, return_counts=True)
    keep = unique[counts >= min_observations]
    mask = np.isin(labels, keep)
    coords_f = coords[mask]
    labels_f = labels[mask]
    n_types = len(keep)
    label_to_idx = {l: i for i, l in enumerate(keep)}
    label_idx = np.array([label_to_idx[l] for l in labels_f])

    if network_type == "Delaunay":
        tri = Delaunay(coords_f)
        edge_set = set()
        for s in tri.simplices:
            for a in range(3):
                for b in range(a + 1, 3):
                    edge_set.add((min(s[a], s[b]), max(s[a], s[b])))
        edges = np.array(list(edge_set))
    else:
        tree = cKDTree(coords_f)
        _, nbrs = tree.query(coords_f, k=k_knn + 1)
        nbrs = nbrs[:, 1:]
        edge_set = set()
        for i, row in enumerate(nbrs):
            for j in row:
                edge_set.add((min(i, j), max(i, j)))
        edges = np.array(list(edge_set))

    def _count(li):
        C = np.zeros((n_types, n_types), dtype=float)
        for e in edges:
            a, b = li[e[0]], li[e[1]]
            C[a, b] += 1
            if a != b:
                C[b, a] += 1
        return C

    def _tx(C):
        if transform == "sqrt":
            return np.sqrt(C)
        if transform == "log":
            return np.log1p(C)
        return C

    C_obs = _tx(_count(label_idx))
    rng = np.random.default_rng(seed)
    null_counts = np.zeros((n_perms, n_types, n_types))
    for p in range(n_perms):
        null_counts[p] = _tx(_count(rng.permutation(label_idx)))
    nm = null_counts.mean(axis=0)
    ns = null_counts.std(axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        SES = np.where(ns > 0, (C_obs - nm) / ns, 0.0)

    z_flat = SES.ravel()
    p_flat = 2 * norm.sf(np.abs(z_flat))
    _, p_corr, _, _ = multipletests(p_flat, alpha=alpha, method="fdr_bh")
    p_corr = p_corr.reshape(n_types, n_types)
    sig = p_corr < alpha

    keep_list = list(keep)
    return (
        pd.DataFrame(SES, index=keep_list, columns=keep_list),
        pd.DataFrame(p_corr, index=keep_list, columns=keep_list),
        pd.DataFrame(sig, index=keep_list, columns=keep_list),
    )
