"""Interaction-changed features (ICF): differential expression by neighbour type."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import mannwhitneyu
from statsmodels.stats.multitest import multipletests

from .. import config


def icf_test_mwu(values: np.ndarray, has_nbr: np.ndarray,
                 min_group: int = 5) -> tuple[float, float]:
    """Mann-Whitney U test of `values` between cells with vs without neighbour."""
    g0 = values[~has_nbr]
    g1 = values[has_nbr]
    if len(g0) < min_group or len(g1) < min_group:
        return float("nan"), float("nan")
    effect = float(np.median(g1) - np.median(g0))
    try:
        _, p = mannwhitneyu(g1, g0, alternative="two-sided")
        return effect, float(p)
    except Exception:
        return effect, float("nan")


def compute_icf(coords: np.ndarray, labels: np.ndarray,
                Xmat: np.ndarray, gene_names: list[str],
                k: int = 8, top_n_genes: int = 200,
                max_focal: int = 500,
                seed: int = config.RANDOM_SEED) -> dict:
    """All-pairs ICF on top-variance genes with FDR correction."""
    rng = np.random.default_rng(seed)
    labels = np.asarray(labels)
    cell_types = np.unique(labels)

    tree = cKDTree(coords)
    _, nbrs = tree.query(coords, k=k + 1)
    nbrs = nbrs[:, 1:]

    Xdense = Xmat.toarray() if hasattr(Xmat, "toarray") else np.asarray(Xmat)
    var_idx = np.argsort(Xdense.var(axis=0))[::-1][:top_n_genes]
    Xsub = Xdense[:, var_idx]
    gene_sub = [gene_names[g] for g in var_idx]

    results: dict = {}
    for focal_type in cell_types:
        focal_mask = labels == focal_type
        focal_idx = np.where(focal_mask)[0]
        if len(focal_idx) < 10:
            continue
        if len(focal_idx) > max_focal:
            focal_idx = rng.choice(focal_idx, size=max_focal, replace=False)

        for nbr_type in cell_types:
            if nbr_type == focal_type:
                continue
            has_nbr = np.array([
                bool(np.any(labels[nbrs[i]] == nbr_type)) for i in focal_idx
            ])
            if has_nbr.sum() < 5 or (~has_nbr).sum() < 5:
                continue
            X_focal = Xsub[focal_idx]
            effects = np.zeros(len(gene_sub))
            pvals = np.zeros(len(gene_sub))
            for g in range(len(gene_sub)):
                effects[g], pvals[g] = icf_test_mwu(X_focal[:, g], has_nbr)
            valid = ~np.isnan(pvals)
            padj = np.full(len(pvals), np.nan)
            if valid.sum() > 0:
                _, padj[valid], _, _ = multipletests(pvals[valid], method="fdr_bh")
            results[(focal_type, nbr_type)] = pd.DataFrame({
                "gene": gene_sub,
                "effect": effects,
                "p_raw": pvals,
                "p_adj": padj,
            }).dropna().sort_values("p_adj")
    return results


def icf_significance_matrix(results: dict, alpha: float = 0.05) -> pd.DataFrame:
    """Count of significant genes per (focal, neighbour) pair."""
    cell_types = sorted({t for pair in results for t in pair})
    M = np.full((len(cell_types), len(cell_types)), np.nan)
    for (ft, nt), df in results.items():
        i = cell_types.index(ft)
        j = cell_types.index(nt)
        M[i, j] = int((df["p_adj"] < alpha).sum())
    return pd.DataFrame(M, index=cell_types, columns=cell_types)
