"""Tumour-stroma boundary / interface zone analysis."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import mannwhitneyu
from statsmodels.stats.multitest import multipletests


DEFAULT_TUMOUR_TYPES = ["Epithelial"]
DEFAULT_STROMA_TYPES = ["CAFs", "Endothelial", "Perivascular-like",
                        "Myeloid", "T-cells", "Plasmablasts"]


def assign_zones(coords: np.ndarray, labels: np.ndarray,
                 tumour_types: list[str] = DEFAULT_TUMOUR_TYPES,
                 stroma_types: list[str] = DEFAULT_STROMA_TYPES,
                 interface_dist: float = 100.0) -> np.ndarray:
    """Label each cell as tumour/stroma core/interface or 'Other'."""
    labels = np.asarray(labels)
    tumour_mask = np.isin(labels, tumour_types)
    stroma_mask = np.isin(labels, stroma_types)
    pts_t = coords[tumour_mask]
    pts_s = coords[stroma_mask]

    tree_s = cKDTree(pts_s) if len(pts_s) > 0 else None
    tree_t = cKDTree(pts_t) if len(pts_t) > 0 else None
    d_t_to_s = (tree_s.query(pts_t)[0]
                if tree_s is not None
                else np.full(len(pts_t), np.inf))
    d_s_to_t = (tree_t.query(pts_s)[0]
                if tree_t is not None
                else np.full(len(pts_s), np.inf))

    zone = np.full(len(coords), "Other", dtype=object)
    for k, idx in enumerate(np.where(tumour_mask)[0]):
        zone[idx] = "Tumour interface" if d_t_to_s[k] <= interface_dist else "Tumour core"
    for k, idx in enumerate(np.where(stroma_mask)[0]):
        zone[idx] = "Stroma interface" if d_s_to_t[k] <= interface_dist else "Stroma core"
    return zone


def zone_composition(zone: np.ndarray, labels: np.ndarray) -> pd.DataFrame:
    """Cell-type composition fractions per zone."""
    df = pd.DataFrame({"Zone": zone, "Cell type": np.asarray(labels)})
    df = df[df["Zone"] != "Other"]
    g = df.groupby(["Zone", "Cell type"]).size().reset_index(name="Count")
    g["Fraction"] = g.groupby("Zone")["Count"].transform(lambda x: x / x.sum())
    return g


def interface_vs_core_de(Xmat: np.ndarray, gene_names: list[str],
                         zone: np.ndarray,
                         compartment_zones: tuple[str, str] = ("Tumour interface", "Tumour core"),
                         n_test_genes: int = 20) -> pd.DataFrame:
    """Differential expression between two zones on top-variance genes."""
    interface_label, core_label = compartment_zones
    mask = np.isin(zone, list(compartment_zones))
    if mask.sum() < 10:
        return pd.DataFrame()

    Xz = Xmat[mask]
    zz = zone[mask]
    is_int = zz == interface_label
    is_core = zz == core_label

    gv = np.var(Xz, axis=0)
    top = np.argsort(gv)[::-1][:n_test_genes]
    names = [gene_names[i] for i in top]

    pvals, fcs = [], []
    for gi in top:
        a = Xz[is_int, gi]
        b = Xz[is_core, gi]
        if len(a) < 3 or len(b) < 3:
            pvals.append(1.0)
            fcs.append(0.0)
            continue
        _, p = mannwhitneyu(a, b, alternative="two-sided")
        pvals.append(float(p))
        fcs.append(float(np.log2(a.mean() + 1e-6) - np.log2(b.mean() + 1e-6)))
    _, padj, _, _ = multipletests(pvals, method="fdr_bh")
    return pd.DataFrame({
        "Gene": names,
        "log2FC": fcs,
        "p_adj": padj,
        "Significant": padj < 0.05,
    }).sort_values("log2FC", ascending=False)
