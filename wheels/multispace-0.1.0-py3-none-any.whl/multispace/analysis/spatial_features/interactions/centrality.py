"""Centrality scores and per-cell-type network topology descriptors."""
from __future__ import annotations

import networkx as nx
import numpy as np
import pandas as pd

from .. import config
from ..io import prepare_adata_for_metrics
from ..pointpat.helpers import _graph_topology
from ..weights import attach_graph_to_adata

try:
    import squidpy as sq

    HAS_SQUIDPY = True
except ImportError:
    sq = None
    HAS_SQUIDPY = False


def compute_centrality(sdata, graph: nx.Graph,
                       cluster_key: str = config.CLUSTER_KEY) -> pd.DataFrame:
    """Squidpy degree, closeness, and betweenness centrality per cell type.

    Requires the optional ``squidpy`` dependency
    (``pip install spatial_features[squidpy]``).
    """
    if not HAS_SQUIDPY:
        raise ImportError(
            "compute_centrality() requires the optional 'squidpy' package. "
            "Install it with: pip install spatial_features[squidpy]"
        )
    adata = prepare_adata_for_metrics(sdata, cluster_key)
    attach_graph_to_adata(adata, graph)
    sq.gr.centrality_scores(adata, cluster_key=cluster_key)
    return adata.uns[f"{cluster_key}_centrality_scores"].copy()


def centrality_to_features(cent_df: pd.DataFrame) -> dict:
    """Flatten centrality DataFrame into a feature dict keyed by `cent__<m>__<ct>`."""
    metrics = ["degree_centrality", "closeness_centrality", "betweenness_centrality"]
    df = cent_df.reset_index()
    if "cell_type" not in df.columns:
        df = df.rename(columns={df.columns[0]: "cell_type"})
    df = df.set_index("cell_type")
    feats: dict = {}
    for m in metrics:
        if m not in df.columns:
            continue
        for ct in df.index:
            v = df.loc[ct, m]
            feats[f"cent__{m}__{ct}"] = float(v) if pd.notna(v) else np.nan
    return feats


def compute_network_measures(sdata, graph: nx.Graph,
                             cluster_key: str = config.CLUSTER_KEY) -> pd.DataFrame:
    """Per-cell-type network topology descriptors on the disparity graph."""
    adata = prepare_adata_for_metrics(sdata, cluster_key)
    attach_graph_to_adata(adata, graph)
    G = graph
    cell_types = adata.obs[cluster_key].astype(str).values
    n_rows = len(cell_types)

    ct_to_nodes: dict = {}
    for node in G.nodes():
        idx = int(node)
        if 0 <= idx < n_rows:
            ct = cell_types[idx]
            ct_to_nodes.setdefault(ct, []).append(idx)

    graph_dict: dict = {"__all__": G}
    for ct, nodes in ct_to_nodes.items():
        if nodes:
            graph_dict[ct] = G.subgraph(nodes).copy()

    rows = []
    for label, sg in graph_dict.items():
        row = {"cell_type": label}
        row.update(_graph_topology(sg))
        rows.append(row)
    df = pd.DataFrame(rows).set_index("cell_type")
    order = ["__all__"] + [c for c in df.index if c != "__all__"]
    return df.loc[order]


def network_to_features(netm_df: pd.DataFrame) -> dict:
    """Flatten network topology DataFrame into a feature dict."""
    metric_to_short = {
        "average_clustering": "clustering",
        "average_shortest_path_length": "shortest_path",
        "degree_assortativity_coefficient": "assortativity",
    }
    feats: dict = {}
    for ct in netm_df.index:
        tag = "all" if ct == "__all__" else ct
        for metric, short in metric_to_short.items():
            if metric not in netm_df.columns:
                continue
            v = netm_df.loc[ct, metric]
            feats[f"network__{short}__{tag}"] = float(v) if pd.notna(v) else np.nan
    return feats
