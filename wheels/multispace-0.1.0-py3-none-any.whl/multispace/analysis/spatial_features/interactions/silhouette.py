"""Spatial silhouette family (path, boundary, nearest-label) via esda."""
from __future__ import annotations

import numpy as np
from esda import silhouettes as esda_sil


def spatial_silhouette(X: np.ndarray, labels_arr: np.ndarray, w) -> dict:
    """Path silhouette, boundary silhouette, and nearest-label relabel count."""
    path_sil = esda_sil.path_silhouette(X, labels_arr, w)
    bs = esda_sil.boundary_silhouette(X, labels_arr, w)
    nl = esda_sil.nearest_label(X, labels_arr)
    relabel_n = int((nl != labels_arr).sum())
    return {
        "path_silhouette": path_sil,
        "boundary_silhouette": bs,
        "nearest_label": nl,
        "path_silhouette_mean": float(np.nanmean(path_sil)),
        "boundary_silhouette_mean": float(np.nanmean(bs)),
        "nearest_label_relabel_count": relabel_n,
        "n": len(labels_arr),
    }
