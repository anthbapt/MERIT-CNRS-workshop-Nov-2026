"""Functional spatial entropy (FunSpace) and Simpson's diversity / multi-scale ANNI."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.special import gamma
from scipy.stats import entropy as scipy_entropy
from scipy.stats import norm as scipy_norm

from .. import config


# ── FunSpace ─────────────────────────────────────────────────────────────────
def functional_spatial_entropy(coords: np.ndarray, labels: np.ndarray,
                               radii: np.ndarray | None = None,
                               min_neighbours: int = 3) -> tuple[np.ndarray, dict]:
    """H(r) = mean Shannon entropy of cell-type composition within radius r."""
    if radii is None:
        radii = np.linspace(10, 300, 30)
    labels = np.asarray(labels)
    unique_types = np.unique(labels)
    n_types = len(unique_types)
    type_to_idx = {t: i for i, t in enumerate(unique_types)}
    label_idx = np.array([type_to_idx[l] for l in labels])

    tree = cKDTree(coords)
    n = len(coords)
    H_all = np.full((n, len(radii)), np.nan)
    for k, r in enumerate(radii):
        nbrs = tree.query_ball_point(coords, r)
        for i, nb in enumerate(nbrs):
            if len(nb) < min_neighbours:
                continue
            counts = np.bincount(label_idx[nb], minlength=n_types).astype(float)
            p = counts / counts.sum()
            H_all[i, k] = scipy_entropy(p, base=2)

    H_mean = np.nanmean(H_all, axis=0)
    H_by_type = {t: np.nanmean(H_all[labels == t], axis=0) for t in unique_types}
    return H_mean, H_by_type


def funspace_inflection_scale(H_mean: np.ndarray,
                              radii: np.ndarray) -> dict:
    """Characteristic mixing scale = inflection of H(r) (where d²H/dr² ≈ 0)."""
    dH = np.gradient(H_mean, radii)
    d2H = np.gradient(dH, radii)
    idx = int(np.argmin(np.abs(d2H)))
    return {
        "inflection_r": float(radii[idx]),
        "H_at_inflection": float(H_mean[idx]),
        "dH": dH,
        "d2H": d2H,
    }


# ── Spatial Simpson's diversity ──────────────────────────────────────────────
def spatial_simpsons_diversity(coords: np.ndarray, labels: np.ndarray,
                               radius: float = config.SIMPSONS_RADIUS,
                               min_neighbours: int = 3) -> tuple[np.ndarray, dict]:
    """Per-cell spatial Simpson's D = 1 - Σ p_i² within a fixed radius."""
    labels = np.asarray(labels)
    unique_types = np.unique(labels)
    n_types = len(unique_types)
    type_to_idx = {t: i for i, t in enumerate(unique_types)}
    label_idx = np.array([type_to_idx[l] for l in labels])

    tree = cKDTree(coords)
    nbrs = tree.query_ball_point(coords, radius)

    D = np.full(len(coords), np.nan)
    for i, nb in enumerate(nbrs):
        if len(nb) < min_neighbours:
            continue
        counts = np.bincount(label_idx[nb], minlength=n_types).astype(float)
        p = counts / counts.sum()
        D[i] = 1.0 - np.sum(p ** 2)

    D_by_type = {t: float(np.nanmean(D[labels == t])) for t in unique_types}
    return D, D_by_type


# ── Multi-scale Clark-Evans ANNI profile ─────────────────────────────────────
def multiscale_clark_evans(pts_type: np.ndarray, area: float,
                           k_max: int = 10) -> tuple:
    """Clark-Evans ANNI for k = 1..k_max nearest neighbours."""
    n = len(pts_type)
    if n < k_max + 1:
        return (np.arange(1, k_max + 1),
                np.full(k_max, np.nan),
                np.full(k_max, np.nan),
                np.full(k_max, np.nan))

    tree = cKDTree(pts_type)
    dists, _ = tree.query(pts_type, k=k_max + 1)
    density = n / area
    SE_1 = 0.26136 / np.sqrt(n * density)

    k_vals = np.arange(1, k_max + 1)
    anni = np.zeros(k_max)
    z_scores = np.zeros(k_max)
    p_vals = np.zeros(k_max)

    for idx, k in enumerate(k_vals):
        r_obs = dists[:, k].mean()
        r_exp_k = gamma(k + 0.5) / (gamma(k) * np.sqrt(np.pi * density))
        SE_k = SE_1 * np.sqrt(k)
        anni[idx] = r_obs / r_exp_k
        z_scores[idx] = (r_obs - r_exp_k) / SE_k
        p_vals[idx] = 2 * scipy_norm.sf(abs(z_scores[idx]))
    return k_vals, anni, z_scores, p_vals


def multiscale_clark_evans_per_type(coords: np.ndarray, labels: np.ndarray,
                                    types: list[str], area: float,
                                    k_max: int = 10,
                                    min_cells: int | None = None) -> dict:
    """Multi-scale Clark-Evans ANNI for every cell type in `types`."""
    labels = np.asarray(labels)
    if min_cells is None:
        min_cells = k_max + 2
    out: dict = {}
    for t in types:
        P = coords[labels == t]
        if len(P) < min_cells:
            continue
        out[t] = multiscale_clark_evans(P, area, k_max)
    return out
