"""Cell-type interaction and neighbourhood analysis."""
