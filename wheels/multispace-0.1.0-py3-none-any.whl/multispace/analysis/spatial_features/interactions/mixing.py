"""Mixing scores: Schmid global/pairwise, SPIAT (raw + normalised), Clark-Evans."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import norm as scipy_norm


def schmid_mixing_score(coords: np.ndarray, labels: np.ndarray,
                        k: int = 8) -> tuple[float, np.ndarray]:
    """Schmid (2022) mixing score: mean fraction of k-NN with a different label."""
    tree = cKDTree(coords)
    _, nbr_idx = tree.query(coords, k=k + 1)
    nbr_idx = nbr_idx[:, 1:]
    labels = np.asarray(labels)
    same = labels[nbr_idx] == labels[:, None]
    mixing = 1.0 - same.mean(axis=1)
    return float(mixing.mean()), mixing


def schmid_per_celltype(coords: np.ndarray, labels: np.ndarray,
                        k: int = 8) -> pd.Series:
    """Per-cell-type mean Schmid mixing score."""
    _, mixing = schmid_mixing_score(coords, labels, k=k)
    labels = np.asarray(labels).astype(str)
    out = {}
    for ct in np.unique(labels):
        mask = labels == ct
        out[ct] = float(mixing[mask].mean())
    return pd.Series(out, name="schmid_mixing")


def schmid_pairwise(coords: np.ndarray, labels: np.ndarray,
                    k: int = 8) -> pd.DataFrame:
    """Schmid pairwise normalised mixing score MS_AB (raw and normalised).

    Mirrors the notebook's cell 225: MS_norm is computed for every pair of
    cell types, including rare ones.
    """
    labels = np.asarray(labels)
    tree = cKDTree(coords)
    _, nbrs = tree.query(coords, k=k + 1)
    nbrs = nbrs[:, 1:]
    cell_types = np.unique(labels)
    rows = []
    for a in cell_types:
        for b in cell_types:
            if a == b:
                continue
            n_AA = n_AB = 0
            for i, row in enumerate(nbrs):
                la = labels[i]
                if la != a:
                    continue
                for j in row:
                    lb = labels[j]
                    if lb == a:
                        n_AA += 1
                    elif lb == b:
                        n_AB += 1
            NA = int((labels == a).sum())
            NB = int((labels == b).sum())
            MS_raw = n_AB / max(n_AA, 1)
            denom_norm = max(n_AA / max(NA * (NA - 1), 1), 1e-9)
            MS_norm_val = (n_AB / max(NA * NB, 1)) / denom_norm
            MS_norm = round(float(MS_norm_val), 4)
            rows.append({
                "type_a": a, "type_b": b,
                "n_AA": n_AA, "n_AB": n_AB,
                "MS": round(MS_raw, 4),
                "MS_norm": MS_norm,
            })
    return pd.DataFrame(rows)


def clark_evans_index(coords: np.ndarray,
                      area: float | None = None) -> dict:
    """Clark-Evans aggregation index R with asymptotic z-test."""
    coords = np.asarray(coords, float)
    n = len(coords)
    if area is None:
        bbox = coords.max(0) - coords.min(0)
        area = float(bbox[0] * bbox[1])
    tree = cKDTree(coords)
    nn_dists, _ = tree.query(coords, k=2)
    d_obs = nn_dists[:, 1].mean()
    lam = n / area
    d_exp = 1.0 / (2.0 * np.sqrt(lam))
    R = d_obs / d_exp
    se = np.sqrt((4 - np.pi) / (4 * np.pi * lam * n))
    z = (d_obs - d_exp) / se
    p = 2 * scipy_norm.sf(abs(z))
    return {"R": float(R), "d_obs": float(d_obs), "d_exp": float(d_exp),
            "z": float(z), "p": float(p), "n": int(n)}


def clark_evans_per_celltype(coords: np.ndarray, labels: np.ndarray,
                             area: float | None = None,
                             min_cells: int = 10,
                             types: list[str] | None = None) -> pd.DataFrame:
    """Per-cell-type Clark-Evans aggregation index.

    Parameters
    ----------
    types : optional ordered list of cell-type names.  When provided the
        output rows follow this order (matching the notebook's behaviour).
        When omitted, types are sorted alphabetically via ``np.unique``.
    """
    labels = np.asarray(labels).astype(str)
    if area is None:
        bbox = coords.max(0) - coords.min(0)
        area = float(bbox[0] * bbox[1])
    # Preserve caller-supplied order; fall back to alphabetical
    ordered_types = types if types is not None else list(np.unique(labels))
    rows = []
    for ct in ordered_types:
        mask = labels == ct
        P = coords[mask]
        if len(P) < min_cells:
            continue
        ce = clark_evans_index(P, area=area)
        ce["cell_type"] = ct
        rows.append(ce)
    return pd.DataFrame(rows).set_index("cell_type") if rows else pd.DataFrame()


def spiat_mixing_score(coords: np.ndarray, labels: np.ndarray,
                       k_neighbours: int = 15,
                       min_cells: int = 10) -> tuple[pd.DataFrame, pd.DataFrame]:
    """SPIAT mixing score (raw) and normalised mixing score."""
    labels = np.asarray(labels)
    unique_types, type_counts = np.unique(labels, return_counts=True)
    keep = unique_types[type_counts >= min_cells]
    n_types = len(keep)

    total = type_counts[np.isin(unique_types, keep)].sum()
    freq = {t: type_counts[unique_types == t][0] / total for t in keep}

    tree = cKDTree(coords)
    _, nbrs = tree.query(coords, k=min(k_neighbours + 1, len(coords)))
    nbrs = nbrs[:, 1:]

    MS = np.zeros((n_types, n_types))
    NMS = np.zeros((n_types, n_types))

    for ti, ta in enumerate(keep):
        mask_a = labels == ta
        if mask_a.sum() < min_cells:
            continue
        nbrs_a = nbrs[mask_a]
        for tj, tb in enumerate(keep):
            frac_b = np.array([np.mean(labels[nb] == tb) for nb in nbrs_a])
            MS[ti, tj] = frac_b.mean()
            NMS[ti, tj] = MS[ti, tj] / freq[tb] if freq[tb] > 0 else np.nan

    keep_list = list(keep)
    return (
        pd.DataFrame(MS, index=keep_list, columns=keep_list),
        pd.DataFrame(NMS, index=keep_list, columns=keep_list),
    )
