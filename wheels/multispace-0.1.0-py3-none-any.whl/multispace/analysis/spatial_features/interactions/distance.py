"""Distance-to-structure framework + intensity-vs-covariate rho-hat."""
from __future__ import annotations

import warnings

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from shapely.geometry import MultiPoint, Point
from sklearn.cluster import DBSCAN

from .. import config


def find_largest_dbscan_cluster(coords: np.ndarray, labels: np.ndarray,
                                target_label: str = config.EPI_TYPE,
                                eps: float = 80.0,
                                min_samples: int = 10) -> tuple:
    """Find the largest DBSCAN aggregate of `target_label` cells."""
    labels = np.asarray(labels)
    target_mask = labels == target_label
    target_pts = coords[target_mask]
    if target_mask.sum() < 10:
        raise ValueError(f"Only {target_mask.sum()} {target_label!r} cells — too few for DBSCAN.")

    db = DBSCAN(eps=eps, min_samples=min_samples).fit(target_pts)
    db_labels = db.labels_
    sizes = {lbl: (db_labels == lbl).sum()
             for lbl in set(db_labels) if lbl != -1}
    if not sizes:
        return None, None, None
    largest = max(sizes, key=sizes.get)
    largest_pts = target_pts[db_labels == largest]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        cluster_poly = MultiPoint(largest_pts).convex_hull.buffer(0)
    return largest_pts, cluster_poly, db_labels


def signed_distance(point_xy, polygon) -> float:
    """Signed distance from a point to the polygon boundary; negative if inside."""
    pt = Point(point_xy)
    d = pt.distance(polygon.boundary)
    return -d if polygon.contains(pt) else d


def signed_distances_to_polygon(coords: np.ndarray, polygon) -> np.ndarray:
    """Signed distance from every point in `coords` to the polygon boundary."""
    return np.array([signed_distance(p, polygon) for p in coords])


def shell_composition(signed_dists: np.ndarray, labels: np.ndarray,
                      shell_edges: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Cell-type composition fraction across signed-distance shells."""
    if shell_edges is None:
        shell_edges = np.linspace(-300, 500, 17)
    shell_mids = 0.5 * (shell_edges[:-1] + shell_edges[1:])
    labels = np.asarray(labels)
    types = np.unique(labels)
    M = np.zeros((len(shell_mids), len(types)))
    for s, (lo, hi) in enumerate(zip(shell_edges[:-1], shell_edges[1:])):
        mask = (signed_dists >= lo) & (signed_dists < hi)
        if mask.sum() == 0:
            continue
        for t, ct in enumerate(types):
            M[s, t] = (labels[mask] == ct).sum()
    rs = M.sum(axis=1, keepdims=True)
    rs[rs == 0] = 1
    return M / rs, shell_mids


def rhohat(coords_sub: np.ndarray, Z_vals_sub: np.ndarray,
           Z_grid: np.ndarray, n_bins: int = 20) -> tuple[np.ndarray, np.ndarray]:
    """Intensity-vs-covariate rho(z) (normalised to mean 1)."""
    bins = np.linspace(Z_grid.min(), Z_grid.max(), n_bins + 1)
    centers = 0.5 * (bins[:-1] + bins[1:])
    rho = np.zeros(n_bins)
    for b in range(n_bins):
        in_grid = ((Z_grid >= bins[b]) & (Z_grid < bins[b + 1])).sum()
        in_pts = ((Z_vals_sub >= bins[b]) & (Z_vals_sub < bins[b + 1])).sum()
        area_frac = in_grid / max(len(Z_grid), 1)
        rho[b] = in_pts / max(area_frac * len(coords_sub), 1e-9)
    rho = rho / max(rho.mean(), 1e-9)
    return centers, rho


def rhohat_per_celltype(coords: np.ndarray, labels: np.ndarray,
                        signed_dists: np.ndarray,
                        cluster_poly,
                        n_grid: int = 120, n_bins: int = 16) -> dict:
    """Compute rho-hat for each cell type using a regular grid evaluation of Z."""
    labels = np.asarray(labels)
    xs = np.linspace(coords[:, 0].min(), coords[:, 0].max(), n_grid)
    ys = np.linspace(coords[:, 1].min(), coords[:, 1].max(), n_grid)
    XX, YY = np.meshgrid(xs, ys)
    grid = np.column_stack([XX.ravel(), YY.ravel()])
    Z_grid = np.array([signed_distance(p, cluster_poly) for p in grid])

    out: dict = {}
    for ct in np.unique(labels):
        mask = labels == ct
        if mask.sum() < 5:
            continue
        Z_ct = signed_dists[mask]
        out[ct] = rhohat(coords[mask], Z_ct, Z_grid, n_bins=n_bins)
    return out
