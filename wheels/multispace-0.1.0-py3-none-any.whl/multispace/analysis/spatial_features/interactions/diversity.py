"""Compositional heterogeneity (CV) and local Shannon entropy."""
from __future__ import annotations

import networkx as nx
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import entropy as scipy_entropy

from .. import config
from ..io import prepare_adata_for_metrics
from ..weights import attach_graph_to_adata


def compute_intracore_cv(sdata, cluster_key: str = config.CLUSTER_KEY,
                         n_quadrats: int = 16) -> float:
    """Coefficient of variation of cell-type proportions across quadrats."""
    adata = prepare_adata_for_metrics(sdata, cluster_key)
    coords = adata.obsm["spatial"].astype(float)
    labels = adata.obs[cluster_key].cat.codes.values
    n_cats = adata.obs[cluster_key].cat.categories.nunique()

    side = int(np.sqrt(n_quadrats))
    x_min, y_min = coords.min(axis=0)
    x_max, y_max = coords.max(axis=0)
    xs = np.linspace(x_min, x_max, side + 1)
    ys = np.linspace(y_min, y_max, side + 1)
    proportions = np.full((side * side, n_cats), np.nan)
    q = 0
    for i in range(side):
        for j in range(side):
            in_q = (
                (coords[:, 0] >= xs[i]) & (coords[:, 0] < xs[i + 1])
                & (coords[:, 1] >= ys[j]) & (coords[:, 1] < ys[j + 1])
            )
            if in_q.sum() == 0:
                q += 1
                continue
            counts = np.bincount(labels[in_q], minlength=n_cats)
            proportions[q] = counts / counts.sum()
            q += 1
    valid = ~np.isnan(proportions).all(axis=1)
    if valid.sum() == 0:
        return float("nan")
    P = proportions[valid]
    cvs = np.where(P.mean(0) > 0, P.std(0) / P.mean(0), np.nan)
    return float(np.nanmean(cvs))


def intracore_cv_to_features(cv: float) -> dict:
    """Wrap intracore CV as a flat feature dict."""
    return {"intracore_cv": float(cv)}


def compute_local_entropy(sdata, graph: nx.Graph,
                          cluster_key: str = config.CLUSTER_KEY,
                          n_neighbors: int = config.N_NEIGHBORS_ENTROPY) -> pd.Series:
    """Per-cell Shannon entropy over neighbour cell-type composition."""
    adata = prepare_adata_for_metrics(sdata, cluster_key)
    attach_graph_to_adata(adata, graph)
    G = graph
    labels = adata.obs[cluster_key].cat.codes.values
    n_cats = adata.obs[cluster_key].cat.categories.nunique()
    n = len(labels)

    mean_degree = 2 * G.number_of_edges() / max(G.number_of_nodes(), 1)
    if mean_degree < 2.0:
        coords = adata.obsm["spatial"]
        tree = cKDTree(coords)
        ent = []
        for i in range(n):
            _, idx = tree.query(coords[i], k=n_neighbors + 1)
            counts = np.bincount(labels[idx[1:]], minlength=n_cats)
            probs = counts / counts.sum()
            ent.append(scipy_entropy(probs + 1e-10))
    else:
        ent = []
        for i in range(n):
            if i not in G or G.degree(i) == 0:
                ent.append(np.nan)
                continue
            neigh = [j for j in G.neighbors(i) if j < n]
            if not neigh:
                ent.append(np.nan)
                continue
            counts = np.bincount(labels[neigh], minlength=n_cats)
            probs = counts / counts.sum()
            ent.append(scipy_entropy(probs + 1e-10))
    return pd.Series(ent, index=adata.obs_names, name="local_entropy").dropna()


def entropy_to_features(entropy_series: pd.Series) -> dict:
    """Summarise per-cell entropy as core-level scalar features."""
    vals = entropy_series.values.astype(float)
    if len(vals) == 0:
        return {"entropy__mean": float("nan"),
                "entropy__median": float("nan"),
                "entropy__std": float("nan")}
    return {
        "entropy__mean": float(np.mean(vals)),
        "entropy__median": float(np.median(vals)),
        "entropy__std": float(np.std(vals)),
    }
