"""Neighbourhood enrichment and per-cell composition / co-occurrence."""
from __future__ import annotations

import networkx as nx
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from .. import config
from ..io import prepare_adata_for_metrics
from ..weights import attach_graph_to_adata

try:
    import squidpy as sq

    HAS_SQUIDPY = True
except ImportError:
    sq = None
    HAS_SQUIDPY = False


def compute_nhood_enrichment(sdata, graph: nx.Graph,
                             cluster_key: str = config.CLUSTER_KEY,
                             n_perms: int = config.N_PERMS_NHOOD) -> pd.DataFrame:
    """Squidpy neighbourhood enrichment z-score matrix on the disparity graph.

    Requires the optional ``squidpy`` dependency
    (``pip install spatial_features[squidpy]``).
    """
    if not HAS_SQUIDPY:
        raise ImportError(
            "compute_nhood_enrichment() requires the optional 'squidpy' package. "
            "Install it with: pip install spatial_features[squidpy]"
        )
    adata = prepare_adata_for_metrics(sdata, cluster_key)
    attach_graph_to_adata(adata, graph)

    sq.gr.nhood_enrichment(
        adata,
        cluster_key=cluster_key,
        n_perms=n_perms,
        n_jobs=1,
        show_progress_bar=False,
    )
    cats = adata.obs[cluster_key].cat.categories.tolist()
    z = pd.DataFrame(
        adata.uns[f"{cluster_key}_nhood_enrichment"]["zscore"],
        index=cats, columns=cats,
    )
    return z


def nhood_to_features(z: pd.DataFrame) -> dict:
    """Flatten the upper triangle of the z-score matrix into a flat feature dict."""
    cats = z.index.tolist()
    feats: dict = {}
    for i, a in enumerate(cats):
        for b in cats[i:]:
            feats[f"nhood__{a}__{b}"] = float(z.loc[a, b]) if pd.notna(z.loc[a, b]) else np.nan
    return feats


# ── Per-cell composition vectors and cellular neighbourhoods ─────────────────
def composition_vectors(coords: np.ndarray, labels_arr: np.ndarray,
                        unique_labels: np.ndarray, k: int = 8) -> np.ndarray:
    """Per-cell length-L composition vector over k nearest neighbours."""
    tree = cKDTree(coords)
    _, nbrs = tree.query(coords, k=k + 1)
    nbrs = nbrs[:, 1:]
    L = len(unique_labels)
    comp = np.zeros((len(coords), L))
    for i, row in enumerate(nbrs):
        for j in row:
            comp[i, labels_arr[j]] += 1
    comp /= k
    return comp


def select_k_by_information_criteria(comp: np.ndarray,
                                     k_max: int | None = None,
                                     seed: int = config.RANDOM_SEED) -> dict:
    """Run KMeans for k=2..k_max and return AIC, BIC, inertia."""
    rng_seed = seed
    n, d = comp.shape
    if k_max is None:
        k_max = min(13, d + 1)
    comp_scaled = StandardScaler().fit_transform(comp)
    ks = list(range(2, k_max))
    aics, bics, inertias = [], [], []
    for k in ks:
        km = KMeans(k, random_state=rng_seed, n_init=10).fit(comp_scaled)
        ssr = km.inertia_
        n_params = k * comp_scaled.shape[1]
        aics.append(n * np.log(ssr / n) + 2 * n_params)
        bics.append(n * np.log(ssr / n) + n_params * np.log(n))
        inertias.append(ssr)
    return {
        "ks": ks, "aics": aics, "bics": bics, "inertias": inertias,
        "best_k_bic": ks[int(np.argmin(bics))],
        "best_k_aic": ks[int(np.argmin(aics))],
    }


def cluster_cellular_neighborhoods(comp: np.ndarray, k: int,
                                   seed: int = config.RANDOM_SEED) -> np.ndarray:
    """KMeans cluster of composition vectors → cellular neighbourhood labels."""
    return KMeans(k, random_state=seed, n_init=10).fit_predict(comp)


def cooccurrence_zscore(labels_arr: np.ndarray, nbrs: np.ndarray,
                        L: int, n_perm: int = 80,
                        seed: int = config.RANDOM_SEED) -> np.ndarray:
    """Permutation z-score of neighbour co-occurrence counts."""
    obs = np.zeros((L, L))
    for i, row in enumerate(nbrs):
        a = labels_arr[i]
        for j in row:
            obs[a, labels_arr[j]] += 1
    rng = np.random.default_rng(seed)
    perm = np.zeros((n_perm, L, L))
    for p in range(n_perm):
        sh = labels_arr.copy()
        rng.shuffle(sh)
        for i, row in enumerate(nbrs):
            a = sh[i]
            for j in row:
                perm[p, a, sh[j]] += 1
    mu = perm.mean(0)
    sd = perm.std(0) + 1e-9
    return (obs - mu) / sd


# ── Co-occurrence z-score (notebook Cell 204 API) ─────────────────────────────
def cooccur(labels: "np.ndarray", nbrs: "np.ndarray",
            L: int, n_perm: int = 100,
            seed: int = 0) -> "np.ndarray":
    """Permutation-based co-occurrence z-score matrix.

    Matches the notebook's Cell 204 ``cooccur`` function exactly.

    Parameters
    ----------
    labels : (n_cells,) integer label array (0-indexed)
    nbrs   : (n_cells, k) integer neighbour-index array (from cKDTree)
    L      : number of unique cell types
    n_perm : number of label-shuffle permutations
    seed   : random seed

    Returns
    -------
    Z : (L, L) z-score matrix  (positive = co-enriched, negative = co-depleted)
    """
    import numpy as np

    obs = np.zeros((L, L))
    for i, row in enumerate(nbrs):
        a = labels[i]
        for j in row:
            obs[a, labels[j]] += 1

    rng_ = np.random.default_rng(seed)
    perm = np.zeros((n_perm, L, L))
    for p in range(n_perm):
        sh = labels.copy()
        rng_.shuffle(sh)
        for i, row in enumerate(nbrs):
            a = sh[i]
            for j in row:
                perm[p, a, sh[j]] += 1

    mu = perm.mean(0)
    sd = perm.std(0) + 1e-9
    return (obs - mu) / sd
