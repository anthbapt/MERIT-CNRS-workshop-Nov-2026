"""Directional / anisotropic pair correlation function g(r, θ)."""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree


def directional_pcf(A: np.ndarray, B: np.ndarray,
                    support: np.ndarray, roi_poly,
                    n_angle_bins: int = 8,
                    annulus_width: float | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Directional pair correlation function g(r, θ) by angular sectors."""
    if annulus_width is None:
        annulus_width = support[1] - support[0] if len(support) > 1 else support[0]

    n_A, n_B = len(A), len(B)
    area = roi_poly.area
    lam_B = n_B / area

    angle_edges = np.linspace(-np.pi, np.pi, n_angle_bins + 1)
    angle_centres = 0.5 * (angle_edges[:-1] + angle_edges[1:])

    tree = cKDTree(B)
    g_dir = np.zeros((n_angle_bins, len(support)))

    for k, r_mid in enumerate(support):
        r_inner = max(0.0, r_mid - annulus_width / 2)
        r_outer = r_mid + annulus_width / 2
        annulus_area = np.pi * (r_outer ** 2 - r_inner ** 2)
        sector_area = annulus_area / n_angle_bins
        expected = n_A * lam_B * sector_area

        outer_idx = tree.query_ball_point(A, r_outer)
        inner_idx = tree.query_ball_point(A, r_inner)
        sector_counts = np.zeros(n_angle_bins)

        for i in range(n_A):
            in_annulus = np.setdiff1d(outer_idx[i], inner_idx[i])
            if len(in_annulus) == 0:
                continue
            dx = B[in_annulus, 0] - A[i, 0]
            dy = B[in_annulus, 1] - A[i, 1]
            angles_ij = np.arctan2(dy, dx)
            bin_idx = np.clip(np.digitize(angles_ij, angle_edges) - 1,
                              0, n_angle_bins - 1)
            for b in bin_idx:
                sector_counts[b] += 1

        g_dir[:, k] = sector_counts / expected if expected > 0 else np.nan

    return g_dir, angle_centres


def anisotropy_index(g_dir: np.ndarray,
                     angle_centres: np.ndarray) -> tuple[float, float]:
    """Return (anisotropy_index = max/min, preferred_angle in degrees)."""
    g_mean_angle = np.nanmean(g_dir, axis=1)
    aniso = (g_mean_angle.max() / g_mean_angle.min()
             if g_mean_angle.min() > 0 else float("nan"))
    pref_angle = float(np.degrees(angle_centres[np.argmax(g_mean_angle)]))
    return float(aniso), pref_angle
