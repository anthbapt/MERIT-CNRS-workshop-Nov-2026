"""CSR diagnostics: Hopkins-Skellam and quadrat tests."""
from __future__ import annotations

import numpy as np
from scipy.spatial import cKDTree
from pointpats import PointPattern, QStatistic
from pointpats import random as pp_random
from shapely.geometry import box, Point

from .. import config


def hopkins_skellam(
    coords: np.ndarray,
    n_iter: int = config.HOPKINS_N_ITER,
    m_frac: float = config.HOPKINS_M_FRAC,
    seed: int = config.RANDOM_SEED,
) -> np.ndarray:
    """Hopkins-Skellam clustering statistic.

    H ~ 0.5 -> CSR, > 0.75 -> strong clustering, < 0.25 -> regularity.
    Returns the array of `n_iter` H-values.
    """
    coords = np.asarray(coords, float)
    n = len(coords)
    m = max(int(m_frac * n), 5)
    bbox = np.column_stack([coords.min(0), coords.max(0)])
    rng = np.random.default_rng(seed)
    tree = cKDTree(coords)
    H = []
    for _ in range(n_iter):
        rnd = np.column_stack(
            [rng.uniform(bbox[d, 0], bbox[d, 1], m) for d in range(2)]
        )
        u = tree.query(rnd, k=1)[0]
        idx = rng.choice(n, m, replace=False)
        w = tree.query(coords[idx], k=2)[0][:, 1]
        H.append(u.sum() / (u.sum() + w.sum()))
    return np.array(H)


def quadrat_statistic(
    coords: np.ndarray,
    nx: int = config.QUADRAT_NX,
    ny: int = config.QUADRAT_NY,
) -> QStatistic:
    """Pointpats QStatistic on a 2D point pattern with `nx` x `ny` quadrats."""
    coords = np.asarray(coords, float)
    return QStatistic(coords, nx=nx, ny=ny)


def quadrat_counts(
    coords: np.ndarray, nx: int = config.QUADRAT_NX, ny: int = config.QUADRAT_NY
) -> dict:
    """Build the histogram of quadrat counts that underlies the chi-square
    quadrat test."""
    xy = np.asarray(coords, float)
    xmin, ymin = xy.min(0)
    xmax, ymax = xy.max(0)
    xedges = np.linspace(xmin, xmax, nx + 1)
    yedges = np.linspace(ymin, ymax, ny + 1)
    counts, _, _ = np.histogram2d(xy[:, 0], xy[:, 1], bins=[xedges, yedges])
    return {"counts": counts, "xedges": xedges, "yedges": yedges}


def csr_random_pattern(window, size: int, seed: int = config.RANDOM_SEED):
    """Generate a CSR Poisson pattern of `size` points inside `window`
    (a Shapely geometry)."""
    rng = np.random.default_rng(seed)
    # `pp_random.poisson` does not accept a seed argument in older versions,
    # so we pre-seed the global RNG state for reproducibility where possible.
    np.random.seed(int(rng.integers(0, 2**31 - 1)))
    return pp_random.poisson(window, size=size)


def quadrat_in_subwindow(
    coords: np.ndarray,
    target_coords: np.ndarray,
    alpha_shape_geom,
    epi_coords: np.ndarray,
    fraction: float = 0.30,
    nx: int = 5,
    ny: int = 5,
    seed: int = config.RANDOM_SEED,
) -> dict:
    """Run the rectangle-in-the-middle quadrat test.

    A central rectangle covering `fraction` of the bounding-box extent on each
    side is drawn. CSR Poisson points are simulated inside the alpha-shape and
    real `epi_coords` are filtered into the rectangle. The two QStatistic
    objects are returned together with the rectangle and counts.
    """
    coords = np.asarray(coords, float)
    epi_coords = np.asarray(epi_coords, float)

    xmin_full, ymin_full = coords.min(0)
    xmax_full, ymax_full = coords.max(0)
    cx = (xmin_full + xmax_full) / 2
    cy = (ymin_full + ymax_full) / 2
    half = fraction / 2
    hx = half * (xmax_full - xmin_full)
    hy = half * (ymax_full - ymin_full)
    xmin, xmax = cx - hx, cx + hx
    ymin, ymax = cy - hy, cy + hy

    rectangle = box(xmin, ymin, xmax, ymax)

    random_pattern = csr_random_pattern(
        alpha_shape_geom, size=len(target_coords), seed=seed
    )
    random_in_rect = np.array(
        [p for p in random_pattern if rectangle.contains(Point(p))]
    )

    in_rect = (
        (epi_coords[:, 0] >= xmin) & (epi_coords[:, 0] <= xmax)
        & (epi_coords[:, 1] >= ymin) & (epi_coords[:, 1] <= ymax)
    )
    epi_in_rectangle = epi_coords[in_rect]
    epi_pattern_rect = np.array(
        [p for p in epi_in_rectangle if rectangle.contains(Point(p))]
    )

    qstat_null = QStatistic(PointPattern(random_in_rect), nx=nx, ny=ny)
    qstat_epi = QStatistic(PointPattern(epi_pattern_rect), nx=nx, ny=ny)

    return {
        "rectangle": rectangle,
        "rectangle_bounds": (xmin, ymin, xmax, ymax),
        "random_in_rect": random_in_rect,
        "epi_in_rect": epi_pattern_rect,
        "qstat_null": qstat_null,
        "qstat_epi": qstat_epi,
        "pvalue_null": float(qstat_null.chi2_pvalue),
        "pvalue_epi": float(qstat_epi.chi2_pvalue),
    }
