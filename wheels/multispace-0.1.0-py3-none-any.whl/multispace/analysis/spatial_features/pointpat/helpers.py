"""Shared helper utilities for point-pattern analyses."""
from __future__ import annotations

import numpy as np
import pandas as pd
import networkx as nx

from .. import config


def _filter_to_palette(labels: pd.Series) -> pd.Series:
    """Keep only cells whose label is in CELL_TYPE_PALETTE."""
    s = labels.astype(str)
    s = s[s.isin(config.ALLOWED_CELL_TYPES)]
    return s.astype("category")


def _ripley_edge_weights_analytical(pts, D, x_min, x_max, y_min, y_max):
    """
    Exact analytical isotropic edge-correction weights (Haase 1995).
    For each (i,j) pair, returns the proportion of the circumference of a
    circle centred at pts[i] with radius D[i,j] that lies inside the bbox.
    """
    d_l = pts[:, 0] - x_min
    d_r = x_max - pts[:, 0]
    d_b = pts[:, 1] - y_min
    d_t = y_max - pts[:, 1]

    def side_arc(d_side, D):
        d = d_side[:, np.newaxis]
        ratio = np.clip(np.where(d < D, d / D, 1.0), -1.0, 1.0)
        return np.where(d < D, 2.0 * np.arccos(ratio), 0.0)

    total_clipped = (
        side_arc(d_l, D) + side_arc(d_r, D)
        + side_arc(d_b, D) + side_arc(d_t, D)
    )

    def corner_arc_lb(d_a, d_b, D):
        da = d_a[:, np.newaxis]; db = d_b[:, np.newaxis]
        mask = (da < D) & (db < D)
        r = np.where(mask, D, 1.0)
        asin_a = np.arcsin(np.clip(da / r, -1, 1))
        asin_b = np.arcsin(np.clip(db / r, -1, 1))
        start = np.maximum(np.pi / 2 + asin_a, np.pi + asin_b)
        end = np.minimum(3 * np.pi / 2 - asin_a, 2 * np.pi - asin_b)
        return np.where(mask, np.maximum(0.0, end - start), 0.0)

    def corner_arc_lt(d_a, d_b, D):
        da = d_a[:, np.newaxis]; db = d_b[:, np.newaxis]
        mask = (da < D) & (db < D)
        r = np.where(mask, D, 1.0)
        asin_a = np.arcsin(np.clip(da / r, -1, 1))
        asin_b = np.arcsin(np.clip(db / r, -1, 1))
        start = np.maximum(np.pi / 2 + asin_a, asin_b)
        end = np.minimum(3 * np.pi / 2 - asin_a, np.pi - asin_b)
        return np.where(mask, np.maximum(0.0, end - start), 0.0)

    def corner_arc_rb(d_a, d_b, D):
        da = d_a[:, np.newaxis]; db = d_b[:, np.newaxis]
        mask = (da < D) & (db < D)
        r = np.where(mask, D, 1.0)
        asin_a = np.arcsin(np.clip(da / r, -1, 1))
        asin_b = np.arcsin(np.clip(db / r, -1, 1))
        start = 3 * np.pi / 2 + asin_a
        end = 2 * np.pi - asin_b
        return np.where(mask, np.maximum(0.0, end - start), 0.0)

    def corner_arc_rt(d_a, d_b, D):
        da = d_a[:, np.newaxis]; db = d_b[:, np.newaxis]
        mask = (da < D) & (db < D)
        r = np.where(mask, D, 1.0)
        asin_a = np.arcsin(np.clip(da / r, -1, 1))
        asin_b = np.arcsin(np.clip(db / r, -1, 1))
        start = asin_b
        end = np.pi / 2 - asin_a
        return np.where(mask, np.maximum(0.0, end - start), 0.0)

    total_clipped -= (
        corner_arc_lb(d_l, d_b, D)
        + corner_arc_lt(d_l, d_t, D)
        + corner_arc_rb(d_r, d_b, D)
        + corner_arc_rt(d_r, d_t, D)
    )

    return np.clip((2.0 * np.pi - total_clipped) / (2.0 * np.pi), 1e-6, 1.0)


def _graph_topology(G: nx.Graph) -> dict:
    """
    Compute three topological descriptors for a single graph:
      - average_clustering
      - average_shortest_path_length  (component-size weighted)
      - degree_assortativity_coefficient
    Returns a dict; values are NaN on failure.
    """
    avg_clustering = avg_shortest_path = assortativity = float("nan")
    try:
        if G is None or G.number_of_nodes() == 0:
            return {
                "average_clustering": np.nan,
                "average_shortest_path_length": np.nan,
                "degree_assortativity_coefficient": np.nan,
            }

        avg_clustering = nx.average_clustering(G)

        n_total = G.number_of_nodes()
        avg_shortest_path = 0.0
        for comp in nx.connected_components(G):
            sg = G.subgraph(comp).copy()
            if sg.number_of_nodes() < 2:
                continue
            avg_shortest_path += (sg.number_of_nodes() / n_total) * \
                nx.average_shortest_path_length(sg)

        assortativity = nx.degree_assortativity_coefficient(G)
    except Exception:
        pass

    return {
        "average_clustering": avg_clustering,
        "average_shortest_path_length": avg_shortest_path,
        "degree_assortativity_coefficient": assortativity,
    }
