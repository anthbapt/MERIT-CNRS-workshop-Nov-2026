"""Ripley summary functions (G, F, J, K, L) and CSR envelopes."""
from __future__ import annotations

import numpy as np
from pointpats import distance_statistics

from .. import config


def _pack(test) -> dict:
    """Standardise the dict returned by the wrappers below."""
    out = {
        "support": np.asarray(test.support),
        "statistic": np.asarray(test.statistic),
        "simulations": (
            np.asarray(test.simulations) if test.simulations is not None
            else None
        ),
        "pvalue": getattr(test, "pvalue", None),
    }
    return out


def ripley_g(
    coords: np.ndarray,
    support=config.RIPLEY_SUPPORT,
    keep_simulations: bool = True,
) -> dict:
    """Ripley's G (nearest-neighbour distribution) with CSR simulations."""
    coords = np.asarray(coords, float)
    test = distance_statistics.g_test(
        coords, support=support, keep_simulations=keep_simulations
    )
    return _pack(test)


def ripley_f(
    coords: np.ndarray,
    support=config.RIPLEY_SUPPORT,
    keep_simulations: bool = True,
) -> dict:
    """Ripley's F (empty-space) function with CSR simulations."""
    coords = np.asarray(coords, float)
    test = distance_statistics.f_test(
        coords, support=support, keep_simulations=keep_simulations
    )
    return _pack(test)


def ripley_j(
    coords: np.ndarray,
    support=config.RIPLEY_SUPPORT,
    keep_simulations: bool = True,
    eps: float = 1e-6,
    f_cutoff: float = 0.95,
) -> dict:
    """Ripley's J = (1 - G) / (1 - F).

    Returns the observed J, the simulated J envelope, and a boolean mask
    `valid` where F_obs < `f_cutoff` (the reliable region).
    """
    coords = np.asarray(coords, float)
    g_test = distance_statistics.g_test(
        coords, support=support, keep_simulations=keep_simulations
    )
    f_test = distance_statistics.f_test(
        coords, support=support, keep_simulations=keep_simulations
    )

    if not np.allclose(g_test.support, f_test.support):
        raise ValueError("G and F support grids differ - cannot compute J.")

    r_j = np.asarray(f_test.support)
    G_obs = np.asarray(g_test.statistic)
    F_obs = np.asarray(f_test.statistic)

    J_obs = (1 - G_obs) / (1 - F_obs + eps)
    if g_test.simulations is not None and f_test.simulations is not None:
        J_sims = (1 - np.asarray(g_test.simulations)) / (
            1 - np.asarray(f_test.simulations) + eps
        )
    else:
        J_sims = None

    valid = F_obs < f_cutoff

    return {
        "support": r_j,
        "statistic": J_obs,
        "simulations": J_sims,
        "valid": valid,
        "g_statistic": G_obs,
        "f_statistic": F_obs,
    }


def ripley_k(
    coords: np.ndarray,
    support=config.RIPLEY_SUPPORT,
    keep_simulations: bool = True,
) -> dict:
    """Ripley's K function with CSR simulations."""
    coords = np.asarray(coords, float)
    test = distance_statistics.k_test(
        coords, support=support, keep_simulations=keep_simulations
    )
    return _pack(test)


def ripley_l(
    coords: np.ndarray,
    support=config.RIPLEY_SUPPORT,
    keep_simulations: bool = True,
) -> dict:
    """Besag's L = sqrt(K / pi). Centred form `L(r) - r` is also returned."""
    coords = np.asarray(coords, float)
    k_test = distance_statistics.k_test(
        coords, support=support, keep_simulations=keep_simulations
    )
    r = np.asarray(k_test.support)
    L_obs = np.sqrt(np.asarray(k_test.statistic) / np.pi)
    if k_test.simulations is not None:
        L_sim = np.sqrt(np.asarray(k_test.simulations) / np.pi)
    else:
        L_sim = None

    return {
        "support": r,
        "statistic": L_obs,
        "simulations": L_sim,
        "centered_statistic": L_obs - r,
        "centered_simulations": (L_sim - r if L_sim is not None else None),
    }


# ── Backward-compat: closure-style points_of_type factory ────────────────────
def make_points_of_type(coords: np.ndarray, labels_arr: np.ndarray,
                        unique_labels: np.ndarray,
                        sub_cap: int = 600,
                        seed: int = config.RANDOM_SEED):
    """Return a closure ``points_of_type(t)`` matching the notebook's API.

    The notebook defines ``points_of_type`` as a closure that captures
    ``pts``, ``labels_arr``, ``unique_labels``, and ``SUB_CAP`` from the
    enclosing scope.  This factory recreates that pattern so package users
    can write::

        points_of_type = make_points_of_type(coords, labels_arr, unique_labels)
        P_epi = points_of_type("Epithelial")
    """
    rng = np.random.default_rng(seed)

    def points_of_type(t: str) -> np.ndarray:
        mask = unique_labels[labels_arr] == t
        P = coords[mask]
        if len(P) > sub_cap:
            idx = rng.choice(len(P), size=sub_cap, replace=False)
            P = P[idx]
        return P

    return points_of_type
