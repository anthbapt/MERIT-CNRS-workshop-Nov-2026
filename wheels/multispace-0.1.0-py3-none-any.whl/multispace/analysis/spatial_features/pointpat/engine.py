"""Per-cell-type and all-pairs Ripley engine.

Wraps `compute_ripley` for L(r) with analytical isotropic edge correction,
plus the all-pairs cross-K AUC summaries and the dL/dr derivative analysis.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from pointpats import distance_statistics
from scipy.ndimage import gaussian_filter1d
from scipy.spatial import cKDTree
from scipy.spatial.distance import cdist

from .. import config
from ..io import prepare_adata_for_metrics
from .helpers import _ripley_edge_weights_analytical


# ── Per-cell-type L(r) with analytical edge correction ───────────────────────
def compute_ripley(sdata, cluster_key: str = config.CLUSTER_KEY,
                   radii=config.RIPLEY_RADII, n_bins: int = 40,
                   r_max: float = 200.0, min_cells: int = 30) -> dict:
    """Per-cell-type L(r) with exact analytical isotropic edge correction.

    Returns ``{cell_type: {"bins", "L", "L_minus_r"}}``.
    """
    R_BINS = np.linspace(0, r_max, n_bins)

    adata = prepare_adata_for_metrics(sdata, cluster_key)
    coords = adata.obsm["spatial"].astype(float)
    labels = adata.obs[cluster_key]

    x_min, y_min = coords.min(axis=0)
    x_max, y_max = coords.max(axis=0)
    area = max((x_max - x_min) * (y_max - y_min), 1.0)

    results: dict = {}
    for ct in labels.cat.categories:
        mask = (labels == ct).values
        pts = coords[mask]
        n_ct = len(pts)
        if n_ct < min_cells:
            continue

        D = cdist(pts, pts)
        np.fill_diagonal(D, np.inf)
        w_mat = _ripley_edge_weights_analytical(pts, D, x_min, x_max, y_min, y_max)
        denom = float(n_ct * (n_ct - 1))
        D_flat = D.ravel()
        w_flat = w_mat.ravel()
        order = np.argsort(D_flat)
        D_sorted = D_flat[order]
        inv_w_sort = (1.0 / w_flat)[order]
        cum_inv_w = np.concatenate([[0.0], np.cumsum(inv_w_sort)])
        idx = np.searchsorted(D_sorted, R_BINS, side="right")
        K_vals = (area / denom) * cum_inv_w[idx]
        L_vals = np.sqrt(np.maximum(K_vals / np.pi, 0.0))
        L_vals[R_BINS == 0] = 0.0

        results[ct] = {
            "bins": R_BINS.copy(),
            "L": L_vals,
            "L_minus_r": L_vals - R_BINS,
        }
    return results


def ripley_to_features(ripley_results: dict,
                       radii=config.RIPLEY_RADII) -> dict:
    """Scalar features from L(r)−r at fixed radii + the per-type peak."""
    feats: dict = {}
    for ct, data in ripley_results.items():
        bins = data["bins"]
        L_minus_r = data["L_minus_r"]
        L_at = np.interp(radii, bins, L_minus_r)
        for r, val in zip(radii, L_at):
            feats[f"ripley__{ct}__r{int(r)}"] = float(val)
        feats[f"ripley_peak__{ct}"] = (
            float(np.max(L_minus_r[1:])) if len(L_minus_r) > 1 else np.nan
        )
    return feats


# ── Per-type Ripley K/G/F/J/L/pcf via pointpats ──────────────────────────────
def points_of_type(coords: np.ndarray, labels_arr: np.ndarray,
                   unique_labels: np.ndarray, t: str,
                   sub_cap: int = 5000,
                   seed: int = config.RANDOM_SEED) -> np.ndarray:
    """Return the (subsampled) point set for a single cell type."""
    rng = np.random.default_rng(seed)
    P = coords[unique_labels[labels_arr] == t]
    if len(P) > sub_cap:
        P = P[rng.choice(len(P), sub_cap, replace=False)]
    return P


def ripley_set(P: np.ndarray, support: np.ndarray) -> dict:
    """Compute K, G, F, L, J, pcf for a single point set."""
    out: dict = {}
    out["K"] = distance_statistics.k_test(P, support=support, keep_simulations=False).statistic
    out["G"] = distance_statistics.g_test(P, support=support, keep_simulations=False).statistic
    out["F"] = distance_statistics.f_test(P, support=support, keep_simulations=False).statistic
    out["L"] = np.sqrt(np.asarray(out["K"]) / np.pi) - support
    G = np.asarray(out["G"])
    F = np.asarray(out["F"])
    out["J"] = (1 - G) / (1 - F + 1e-12)
    r = np.asarray(support)
    K = np.asarray(out["K"])
    with np.errstate(divide="ignore", invalid="ignore"):
        out["pcf"] = np.gradient(K, r) / (2 * np.pi * np.where(r > 0, r, np.nan))
    return out


def per_type_ripley_set(coords: np.ndarray, labels_arr: np.ndarray,
                        unique_labels: np.ndarray, top_types: list[str],
                        support: np.ndarray, min_cells: int = 30,
                        sub_cap: int = 5000) -> dict:
    """Run `ripley_set` for every cell type in `top_types`."""
    out: dict = {}
    for t in top_types:
        P = points_of_type(coords, labels_arr, unique_labels, t, sub_cap)
        if len(P) < min_cells:
            continue
        try:
            out[t] = ripley_set(P, support)
        except Exception as e:
            print(f"Skipping {t}: {e}")
    return out


# ── All-pairs cross-K (uncorrected) + AUC ────────────────────────────────────
def cross_k_simple(A: np.ndarray, B: np.ndarray,
                   support: np.ndarray, area: float) -> np.ndarray:
    """Uncorrected cross-K = area / (n_A·n_B) · Σ_i #{j ∈ B: d_ij ≤ r}."""
    t = cKDTree(B)
    n_A, n_B = len(A), len(B)
    return np.array([
        t.query_ball_point(A, r, return_length=True).sum()
        for r in support
    ]) * area / (n_A * n_B)


def all_pairs_cross_k(P_by_type: dict[str, np.ndarray],
                      types: list[str], support: np.ndarray,
                      area: float, min_cells: int = 30) -> tuple[np.ndarray, np.ndarray]:
    """All-pairs uncorrected cross-K + AUC matrix relative to πr²."""
    N = len(types)
    crossK = np.full((N, N, len(support)), np.nan)
    auc_K = np.full((N, N), np.nan)
    for i, a in enumerate(types):
        A = P_by_type[a]
        if len(A) < min_cells:
            continue
        for j, b in enumerate(types):
            if i == j:
                continue
            B = P_by_type[b]
            if len(B) < min_cells:
                continue
            K_ab = cross_k_simple(A, B, support, area)
            crossK[i, j] = K_ab
            auc_K[i, j] = np.trapz(K_ab - np.pi * support ** 2, support)
    return crossK, auc_K


# ── Cross-K scalar summaries (AUC + crossing radius r*) ──────────────────────
def cross_k_summary(K_obs: np.ndarray, support: np.ndarray) -> tuple[float, float]:
    """Return (AUC of K - πr², crossing radius r*) for one curve."""
    csr = np.pi * support ** 2
    diff = K_obs - csr
    auc = float(np.trapz(diff, support))
    sign = np.sign(diff)
    nz = np.where(np.abs(diff) > 1e-9)[0]
    r_star = np.nan
    if nz.size > 1:
        s0 = sign[nz[0]]
        for idx in nz[1:]:
            if sign[idx] != s0 and sign[idx] != 0:
                r0, r1 = support[idx - 1], support[idx]
                d0, d1 = diff[idx - 1], diff[idx]
                r_star = float(r0 - d0 * (r1 - r0) / (d1 - d0))
                break
    return auc, r_star


def cross_k_summaries(crossK: np.ndarray, support: np.ndarray,
                      types: list[str]) -> pd.DataFrame:
    """Build (type_a, type_b, AUC, r*, interaction) rows for every pair."""
    rows = []
    for i, a in enumerate(types):
        for j, b in enumerate(types):
            if i == j or np.isnan(crossK[i, j]).all():
                continue
            auc, rstar = cross_k_summary(crossK[i, j], support)
            rows.append({
                "type_a": a, "type_b": b,
                "AUC": round(auc, 1),
                "r_star": round(rstar, 1) if not np.isnan(rstar) else np.nan,
                "interaction": "attraction" if auc > 0 else "repulsion",
            })
    return pd.DataFrame(rows).sort_values("AUC", ascending=False)


# ── dL/dr (derivative-based PCF) ─────────────────────────────────────────────
def compute_dL_dr(ripley_per_type: dict,
                  sigma_smooth: float = 1.5,
                  eps: float = 1e-10) -> dict:
    """For each cell type, compute dL/dr and a g(r) derived from it."""
    out: dict = {}
    for t, vals in ripley_per_type.items():
        L = np.asarray(vals["L"])
        K = np.asarray(vals["K"])
        # support is implicit as L's index; reconstruct from K via K = π(L+r)²
        # but it's easier to demand it from ripley_set's caller. Use np.arange.
        r = np.arange(len(L), dtype=float)
        L_sm = gaussian_filter1d(L, sigma=sigma_smooth)
        K_sm = gaussian_filter1d(K, sigma=sigma_smooth)
        dL_dr = np.gradient(L_sm, r)
        g_from_dL = np.where(r > 0,
                             (1.0 + dL_dr) ** 2 - 1.0,
                             np.nan)
        out[t] = {"r": r, "dL_dr": dL_dr, "g_from_dL": g_from_dL,
                  "K_smoothed": K_sm}
    return out
