"""Cross-functions for multitype point patterns.

Cross-G, Cross-J, Cross-K (uncorrected and Ripley isotropic edge-corrected),
and inhomogeneous cross-K / cross-PCF.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import gaussian_kde
from shapely.geometry import Point

from .. import config


# ── Cross-G ───────────────────────────────────────────────────────────────────
def cross_g(coords_a: np.ndarray, coords_b: np.ndarray,
            r: np.ndarray, n_sim: int = 100,
            window_min=None, window_max=None,
            seed: int = config.RANDOM_SEED) -> dict:
    """Empirical Cross-G_AB(r): nearest-neighbour distribution from A to B."""
    rng = np.random.default_rng(seed)
    tree_b = cKDTree(coords_b)
    dist_ab, _ = tree_b.query(coords_a, k=1)
    g_obs = np.array([(dist_ab <= ri).mean() for ri in r])

    # Default simulation window matches the notebook (cell 118):
    # ``[coords_a.min, coords_b.max]`` per axis. Override via window_min /
    # window_max if a different observation window is required.
    if window_min is None:
        window_min = coords_a.min(axis=0)
    if window_max is None:
        window_max = coords_b.max(axis=0)

    g_sim = []
    for _ in range(n_sim):
        rand_b = rng.uniform(window_min, window_max, size=coords_b.shape)
        tree_rb = cKDTree(rand_b)
        dist = tree_rb.query(coords_a, k=1)[0]
        g_sim.append([(dist <= ri).mean() for ri in r])
    return {"r": r, "g_obs": g_obs, "g_sim": np.array(g_sim)}


# ── Cross-J helpers + cross-J ─────────────────────────────────────────────────
def compute_F(target: np.ndarray, window: np.ndarray,
              r: np.ndarray, n_sim: int = 100,
              seed: int = config.RANDOM_SEED) -> np.ndarray:
    """Empty-space function F(r) for `target` evaluated against `window`."""
    rng = np.random.default_rng(seed)
    tree = cKDTree(target)
    F_sims = []
    for _ in range(n_sim):
        rand = rng.uniform(window.min(axis=0), window.max(axis=0),
                           size=(len(target), 2))
        dist = tree.query(rand, k=1)[0]
        F_sims.append([(dist <= ri).mean() for ri in r])
    return np.array(F_sims)


def cross_j(coords_a: np.ndarray, coords_b: np.ndarray,
            r: np.ndarray, window: np.ndarray | None = None,
            n_sim: int = 100, eps: float = 1e-10,
            seed: int = config.RANDOM_SEED) -> dict:
    """Cross-J_AB(r) = (1 - G_AB(r)) / (1 - F_B(r))."""
    if window is None:
        window = np.vstack([coords_a, coords_b])
    tree_b = cKDTree(coords_b)
    dist_ab = tree_b.query(coords_a, k=1)[0]
    G_ab = np.array([(dist_ab <= ri).mean() for ri in r])
    F_sims = compute_F(coords_b, window, r, n_sim=n_sim, seed=seed)
    J_sims = (1 - G_ab) / (1 - F_sims + eps)
    J_ab = np.mean(J_sims, axis=0)
    return {"r": r, "J_ab": J_ab, "J_sims": J_sims, "G_ab": G_ab}


# ── Cross-K (uncorrected) ─────────────────────────────────────────────────────
def cross_k(coords_a: np.ndarray, coords_b: np.ndarray,
            r: np.ndarray, area: float | None = None,
            n_sim: int = 100, window_coords: np.ndarray | None = None,
            seed: int = 42) -> dict:
    """Standard Cross-K(r) with uniform CSR envelope.

    K_AB(r) = area / (n_A * n_B) * Σ_i #{j ∈ B: d(i,j) ≤ r}.
    """
    rng = np.random.default_rng(seed)
    if area is None:
        full = np.vstack([coords_a, coords_b])
        area = float((full.max(axis=0) - full.min(axis=0)).prod())

    n_A, n_B = len(coords_a), len(coords_b)
    lam_b = n_B / area
    tree_b = cKDTree(coords_b)
    K_ab = np.array([
        tree_b.query_ball_point(coords_a, ri, return_length=True).sum()
        / (n_A * lam_b)
        for ri in r
    ])

    # Notebook (cell 126) simulates B uniformly over the full tissue bounding
    # box; pass ``window_coords=ctx.coords`` to reproduce that. Fallback uses
    # the A∪B bbox.
    if window_coords is None:
        window_coords = np.vstack([coords_a, coords_b])
    sim_min = window_coords.min(axis=0)
    sim_max = window_coords.max(axis=0)
    K_sim = []
    for _ in range(n_sim):
        rand_b = rng.uniform(sim_min, sim_max, size=(n_B, 2))
        tree_rb = cKDTree(rand_b)
        sim = np.array([
            tree_rb.query_ball_point(coords_a, ri, return_length=True).sum()
            / (n_A * lam_b)
            for ri in r
        ])
        K_sim.append(sim)
    return {"r": r, "K_ab": K_ab, "K_sim": np.array(K_sim), "area": area}


# ── Cross-K with Ripley isotropic edge correction ─────────────────────────────
def _edge_weights(pts_A: np.ndarray, roi_poly, r: float) -> np.ndarray:
    """Ripley isotropic edge-correction weights for each point in pts_A at r."""
    pi_r2 = np.pi * r * r
    if pi_r2 == 0:
        return np.ones(len(pts_A))
    w = np.array([
        Point(p).buffer(r, resolution=32).intersection(roi_poly).area / pi_r2
        for p in pts_A
    ])
    return np.clip(w, 1e-6, 1.0)


def cross_k_isotropic(A: np.ndarray, B: np.ndarray,
                      support: np.ndarray, roi_poly) -> np.ndarray:
    """Edge-corrected Cross-K (Ripley isotropic) over a shapely ROI polygon.

    K_AB(r) = (area / n_A·n_B) · Σ_i [ #{j ∈ B: d_ij ≤ r} / w_i(r) ].
    """
    n_A, n_B = len(A), len(B)
    area = roi_poly.area
    tree = cKDTree(B)
    K = np.zeros(len(support))
    for k, r in enumerate(support):
        if r == 0:
            continue
        counts = tree.query_ball_point(A, r, return_length=True).astype(float)
        w = _edge_weights(A, roi_poly, r)
        K[k] = (area / (n_A * n_B)) * np.sum(counts / w)
    return K


def all_pairs_cross_k_isotropic(P_by_type: dict[str, np.ndarray],
                                types: list[str],
                                support: np.ndarray, roi_poly,
                                min_cells: int = 30) -> tuple[np.ndarray, np.ndarray]:
    """Compute Cross-K for every ordered pair; return (curves, AUC matrix)."""
    N = len(types)
    crossK = np.full((N, N, len(support)), np.nan)
    auc_K = np.full((N, N), np.nan)

    for i, a in enumerate(types):
        A = P_by_type.get(a)
        if A is None or len(A) < min_cells:
            continue
        for j, b in enumerate(types):
            if i == j:
                continue
            B = P_by_type.get(b)
            if B is None or len(B) < min_cells:
                continue
            K_ab = cross_k_isotropic(A, B, support, roi_poly)
            crossK[i, j] = K_ab
            auc_K[i, j] = np.trapz(K_ab - np.pi * support ** 2, support)
    return crossK, auc_K


# ── Inhomogeneous Cross-K and Cross-PCF ───────────────────────────────────────
def estimate_intensity(pts: np.ndarray, eval_pts: np.ndarray | None = None,
                       bandwidth=None) -> np.ndarray:
    """KDE-based intensity (cells/µm²) at each point."""
    if eval_pts is None:
        eval_pts = pts
    kde = gaussian_kde(pts.T, bw_method=bandwidth)
    lam = kde(eval_pts.T) * len(pts)
    return np.maximum(lam, 1e-12)


def inhomogeneous_cross_k(A: np.ndarray, B: np.ndarray,
                          support: np.ndarray, roi_poly,
                          bw_A=None, bw_B=None) -> np.ndarray:
    """Inhomogeneous Cross-K (Baddeley et al. 2000) with edge correction."""
    n_A = len(A)
    lam_A = estimate_intensity(A, A, bw_A)
    lam_B = estimate_intensity(B, B, bw_B)
    tree = cKDTree(B)
    K_inhom = np.zeros(len(support))
    for k, r in enumerate(support):
        if r == 0:
            continue
        w_edge = np.clip(np.array([
            Point(p).buffer(r, resolution=32).intersection(roi_poly).area
            / (np.pi * r ** 2)
            for p in A
        ]), 1e-6, 1.0)
        nbrs = tree.query_ball_point(A, r)
        total = 0.0
        for i, nb in enumerate(nbrs):
            if not nb:
                continue
            contrib = np.sum(1.0 / (lam_A[i] * lam_B[nb]))
            total += contrib / w_edge[i]
        K_inhom[k] = total / n_A
    return K_inhom


def inhomogeneous_cross_pcf(A: np.ndarray, B: np.ndarray,
                            support: np.ndarray, roi_poly,
                            annulus_width: float | None = None,
                            bw_A=None, bw_B=None) -> np.ndarray:
    """Inhomogeneous cross-PCF g_inhom_AB(r) by annulus counting."""
    if annulus_width is None:
        annulus_width = support[1] - support[0] if len(support) > 1 else support[0]

    n_A = len(A)
    lam_A = estimate_intensity(A, A, bw_A)
    lam_B = estimate_intensity(B, B, bw_B)
    tree = cKDTree(B)
    g_inhom = np.zeros(len(support))

    for k, r_mid in enumerate(support):
        r_inner = max(0.0, r_mid - annulus_width / 2)
        r_outer = r_mid + annulus_width / 2
        annulus_area = np.pi * (r_outer ** 2 - r_inner ** 2)

        outer_idx = tree.query_ball_point(A, r_outer)
        inner_idx = tree.query_ball_point(A, r_inner)

        total = 0.0
        for i in range(n_A):
            in_annulus = np.setdiff1d(outer_idx[i], inner_idx[i])
            if len(in_annulus) == 0:
                continue
            total += np.sum(1.0 / (lam_A[i] * lam_B[in_annulus]))
        expected = n_A * annulus_area
        g_inhom[k] = total / expected if expected > 0 else np.nan
    return g_inhom


def all_pairs_inhomogeneous_cross(P_by_type: dict[str, np.ndarray],
                                  types: list[str],
                                  support: np.ndarray, roi_poly,
                                  min_cells: int = 30) -> dict:
    """Run inhomogeneous K and PCF for every ordered pair of types."""
    N = len(types)
    width = support[1] - support[0] if len(support) > 1 else support[0]
    K = np.full((N, N, len(support)), np.nan)
    PCF = np.full((N, N, len(support)), np.nan)
    AUC = np.full((N, N), np.nan)

    for i, a in enumerate(types):
        A = P_by_type.get(a)
        if A is None or len(A) < min_cells:
            continue
        for j, b in enumerate(types):
            if i == j:
                continue
            B = P_by_type.get(b)
            if B is None or len(B) < min_cells:
                continue
            K_ih = inhomogeneous_cross_k(A, B, support, roi_poly)
            g_ih = inhomogeneous_cross_pcf(A, B, support, roi_poly,
                                           annulus_width=width)
            K[i, j] = K_ih
            PCF[i, j] = g_ih
            AUC[i, j] = np.trapz(K_ih - np.pi * support ** 2, support)
    return {"K_inhom": K, "PCF_inhom": PCF, "AUC_inhom": AUC,
            "support": support}


# ── Notebook-compatible public aliases ────────────────────────────────────────
def cross_K_corrected(A: np.ndarray, B: np.ndarray,
                      support: np.ndarray, roi_poly) -> np.ndarray:
    """Edge-corrected cross-K — alias for cross_k_isotropic (notebook API).

    Matches the notebook's Cell 129 signature exactly::

        K_ab = cross_K_corrected(A, B, support_pair_fix, roi_poly)
    """
    return cross_k_isotropic(A, B, support, roi_poly)


def cross_K(A: np.ndarray, B: np.ndarray,
            support: np.ndarray, area: float) -> np.ndarray:
    """Uncorrected cross-K — matches notebook Cell 164 signature exactly.

    K_AB(r) = area / (n_A * n_B) * Σ_i #{j ∈ B: d(i,j) ≤ r}
    """
    tree = cKDTree(B)
    n_A = len(A)
    n_B = len(B)
    return np.array([
        tree.query_ball_point(A, r, return_length=True).sum()
        for r in support
    ]) * area / (n_A * n_B)


def cross_K_summary(crossK: np.ndarray, support: np.ndarray,
                    types: list[str]) -> "pd.DataFrame":
    """Summarise cross-K curves into a long-format DataFrame with AUC and r*.

    Parameters
    ----------
    crossK  : (N, N, len(support)) array from all_pairs_cross_k_isotropic
    support : 1-D radius array
    types   : list of cell-type names

    Returns
    -------
    DataFrame with columns: type_a, type_b, auc, r_star
    """
    rows = []
    csr = np.pi * support ** 2
    for i, a in enumerate(types):
        for j, b in enumerate(types):
            if i == j:
                continue
            K_ab = crossK[i, j]
            if np.all(np.isnan(K_ab)):
                continue
            auc = float(np.trapz(K_ab - csr, support))
            excess = K_ab - csr
            valid = support > 10.0
            r_star = float(support[valid][np.argmax(excess[valid])]) if valid.any() else float("nan")
            rows.append({"type_a": a, "type_b": b, "auc": auc, "r_star": r_star})
    return pd.DataFrame(rows)
