"""Higher-order spatial descriptors.

Pair correlation function (PCF), cross-PCF, O-ring, mark correlation,
and the empty-space hazard function.
"""
from __future__ import annotations

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.spatial import cKDTree
from scipy.spatial.distance import pdist, squareform

from .. import config


# ── Pair Correlation Function (univariate) ────────────────────────────────────
def pcf(r_pcf: np.ndarray, K_obs: np.ndarray,
        K_sims: np.ndarray | None = None,
        sigma_smooth: float = 1.5,
        eps: float = 1e-10) -> dict:
    """g(r) = (1/2πr) dK/dr, with smoothing before differentiation."""
    K_obs_sm = gaussian_filter1d(K_obs, sigma=sigma_smooth)
    r_safe = np.where(r_pcf > 0, r_pcf, np.nan)
    dK_dr_obs = np.gradient(K_obs_sm, r_pcf)
    g_obs = dK_dr_obs / (2 * np.pi * r_safe + eps)
    out = {"r": r_pcf, "g_obs": g_obs}
    if K_sims is not None:
        K_sims_sm = gaussian_filter1d(K_sims, sigma=sigma_smooth, axis=1)
        dK_dr_sims = np.gradient(K_sims_sm, r_pcf, axis=1)
        out["g_sims"] = dK_dr_sims / (2 * np.pi * r_safe[np.newaxis, :] + eps)
    return out


# ── Cross-PCF derived from cross-K ────────────────────────────────────────────
def cross_pcf(coords_a: np.ndarray, coords_b: np.ndarray,
              r: np.ndarray, area: float | None = None,
              n_sim: int = 100, sigma_smooth: float = 1.5,
              window_coords: np.ndarray | None = None,
              seed: int = 42, eps: float = 1e-10) -> dict:
    """Cross-PCF from smoothed Cross-K derivative + CSR envelope.

    Pass ``window_coords=ctx.coords`` to simulate B uniformly over the full
    tissue bounding box (matches notebook cell 143).
    """
    rng = np.random.default_rng(seed)
    if area is None:
        full = np.vstack([coords_a, coords_b])
        area = float((full.max(axis=0) - full.min(axis=0)).prod())

    n_A, n_B = len(coords_a), len(coords_b)
    lam_b = n_B / area
    tree_b = cKDTree(coords_b)
    K_ab = np.array([
        tree_b.query_ball_point(coords_a, ri, return_length=True).sum()
        / (n_A * lam_b)
        for ri in r
    ])
    K_ab_sm = gaussian_filter1d(K_ab, sigma=sigma_smooth)
    dK = np.gradient(K_ab_sm, r)
    g_ab = np.where(r > 0, dK / (2 * np.pi * r + eps), np.nan)

    if window_coords is None:
        window_coords = np.vstack([coords_a, coords_b])
    sim_min = window_coords.min(axis=0)
    sim_max = window_coords.max(axis=0)
    K_sims = []
    for _ in range(n_sim):
        rand_b = rng.uniform(sim_min, sim_max, size=(n_B, 2))
        tree_rb = cKDTree(rand_b)
        K_sim = np.array([
            tree_rb.query_ball_point(coords_a, ri, return_length=True).sum()
            / (n_A * lam_b)
            for ri in r
        ])
        K_sims.append(gaussian_filter1d(K_sim, sigma=sigma_smooth))
    K_sims = np.array(K_sims)
    g_sims = np.where(
        r > 0,
        np.gradient(K_sims, r, axis=1) / (2 * np.pi * r + eps),
        np.nan,
    )
    return {"r": r, "g_ab": g_ab, "g_sims": g_sims, "K_ab": K_ab}


# ── O-ring ────────────────────────────────────────────────────────────────────
def oring(coords: np.ndarray, r_max: float = 400.0,
          dr: float = config.ORING_DR, n_sim: int = 100,
          window_min=None, window_max=None,
          seed: int = config.RANDOM_SEED) -> dict:
    """O-ring function: average count in annulus [r-dr/2, r+dr/2]."""
    rng = np.random.default_rng(seed)
    r_grid = np.arange(0, r_max + dr, dr)
    tree = cKDTree(coords)

    O_obs = []
    for i in range(len(r_grid) - 1):
        r1, r2 = r_grid[i], r_grid[i + 1]
        c_out = tree.query_ball_point(coords, r2, return_length=True) - 1
        c_in = tree.query_ball_point(coords, r1, return_length=True) - 1
        O_obs.append(np.mean(c_out - c_in))
    O_obs = np.array(O_obs)
    r_mid = (r_grid[:-1] + r_grid[1:]) / 2

    if window_min is None:
        window_min = coords.min(axis=0)
    if window_max is None:
        window_max = coords.max(axis=0)

    O_sims = []
    for _ in range(n_sim):
        rand = rng.uniform(window_min, window_max, size=coords.shape)
        tr = cKDTree(rand)
        O_sim = []
        for i in range(len(r_grid) - 1):
            r1, r2 = r_grid[i], r_grid[i + 1]
            c_out = tr.query_ball_point(rand, r2, return_length=True) - 1
            c_in = tr.query_ball_point(rand, r1, return_length=True) - 1
            O_sim.append(np.mean(c_out - c_in))
        O_sims.append(O_sim)
    return {"r": r_mid, "O_obs": O_obs, "O_sims": np.array(O_sims)}


# ── Mark correlation ──────────────────────────────────────────────────────────
def mark_correlation(coords: np.ndarray, marks: np.ndarray,
                     r_max: float = 400.0, n_bins: int = 30,
                     subsample: int = 1500, n_perm: int = 99,
                     seed: int = config.RANDOM_SEED) -> dict:
    """Mark correlation k_m(r) with permutation envelope (annular binning)."""
    rng = np.random.default_rng(seed)
    n = len(coords)
    if n > subsample:
        idx = rng.choice(n, size=subsample, replace=False)
        P = coords[idx]
        m = marks[idx]
    else:
        P = coords
        m = marks
    mu = m.mean()
    r_grid = np.linspace(0, r_max, n_bins)
    tree = cKDTree(P)

    def _annulus_kmm(marks_vec, mean_val):
        k_m = []
        for i in range(len(r_grid) - 1):
            r1, r2 = r_grid[i], r_grid[i + 1]
            pairs_out = tree.query_pairs(r2, output_type="ndarray")
            pairs_in = (tree.query_pairs(r1, output_type="ndarray")
                        if r1 > 0 else np.empty((0, 2), dtype=int))
            if len(pairs_out) == 0:
                k_m.append(np.nan)
                continue
            set_out = set(map(tuple, pairs_out))
            set_in = set(map(tuple, pairs_in)) if len(pairs_in) > 0 else set()
            ann = np.array(list(set_out - set_in), dtype=int) if set_out - set_in else np.empty((0, 2), dtype=int)
            if len(ann) == 0:
                k_m.append(np.nan)
                continue
            prods = marks_vec[ann[:, 0]] * marks_vec[ann[:, 1]]
            k_m.append(float(np.mean(prods)) / (mean_val ** 2 + 1e-12))
        return np.array(k_m)

    k_m_obs = _annulus_kmm(m, mu)
    k_m_sims = []
    for _ in range(n_perm):
        m_perm = rng.permutation(m)
        k_m_sims.append(_annulus_kmm(m_perm, m_perm.mean()))
    r_mid = (r_grid[:-1] + r_grid[1:]) / 2
    return {"r": r_mid, "k_m_obs": k_m_obs, "k_m_sims": np.array(k_m_sims)}


def mark_correlation_pairwise(coords: np.ndarray, marks: np.ndarray,
                              support: np.ndarray,
                              subsample: int = 1500,
                              seed: int = config.RANDOM_SEED) -> np.ndarray:
    """Mark correlation k_mm(r) via full pairwise-distance matrix on subsample."""
    rng = np.random.default_rng(seed)
    n = len(coords)
    if n > subsample:
        idx = rng.choice(n, size=subsample, replace=False)
        P = coords[idx]
        m = marks[idx]
    else:
        P = coords
        m = marks
    mu = m.mean()
    D = squareform(pdist(P))
    np.fill_diagonal(D, np.inf)
    prod = np.outer(m, m)
    np.fill_diagonal(prod, 0)
    kmm = np.zeros(len(support))
    for k, r in enumerate(support):
        mask = D <= r
        denom = max(int(mask.sum()), 1)
        kmm[k] = (prod[mask].sum() / denom) / (mu * mu + 1e-12)
    return kmm


# ── Empty-space hazard ────────────────────────────────────────────────────────
def empty_space_hazard(F_obs: np.ndarray, F_sims: np.ndarray,
                       support: np.ndarray, eps: float = 1e-10) -> dict:
    """h(r) = f(r) / (1 - F(r)). Truncate where F > 0.95."""
    f_obs = np.gradient(F_obs, support)
    f_sims = np.gradient(F_sims, support, axis=1)
    h_obs = f_obs / (1 - F_obs + eps)
    h_sims = f_sims / (1 - F_sims + eps)
    valid = F_obs < 0.95
    return {"r": support, "h_obs": h_obs, "h_sims": h_sims, "valid": valid}
