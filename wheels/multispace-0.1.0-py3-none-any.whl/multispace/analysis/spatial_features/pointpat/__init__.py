"""Point pattern analysis."""
