"""Edge-corrected Ripley K via astropy + 2D KDE field with Ricker wavelets."""
from __future__ import annotations

import numpy as np
from scipy.stats import gaussian_kde

from .. import config


def astropy_ripley_k(coords: np.ndarray,
                     radii: np.ndarray | None = None,
                     modes: tuple[str, ...] = (
                         "none", "translation", "ohser", "ripley", "var-width",
                     )) -> dict:
    """Run astropy's RipleysKEstimator under multiple edge corrections."""
    from astropy.stats import RipleysKEstimator

    bbox = coords.max(0) - coords.min(0)
    area = float(bbox[0] * bbox[1])
    rk = RipleysKEstimator(
        area=area,
        x_min=coords[:, 0].min(), x_max=coords[:, 0].max(),
        y_min=coords[:, 1].min(), y_max=coords[:, 1].max(),
    )
    if radii is None:
        radii = np.linspace(0, 0.4 * bbox.max(), 30)

    out: dict = {"radii": radii, "csr": np.pi * radii ** 2}
    for mode in modes:
        try:
            out[mode] = rk(data=coords, radii=radii, mode=mode)
        except Exception as e:
            out[mode] = None
            print(f"mode {mode!r} failed: {e}")
    return out


def kde_field(coords: np.ndarray,
              n_grid: int = 200,
              standardize: bool = True) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build a 2D KDE intensity field on a regular grid."""
    xs = np.linspace(coords[:, 0].min(), coords[:, 0].max(), n_grid)
    ys = np.linspace(coords[:, 1].min(), coords[:, 1].max(), n_grid)
    XX, YY = np.meshgrid(xs, ys)
    kde = gaussian_kde(coords.T, bw_method="scott")
    field = kde(np.vstack([XX.ravel(), YY.ravel()])).reshape(XX.shape)
    if standardize:
        field = (field - field.mean()) / field.std()
    return field, xs, ys


def ricker_wavelet_responses(field: np.ndarray,
                             sigmas: np.ndarray | None = None) -> dict:
    """Convolve a 2D field with Ricker (Mexican Hat) wavelets at multiple scales."""
    from astropy.convolution import RickerWavelet2DKernel, convolve

    if sigmas is None:
        sigmas = np.linspace(2, 14, 5)
    out: dict = {"sigmas": sigmas, "field": field}
    out["responses"] = {}
    for s in sigmas:
        kern = RickerWavelet2DKernel(width=float(s))
        resp = convolve(field, kern, boundary="extend", normalize_kernel=False)
        out["responses"][float(s)] = resp
    return out


def kde_field_and_wavelet_detection(coords: np.ndarray,
                                    sigmas: np.ndarray | None = None,
                                    n_grid: int = 200) -> dict:
    """Convenience wrapper: KDE field + multi-scale Ricker responses."""
    field, xs, ys = kde_field(coords, n_grid=n_grid)
    out = ricker_wavelet_responses(field, sigmas=sigmas)
    out["xs"], out["ys"] = xs, ys
    return out
