"""Centrography and spatial descriptors for point patterns."""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd
from pointpats import centrography
import libpysal
from shapely.geometry import Polygon as ShapelyPolygon
import geopandas as gpd


def compute_centrography(target_coords: np.ndarray) -> dict:
    """Compute mean / median centres and the standard-deviation ellipse for a
    set of 2D points."""
    target_coords = np.asarray(target_coords, float)
    P_df = pd.DataFrame({"x": target_coords[:, 0], "y": target_coords[:, 1]})

    mean_center = centrography.mean_center(P_df)
    med_center = centrography.euclidean_median(P_df)
    major, minor, rotation = centrography.ellipse(P_df)

    return {
        "mean_center": np.asarray(mean_center, float),
        "median_center": np.asarray(med_center, float),
        "ellipse_major": float(major),
        "ellipse_minor": float(minor),
        "ellipse_rotation": float(rotation),
        "n_points": int(len(target_coords)),
    }


def convex_hull_vertices(target_coords: np.ndarray) -> np.ndarray:
    """Return the convex-hull vertices of a 2D point cloud."""
    return centrography.hull(np.asarray(target_coords, float))


def convex_hull_centroid(target_coords: np.ndarray) -> np.ndarray:
    """Return the (x, y) centroid of the convex hull of a point cloud."""
    verts = convex_hull_vertices(target_coords)
    poly = ShapelyPolygon(verts)
    return np.array([poly.centroid.x, poly.centroid.y])


def alpha_shape(target_coords: np.ndarray):
    """Compute the auto-tuned alpha shape (tightest concave hull).
    Returns (shape, alpha, bounding_circles) as produced by libpysal."""
    target_coords = np.asarray(target_coords, float)
    shape, alpha, circs = libpysal.cg.alpha_shape_auto(
        target_coords, return_circles=True
    )
    return shape, float(alpha), circs


def minimum_bounding_rectangle(target_coords: np.ndarray) -> np.ndarray:
    """Vertices of the minimum bounding rectangle."""
    return centrography.minimum_bounding_rectangle(
        np.asarray(target_coords, float)
    )


def minimum_bounding_circle(target_coords: np.ndarray) -> dict:
    """Center and radius of the minimum bounding circle."""
    (cx, cy), r = centrography.minimum_bounding_circle(
        np.asarray(target_coords, float)
    )
    return {"center": np.array([cx, cy]), "radius": float(r)}


def minimum_rotated_rectangle(target_coords: np.ndarray):
    """Shapely minimum rotated rectangle of a point cloud."""
    target_coords = np.asarray(target_coords, float)
    point_array = gpd.points_from_xy(
        x=target_coords[:, 0], y=target_coords[:, 1]
    )
    return point_array.union_all().minimum_rotated_rectangle


def displacement_to_hull_centroid(
    target_coords: np.ndarray, hull_coords: np.ndarray
) -> dict:
    """Displacement (vector & magnitude) from the mean centre of
    `target_coords` to the convex-hull centroid of `hull_coords`."""
    centro = compute_centrography(target_coords)
    hull_centroid = convex_hull_centroid(hull_coords)
    disp_vec = hull_centroid - centro["mean_center"]
    return {
        "hull_centroid": hull_centroid,
        "mean_center": centro["mean_center"],
        "displacement_vector": disp_vec,
        "displacement_magnitude": float(np.hypot(*disp_vec)),
    }


def asymmetry_metrics(
    coords: np.ndarray,
    labels: np.ndarray,
    types: list,
    hull_centroid: Optional[np.ndarray] = None,
    min_cells: int = 30,
) -> pd.Series:
    """For each cell type in `types`, distance from the type's mean centre to
    the convex-hull centroid of the whole core."""
    coords = np.asarray(coords, float)
    labels = np.asarray(labels)
    if hull_centroid is None:
        hull_centroid = convex_hull_centroid(coords)

    asymmetry = {}
    for t in types:
        P = coords[labels == t]
        if len(P) < min_cells:
            continue
        asymmetry[t] = float(np.hypot(*(hull_centroid - P.mean(axis=0))))
    return pd.Series(asymmetry).sort_values(ascending=False)
