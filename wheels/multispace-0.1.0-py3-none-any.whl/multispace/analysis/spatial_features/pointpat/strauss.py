"""Strauss / Gibbs process fitting via maximum pseudolikelihood (MPLE)."""
from __future__ import annotations

import warnings

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.spatial import cKDTree
from shapely.geometry import Point

from .. import config


def strauss_mple(pts_type: np.ndarray, roi_poly,
                 r_interact: float, n_dummy: int = 500,
                 seed: int = config.RANDOM_SEED) -> tuple[float, float, float, float]:
    """Maximum pseudolikelihood estimation for the Strauss process.

    Returns (β, γ, AIC_Strauss, AIC_Poisson).
    """
    n = len(pts_type)
    area = roi_poly.area

    rng = np.random.default_rng(seed)
    bounds = roi_poly.bounds
    dummy_pts = []
    attempts = 0
    while len(dummy_pts) < n_dummy and attempts < n_dummy * 20:
        x = rng.uniform(bounds[0], bounds[2])
        y = rng.uniform(bounds[1], bounds[3])
        if roi_poly.contains(Point(x, y)):
            dummy_pts.append([x, y])
        attempts += 1
    dummy_pts = np.array(dummy_pts)
    if len(dummy_pts) < 10:
        return float("nan"), float("nan"), float("nan"), float("nan")

    all_pts = np.vstack([pts_type, dummy_pts])
    y_resp = np.array([1] * n + [0] * len(dummy_pts), dtype=float)

    w_data = np.ones(n) / n
    w_dummy = np.ones(len(dummy_pts)) * area / len(dummy_pts)
    weights = np.concatenate([w_data, w_dummy])

    tree_data = cKDTree(pts_type)
    s_counts = tree_data.query_ball_point(all_pts, r_interact,
                                          return_length=True).astype(float)
    s_counts[:n] -= 1

    def neg_log_pl(theta):
        eta = theta[0] + theta[1] * s_counts
        ll = (y_resp * eta - np.log1p(np.exp(eta))) * weights
        return -ll.sum()

    def neg_log_pl_grad(theta):
        eta = theta[0] + theta[1] * s_counts
        p_hat = 1.0 / (1.0 + np.exp(-eta))
        resid = (y_resp - p_hat) * weights
        return np.array([-resid.sum(), -(resid * s_counts).sum()])

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = minimize(neg_log_pl, x0=[np.log(n / area), 0.0],
                       jac=neg_log_pl_grad, method="L-BFGS-B",
                       options={"maxiter": 500, "ftol": 1e-10})
    if not res.success:
        return float("nan"), float("nan"), float("nan"), float("nan")

    theta0, theta1 = res.x
    beta = float(np.exp(theta0))
    gamma_param = float(np.exp(theta1))

    aic = float(2 * res.fun + 2 * 2)
    res0 = minimize(lambda t: neg_log_pl([t[0], 0.0]),
                    x0=[theta0], method="L-BFGS-B")
    aic0 = float(2 * res0.fun + 2 * 1)

    return beta, gamma_param, aic, aic0


def fit_strauss_per_celltype(coords: np.ndarray, labels_arr: np.ndarray,
                             unique_labels: np.ndarray,
                             top_types: list[str],
                             roi_poly,
                             r_per_type: dict[str, float] | None = None,
                             default_r: float = config.STRAUSS_R,
                             min_cells: int = 30,
                             n_dummy: int = 800) -> pd.DataFrame:
    """Fit the Strauss process for each cell type; return a summary DataFrame."""
    rows = []
    for t in top_types:
        P = coords[unique_labels[labels_arr] == t]
        if len(P) < min_cells:
            continue
        r_t = (r_per_type or {}).get(t, default_r)
        if not np.isfinite(r_t) or r_t <= 0:
            r_t = default_r
        beta, gamma_param, aic, aic0 = strauss_mple(P, roi_poly, r_interact=r_t,
                                                    n_dummy=n_dummy)
        delta_aic = aic - aic0 if not np.isnan(aic) else float("nan")
        if not np.isnan(gamma_param) and gamma_param < 0.9:
            pattern = "Inhibition (regular)"
        elif not np.isnan(gamma_param) and gamma_param > 1.1:
            pattern = "Clustering tendency"
        else:
            pattern = "Near-CSR"
        rows.append({
            "Cell type": t,
            "n": len(P),
            "r_interact (µm)": round(r_t, 0),
            "β (intensity)": beta,
            "γ (interaction)": round(gamma_param, 3) if not np.isnan(gamma_param) else float("nan"),
            "ΔAIC (Strauss−Poisson)": round(delta_aic, 1) if not np.isnan(delta_aic) else float("nan"),
            "pattern": pattern,
        })
    return pd.DataFrame(rows).set_index("Cell type")
