"""Inhomogeneous Ripley K and global CSR envelopes (MAD/DCLF tests)."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial.distance import pdist, squareform
from scipy.stats import gaussian_kde

from .. import config


def Kinhom(coords: np.ndarray, support: np.ndarray,
           area: float | None = None,
           lam: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
    """Inhomogeneous K via KDE intensity (O(n²); fine up to a few thousand pts)."""
    coords = np.asarray(coords, float)
    n = len(coords)
    if lam is None:
        kde = gaussian_kde(coords.T, bw_method="scott")
        lam = kde(coords.T) * n
    if area is None:
        bbox = coords.max(axis=0) - coords.min(axis=0)
        area = bbox[0] * bbox[1]

    dists = squareform(pdist(coords))
    np.fill_diagonal(dists, np.inf)
    invl = 1.0 / np.outer(lam, lam)
    np.fill_diagonal(invl, 0)
    K = np.array([(invl * (dists <= r)).sum() for r in support]) / area
    return K, lam


def Khom(coords: np.ndarray, support: np.ndarray,
         area: float | None = None) -> np.ndarray:
    """Standard (homogeneous) Ripley K — for comparison against Kinhom."""
    coords = np.asarray(coords, float)
    n = len(coords)
    if area is None:
        bbox = coords.max(axis=0) - coords.min(axis=0)
        area = bbox[0] * bbox[1]
    dists = squareform(pdist(coords))
    np.fill_diagonal(dists, np.inf)
    K = np.array([(dists <= r).sum() for r in support]) * area / (n * (n - 1))
    return K


def pcf_inhom(support: np.ndarray, K_inh: np.ndarray) -> np.ndarray:
    """g_inhom(r) = (1/2πr) dK_inhom/dr."""
    r = np.asarray(support)
    dK = np.gradient(K_inh, r)
    with np.errstate(divide="ignore", invalid="ignore"):
        g = dK / (2 * np.pi * r)
    g[~np.isfinite(g)] = np.nan
    return g


def per_celltype_kinhom(coords: np.ndarray, labels_arr: np.ndarray,
                        unique_labels: np.ndarray,
                        types: list[str], support: np.ndarray,
                        sub_cap: int = 600,
                        min_cells: int = 30,
                        seed: int = config.RANDOM_SEED) -> dict:
    """Run K_hom + K_inhom for each cell type with subsampling."""
    rng = np.random.default_rng(seed)
    out: dict = {}
    for ct in types:
        mask = unique_labels[labels_arr] == ct
        P = coords[mask]
        if len(P) < min_cells:
            continue
        if len(P) > sub_cap:
            P = P[rng.choice(len(P), size=sub_cap, replace=False)]
        K_hom = Khom(P, support)
        K_inh, lam = Kinhom(P, support)
        out[ct] = {"K_hom": K_hom, "K_inh": K_inh, "lam": lam, "n": len(P)}
    return out


def per_celltype_pcf_inhom(per_type_results: dict,
                           support: np.ndarray) -> dict:
    """Apply pcf_inhom to each per-type Kinhom curve."""
    return {ct: pcf_inhom(support, res["K_inh"])
            for ct, res in per_type_results.items()}


# ── CSR simulation envelopes (pointwise + global; MAD and DCLF tests) ────────
def _K_at(coords: np.ndarray, support: np.ndarray, area: float) -> np.ndarray:
    coords = np.asarray(coords, float)
    n = len(coords)
    d = squareform(pdist(coords))
    np.fill_diagonal(d, np.inf)
    return np.array([(d <= r).sum() for r in support]) * area / (n * (n - 1))


def csr_envelopes(coords: np.ndarray, support: np.ndarray,
                  n_sim: int = config.N_ENVELOPE_SIM, level: float = 0.05,
                  sub_cap: int = 600,
                  seed: int = config.RANDOM_SEED,
                  as_tuple: bool = False) -> dict:
    """CSR envelopes (pointwise + global) and MAD/DCLF p-values for K(r)."""
    rng = np.random.default_rng(seed)
    if len(coords) > sub_cap:
        coords = coords[rng.choice(len(coords), size=sub_cap, replace=False)]
    n = len(coords)
    bbox = np.column_stack([coords.min(0), coords.max(0)])
    area = float(np.diff(bbox, axis=1).prod())

    sims = np.zeros((n_sim, len(support)))
    for s in range(n_sim):
        pts_sim = np.column_stack([
            rng.uniform(bbox[d, 0], bbox[d, 1], n) for d in range(2)
        ])
        sims[s] = _K_at(pts_sim, support, area)

    obs = _K_at(coords, support, area)
    pw_lo = np.quantile(sims, level / 2, axis=0)
    pw_hi = np.quantile(sims, 1 - level / 2, axis=0)
    median = np.median(sims, axis=0)
    dev_sims = np.abs(sims - median).max(axis=1)
    cutoff = np.quantile(dev_sims, 1 - level)
    glo_lo = median - cutoff
    glo_hi = median + cutoff
    mad_obs = np.abs(obs - median).max()
    mad_p = (1 + (dev_sims >= mad_obs).sum()) / (n_sim + 1)
    dclf_sims = ((sims - median) ** 2).sum(axis=1)
    dclf_obs = ((obs - median) ** 2).sum()
    dclf_p = (1 + (dclf_sims >= dclf_obs).sum()) / (n_sim + 1)
    result = {
        "support": support, "obs": obs, "median": median,
        "pw_lo": pw_lo, "pw_hi": pw_hi,
        "global_lo": glo_lo, "global_hi": glo_hi,
        "mad_p": float(mad_p), "dclf_p": float(dclf_p),
        "sims": sims, "area": area,
    }
    if as_tuple:
        # Backward-compat: notebook Cell 184 unpacks a 7-tuple
        # (support, obs, pw_lo, pw_hi, global_lo, global_hi, median)
        return (support, obs, pw_lo, pw_hi, glo_lo, glo_hi, median)
    return result


# ── PCF from L derivative (5.7b) and per-type r* ─────────────────────────────
def pcf_from_L_derivative(L_curve: np.ndarray,
                          support: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
    """g(r) = (1/r) dL/dr + 1; returns (g_from_dL, dL_dr, r*)."""
    dL_dr = np.gradient(L_curve, support)
    with np.errstate(divide="ignore", invalid="ignore"):
        g_from_dL = np.where(support > 0, dL_dr / support + 1.0, np.nan)
    valid = support > 10.0
    r_star = float(support[valid][np.argmax(dL_dr[valid])]) if valid.any() else float("nan")
    return g_from_dL, dL_dr, r_star


def per_type_dominant_scale(coords: np.ndarray, labels_arr: np.ndarray,
                            unique_labels: np.ndarray,
                            types: list[str], support: np.ndarray,
                            roi_poly,
                            min_cells: int = 30) -> dict:
    """Per-type edge-corrected K → L → dL/dr → r* (dominant clustering scale)."""
    from scipy.spatial import cKDTree
    from shapely.geometry import Point as _Point

    def per_type_K(pts_type, supp, poly):
        n = len(pts_type)
        area = poly.area
        tree = cKDTree(pts_type)
        K = np.zeros(len(supp))
        for k, r in enumerate(supp):
            if r == 0:
                continue
            counts = tree.query_ball_point(pts_type, r, return_length=True).astype(float)
            counts -= 1
            w = np.array([
                _Point(p).buffer(r, resolution=24).intersection(poly).area
                / (np.pi * r ** 2)
                for p in pts_type
            ])
            w = np.clip(w, 1e-6, 1.0)
            K[k] = (area / (n * (n - 1))) * np.sum(counts / w)
        return K

    out: dict = {}
    for t in types:
        P = coords[unique_labels[labels_arr] == t]
        if len(P) < min_cells:
            continue
        K_t = per_type_K(P, support, roi_poly)
        with np.errstate(invalid="ignore"):
            L_t = np.sqrt(np.maximum(K_t, 0) / np.pi) - support
        g_dL, dL_dr, r_star = pcf_from_L_derivative(L_t, support)
        out[t] = {"K": K_t, "L": L_t, "g_dL": g_dL,
                  "dL_dr": dL_dr, "r_star": r_star}
    return out


# ── Backward-compat alias (notebook used singular name) ──────────────────────
def csr_envelope(coords: np.ndarray, support: np.ndarray, **kwargs):
    """Alias for csr_envelopes — returns 7-tuple for notebook compatibility."""
    return csr_envelopes(coords, support, as_tuple=True, **kwargs)
