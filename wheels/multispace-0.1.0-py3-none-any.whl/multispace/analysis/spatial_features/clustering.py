"""Spatially-constrained clustering: Potts MRF and cellular niche identification."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial import Delaunay, cKDTree
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import (
    adjusted_rand_score, normalized_mutual_info_score, silhouette_score,
)
from sklearn.preprocessing import StandardScaler

from . import config


# ── Potts MRF (ICM solver) ────────────────────────────────────────────────────
def potts_icm(X: np.ndarray, w, k: int = 5, beta: float = 2.0,
              n_iter: int = 20, init=None,
              random_state: int = config.RANDOM_SEED) -> np.ndarray:
    """Iterated Conditional Modes for a Potts MRF on a libpysal weights graph."""
    X = np.asarray(X, float)
    n = X.shape[0]
    if init is None:
        labels = KMeans(k, random_state=random_state, n_init=10).fit_predict(X)
    else:
        labels = np.asarray(init, int).copy()
    centers = np.array([X[labels == c].mean(axis=0) for c in range(k)])

    for _ in range(n_iter):
        changed = 0
        for c in range(k):
            mask = labels == c
            if mask.any():
                centers[c] = X[mask].mean(axis=0)
        for i in range(n):
            data_term = ((X[i] - centers) ** 2).sum(axis=1)
            nbrs = list(w.neighbors[i])
            disagree = np.zeros(k)
            for c in range(k):
                disagree[c] = sum(1 for j in nbrs if labels[j] != c)
            energy = data_term + beta * disagree
            new_label = int(np.argmin(energy))
            if new_label != labels[i]:
                labels[i] = new_label
                changed += 1
        if changed == 0:
            break
    return labels


def run_potts_pipeline(Xmat: np.ndarray, w, labels_arr: np.ndarray,
                      n_components: int = 20, beta: float = 1.5,
                      n_iter: int = 30,
                      random_state: int = config.RANDOM_SEED) -> dict:
    """Standardise, PCA-reduce, run Potts ICM, score against ground truth."""
    X_scaled = StandardScaler().fit_transform(Xmat)
    X_pca = PCA(n_components=n_components, random_state=random_state).fit_transform(X_scaled)
    n_types = len(np.unique(labels_arr))
    potts_labels = potts_icm(X_pca, w, k=n_types, beta=beta,
                             n_iter=n_iter, random_state=random_state)
    return {
        "potts_labels": potts_labels,
        "ari": float(adjusted_rand_score(labels_arr, potts_labels)),
        "nmi": float(normalized_mutual_info_score(labels_arr, potts_labels)),
        "X_pca": X_pca,
    }


# ── Cellular niche identification ─────────────────────────────────────────────
def compute_neighbourhood_composition(coords: np.ndarray, labels: np.ndarray,
                                      radius: float = 100.0,
                                      min_neighbours: int = 3) -> tuple[np.ndarray, np.ndarray, list]:
    """Per-cell length-L composition vector inside `radius`."""
    labels = np.asarray(labels)
    unique_types = list(np.unique(labels))
    n_types = len(unique_types)
    type_to_idx = {t: i for i, t in enumerate(unique_types)}
    label_idx = np.array([type_to_idx[l] for l in labels])

    tree = cKDTree(coords)
    nbrs = tree.query_ball_point(coords, radius)

    comp_mat = np.zeros((len(coords), n_types))
    valid_mask = np.zeros(len(coords), dtype=bool)
    for i, nb in enumerate(nbrs):
        if len(nb) < min_neighbours:
            continue
        counts = np.bincount(label_idx[nb], minlength=n_types).astype(float)
        comp_mat[i] = counts / counts.sum()
        valid_mask[i] = True
    return comp_mat, valid_mask, unique_types


def select_n_niches(comp_mat: np.ndarray,
                    k_range=range(2, 9),
                    seed: int = config.RANDOM_SEED) -> tuple[int, dict]:
    """Pick optimal #niches by silhouette score."""
    scores: dict = {}
    for k in k_range:
        km = KMeans(n_clusters=k, random_state=seed, n_init=10)
        lab = km.fit_predict(comp_mat)
        if len(np.unique(lab)) < 2:
            continue
        scores[k] = float(silhouette_score(
            comp_mat, lab, sample_size=min(2000, len(comp_mat)),
        ))
    best_k = int(max(scores, key=scores.get))
    return best_k, scores


def fit_niches(comp_mat: np.ndarray, valid_mask: np.ndarray,
               unique_types: list[str],
               k: int,
               seed: int = config.RANDOM_SEED) -> dict:
    """Fit final KMeans on valid composition vectors and produce a label vector."""
    km = KMeans(n_clusters=k, random_state=seed, n_init=20)
    lab_valid = km.fit_predict(comp_mat[valid_mask])
    full_labels = np.full(len(comp_mat), -1, dtype=int)
    full_labels[valid_mask] = lab_valid
    profiles = pd.DataFrame(
        km.cluster_centers_,
        columns=unique_types,
        index=[f"Niche {i}" for i in range(k)],
    )
    names = {i: f"N{i}: {profiles.iloc[i].idxmax()}-rich" for i in range(k)}
    return {
        "niche_labels": full_labels,
        "valid_mask": valid_mask,
        "profiles": profiles,
        "names": names,
        "kmeans": km,
    }


def niche_adjacency(coords: np.ndarray, niche_labels: np.ndarray,
                    valid_mask: np.ndarray, k: int,
                    names: dict | None = None) -> pd.DataFrame:
    """Symmetric Delaunay-edge counts between niches.

    When ``names`` is supplied, the DataFrame index/columns use the niche
    names (matching the notebook's ``"N0: <type>-rich"`` style); otherwise
    they fall back to integer ids.
    """
    valid_pts = coords[valid_mask]
    valid_niches = niche_labels[valid_mask]
    tri = Delaunay(valid_pts)
    M = np.zeros((k, k), dtype=int)
    for s in tri.simplices:
        for a in range(3):
            for b in range(a + 1, 3):
                na, nb = valid_niches[s[a]], valid_niches[s[b]]
                if na != nb:
                    M[na, nb] += 1
                    M[nb, na] += 1
    if names is not None:
        labels = [names.get(i, i) for i in range(k)]
    else:
        labels = list(range(k))
    return pd.DataFrame(M, index=labels, columns=labels)
