"""Figure helpers for the spatial_features pipeline.

Each function builds a matplotlib Figure and returns it. The runner script
saves figures to RESULTS_DIR — these helpers don't call plt.show() or savefig.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.patches import Patch

from . import config


# ── Generic helpers ──────────────────────────────────────────────────────────
def save_fig(fig, name: str, results_dir: Path | None = None,
             dpi: int = 150) -> Path:
    """Save a matplotlib Figure to results/<name>.png and close it."""
    out = (results_dir or config.RESULTS_DIR) / f"{name}.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return out


# ── Section 2 — labelled spatial scatter ─────────────────────────────────────
def plot_label_map(coords: np.ndarray, labels_arr: np.ndarray,
                   unique_labels: np.ndarray,
                   title: str = "All cells coloured by phenotype"):
    fig, ax = plt.subplots(1, 1, figsize=(8, 8))
    ax.scatter(coords[:, 0], coords[:, 1], c=labels_arr, cmap="tab20", s=2)
    ax.set_aspect("equal")
    ax.set_axis_off()
    ax.set_title(f"{title} ({len(unique_labels)} classes)")
    return fig


# ── Section 3 — Voronoi tessellation ─────────────────────────────────────────
def plot_voronoi(regions, points_gdf):
    fig, ax = plt.subplots(1, figsize=(7, 7))
    regions.boundary.plot(ax=ax, color="0.4", linewidth=0.4)
    points_gdf.plot(ax=ax, color="C3", markersize=4)
    ax.set_title("Voronoi tessellation of cell centroids")
    ax.set_axis_off()
    return fig


# ── Section 4 — autocorrelation ──────────────────────────────────────────────
def plot_morans_per_celltype(moran_df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(max(5, 0.8 * len(moran_df)), 4))
    ax.bar(moran_df.index, moran_df["I"], color="steelblue", edgecolor="k")
    ax.axhline(0, color="k", linestyle="--", lw=0.8)
    ax.set_ylabel("Moran's I")
    ax.set_title("Per-cell-type Moran's I (binary indicator)")
    ax.set_xticks(range(len(moran_df)))
    ax.set_xticklabels(moran_df.index, rotation=30, ha="right")
    return fig


def plot_svg_volcano(svg_df: pd.DataFrame, n_label: int = 10):
    """Two-panel SVG figure: histogram of Moran's I + volcano scatter.

    Matches the notebook's Cell 63 layout exactly.  Labels the top
    ``n_label`` SVGs on the scatter panel.
    """
    i_col = "Moran's I" if "Moran's I" in svg_df.columns else (
        "I" if "I" in svg_df.columns else None)
    if i_col is None or "p_adj" not in svg_df.columns:
        fig, _ = plt.subplots(figsize=(13, 5))
        return fig

    I_vals = svg_df[i_col].values
    p_adj = svg_df["p_adj"].values
    is_svg = p_adj < 0.05
    n_svg = int(is_svg.sum())
    neg_log_p = -np.log10(p_adj + 1e-300)
    colors_svg = np.where(is_svg, "#d62728", "#bdbdbd")

    fig, axs = plt.subplots(1, 2, figsize=(13, 5))

    # Panel 1 — histogram of Moran's I
    axs[0].hist(I_vals, bins=80, color="steelblue", edgecolor="none", alpha=0.8)
    axs[0].axvline(0, color="k", lw=0.8, linestyle="--")
    axs[0].set_xlabel("Moran's I")
    axs[0].set_ylabel("Number of genes")
    axs[0].set_title(
        f"Distribution of Moran's I across {len(svg_df)} genes\n"
        f"{n_svg} SVGs (BH q < 0.05)"
    )

    # Panel 2 — volcano scatter
    axs[1].scatter(I_vals, neg_log_p, c=colors_svg, s=3, alpha=0.6,
                   edgecolor="none")
    axs[1].axhline(-np.log10(0.05), color="k", lw=0.8, linestyle="--",
                   label="q = 0.05")
    axs[1].set_xlabel("Moran's I")
    axs[1].set_ylabel("-log10(p_adj)")
    axs[1].set_title(
        "SVG detection: Moran's I vs significance\n"
        "(red = SVG, grey = not significant)"
    )
    axs[1].legend(fontsize=8)

    # Label top n_label SVGs
    gene_col = "Gene" if "Gene" in svg_df.columns else svg_df.columns[0]
    top = svg_df.head(n_label)
    for _, row in top.iterrows():
        axs[1].text(
            row[i_col],
            -np.log10(row["p_adj"] + 1e-300),
            str(row[gene_col]),
            fontsize=6,
        )

    fig.tight_layout()
    return fig


# ── Section 5 — point-pattern envelope plot ──────────────────────────────────
def plot_envelope(r: np.ndarray, obs: np.ndarray, sims: np.ndarray | None,
                  title: str, ylabel: str = "f(r)",
                  csr_line: float | None = None,
                  coords: np.ndarray | None = None,
                  valid: np.ndarray | None = None):
    """Envelope plot with optional right-panel point-pattern scatter.

    When ``coords`` is provided a second panel is added showing the spatial
    point pattern, matching the notebook's 2-panel layout for Ripley G/F/J/K/L.

    ``valid`` is an optional boolean mask (same length as ``r``) that restricts
    the plot to reliable r values — used for Ripley J where J(r) diverges when
    F(r) → 1.  When provided, only the True entries are plotted.
    """
    # Apply valid mask to avoid blow-up (e.g. J-function when F→1)
    r = np.asarray(r)
    obs = np.asarray(obs)
    if valid is not None:
        valid = np.asarray(valid, dtype=bool)
        r = r[valid]
        obs = obs[valid]
        if sims is not None:
            sims = np.asarray(sims)
            sims = sims[:, valid] if sims.ndim == 2 else sims[valid]

    if coords is not None:
        fig, axs = plt.subplots(1, 2, figsize=(9, 5),
                                gridspec_kw={"width_ratios": (5, 5)})
        ax = axs[0]
    else:
        fig, ax = plt.subplots(figsize=(7, 4.5))

    if sims is not None:
        ax.plot(r, sims.T, color="k", alpha=0.01)
        ax.fill_between(r,
                        np.nanpercentile(sims, 2.5, axis=0),
                        np.nanpercentile(sims, 97.5, axis=0),
                        alpha=0.25, label="95% envelope")
        ax.plot(r, np.nanmedian(sims, axis=0), color="cyan",
                label="median simulation")
    ax.plot(r, obs, color="red", label="observed")
    if csr_line is not None:
        ax.axhline(csr_line, color="gray", linestyle="--", label="CSR")
    ax.set_xlabel("distance (µm)")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend(fontsize=8)

    if coords is not None:
        axs[1].scatter(coords[:, 0], coords[:, 1], s=0.5)
        axs[1].set_xticks([])
        axs[1].set_yticks([])
        axs[1].set_title("Pattern")

    fig.tight_layout()
    return fig


def plot_cross_k_auc_heatmap(auc_K: np.ndarray, types: list[str],
                             title: str = "Cross-K AUC"):
    fig, ax = plt.subplots(figsize=(0.7 * len(types) + 2, 0.7 * len(types) + 1.5))
    vmax = float(np.nanpercentile(np.abs(auc_K), 95)) or 1.0
    im = ax.imshow(auc_K, cmap="RdBu_r", aspect="auto", vmin=-vmax, vmax=vmax)
    ax.set_xticks(range(len(types)))
    ax.set_xticklabels(types, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(len(types)))
    ax.set_yticklabels(types, fontsize=8)
    ax.set_title(title)
    fig.colorbar(im, ax=ax, label="AUC of K_ab(r) − πr²")
    return fig


def plot_strauss_gamma(strauss_df: pd.DataFrame):
    gamma_col = next((c for c in ("γ (interaction)", "gamma")
                      if c in strauss_df.columns), None)
    aic_col = next((c for c in ("ΔAIC (Strauss−Poisson)", "delta_aic")
                    if c in strauss_df.columns), None)
    if gamma_col is None:
        return None
    valid = strauss_df[gamma_col].notna()
    if not valid.any():
        return None
    fig, ax = plt.subplots(figsize=(max(5, 0.9 * valid.sum() + 1), 4.5))
    g = strauss_df.loc[valid, gamma_col].values
    colors = ["#d62728" if x < 0.9 else "#1f77b4" if x > 1.1 else "#7f7f7f"
              for x in g]
    bars = ax.bar(strauss_df.index[valid], g, color=colors, edgecolor="k")
    ax.axhline(1.0, color="k", linestyle="--", label="CSR (γ=1)")
    ax.set_ylabel("γ (Strauss interaction parameter)")
    ax.set_title("Strauss Process: Interaction Parameter γ\n"
                 "γ < 1 = inhibition (regular); γ > 1 = clustering tendency; γ = 1 = CSR")
    ax.set_xticks(range(valid.sum()))
    ax.set_xticklabels(strauss_df.index[valid], rotation=30, ha="right")
    ax.legend()
    if aic_col is not None:
        for bar, daic in zip(bars, strauss_df.loc[valid, aic_col].values):
            if pd.notna(daic):
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + 0.02,
                        f"ΔAIC={daic:.0f}",
                        ha="center", va="bottom", fontsize=7)
    return fig


# ── Section 6 — interactions ─────────────────────────────────────────────────
def plot_nhood_zscore(z_df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(0.6 * len(z_df) + 2, 0.6 * len(z_df) + 1.5))
    vmax = float(np.nanpercentile(np.abs(z_df.values), 95)) or 1.0
    sns.heatmap(z_df, ax=ax, cmap="RdBu_r", center=0, vmin=-vmax, vmax=vmax,
                annot=True, fmt=".1f", annot_kws={"size": 7})
    ax.set_title("Squidpy neighbourhood-enrichment z-score")
    return fig


def plot_funspace_curve(radii: np.ndarray, H_mean: np.ndarray,
                        H_by_type: dict | None = None):
    fig, axs = plt.subplots(1, 2, figsize=(13, 4.5))
    axs[0].plot(radii, H_mean, "k-", lw=2.5, label="all cells")
    axs[0].set_xlabel("radius r (µm)")
    axs[0].set_ylabel("Mean Shannon entropy H(r) (bits)")
    axs[0].set_title("FunSpace: global H(r)")
    axs[0].legend()
    if H_by_type:
        cmap = plt.get_cmap("tab10", len(H_by_type))
        for i, (t, H_t) in enumerate(H_by_type.items()):
            axs[1].plot(radii, H_t, lw=1.6, color=cmap(i), label=t)
        axs[1].set_xlabel("radius r (µm)")
        axs[1].set_ylabel("Mean H(r) (bits)")
        axs[1].set_title("Per cell-type H(r)")
        axs[1].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    return fig


def plot_zone_map(coords: np.ndarray, zone: np.ndarray, palette: dict | None = None):
    palette = palette or {
        "Tumour core": "#d62728", "Tumour interface": "#ff7f0e",
        "Stroma interface": "#1f77b4", "Stroma core": "#aec7e8",
        "Other": "#bdbdbd",
    }
    fig, ax = plt.subplots(figsize=(7, 7))
    ax.scatter(coords[:, 0], coords[:, 1],
               c=[palette.get(z, "#bdbdbd") for z in zone], s=2, alpha=0.7)
    handles = [Patch(color=c, label=l) for l, c in palette.items()
               if (zone == l).any()]
    ax.legend(handles=handles, fontsize=8, markerscale=3, loc="upper right")
    ax.set_aspect("equal")
    ax.set_title("Tumour-stroma interface zones")
    return fig


# ── Section 7 — clustering ───────────────────────────────────────────────────
def plot_potts_vs_truth(coords: np.ndarray, potts_labels: np.ndarray,
                        truth_labels: np.ndarray, n_types: int):
    fig, axs = plt.subplots(1, 2, figsize=(14, 6))
    sc0 = axs[0].scatter(coords[:, 0], coords[:, 1], c=potts_labels,
                         cmap="tab10", s=1, vmin=0, vmax=n_types - 1)
    fig.colorbar(sc0, ax=axs[0], label="Potts cluster")
    axs[0].set_title("Potts MRF labels")
    axs[0].set_aspect("equal")
    sc1 = axs[1].scatter(coords[:, 0], coords[:, 1], c=truth_labels,
                         cmap="tab10", s=1, vmin=0, vmax=n_types - 1)
    fig.colorbar(sc1, ax=axs[1], label="ground truth")
    axs[1].set_title("Ground-truth cell types")
    axs[1].set_aspect("equal")
    return fig


def plot_niche_silhouette(scores: dict, best_k: int):
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(list(scores.keys()), list(scores.values()), "o-", lw=2)
    ax.axvline(best_k, color="C1", linestyle="--", label=f"best k = {best_k}")
    ax.set_xlabel("k")
    ax.set_ylabel("silhouette score")
    ax.set_title("Cellular niche selection")
    ax.legend()
    return fig


def plot_niche_map(coords: np.ndarray, niche_labels: np.ndarray,
                   names: dict, k: int):
    cmap = plt.get_cmap("tab10", k)
    cols = np.array([cmap(niche_labels[i]) if niche_labels[i] >= 0
                     else (0.8, 0.8, 0.8, 0.3) for i in range(len(coords))])
    fig, ax = plt.subplots(figsize=(7, 7))
    ax.scatter(coords[:, 0], coords[:, 1], c=cols, s=3, alpha=0.8)
    handles = [Patch(color=cmap(i), label=names[i]) for i in range(k)]
    ax.legend(handles=handles, fontsize=7, loc="upper right", markerscale=2)
    ax.set_aspect("equal")
    ax.set_title(f"Cellular niche map (k={k})")
    return fig


# ── Section 8 — morphology ───────────────────────────────────────────────────
def plot_orientation_rose(angles_rad: np.ndarray, n_bins: int = 18):
    fig, ax = plt.subplots(subplot_kw={"projection": "polar"}, figsize=(5, 5))
    counts, edges = np.histogram(angles_rad, bins=n_bins, range=(0, np.pi))
    centres = 0.5 * (edges[:-1] + edges[1:])
    theta = np.concatenate([centres, centres + np.pi])
    counts_full = np.concatenate([counts, counts])
    ax.bar(theta, counts_full, width=np.pi / n_bins,
           alpha=0.7, color="steelblue", edgecolor="k")
    ax.set_theta_zero_location("E")
    ax.set_title("Orientation rose diagram", pad=15)
    return fig


# ── Section 9/10 — generic SES heatmap ───────────────────────────────────────
def plot_ses_heatmap(ses_df: pd.DataFrame, sig_df: pd.DataFrame | None = None,
                    title: str = "SES heatmap"):
    """SES heatmap with annotated values and significance asterisks.

    Each cell shows the SES value (1 decimal place).  Cells that are
    statistically significant (``sig_df`` True) are additionally marked
    with a bold ``*`` overlaid on the annotation.  NaN cells are left blank.
    """
    n = len(ses_df)
    sz = max(1.2 * n, 7) + 1
    fig, ax = plt.subplots(figsize=(sz, sz - 0.5))
    vmax = float(np.nanpercentile(np.abs(ses_df.values), 95)) or 1.0
    sns.heatmap(ses_df, ax=ax, cmap="RdBu_r", center=0,
                vmin=-vmax, vmax=vmax, linewidths=0.4, linecolor="grey",
                annot=True, fmt=".1f", annot_kws={"size": 8},
                cbar_kws={"label": "SES"})
    if sig_df is not None:
        for i in range(n):
            for j in range(n):
                if sig_df.values[i, j]:
                    ax.text(j + 0.5, i + 0.5, "*", ha="center", va="bottom",
                            fontsize=13, fontweight="bold", color="black")
    ax.set_title(title)
    fig.canvas.draw()
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right", fontsize=8)
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=8)
    fig.tight_layout()
    return fig


def plot_anni_bar(anni_df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(max(5, 0.8 * len(anni_df)), 4))
    cols = ["#d62728" if r["Pattern"] == "Clustered"
            else "#1f77b4" if r["Pattern"] == "Dispersed"
            else "#7f7f7f"
            for _, r in anni_df.iterrows()]
    bars = ax.bar(anni_df.index, anni_df["ANNI"], color=cols, edgecolor="k")
    ax.axhline(1.0, color="k", linestyle="--", label="CSR")
    for bar, (_, r) in zip(bars, anni_df.iterrows()):
        if r["p-value"] < 0.05:
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.01, "*", ha="center", va="bottom",
                    fontsize=12, fontweight="bold")
    ax.set_ylabel("ANNI")
    ax.set_title("Average Nearest Neighbour Index per cell type")
    ax.set_xticks(range(len(anni_df)))
    ax.set_xticklabels(anni_df.index, rotation=30, ha="right")
    ax.legend()
    return fig


def plot_swd_heatmap(swd_df: pd.DataFrame):
    n = len(swd_df)
    sz = max(1.2 * n, 7) + 1
    fig, ax = plt.subplots(figsize=(sz, sz - 0.5))
    sns.heatmap(swd_df, ax=ax, cmap="magma_r", vmin=0,
                annot=True, fmt=".0f", annot_kws={"size": 8},
                linewidths=0.4, linecolor="grey",
                cbar_kws={"label": "Sliced Wasserstein Distance (µm)"})
    ax.set_title("Sliced Wasserstein Distance")
    fig.canvas.draw()
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right", fontsize=8)
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=8)
    fig.tight_layout()
    return fig


def plot_morisita_heatmap(mh_df: pd.DataFrame):
    n = len(mh_df)
    sz = max(1.2 * n, 7) + 1
    fig, ax = plt.subplots(figsize=(sz, sz - 0.5))
    sns.heatmap(mh_df, ax=ax, cmap="viridis", vmin=0, vmax=1,
                annot=True, fmt=".2f", annot_kws={"size": 8},
                linewidths=0.4, linecolor="grey",
                cbar_kws={"label": "Morisita-Horn"})
    ax.set_title("Morisita-Horn index")
    fig.canvas.draw()
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right", fontsize=8)
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=8)
    fig.tight_layout()
    return fig


def plot_tcm(tcm: np.ndarray, xx: np.ndarray, yy: np.ndarray,
             A: np.ndarray, B: np.ndarray, ta: str, tb: str):
    fig, ax = plt.subplots(figsize=(7, 6))
    vmax = float(np.nanpercentile(np.abs(tcm), 98)) or 1.0
    # Use a copy of the colormap with NaN cells rendered as light grey
    # (tissue boundary / outside ROI) rather than white rectangles.
    cmap = plt.get_cmap("RdBu_r").copy()
    cmap.set_bad(color="#CCCCCC")
    im = ax.pcolormesh(xx, yy, tcm, cmap=cmap,
                       vmin=-vmax, vmax=vmax, shading="auto")
    ax.scatter(A[:, 0], A[:, 1], s=1, c="k", alpha=0.3, label=ta)
    ax.scatter(B[:, 0], B[:, 1], s=1, c="lime", alpha=0.3, label=tb)
    fig.colorbar(im, ax=ax, label="TCM score")
    ax.set_aspect("equal")
    ax.set_title(f"TCM: {ta} → {tb}")
    ax.legend(fontsize=7, markerscale=4)
    return fig


# ──────────────────────────────────────────────────────────────────────────────
# Section 4 — autocorrelation extras
# ──────────────────────────────────────────────────────────────────────────────
def plot_focal_gene_distribution(y: np.ndarray, gene_name: str):
    """Mapclassify ADCM bar plot for the focal feature.

    Mirrors notebook cell 23: compute the absolute deviation around class
    medians (ADCM) for several mapclassify schemes (Quantiles, EqualInterval,
    HeadTailBreaks, MaximumBreaks, StdMean, FisherJenks) and render a
    horizontal bar plot — the chart used to choose the binning that minimises
    within-class spread for the focal gene.
    """
    import mapclassify

    classifiers = []
    for cls, kwargs in (
        (mapclassify.Quantiles, {"k": 5}),
        (mapclassify.EqualInterval, {"k": 5}),
        (mapclassify.HeadTailBreaks, {}),
        (mapclassify.MaximumBreaks, {"k": 5}),
        (mapclassify.StdMean, {}),
        (mapclassify.FisherJenks, {"k": 5}),
    ):
        try:
            classifiers.append(cls(np.asarray(y, dtype=float), **kwargs))
        except Exception:
            continue

    if not classifiers:
        fig, ax = plt.subplots(figsize=(7, 4))
        ax.hist(y, bins=40, color="steelblue", alpha=0.85, edgecolor="k")
        ax.set_xlabel(gene_name)
        ax.set_ylabel("count")
        ax.set_title(f"Distribution of focal feature: {gene_name}")
        return fig

    adcms = pd.DataFrame({
        "ADCM": [float(c.adcm) for c in classifiers],
        "Classifier": [c.name for c in classifiers],
    })
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.barplot(y="Classifier", x="ADCM", data=adcms,
                palette="Pastel1", ax=ax)
    ax.set_title(f"Mapclassify ADCM — {gene_name}")
    fig.tight_layout()
    return fig


def plot_moran_scatter(y: np.ndarray, w_lag: np.ndarray, moran_I: float):
    """Moran scatter: y vs spatial lag of y."""
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(y, w_lag, s=4, alpha=0.5, color="steelblue")
    ax.axhline(0, color="k", lw=0.5)
    ax.axvline(0, color="k", lw=0.5)
    m, b = np.polyfit(y, w_lag, 1)
    xs = np.linspace(y.min(), y.max(), 50)
    ax.plot(xs, m * xs + b, "r-", lw=1.5, label=f"slope={m:.3f}")
    ax.set_xlabel("y (centred)")
    ax.set_ylabel("Wy (spatial lag)")
    ax.set_title(f"Moran scatter — I = {moran_I:.3f}")
    ax.legend()
    return fig


def plot_lisa_map(coords: np.ndarray, lisa, gistar=None,
                  local_geary=None, alpha: float = 0.05):
    """3-panel local-statistics map (Local Moran I_i, G_i*, Local Geary c_i).

    Mirrors notebook cell 47: cells with p ≥ α drawn in light grey,
    significant cells coloured by their local value with a Blues colormap.
    Falls back to the single LISA quadrant scatter if ``gistar`` and
    ``local_geary`` are not provided.
    """
    if gistar is None or local_geary is None:
        sig = lisa.p_sim < alpha
        quad = np.asarray(lisa.q)
        cmap = {0: "#bdbdbd", 1: "#d62728", 2: "#1f77b4",
                3: "#ff7f0e", 4: "#2ca02c"}
        cls = np.where(sig, quad, 0)
        cols = np.array([cmap[int(c)] for c in cls])
        fig, ax = plt.subplots(figsize=(7, 7))
        ax.scatter(coords[:, 0], coords[:, 1], c=cols, s=4)
        ax.set_aspect("equal")
        ax.set_axis_off()
        ax.set_title(f"Local Moran (LISA) quadrants — α={alpha}")
        handles = [
            Patch(color="#d62728", label="HH"),
            Patch(color="#1f77b4", label="LL"),
            Patch(color="#ff7f0e", label="HL"),
            Patch(color="#2ca02c", label="LH"),
            Patch(color="#bdbdbd", label="n.s."),
        ]
        ax.legend(handles=handles, fontsize=8, loc="upper right",
                  markerscale=1)
        return fig

    panels = [
        ("Local Moran $I_i$",
         np.asarray(lisa.Is), np.asarray(lisa.p_sim)),
        ("Local Gi*",
         np.asarray(getattr(gistar, "Zs", getattr(gistar, "Gs", None))),
         np.asarray(gistar.p_sim)),
        ("Local Geary $c_i$",
         np.asarray(getattr(local_geary, "localG",
                            getattr(local_geary, "Gs", None))),
         np.asarray(local_geary.p_sim)),
    ]
    fig, axs = plt.subplots(1, 3, figsize=(15, 5))
    for ax, (name, vals, pvals) in zip(axs, panels):
        sig = pvals < alpha
        ax.scatter(coords[~sig, 0], coords[~sig, 1], s=1, color="0.85")
        sc = ax.scatter(coords[sig, 0], coords[sig, 1], s=3,
                        c=vals[sig], cmap="Blues")
        plt.colorbar(sc, ax=ax, fraction=0.04)
        ax.set_aspect("equal")
        ax.set_axis_off()
        ax.set_title(name)
    fig.tight_layout()
    return fig


def plot_top_svg_maps(coords: np.ndarray, Xmat: np.ndarray,
                      var_names: list[str], top_genes: list[str],
                      svg_df: pd.DataFrame | None = None):
    """6-panel grid of spatial maps for the top SVGs.

    Mirrors notebook cell 64: ``cmap='magma'``, per-panel ``vmin/vmax`` from
    the 5/95 percentile of the gene's expression, point size 3 with α=0.8,
    and a per-panel ``"{gene}\\nI = {moran_I:.3f}"`` title when ``svg_df`` is
    supplied.
    """
    n = min(len(top_genes), 6)
    ncols = 3
    nrows = (n + ncols - 1) // ncols
    fig, axs = plt.subplots(nrows, ncols,
                            figsize=(5 * ncols, 4.5 * nrows),
                            squeeze=False)
    name_to_idx = {g: i for i, g in enumerate(var_names)}

    moran_lookup = {}
    if svg_df is not None and "Gene" in svg_df.columns and "Moran's I" in svg_df.columns:
        moran_lookup = dict(zip(svg_df["Gene"], svg_df["Moran's I"]))

    for i in range(n):
        ax = axs[i // ncols][i % ncols]
        g = top_genes[i]
        if g not in name_to_idx:
            ax.set_axis_off()
            continue
        v = np.asarray(Xmat[:, name_to_idx[g]], float)
        vmin_g = float(np.percentile(v, 5))
        vmax_g = float(np.percentile(v, 95))
        sc = ax.scatter(coords[:, 0], coords[:, 1], c=v,
                        cmap="magma", s=3, alpha=0.8,
                        vmin=vmin_g, vmax=vmax_g)
        plt.colorbar(sc, ax=ax, label="Expression")
        ax.set_aspect("equal")
        ax.set_axis_off()
        if g in moran_lookup:
            ax.set_title(f"{g}\nI = {float(moran_lookup[g]):.3f}",
                         fontsize=9)
        else:
            ax.set_title(g, fontsize=9)
    for j in range(n, nrows * ncols):
        axs[j // ncols][j % ncols].set_axis_off()
    fig.suptitle("Top Spatially Variable Genes (SVGs)\n"
                 "High Moran's I = expression concentrated in specific tissue regions",
                 fontsize=10)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    return fig


def plot_bivariate_moran_heatmap(pairs_df: pd.DataFrame, top_n: int = 30):
    """Heatmap of pairwise bivariate Moran's I on top HVGs."""
    df = pairs_df.copy()
    genes = sorted(set(df["gene_1"]).union(df["gene_2"]))[:top_n]
    M = pd.DataFrame(np.nan, index=genes, columns=genes)
    for _, r in df.iterrows():
        a, b = r["gene_1"], r["gene_2"]
        if a in M.index and b in M.columns:
            M.loc[a, b] = r["I"]
            M.loc[b, a] = r["I"]
    fig, ax = plt.subplots(figsize=(0.4 * len(genes) + 2, 0.4 * len(genes) + 1.5))
    vmax = float(np.nanpercentile(np.abs(M.values), 95)) or 1.0
    sns.heatmap(M, ax=ax, cmap="RdBu_r", center=0, vmin=-vmax, vmax=vmax,
                xticklabels=True, yticklabels=True, cbar_kws={"label": "I"})
    ax.set_title("Bivariate Moran's I — top HVG pairs")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=90, fontsize=6)
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=6)
    return fig


# ──────────────────────────────────────────────────────────────────────────────
# Section 5 — point-pattern extras
# ──────────────────────────────────────────────────────────────────────────────
def plot_per_type_ripley(per_type_results: dict, support: np.ndarray):
    """5-panel curve plot K/G/F/L/pcf, one curve per cell type."""
    stat_names = ["K", "G", "F", "L", "pcf"]
    fig, axs = plt.subplots(1, 5, figsize=(20, 4.5))
    csr_K = np.pi * support ** 2
    for ax, sname in zip(axs, stat_names):
        for t, vals in per_type_results.items():
            ax.plot(support, vals[sname], label=t, linewidth=1.0)
        if sname == "K":
            ax.plot(support, csr_K, "k--", lw=0.8, label="CSR")
        elif sname == "L":
            ax.axhline(0, color="k", linestyle="--", lw=0.8)
        elif sname == "pcf":
            ax.axhline(1, color="k", linestyle="--", lw=0.8)
        ax.set_xlabel("r")
        ax.set_title(sname)
    axs[0].legend(fontsize=7, loc="upper left", frameon=False)
    fig.tight_layout()
    return fig


def plot_rstar_heatmap(crossK_summary: pd.DataFrame, types: list[str]):
    """r* (crossing radius) heatmap from the cross-K summaries DataFrame."""
    M = pd.DataFrame(np.nan, index=types, columns=types)
    for _, r in crossK_summary.iterrows():
        if r["type_a"] in M.index and r["type_b"] in M.columns:
            M.loc[r["type_a"], r["type_b"]] = r["r_star"]
    n = len(types)
    sz = max(1.2 * n, 7) + 1
    fig, ax = plt.subplots(figsize=(sz, sz - 0.5))
    sns.heatmap(M, ax=ax, cmap="viridis_r", annot=True, fmt=".0f",
                mask=M.isna(), cbar_kws={"label": "r* (µm)"},
                annot_kws={"size": 8})
    ax.set_title("Crossing radius r* of Cross-K (µm)")
    ax.set_xlabel("type b")
    ax.set_ylabel("type a")
    # canvas.draw() forces seaborn to populate tick labels before we rotate them
    fig.canvas.draw()
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right", fontsize=8)
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=8)
    fig.tight_layout()
    return fig


def plot_dL_dr_panels(dL_results: dict, support: np.ndarray):
    """Per-cell-type L(r), dL/dr, g_from_dL panels (3 rows × N cols)."""
    n = len(dL_results)
    if n == 0:
        return None
    fig, axs = plt.subplots(3, n, figsize=(4 * n, 9), squeeze=False)
    for col, (t, res) in enumerate(dL_results.items()):
        r = support
        axs[0, col].plot(r, res["L"], "C0-", lw=1.8)
        axs[0, col].axhline(0, color="k", lw=0.6, linestyle="--")
        axs[0, col].axvline(res["r_star"], color="C1", linestyle=":",
                            label=f"r* = {res['r_star']:.0f} µm")
        axs[0, col].set_title(f"{t}\nL(r)", fontsize=9)
        axs[0, col].legend(fontsize=7)
        axs[1, col].plot(r, res["dL_dr"], "C2-", lw=1.8)
        axs[1, col].axvline(res["r_star"], color="C1", linestyle=":")
        axs[1, col].set_title("dL/dr (peak = dominant scale)", fontsize=9)
        g_plot = np.clip(res["g_dL"], 0, 5)
        axs[2, col].plot(r, g_plot, "C3-", lw=1.8)
        axs[2, col].axhline(1.0, color="k", lw=0.6, linestyle="--")
        axs[2, col].set_title("g from dL/dr (consistency check)", fontsize=9)
        axs[2, col].set_xlabel("r (µm)")
    fig.suptitle("PCF from L-function derivative", fontsize=10)
    fig.tight_layout()
    return fig


def plot_per_type_kinhom(per_type_results: dict, support: np.ndarray):
    """K_hom vs K_inhom per cell type (one panel per type)."""
    n = len(per_type_results)
    if n == 0:
        return None
    fig, axs = plt.subplots(1, n, figsize=(5 * n, 4), squeeze=False)
    K_csr = np.pi * support ** 2
    for ax, (ct, res) in zip(axs[0], per_type_results.items()):
        ax.plot(support, res["K_hom"], "C0", lw=1.5, label="Homogeneous K(r)")
        ax.plot(support, res["K_inh"], "C2", lw=1.5,
                label=r"$K_{\mathrm{inhom}}(r)$")
        ax.plot(support, K_csr, "k--", lw=1, label=r"CSR ($\pi r^2$)")
        ax.set_title(ct, fontsize=10)
        ax.set_xlabel("r (µm)")
        ax.set_ylabel("K(r)")
        ax.legend(fontsize=8)
    fig.suptitle("Homogeneous vs Inhomogeneous K — per cell type", fontsize=11)
    fig.tight_layout()
    return fig


def plot_per_type_pcf_inhom(pcf_inhom_dict: dict, support: np.ndarray):
    """g_inhom(r) per cell type."""
    n = len(pcf_inhom_dict)
    if n == 0:
        return None
    fig, axs = plt.subplots(1, n, figsize=(5 * n, 4), sharey=True, squeeze=False)
    for ax, (ct, g) in zip(axs[0], pcf_inhom_dict.items()):
        ax.plot(support, g, "C2", lw=1.5)
        ax.axhline(1, color="k", linestyle="--", lw=1, label="Inhom. Poisson")
        ax.set_title(ct, fontsize=10)
        ax.set_xlabel("r (µm)")
        ax.set_ylabel(r"$g_{\mathrm{inhom}}(r)$")
        ax.legend(fontsize=8)
    fig.suptitle(r"Inhomogeneous pair correlation $g_{\mathrm{inhom}}(r)$",
                 fontsize=11)
    fig.tight_layout()
    return fig


def plot_csr_envelope_K(env_dict: dict):
    """Pointwise + global CSR envelope for K(r) with MAD/DCLF p-values.

    Draw order (back → front):
      1. Global 95% envelope  (orange, wider band)
      2. Pointwise 95% envelope (blue, narrower band, on top so it stays visible)
      3. Observed K(r) and CSR lines
    """
    r = env_dict["support"]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    # Global envelope drawn first (background)
    ax.fill_between(r, env_dict["global_lo"], env_dict["global_hi"],
                    color="C1", alpha=0.35, zorder=1,
                    label="Global 95% envelope")
    # Pointwise envelope drawn on top so it is always visible
    ax.fill_between(r, env_dict["pw_lo"], env_dict["pw_hi"],
                    color="C0", alpha=0.45, zorder=2,
                    label="Pointwise 95% envelope")
    ax.plot(r, env_dict["obs"], "k", lw=1.8, zorder=4, label="Observed K(r)")
    ax.plot(r, np.pi * r ** 2, "k--", lw=1, zorder=3, label=r"CSR ($\pi r^2$)")
    ax.set_xlabel("r (µm)")
    ax.set_ylabel("K(r)")
    ax.set_title(f"Ripley K — pointwise vs global CSR envelopes\n"
                 f"MAD p = {env_dict['mad_p']:.3f}  |  "
                 f"DCLF p = {env_dict['dclf_p']:.3f}")
    ax.legend(fontsize=8)
    return fig


def plot_astropy_modes(astropy_dict: dict):
    """Astropy edge-corrected K under multiple modes."""
    r = astropy_dict["radii"]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    for mode, K in astropy_dict.items():
        if mode in ("radii", "csr") or K is None:
            continue
        ax.plot(r, K, label=mode, lw=1.2)
    ax.plot(r, astropy_dict["csr"], "k--", lw=0.8, label="CSR")
    ax.set_xlabel("r")
    ax.set_ylabel("K(r)")
    ax.legend()
    ax.set_title("Ripley K — five edge corrections (astropy)")
    return fig


def plot_kde_ricker(field: np.ndarray, responses: dict, sigmas: np.ndarray):
    """KDE field + per-scale Ricker wavelet responses."""
    n = len(sigmas) + 1
    fig, axs = plt.subplots(1, n, figsize=(3 * n, 3.5))
    axs[0].imshow(field, origin="lower", cmap="viridis")
    axs[0].set_title("KDE field")
    axs[0].set_axis_off()
    for k, s in enumerate(sigmas, start=1):
        resp = responses[float(s)]
        axs[k].imshow(resp, origin="lower", cmap="RdBu_r")
        axs[k].set_title(f"Ricker σ={s:.0f}")
        axs[k].set_axis_off()
    fig.tight_layout()
    return fig


def plot_directional_pcf(g_dir: np.ndarray, angle_centres: np.ndarray,
                         support: np.ndarray, ta: str, tb: str):
    """Cartesian heatmap (angle × radius) + polar of mean g(θ)."""
    fig = plt.figure(figsize=(13, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    vmax = float(np.nanpercentile(np.abs(g_dir - 1), 95)) + 1
    im = ax1.imshow(g_dir, aspect="auto", origin="lower", cmap="RdBu_r",
                    vmin=2 - vmax, vmax=vmax,
                    extent=[support[0], support[-1],
                            np.degrees(angle_centres[0]),
                            np.degrees(angle_centres[-1])])
    plt.colorbar(im, ax=ax1, label="g_dir(r, θ)  (1 = isotropic)")
    ax1.set_xlabel("Distance r (µm)")
    ax1.set_ylabel("Direction θ (degrees)")
    ax1.set_title(f"Directional PCF: {ta} → {tb}")

    ax2 = fig.add_subplot(1, 2, 2, projection="polar")
    g_mean = np.nanmean(g_dir, axis=1)
    theta = np.append(angle_centres, angle_centres[0])
    g_plot = np.append(g_mean, g_mean[0])
    ax2.plot(theta, g_plot, "C0-o", lw=2, markersize=5)
    ax2.fill(theta, g_plot, alpha=0.2, color="C0")
    ax2.axhline(1.0, color="k", linestyle="--", lw=0.8)
    ax2.set_title(f"Mean g(θ) over all r\n{ta} → {tb}", pad=15)
    ax2.set_theta_zero_location("E")
    fig.tight_layout()
    return fig


def plot_cross_k_isotropic_heatmap(auc_K: np.ndarray, types: list[str]):
    """Cross-K AUC heatmap (Ripley isotropic edge correction)."""
    fig, ax = plt.subplots(figsize=(0.7 * len(types) + 2, 0.7 * len(types) + 1.5))
    vmax = float(np.nanpercentile(np.abs(auc_K), 95)) or 1.0
    im = ax.imshow(auc_K, cmap="RdBu_r", vmin=-vmax, vmax=vmax)
    ax.set_xticks(range(len(types)))
    ax.set_xticklabels(types, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(len(types)))
    ax.set_yticklabels(types, fontsize=8)
    ax.set_title("Cross-K AUC (Ripley isotropic edge correction)")
    fig.colorbar(im, ax=ax, label="AUC of K_ab(r) − πr²")
    return fig


def plot_inhomogeneous_compare(auc_homog: np.ndarray, auc_inhom: np.ndarray,
                               types: list[str]):
    """Side-by-side homogeneous vs inhomogeneous Cross-K AUC heatmaps."""
    fig, axs = plt.subplots(1, 2, figsize=(13, 0.6 * len(types) + 2))
    for ax, mat, title in zip(
        axs, [auc_homog, auc_inhom],
        ["Cross-K AUC (homogeneous)", "Cross-K AUC (inhomogeneous)"],
    ):
        vmax = float(np.nanpercentile(np.abs(mat), 95)) or 1.0
        im = ax.imshow(mat, cmap="RdBu_r", vmin=-vmax, vmax=vmax)
        ax.set_xticks(range(len(types)))
        ax.set_xticklabels(types, rotation=45, ha="right", fontsize=8)
        ax.set_yticks(range(len(types)))
        ax.set_yticklabels(types, fontsize=8)
        ax.set_title(title)
        plt.colorbar(im, ax=ax, label="AUC")
    fig.suptitle("Inhomogeneous correction removes density-gradient confound",
                 fontsize=10)
    fig.tight_layout()
    return fig


def plot_pcf_envelope(pcf_dict: dict, title: str = "PCF g(r)"):
    """Envelope plot for univariate or cross-PCF dicts from higher_order.py."""
    r = pcf_dict["r"]
    obs = pcf_dict.get("g_obs", pcf_dict.get("g_ab"))
    sims = pcf_dict.get("g_sims")
    fig, ax = plt.subplots(figsize=(7, 4.5))
    if sims is not None:
        ax.fill_between(r, np.nanpercentile(sims, 2.5, axis=0),
                        np.nanpercentile(sims, 97.5, axis=0),
                        color="C0", alpha=0.25, label="95% envelope")
        ax.plot(r, np.nanmedian(sims, axis=0), color="cyan",
                label="median sim")
    ax.plot(r, obs, color="red", label="observed")
    ax.axhline(1.0, color="k", linestyle="--")
    ax.set_xlabel("distance (µm)")
    ax.set_ylabel("g(r)")
    ax.set_title(title)
    ax.legend(fontsize=8)
    return fig


def plot_oring(oring_dict: dict):
    """O-ring envelope plot."""
    r = oring_dict["r"]
    obs = oring_dict["O_obs"]
    sims = oring_dict.get("O_sims")
    fig, ax = plt.subplots(figsize=(7, 4.5))
    if sims is not None:
        ax.fill_between(r, np.nanpercentile(sims, 2.5, axis=0),
                        np.nanpercentile(sims, 97.5, axis=0),
                        color="C0", alpha=0.25, label="95% envelope")
        ax.plot(r, np.nanmedian(sims, axis=0), color="cyan",
                label="median sim")
    ax.plot(r, obs, color="red", label="observed")
    ax.set_xlabel("distance (µm)")
    ax.set_ylabel("O(r)")
    ax.set_title("O-ring function")
    ax.legend(fontsize=8)
    return fig


def plot_mark_correlation(mark_dict: dict, gene_name: str):
    """Mark correlation k_m(r) with permutation envelope."""
    r = mark_dict["r"]
    obs = mark_dict["k_m_obs"]
    sims = mark_dict.get("k_m_sims")
    fig, ax = plt.subplots(figsize=(7, 4.5))
    if sims is not None:
        ax.fill_between(r, np.nanpercentile(sims, 2.5, axis=0),
                        np.nanpercentile(sims, 97.5, axis=0),
                        color="C0", alpha=0.25, label="95% perm envelope")
    ax.plot(r, obs, "red", label="observed")
    ax.axhline(1.0, color="k", linestyle="--")
    ax.set_xlabel("distance (µm)")
    ax.set_ylabel(r"$k_m(r)$")
    ax.set_title(f"Mark correlation — {gene_name}")
    ax.legend(fontsize=8)
    return fig


def plot_empty_space_hazard(haz_dict: dict):
    """h(r) = f(r)/(1-F(r)) with envelope; truncated where F > 0.95."""
    r = haz_dict["r"]
    obs = haz_dict["h_obs"]
    sims = haz_dict.get("h_sims")
    valid = haz_dict["valid"]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    if sims is not None:
        ax.fill_between(r, np.nanpercentile(sims, 2.5, axis=0),
                        np.nanpercentile(sims, 97.5, axis=0),
                        color="C0", alpha=0.25, label="95% envelope")
    ax.plot(r[valid], obs[valid], "red", label="observed")
    ax.axhline(1.0, color="k", linestyle="--")
    ax.set_xlabel("distance (µm)")
    ax.set_ylabel("h(r)")
    ax.set_title("Empty-space hazard function (truncated at F=0.95)")
    ax.legend(fontsize=8)
    return fig


# ──────────────────────────────────────────────────────────────────────────────
# Section 6 — interactions extras
# ──────────────────────────────────────────────────────────────────────────────
def plot_cooccurrence_zscore(Z: np.ndarray, labels: list[str], top_n: int = 12):
    """Top-N permutation-z-score cell-type co-occurrence heatmap."""
    top_idx = np.argsort(-np.abs(Z).sum(axis=1))[: min(top_n, len(labels))]
    Zt = Z[np.ix_(top_idx, top_idx)]
    labs = [labels[i] for i in top_idx]
    fig, ax = plt.subplots(figsize=(0.8 * len(labs) + 2, 0.8 * len(labs) + 1.5))
    sns.heatmap(Zt, ax=ax, xticklabels=labs, yticklabels=labs,
                cmap="RdBu_r", center=0, annot=True, fmt=".1f",
                annot_kws={"size": 8})
    ax.set_title("Co-occurrence z-score (top labels)")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right")
    return fig


def plot_schmid_pairwise(ms_df: pd.DataFrame):
    """Side-by-side raw and normalised Schmid MS_AB heatmaps."""
    raw = ms_df.pivot(index="type_a", columns="type_b", values="MS")
    norm = ms_df.pivot(index="type_a", columns="type_b", values="MS_norm")
    n = len(raw)
    sz = max(1.2 * n, 7) + 1
    fig, axs = plt.subplots(1, 2, figsize=(sz * 2, sz - 0.5))
    # Raw panel — no NaN masking needed (always finite)
    sns.heatmap(raw, ax=axs[0], cmap="YlOrRd", annot=True, fmt=".2f",
                annot_kws={"size": 8})
    axs[0].set_title("Raw MS_AB (n_AB / n_AA)")
    axs[0].set_xlabel("Type B")
    axs[0].set_ylabel("Type A")
    # Normalised panel — mask NaN cells (rare cell types) so they render grey
    norm_mask = norm.isna()
    sns.heatmap(norm, ax=axs[1], cmap="YlOrRd", annot=True, fmt=".2f",
                mask=norm_mask, annot_kws={"size": 8})
    axs[1].set_title("Normalised MS_norm_AB")
    axs[1].set_xlabel("Type B")
    axs[1].set_ylabel("Type A")
    fig.suptitle("Schmid pairwise mixing scores", y=1.01)
    fig.canvas.draw()
    for ax in axs:
        ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right", fontsize=8)
        ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=8)
    fig.tight_layout()
    return fig


def plot_spiat_mixing(ms_df: pd.DataFrame, nms_df: pd.DataFrame, k: int):
    """SPIAT raw mixing + log2(NMS) heatmaps."""
    fig, axs = plt.subplots(1, 2, figsize=(13, 0.6 * len(ms_df) + 2))
    sns.heatmap(ms_df, ax=axs[0], cmap="YlOrRd", vmin=0,
                annot=True, fmt=".2f", annot_kws={"size": 8})
    axs[0].set_title(f"SPIAT mixing score (k={k})")
    log2_nms = np.log2(nms_df.replace(0, np.nan))
    vmax = float(np.nanpercentile(np.abs(log2_nms.values), 95)) or 1.0
    sns.heatmap(log2_nms, ax=axs[1], cmap="RdBu_r", center=0,
                vmin=-vmax, vmax=vmax,
                annot=nms_df.round(2), fmt="", annot_kws={"size": 7})
    axs[1].set_title("log2(NMS)  (0 = random, + = enriched)")
    for ax in axs:
        ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right")
    fig.tight_layout()
    return fig


def plot_distance_shells(coords: np.ndarray, signed_dists: np.ndarray,
                         comp_frac: np.ndarray, shell_mids: np.ndarray,
                         types: list[str]):
    """Signed distance map + cell-type composition stacked bar across shells."""
    fig, axs = plt.subplots(1, 2, figsize=(14, 5))
    sc = axs[0].scatter(coords[:, 0], coords[:, 1],
                        c=np.clip(signed_dists, -300, 500),
                        cmap="RdBu_r", s=1, vmin=-300, vmax=500)
    plt.colorbar(sc, ax=axs[0], label="Signed distance (µm)")
    axs[0].set_aspect("equal")
    axs[0].set_title("Signed distance to largest aggregate")

    bottom = np.zeros(len(shell_mids))
    cmap = plt.get_cmap("tab10", len(types))
    width = (shell_mids[1] - shell_mids[0]) * 0.85 if len(shell_mids) > 1 else 50
    for ti, t in enumerate(types):
        axs[1].bar(shell_mids, comp_frac[:, ti], width=width,
                   bottom=bottom, label=t, color=cmap(ti), alpha=0.85)
        bottom += comp_frac[:, ti]
    axs[1].axvline(0, color="k", linestyle="--", label="boundary")
    axs[1].set_xlabel("Signed distance (µm)")
    axs[1].set_ylabel("Cell-type fraction")
    axs[1].set_title("Composition across distance shells")
    axs[1].legend(fontsize=7, bbox_to_anchor=(1.01, 1), loc="upper left")
    fig.tight_layout()
    return fig


def plot_rhohat(rhohat_results: dict):
    """rho-hat intensity-vs-covariate per cell type."""
    fig, ax = plt.subplots(figsize=(9, 5))
    cmap = plt.get_cmap("tab10", len(rhohat_results))
    for i, (ct, (centers, rho)) in enumerate(rhohat_results.items()):
        ax.plot(centers, rho, lw=1.5, color=cmap(i), label=ct)
    ax.axvline(0, color="k", linestyle="--", label="boundary")
    ax.axhline(1, color="0.5", linestyle=":")
    ax.set_xlabel("Signed distance (µm)")
    ax.set_ylabel("Relative intensity ρ(z)")
    ax.set_title("ρ-hat intensity-vs-covariate")
    ax.legend(fontsize=8, bbox_to_anchor=(1.01, 1), loc="upper left")
    fig.tight_layout()
    return fig


def plot_icf_significance(icf_mat: pd.DataFrame, alpha: float = 0.05):
    """Heatmap of #significant ICF genes per (focal, neighbour) pair."""
    fig, ax = plt.subplots(figsize=(0.8 * len(icf_mat) + 2, 0.8 * len(icf_mat) + 1.5))
    sns.heatmap(icf_mat, ax=ax, cmap="YlOrRd", annot=True, fmt=".0f",
                cbar_kws={"label": f"#genes (FDR<{alpha})"})
    ax.set_title("Interaction-changed features (ICF)")
    ax.set_xlabel("Neighbour type")
    ax.set_ylabel("Focal type")
    return fig


def plot_simpsons_anni(D_cells: np.ndarray, D_by_type: dict,
                       labels: np.ndarray, anni_profiles: dict,
                       radius: float):
    """Per-cell Simpson's D violin + multi-scale ANNI profile."""
    fig, axs = plt.subplots(1, 2, figsize=(13, 4.5))
    df = pd.DataFrame({"Cell type": labels,
                       "Simpson's D": D_cells}).dropna()
    sns.violinplot(data=df, x="Cell type", y="Simpson's D",
                   ax=axs[0], inner="box", cut=0)
    axs[0].set_xticklabels(axs[0].get_xticklabels(), rotation=30, ha="right")
    axs[0].set_title(f"Spatial Simpson's D (r={radius:.0f} µm)")

    cmap = plt.get_cmap("tab10", len(anni_profiles))
    for i, (t, (kv, anni, _, _)) in enumerate(anni_profiles.items()):
        axs[1].plot(kv, anni, "o-", lw=1.5, color=cmap(i), label=t)
    axs[1].axhline(1.0, color="k", linestyle="--", label="CSR")
    axs[1].set_xlabel("k (k-th nearest neighbour)")
    axs[1].set_ylabel("ANNI(k)")
    axs[1].set_title("Multi-scale Clark-Evans ANNI profile")
    axs[1].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    return fig


def plot_zone_composition(comp: pd.DataFrame, zone_order: list[str] | None = None):
    """Stacked bar of cell-type composition per tumour-stroma zone."""
    pivot = comp.pivot(index="Zone", columns="Cell type", values="Fraction").fillna(0)
    if zone_order:
        pivot = pivot.reindex([z for z in zone_order if z in pivot.index])
    fig, ax = plt.subplots(figsize=(9, 4.5))
    pivot.plot(kind="bar", stacked=True, ax=ax, colormap="tab10", width=0.7)
    ax.set_xlabel("Zone")
    ax.set_ylabel("Cell-type fraction")
    ax.set_title("Cell-type composition by zone")
    ax.legend(fontsize=7, bbox_to_anchor=(1.01, 1), loc="upper left")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=30, ha="right")
    fig.tight_layout()
    return fig


def plot_interface_de(de_df: pd.DataFrame):
    """Horizontal bar of interface-vs-core DE log2FC for top genes."""
    if de_df.empty:
        return None
    fig, ax = plt.subplots(figsize=(8, 4.5))
    cols = ["#d62728" if (s and fc > 0)
            else "#1f77b4" if (s and fc < 0)
            else "#bdbdbd"
            for s, fc in zip(de_df["Significant"], de_df["log2FC"])]
    ax.barh(de_df["Gene"], de_df["log2FC"], color=cols, edgecolor="k",
            linewidth=0.4)
    ax.axvline(0, color="k", lw=0.8)
    ax.set_xlabel("log2 FC (interface / core)")
    ax.set_title("Differential expression: interface vs core")
    fig.tight_layout()
    return fig


# ──────────────────────────────────────────────────────────────────────────────
# Section 7 extras
# ──────────────────────────────────────────────────────────────────────────────
def plot_niche_adjacency(adj_df: pd.DataFrame, names: dict):
    """Niche-niche Delaunay adjacency heatmap."""
    fig, ax = plt.subplots(figsize=(0.8 * len(adj_df) + 2,
                                    0.8 * len(adj_df) + 1.5))
    rename = {i: names.get(i, str(i)) for i in adj_df.index}
    df = adj_df.rename(index=rename, columns=rename)
    sns.heatmap(df, ax=ax, cmap="Blues", annot=True, fmt="d",
                cbar_kws={"label": "shared Delaunay edges"})
    ax.set_title("Niche-niche spatial adjacency")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha="right")
    return fig


# ──────────────────────────────────────────────────────────────────────────────
# Section 8 extras
# ──────────────────────────────────────────────────────────────────────────────
def plot_delaunay_angles_polar(theta: np.ndarray, n_bins: int = 36):
    """Polar histogram of Delaunay edge angles."""
    fig, ax = plt.subplots(subplot_kw={"projection": "polar"}, figsize=(6, 5))
    ax.hist(theta, bins=n_bins, color="C0")
    ax.set_title("Delaunay edge angles", pad=15)
    return fig


def plot_minkowski_sweep(sweep: dict, x_label: str = "threshold"):
    """V0/V1/χ as a function of threshold or label-id."""
    fig, axs = plt.subplots(1, 3, figsize=(13, 4))
    x = sweep.get("thresholds", sweep.get("label_ids"))
    axs[0].plot(x, sweep["V0"], "C0")
    axs[0].set_title(r"$V_0$ — area")
    axs[0].set_xlabel(x_label)
    axs[1].plot(x, sweep["V1"], "C1")
    axs[1].set_title(r"$V_1$ — perimeter")
    axs[1].set_xlabel(x_label)
    axs[2].plot(x, sweep["chi"], "C2")
    axs[2].axhline(0, color="k", linestyle="--", alpha=0.4)
    axs[2].set_title(r"$\chi$ — Euler")
    axs[2].set_xlabel(x_label)
    fig.tight_layout()
    return fig


def plot_granulometry(gran: dict):
    """Erosion-radius sweep of V0/V1/χ."""
    fig, axs = plt.subplots(1, 3, figsize=(13, 4))
    r = gran["radii"]
    axs[0].plot(r, gran["V0"], "C0")
    axs[0].set_title("Area vs scale")
    axs[0].set_xlabel("erosion radius (px)")
    axs[1].plot(r, gran["V1"], "C1")
    axs[1].set_title("Perimeter vs scale")
    axs[1].set_xlabel("erosion radius (px)")
    axs[2].plot(r, gran["chi"], "C2")
    axs[2].axhline(0, color="k", linestyle="--", alpha=0.4)
    axs[2].set_title(r"$\chi$ vs scale")
    axs[2].set_xlabel("erosion radius (px)")
    fig.tight_layout()
    return fig


def plot_morph_spatial(coords: np.ndarray, vals: np.ndarray,
                       feat_name: str, mi: float, p: float):
    """Spatial scatter coloured by a morphology feature + violin per cell type."""
    valid = ~np.isnan(vals)
    fig, axs = plt.subplots(1, 2, figsize=(13, 5.5))
    sc = axs[0].scatter(coords[valid, 0], coords[valid, 1],
                        c=vals[valid], cmap="plasma", s=3, alpha=0.8,
                        vmin=np.nanpercentile(vals, 2),
                        vmax=np.nanpercentile(vals, 98))
    plt.colorbar(sc, ax=axs[0], label=feat_name)
    axs[0].set_aspect("equal")
    axs[0].set_title(f"Spatial map: {feat_name}\n"
                     f"Moran's I = {mi:.3f}, p = {p:.3g}")
    axs[1].hist(vals[valid], bins=50, color="steelblue", edgecolor="k")
    axs[1].set_xlabel(feat_name)
    axs[1].set_title(f"{feat_name} distribution")
    fig.tight_layout()
    return fig


def plot_dominant_quadrat_map(grid_labels: np.ndarray, type_names: list[str],
                              xs: np.ndarray, ys: np.ndarray,
                              quadrat_size: float, contagion: float):
    """Quadrat map coloured by dominant cell type."""
    cmap = plt.get_cmap("tab10", len(type_names))
    rgba = np.ones((*grid_labels.shape, 4))
    for yi in range(grid_labels.shape[0]):
        for xi in range(grid_labels.shape[1]):
            ti = grid_labels[yi, xi]
            rgba[yi, xi] = cmap(ti) if ti >= 0 else (0.92, 0.92, 0.92, 0.4)
    extent = [xs[0], xs[-1] + quadrat_size, ys[0], ys[-1] + quadrat_size]
    fig, ax = plt.subplots(figsize=(8, 7))
    ax.imshow(rgba, origin="lower", extent=extent, aspect="equal",
              interpolation="nearest")
    handles = [Patch(color=cmap(i), label=t) for i, t in enumerate(type_names)]
    ax.legend(handles=handles, fontsize=7, loc="upper right", markerscale=2)
    ax.set_title(f"Dominant cell type per {quadrat_size:.0f} µm quadrat\n"
                 f"Contagion = {contagion:.3f}")
    ax.set_xlabel("x (µm)")
    ax.set_ylabel("y (µm)")
    return fig


def plot_patch_size_box(patch_df: pd.DataFrame):
    """Box plot of patch sizes per cell type (log-scale)."""
    if patch_df.empty:
        return None
    fig, ax = plt.subplots(figsize=(max(6, 0.9 * patch_df["Cell type"].nunique() + 2), 4.5))
    order = (patch_df.groupby("Cell type")["Patch size (quadrats)"]
             .median().sort_values(ascending=False).index.tolist())
    sns.boxplot(data=patch_df, x="Cell type", y="Patch size (quadrats)",
                order=order, ax=ax, fliersize=2)
    ax.set_yscale("log")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=30, ha="right")
    ax.set_title("Patch size distribution per cell type")
    fig.tight_layout()
    return fig


# ──────────────────────────────────────────────────────────────────────────────
# Section 9 extras
# ──────────────────────────────────────────────────────────────────────────────
def plot_partial_corr_network(pcn: dict, cell_types: list[str]):
    """Heatmap of SES + spring-layout network of significant edges."""
    import networkx as nx
    from matplotlib.lines import Line2D

    fig, axs = plt.subplots(1, 2, figsize=(16, 7))
    A_df = pcn["A_df"]
    labels = A_df.index.tolist()
    sns.heatmap(A_df, ax=axs[0], cmap="RdBu_r", center=0, annot=True,
                fmt=".2f", cbar_kws={"label": "SES (partial corr)"},
                annot_kws={"size": 8},
                xticklabels=labels, yticklabels=labels)
    # seaborn sets tick labels internally; force rotation after draw
    fig.canvas.draw()
    axs[0].set_xticklabels(axs[0].get_xticklabels(),
                           rotation=45, ha="right", fontsize=8)
    axs[0].set_yticklabels(axs[0].get_yticklabels(),
                           rotation=0, fontsize=8)
    axs[0].set_title("Partial-correlation association network")

    G = pcn["G"]
    # Use kamada_kawai for connected subgraph (better spacing), then place
    # isolated nodes manually in a ring around the periphery.
    connected = [n for n in G.nodes() if G.degree(n) > 0]
    isolated  = [n for n in G.nodes() if G.degree(n) == 0]
    sub = G.subgraph(connected)
    if len(connected) > 1:
        # weight=None: use unit distances (topology only) so Dijkstra doesn't
        # fail on negative SES edge weights stored in the 'weight' attribute.
        pos_conn = nx.kamada_kawai_layout(sub, weight=None, scale=0.6)
    elif len(connected) == 1:
        pos_conn = {connected[0]: np.array([0.0, 0.0])}
    else:
        pos_conn = {}
    # Place isolated nodes evenly on a circle of radius 0.9
    n_iso = len(isolated)
    pos_iso = {}
    for k_i, node in enumerate(isolated):
        angle = 2 * np.pi * k_i / max(n_iso, 1)
        pos_iso[node] = np.array([0.9 * np.cos(angle), 0.9 * np.sin(angle)])
    pos = {**pos_conn, **pos_iso}

    edge_colors = ["#1f77b4" if d["sign"] == "positive" else "#d62728"
                   for _, _, d in G.edges(data=True)]
    edge_widths = [abs(d["weight"]) * 2 for _, _, d in G.edges(data=True)]
    nx.draw_networkx_nodes(G, pos, ax=axs[1], node_size=1200,
                           node_color="#ECE9E2", edgecolors="k")
    # Draw labels with a white bbox so they remain readable even when nodes
    # are close together.
    nx.draw_networkx_labels(G, pos, ax=axs[1], font_size=8,
                            bbox=dict(boxstyle="round,pad=0.25",
                                      fc="white", ec="none", alpha=0.85))
    nx.draw_networkx_edges(G, pos, ax=axs[1], edge_color=edge_colors,
                           width=edge_widths, arrows=False)
    axs[1].set_title("Association network — blue=attraction, red=repulsion")
    axs[1].axis("off")
    # Add padding so node labels at the boundary aren't clipped
    axs[1].set_xlim(-1.1, 1.1)
    axs[1].set_ylim(-1.1, 1.1)
    axs[1].legend(handles=[
        Line2D([0], [0], color="#1f77b4", lw=2, label="Attraction"),
        Line2D([0], [0], color="#d62728", lw=2, label="Repulsion"),
    ], loc="upper left", fontsize=8)
    fig.tight_layout()
    # Extra bottom padding for rotated x-axis labels on the heatmap
    fig.subplots_adjust(bottom=0.18)
    return fig


def plot_isa_pearson_forbes(isa_df: pd.DataFrame, cell_types: list[str],
                            var_ratio: float):
    """Side-by-side Pearson r and Forbes ISA heatmaps."""
    fig, axs = plt.subplots(1, 2, figsize=(14, 6))
    n = len(cell_types)
    for ax, metric, title, cmap, center in [
        (axs[0], "Pearson_r", "Pearson r (abundance ISA)", "RdBu_r", 0),
        (axs[1], "Forbes", "Forbes coefficient (incidence ISA)", "YlOrRd", None),
    ]:
        M = np.full((n, n), np.nan)
        for _, row in isa_df.iterrows():
            i = cell_types.index(row["type_A"])
            j = cell_types.index(row["type_B"])
            M[i, j] = row[metric]
            M[j, i] = row[metric]
        kw = {"center": center} if center is not None else {}
        sns.heatmap(M, xticklabels=cell_types, yticklabels=cell_types,
                    cmap=cmap, annot=True, fmt=".2f", ax=ax,
                    mask=np.isnan(M), **kw)
        ax.set_title(title)
    fig.suptitle(f"Spatially implicit ISA  |  Variance ratio = {var_ratio:.2f}",
                 y=1.01)
    fig.tight_layout()
    return fig


def plot_community_variogram(cv_dict: dict, cell_types: list[str]):
    """Within-type variogram + between-type at one lag bin."""
    lags = cv_dict["lag_mids"]
    fig, axs = plt.subplots(1, 2, figsize=(14, 5))
    for i, ct in enumerate(cell_types):
        axs[0].plot(lags, cv_dict["cov_within"][:, i], "o-", label=ct, lw=1.2)
    axs[0].set_xlabel("Lag (µm)")
    axs[0].set_ylabel("Mean squared difference / 2")
    axs[0].set_title("Within-type variogram (CSA)")
    axs[0].legend(fontsize=7, bbox_to_anchor=(1.01, 1), loc="upper left")

    # Pick the first lag bin that has actual pairs (counts > 0) and is not
    # the zero-distance bin; fall back to bin 2 if all are empty.
    counts = cv_dict.get("counts", np.ones(len(lags), dtype=int))
    non_empty = np.where((counts > 0) & (np.arange(len(lags)) > 0))[0]
    rep = int(non_empty[0]) if len(non_empty) > 0 else min(2, len(lags) - 1)
    isa_lag = cv_dict["cov_between"][rep].copy()
    np.fill_diagonal(isa_lag, np.nan)
    sns.heatmap(isa_lag, xticklabels=cell_types, yticklabels=cell_types,
                cmap="RdBu_r", center=0, annot=True, fmt=".1f", ax=axs[1],
                mask=np.isnan(isa_lag))
    axs[1].set_title(f"Between-type covariance at lag ~{lags[rep]:.0f} µm")
    fig.tight_layout()
    return fig


def plot_beta_r(r_mids: np.ndarray, beta: np.ndarray, baseline: float):
    """Spatially explicit β(r) curve with non-spatial Simpson baseline."""
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(r_mids, beta, "o-", color="C0", lw=2, label="β(r) observed")
    ax.axhline(baseline, color="k", linestyle="--",
               label=f"Simpson baseline = {baseline:.3f}")
    ax.fill_between(r_mids, baseline, beta, where=beta > baseline,
                    alpha=0.18, color="C0",
                    label="ISA-driven mixing")
    ax.fill_between(r_mids, baseline, beta, where=beta < baseline,
                    alpha=0.18, color="C3",
                    label="ISA-driven segregation")
    ax.set_xlabel("Distance r (µm)")
    ax.set_ylabel("β(r)")
    ax.set_title("Spatially explicit β(r): ISA-beta diversity link")
    ax.legend(fontsize=8)
    fig.tight_layout()
    return fig


# ──────────────────────────────────────────────────────────────────────────────
# Section 10 extras
# ──────────────────────────────────────────────────────────────────────────────
def plot_wpcf(wpcf_mat: np.ndarray, mark_centres: np.ndarray,
              support: np.ndarray, ta: str, tb: str, gene_name: str,
              mark_mean: float | None = None):
    """wPCF heatmap (mark × radius)."""
    fig, ax = plt.subplots(figsize=(8, 4.5))
    # Use a data-driven symmetric range centred on 1 (CSR baseline) so that
    # strong clustering (wPCF >> 1.5) or inhibition (wPCF << 0.5) is not
    # silently clipped by hardcoded limits.
    finite_vals = wpcf_mat[np.isfinite(wpcf_mat)]
    if len(finite_vals) > 0:
        delta = max(float(np.abs(finite_vals - 1).max()), 0.5)
    else:
        delta = 0.5
    im = ax.imshow(wpcf_mat, aspect="auto", origin="lower", cmap="RdBu_r",
                   vmin=1 - delta, vmax=1 + delta,
                   extent=[support[0], support[-1],
                           mark_centres[0], mark_centres[-1]])
    if mark_mean is not None:
        ax.axhline(mark_mean, color="k", linestyle="--", lw=0.8,
                   label="mean mark")
        ax.legend(fontsize=8)
    plt.colorbar(im, ax=ax, label="wPCF (1 = CSR)")
    ax.set_xlabel("Distance r (µm)")
    ax.set_ylabel(f"{gene_name} expression (mark)")
    ax.set_title(f"Weighted PCF: {ta} → {tb}\nmark = {gene_name}")
    fig.tight_layout()
    return fig


def plot_persistence_diagrams(diagrams: dict, max_distance: float = 200.0):
    """Persistence diagrams (H0 + H1) per cell type, 2 rows × N cols."""
    n = len(diagrams)
    if n == 0:
        return None
    fig, axs = plt.subplots(2, n, figsize=(3.5 * n, 6), squeeze=False)
    colors_dim = ["C0", "C1"]
    dim_labels = ["H0 (components)", "H1 (loops)"]
    for col, (t, dgms) in enumerate(diagrams.items()):
        for dim in range(min(2, len(dgms))):
            ax = axs[dim, col]
            dgm = dgms[dim]
            finite = dgm[~np.isinf(dgm[:, 1])]
            if len(finite) > 0:
                ax.scatter(finite[:, 0], finite[:, 1], s=8, alpha=0.6,
                           c=colors_dim[dim])
            if dim == 0:
                inf_pts = dgm[np.isinf(dgm[:, 1])]
                if len(inf_pts) > 0:
                    ax.scatter(inf_pts[:, 0],
                               [max_distance * 1.05] * len(inf_pts),
                               s=12, marker="^", c="grey", alpha=0.5,
                               label="∞")
            lim = max_distance * 1.1
            ax.plot([0, lim], [0, lim], "k--", lw=0.7)
            ax.set_xlim(0, lim)
            ax.set_ylim(0, lim)
            ax.set_xlabel("Birth (µm)")
            ax.set_ylabel("Death (µm)")
            ax.set_title(f"{t}\n{dim_labels[dim]}", fontsize=8)
            ax.set_aspect("equal")
    fig.suptitle("Persistence Diagrams — Vietoris-Rips", fontsize=10)
    fig.tight_layout()
    return fig
