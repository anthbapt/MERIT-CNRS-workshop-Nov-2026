"""Minkowski functionals on binary masks + granulometry sweep."""
from __future__ import annotations

import numpy as np
from scipy import ndimage as ndi
from skimage import measure

try:
    import porespy as ps

    HAS_PORESPY = True
except ImportError:
    ps = None
    HAS_PORESPY = False


def _require_porespy(func_name: str) -> None:
    if not HAS_PORESPY:
        raise ImportError(
            f"{func_name}() requires the optional 'porespy' package. "
            "Install it with: pip install spatial_features[porespy]"
        )


def minkowski_functionals_2d(binary: np.ndarray,
                             voxel_size: float = 1.0) -> tuple[float, float, int]:
    """2D Minkowski functionals (V0=area, V1=perimeter, V2=Euler chi).

    Requires the optional ``porespy`` dependency
    (``pip install spatial_features[porespy]``).
    """
    _require_porespy("minkowski_functionals_2d")
    binary = np.asarray(binary, dtype=bool)
    if binary.ndim != 2:
        raise ValueError(f"Expected 2D array, got shape {binary.shape}")
    porosity = ps.metrics.porosity(binary.astype(np.uint8))
    area = porosity * binary.size * (voxel_size ** 2)
    perim_vox, _ = ps.tools.jit_marching_squares_perimeter_and_area(
        binary.astype(np.uint8))
    perimeter = perim_vox * voxel_size
    euler = measure.euler_number(binary, connectivity=1)
    return float(area), float(perimeter), int(euler)


def threshold_sweep(field: np.ndarray,
                    n_thresholds: int = 20) -> dict:
    """Minkowski functions across a continuous threshold sweep on `field`."""
    _require_porespy("threshold_sweep")
    ts = np.linspace(field.min() + 0.1, field.max() - 0.1, n_thresholds)
    V0, V1, chi = [], [], []
    for t in ts:
        m = field >= t
        V0.append(int(m.sum()))
        chi.append(int(measure.euler_number(m, connectivity=1)))
        perim_vox, _ = ps.tools.jit_marching_squares_perimeter_and_area(
            m.astype(np.uint8))
        V1.append(perim_vox)
    return {"thresholds": ts, "V0": np.array(V0),
            "V1": np.array(V1), "chi": np.array(chi)}


def label_sweep(label_field: np.ndarray,
                max_steps: int = 500) -> dict:
    """Minkowski functions over a sweep of label-ID inclusion."""
    _require_porespy("label_sweep")
    ids = np.unique(label_field)
    ids = ids[ids > 0].astype(float)
    if len(ids) > max_steps:
        idx = np.linspace(0, len(ids) - 1, max_steps).astype(int)
        ids = ids[idx]
    V0, V1, chi = [], [], []
    for t in ids:
        m = label_field >= t
        V0.append(int(m.sum()))
        chi.append(int(measure.euler_number(m, connectivity=1)))
        perim_vox, _ = ps.tools.jit_marching_squares_perimeter_and_area(
            m.astype(np.uint8))
        V1.append(perim_vox)
    return {"label_ids": ids, "V0": np.array(V0),
            "V1": np.array(V1), "chi": np.array(chi)}


def granulometry(mask: np.ndarray, n_scales: int = 25,
                 voxel_size: float = 1.0) -> dict:
    """Erosion sweep: V0/V1/chi at each radius via the EDT."""
    mask = mask.astype(bool)
    edt = ndi.distance_transform_edt(mask)
    dist = np.linspace(0.0, edt.max(), n_scales)
    V0, V1, chi = [], [], []
    for r in dist:
        eroded = edt >= r
        a, l, e = minkowski_functionals_2d(eroded, voxel_size=voxel_size)
        V0.append(a)
        V1.append(l)
        chi.append(e)
    return {"radii": dist, "V0": np.array(V0),
            "V1": np.array(V1), "chi": np.array(chi)}
