"""FRAGSTATS-style landscape ecology metrics on cell-type quadrats."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.ndimage import label as ndimage_label


def landscape_ecology_metrics(coords: np.ndarray, labels: np.ndarray,
                              roi_poly,
                              quadrat_size: float = 100.0,
                              min_cells_per_quadrat: int = 1) -> dict:
    """Per-type patch metrics + landscape contagion index over a quadrat grid."""
    labels = np.asarray(labels)
    unique_types = list(np.unique(labels))
    n_types = len(unique_types)
    type_to_idx = {t: i for i, t in enumerate(unique_types)}

    bounds = roi_poly.bounds
    xs = np.arange(bounds[0], bounds[2], quadrat_size)
    ys = np.arange(bounds[1], bounds[3], quadrat_size)
    nx, ny = len(xs), len(ys)

    grid_labels = np.full((ny, nx), -1, dtype=int)
    grid_counts = np.zeros((ny, nx, n_types), dtype=int)

    for xi, x0 in enumerate(xs):
        for yi, y0 in enumerate(ys):
            x1, y1 = x0 + quadrat_size, y0 + quadrat_size
            in_q = ((coords[:, 0] >= x0) & (coords[:, 0] < x1)
                    & (coords[:, 1] >= y0) & (coords[:, 1] < y1))
            if in_q.sum() < min_cells_per_quadrat:
                continue
            counts = np.bincount(
                [type_to_idx[l] for l in labels[in_q]],
                minlength=n_types,
            )
            grid_counts[yi, xi] = counts
            grid_labels[yi, xi] = int(np.argmax(counts))

    total_quadrats = int((grid_labels >= 0).sum())
    if total_quadrats == 0:
        raise ValueError(
            f"No non-empty quadrats. Reduce quadrat_size (now {quadrat_size}) "
            f"or min_cells_per_quadrat."
        )

    rows = []
    for ti, t in enumerate(unique_types):
        type_grid = (grid_labels == ti).astype(int)
        labeled, n_patches = ndimage_label(type_grid)
        if n_patches == 0:
            rows.append({
                "Cell type": t, "Patch richness": 0,
                "Largest patch index": 0.0,
                "Edge density (1/um)": 0.0,
                "Mean patch size (quadrats)": 0.0,
                "n_quadrats": 0,
            })
            continue
        patch_sizes = np.bincount(labeled.ravel())[1:]
        lpi = float(patch_sizes.max()) / total_quadrats

        edge_count = 0
        for yi in range(ny):
            for xi in range(nx):
                if type_grid[yi, xi] == 0:
                    continue
                for dyi, dxi in [(0, 1), (1, 0)]:
                    nyi, nxi = yi + dyi, xi + dxi
                    if 0 <= nyi < ny and 0 <= nxi < nx:
                        if type_grid[nyi, nxi] == 0 and grid_labels[nyi, nxi] >= 0:
                            edge_count += 1
        area_um2 = total_quadrats * quadrat_size ** 2
        ed = (edge_count * quadrat_size) / area_um2

        rows.append({
            "Cell type": t,
            "Patch richness": int(n_patches),
            "Largest patch index": round(lpi, 4),
            "Edge density (1/um)": round(ed, 8),
            "Mean patch size (quadrats)": round(float(patch_sizes.mean()), 2),
            "n_quadrats": int(type_grid.sum()),
        })

    metrics_df = pd.DataFrame(rows).set_index("Cell type")

    adj_counts = np.zeros((n_types, n_types), dtype=float)
    for yi in range(ny):
        for xi in range(nx):
            ti_v = grid_labels[yi, xi]
            if ti_v < 0:
                continue
            for dyi, dxi in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
                nyi, nxi = yi + dyi, xi + dxi
                if 0 <= nyi < ny and 0 <= nxi < nx:
                    tj_v = grid_labels[nyi, nxi]
                    if tj_v >= 0:
                        adj_counts[ti_v, tj_v] += 1

    total_adj = adj_counts.sum()
    if total_adj > 0 and n_types > 1:
        P = adj_counts / total_adj
        with np.errstate(divide="ignore", invalid="ignore"):
            log_P = np.where(P > 0, np.log(P), 0.0)
        contagion = 1.0 + (P * log_P).sum() / (2.0 * np.log(n_types))
        contagion = float(np.clip(contagion, 0.0, 1.0))
    else:
        contagion = float("nan")

    return {
        "metrics_df": metrics_df,
        "contagion": contagion,
        "grid_labels": grid_labels,
        "grid_type_names": unique_types,
        "xs": xs, "ys": ys,
    }


def patch_size_distribution(grid_labels: np.ndarray,
                            grid_type_names: list[str],
                            quadrat_size: float) -> pd.DataFrame:
    """Per-cell-type patch size table (in quadrat counts and µm²)."""
    rows = []
    for ti, t in enumerate(grid_type_names):
        tg = (grid_labels == ti).astype(int)
        labeled, n_patches = ndimage_label(tg)
        if n_patches == 0:
            continue
        sizes = np.bincount(labeled.ravel())[1:]
        for s in sizes:
            rows.append({"Cell type": t,
                         "Patch size (quadrats)": int(s),
                         "Patch size (um2)": int(s) * quadrat_size ** 2})
    return pd.DataFrame(rows)
