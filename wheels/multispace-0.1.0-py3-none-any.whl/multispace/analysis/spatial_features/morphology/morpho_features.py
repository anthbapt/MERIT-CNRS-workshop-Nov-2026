"""Per-cell morphology features and Moran's I on those features."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

from .. import config


def extract_morphology_features(shapes_gdf, id_col: str | None = None) -> pd.DataFrame:
    """Extract area, perimeter, circularity, elongation, orientation per polygon."""
    rows = []
    for geom in shapes_gdf.geometry:
        if geom is None or geom.is_empty:
            rows.append({"area": np.nan, "perimeter": np.nan,
                         "circularity": np.nan, "elongation": np.nan,
                         "orientation": np.nan})
            continue
        area = geom.area
        perimeter = geom.length
        circ = (4 * np.pi * area / perimeter ** 2) if perimeter > 0 else np.nan
        try:
            mrr = geom.minimum_rotated_rectangle
            coords_mrr = np.array(mrr.exterior.coords)[:-1]
            sides = [np.linalg.norm(coords_mrr[i] - coords_mrr[(i + 1) % 4])
                     for i in range(4)]
            sides.sort()
            minor, major = sides[0], sides[-1]
            elong = major / minor if minor > 0 else np.nan
            edge_vecs = [coords_mrr[(i + 1) % 4] - coords_mrr[i] for i in range(4)]
            edge_lens = [np.linalg.norm(v) for v in edge_vecs]
            long_edge = edge_vecs[int(np.argmax(edge_lens))]
            orient = np.degrees(np.arctan2(long_edge[1], long_edge[0])) % 180
        except Exception:
            elong, orient = np.nan, np.nan
        rows.append({"area": area, "perimeter": perimeter,
                     "circularity": circ, "elongation": elong,
                     "orientation": orient})
    df = pd.DataFrame(rows)
    df.index = (shapes_gdf[id_col].astype(str).values if id_col and id_col in shapes_gdf.columns
                else shapes_gdf.index.astype(str))
    return df


def morans_I_vector(values: np.ndarray, coords: np.ndarray,
                    k_neighbours: int = 8, n_perms: int = 199,
                    seed: int = config.RANDOM_SEED) -> tuple[float, float, float]:
    """Moran's I for a continuous variable with KNN spatial weights."""
    values = np.asarray(values, float)
    valid = ~np.isnan(values)
    if valid.sum() < 10:
        return float("nan"), float("nan"), float("nan")
    v = values[valid]
    c = coords[valid]
    n = len(v)

    tree = cKDTree(c)
    _, nbrs = tree.query(c, k=min(k_neighbours + 1, n))
    nbrs = nbrs[:, 1:]
    w = 1.0 / k_neighbours
    z_v = (v - v.mean()) / (v.std() + 1e-12)

    Wz = np.array([w * z_v[nb].sum() for nb in nbrs])
    I_obs = float(np.dot(z_v, Wz) / n)

    rng = np.random.default_rng(seed)
    I_perm = np.zeros(n_perms)
    for p in range(n_perms):
        z_shuf = rng.permutation(z_v)
        Wz_s = np.array([w * z_shuf[nb].sum() for nb in nbrs])
        I_perm[p] = np.dot(z_shuf, Wz_s) / n
    p_perm = float((np.sum(np.abs(I_perm) >= np.abs(I_obs)) + 1) / (n_perms + 1))

    E_I = -1.0 / (n - 1)
    W = n * k_neighbours * w
    W2 = n * k_neighbours * w ** 2
    Var_I = (n * ((n ** 2 - 3 * n + 3) * W2 - n * W2 + 3 * W ** 2) /
             ((n - 1) * (n - 2) * (n - 3) * W ** 2) -
             E_I ** 2)
    z_score = float((I_obs - E_I) / np.sqrt(max(Var_I, 1e-12)))
    return I_obs, z_score, p_perm


def morans_per_morph_feature(morph_df: pd.DataFrame, coords: np.ndarray,
                             features: list[str] | None = None,
                             k: int = 8, n_perms: int = 199) -> pd.DataFrame:
    """Run Moran's I on each morphology feature column."""
    if features is None:
        features = ["area", "circularity", "elongation", "orientation"]
    rows = []
    for feat in features:
        if feat not in morph_df.columns:
            continue
        I, z, p = morans_I_vector(morph_df[feat].values, coords,
                                  k_neighbours=k, n_perms=n_perms)
        rows.append({
            "Feature": feat,
            "Moran's I": round(I, 4) if not np.isnan(I) else np.nan,
            "z-score": round(z, 3) if not np.isnan(z) else np.nan,
            "p-value": round(p, 4) if not np.isnan(p) else np.nan,
            "Significant": (p < 0.05) if not np.isnan(p) else False,
        })
    return pd.DataFrame(rows).set_index("Feature")
