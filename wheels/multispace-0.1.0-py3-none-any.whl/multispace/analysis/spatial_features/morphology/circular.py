"""Circular statistics on Delaunay edge orientations."""
from __future__ import annotations

import numpy as np
from astropy.stats import circmean, rayleightest, vtest
from scipy.spatial import Delaunay


def delaunay_edge_orientations(coords: np.ndarray) -> np.ndarray:
    """Return the angle (radians) of each unique Delaunay edge."""
    tri = Delaunay(coords)
    edges = set()
    for s in tri.simplices:
        for i in range(3):
            a, b = sorted([s[i], s[(i + 1) % 3]])
            edges.add((a, b))
    edges = np.array(list(edges))
    vec = coords[edges[:, 1]] - coords[edges[:, 0]]
    return np.arctan2(vec[:, 1], vec[:, 0])


def circular_summary(theta: np.ndarray) -> dict:
    """Axial circular mean, Rayleigh test, V-test against horizontal."""
    return {
        "n_edges": int(len(theta)),
        "axial_mean": float(circmean(theta * 2) / 2),
        "rayleigh_p": float(rayleightest(theta * 2)),
        "v_test_p_horiz": float(vtest(theta * 2, mu=0)),
    }


def delaunay_orientation_analysis(coords: np.ndarray) -> dict:
    """Convenience wrapper: edges + summary."""
    theta = delaunay_edge_orientations(coords)
    out = circular_summary(theta)
    out["theta"] = theta
    return out
