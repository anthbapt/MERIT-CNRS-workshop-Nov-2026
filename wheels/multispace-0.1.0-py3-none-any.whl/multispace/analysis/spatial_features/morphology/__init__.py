"""Morphological analysis: circular stats, Minkowski, granulometry, landscape ecology."""
