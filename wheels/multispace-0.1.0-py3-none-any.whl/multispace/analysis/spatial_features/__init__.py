"""spatial_features — port of the MB-GU-1017 SpatialData analysis pipeline.

Public API
----------
All public functions from every submodule are importable directly from
``spatial_features``.  Backward-compatible aliases are provided for every
function that was renamed during the refactor so that code written against
the notebook's inline definitions continues to work without modification.

Backward-compat aliases
~~~~~~~~~~~~~~~~~~~~~~~
Notebook name                  →  Package name
-------------------------------   --------------------------------
svg_moran_vectorised           →  autocorr.svg._vectorised_svg_moran
bivariate_spatial_morans_I     →  autocorr.svg._bivariate_spatial_morans_i
schmid_pairwise_mixing         →  interactions.mixing.schmid_pairwise
clark_evans                    →  interactions.mixing.clark_evans_index
csr_envelope                   →  pointpat.inhomogeneous.csr_envelope  (returns 7-tuple)
_get_pair_by_auc               →  muspan.tcm.get_pair_by_auc
_shrink_partial_corr           →  ecology.shrink_partial_corr
cross_K_corrected              →  pointpat.cross.cross_K_corrected
cross_K                        →  pointpat.cross.cross_K
cooccur                        →  interactions.neighborhood.cooccur
points_of_type factory         →  pointpat.ripley.make_points_of_type
"""
from __future__ import annotations

# ── Submodule re-exports (keep submodule access working) ─────────────────────
from . import (
    autocorr,
    clustering,
    config,
    ecology,
    interactions,
    io,
    morphology,
    muspan,
    plotting,
    pointpat,
    weights,
)

# ── Core I/O and context ─────────────────────────────────────────────────────
from .io import (
    AnalysisContext,
    build_context,
    load_spatialdata,
    prepare_adata_for_metrics,
)
from .weights import (
    WeightsBundle,
    build_all as build_weights,
    load_disparity_graph,
)

# ── Autocorrelation ──────────────────────────────────────────────────────────
from .autocorr.global_ import (
    select_focal_gene,
    spatial_lag,
    global_moran,
    global_geary,
    global_getis_ord,
)
from .autocorr.local import (
    local_moran,
    local_getis_ord,
    local_geary,
    all_local_statistics,
)
from .autocorr.svg import (
    _vectorised_svg_moran,
    compute_spatially_variable_genes,
    top_svgs,
    _bivariate_spatial_morans_i,
    bivariate_moran_pairs,
)
from .autocorr.per_celltype import compute_morans_i, morans_to_features
from .autocorr.robust import bootstrap_morans_i_ci

# ── Point-pattern statistics ─────────────────────────────────────────────────
from .pointpat.ripley import (
    ripley_g,
    ripley_f,
    ripley_j,
    ripley_k,
    ripley_l,
    make_points_of_type,
)
from .pointpat.inhomogeneous import (
    Kinhom,
    Khom,
    pcf_inhom,
    per_celltype_kinhom,
    per_celltype_pcf_inhom,
    csr_envelopes,
    csr_envelope,          # backward-compat: returns 7-tuple
    pcf_from_L_derivative,
    per_type_dominant_scale,
)
from .pointpat.cross import (
    cross_g,
    cross_j,
    cross_k,
    cross_k_isotropic,
    cross_K_corrected,     # notebook alias for cross_k_isotropic
    cross_K,               # notebook alias (uncorrected, takes area arg)
    cross_K_summary,
    all_pairs_cross_k_isotropic,
    estimate_intensity,
    inhomogeneous_cross_k,
    inhomogeneous_cross_pcf,
    all_pairs_inhomogeneous_cross,
)
from .pointpat.higher_order import (
    pcf,
    cross_pcf,
    oring,
    mark_correlation,
    empty_space_hazard,
)
from .pointpat.csr import (
    hopkins_skellam,
    quadrat_statistic,
    quadrat_counts,
    csr_random_pattern,
)
from .pointpat.directional import directional_pcf, anisotropy_index
from .pointpat.centrography import (
    compute_centrography,
    convex_hull_vertices,
    convex_hull_centroid,
    alpha_shape,
    minimum_bounding_rectangle,
    minimum_bounding_circle,
    minimum_rotated_rectangle,
    displacement_to_hull_centroid,
    asymmetry_metrics,
)
from .pointpat.strauss import fit_strauss_per_celltype

# ── Interactions ─────────────────────────────────────────────────────────────
from .interactions.mixing import (
    schmid_pairwise,
    clark_evans_index,
    clark_evans_per_celltype,
    spiat_mixing_score,
)
from .interactions.neighborhood import (
    compute_nhood_enrichment,
    composition_vectors,
    select_k_by_information_criteria,
    cluster_cellular_neighborhoods,
    cooccurrence_zscore,
    cooccur,               # notebook Cell 204 API
)
from .interactions.diversity import (
    compute_intracore_cv,
    compute_local_entropy,
)
from .interactions.funspace import (
    functional_spatial_entropy,
    funspace_inflection_scale,
    spatial_simpsons_diversity,
    multiscale_clark_evans,
    multiscale_clark_evans_per_type,
)
from .interactions.icf import compute_icf
from .interactions.boundary import (
    assign_zones,
    zone_composition,
    interface_vs_core_de,
)
from .interactions.distance import (
    find_largest_dbscan_cluster,
    signed_distances_to_polygon,
    shell_composition,
    rhohat,
    rhohat_per_celltype,
)
from .interactions.silhouette import spatial_silhouette
from .interactions.centrality import (
    compute_centrality,
    compute_network_measures,
)

# ── Ecology ──────────────────────────────────────────────────────────────────
from .ecology import (
    build_hex_community_matrix,
    shrink_partial_corr,
    partial_correlation_network,
    isa_metrics,
    community_variogram,
    beta_r,
)

# ── MuSpAn ───────────────────────────────────────────────────────────────────
from .muspan.tcm import (
    topographical_correlation_map,
    get_pair_by_auc,
)
from .muspan.wpcf import weighted_pcf
from .muspan.apt import adjacency_permutation_test
from .muspan.qcm import quadrat_correlation_matrix
from .muspan.morisita import morisita_horn_index
from .muspan.persistence import (
    vietoris_rips,
    vectorise_persistence,
    persistence_per_celltype,
)
from .muspan.wasserstein import (
    sliced_wasserstein_distance,
    pairwise_swd,
    average_nearest_neighbour_index,
    anni_per_celltype,
)

# ── Morphology ───────────────────────────────────────────────────────────────
from .morphology.minkowski import (
    minkowski_functionals_2d,
    threshold_sweep,
    label_sweep,
    granulometry,
)
from .morphology.circular import (
    delaunay_edge_orientations,
    circular_summary,
    delaunay_orientation_analysis,
)
from .morphology.landscape import (
    landscape_ecology_metrics,
    patch_size_distribution,
)
from .morphology.morpho_features import (
    extract_morphology_features,
    morans_I_vector,
    morans_per_morph_feature,
)

# ── Clustering ───────────────────────────────────────────────────────────────
from .clustering import (
    potts_icm,
    run_potts_pipeline,
    compute_neighbourhood_composition,
    select_n_niches,
    fit_niches,
    niche_adjacency,
)

# ── Plotting ─────────────────────────────────────────────────────────────────
from .plotting import (
    save_fig,
    plot_label_map,
    plot_voronoi,
    plot_morans_per_celltype,
    plot_svg_volcano,
    plot_envelope,
    plot_cross_k_auc_heatmap,
    plot_strauss_gamma,
    plot_nhood_zscore,
    plot_funspace_curve,
    plot_zone_map,
    plot_niche_silhouette,
    plot_niche_map,
    plot_orientation_rose,
    plot_ses_heatmap,
    plot_anni_bar,
    plot_swd_heatmap,
    plot_morisita_heatmap,
    plot_tcm,
    plot_focal_gene_distribution,
    plot_moran_scatter,
    plot_lisa_map,
    plot_top_svg_maps,
    plot_bivariate_moran_heatmap,
    plot_per_type_ripley,
    plot_rstar_heatmap,
    plot_dL_dr_panels,
    plot_per_type_kinhom,
    plot_per_type_pcf_inhom,
    plot_csr_envelope_K,
    plot_astropy_modes,
    plot_kde_ricker,
    plot_directional_pcf,
    plot_cross_k_isotropic_heatmap,
    plot_inhomogeneous_compare,
    plot_pcf_envelope,
    plot_oring,
    plot_mark_correlation,
    plot_empty_space_hazard,
    plot_cooccurrence_zscore,
    plot_schmid_pairwise,
    plot_spiat_mixing,
    plot_distance_shells,
    plot_rhohat,
    plot_icf_significance,
    plot_simpsons_anni,
    plot_zone_composition,
    plot_interface_de,
    plot_niche_adjacency,
    plot_delaunay_angles_polar,
    plot_minkowski_sweep,
    plot_granulometry,
    plot_morph_spatial,
    plot_dominant_quadrat_map,
    plot_patch_size_box,
    plot_partial_corr_network,
    plot_isa_pearson_forbes,
    plot_community_variogram,
    plot_beta_r,
    plot_wpcf,
    plot_persistence_diagrams,
)

# ── Backward-compatible aliases (notebook → package name mapping) ─────────────
# These allow code written against the notebook's inline function names to
# import directly from spatial_features without modification.

# autocorr/svg.py
svg_moran_vectorised       = _vectorised_svg_moran
bivariate_spatial_morans_I = _bivariate_spatial_morans_i

# interactions/mixing.py
schmid_pairwise_mixing = schmid_pairwise
clark_evans            = clark_evans_index

# ecology.py
_shrink_partial_corr = shrink_partial_corr

# muspan/tcm.py
_get_pair_by_auc = get_pair_by_auc

# pointpat/ripley.py — factory for closure-style points_of_type(t)
# Usage: points_of_type = make_points_of_type(coords, labels_arr, unique_labels)

__all__ = [
    # submodules
    "autocorr", "clustering", "config", "ecology", "interactions",
    "io", "morphology", "muspan", "plotting", "pointpat", "weights",
    # I/O
    "AnalysisContext", "WeightsBundle", "build_context", "build_weights",
    "load_spatialdata", "load_disparity_graph", "prepare_adata_for_metrics",
    # autocorr
    "select_focal_gene", "spatial_lag", "global_moran", "global_geary",
    "global_getis_ord", "local_moran", "local_getis_ord", "local_geary",
    "all_local_statistics", "_vectorised_svg_moran",
    "compute_spatially_variable_genes", "top_svgs",
    "_bivariate_spatial_morans_i", "bivariate_moran_pairs",
    "compute_morans_i", "morans_to_features", "bootstrap_morans_i_ci",
    # pointpat
    "ripley_g", "ripley_f", "ripley_j", "ripley_k", "ripley_l",
    "make_points_of_type",
    "Kinhom", "Khom", "pcf_inhom", "per_celltype_kinhom",
    "per_celltype_pcf_inhom", "csr_envelopes", "csr_envelope",
    "pcf_from_L_derivative", "per_type_dominant_scale",
    "cross_g", "cross_j", "cross_k", "cross_k_isotropic",
    "cross_K_corrected", "cross_K", "cross_K_summary",
    "all_pairs_cross_k_isotropic", "estimate_intensity",
    "inhomogeneous_cross_k", "inhomogeneous_cross_pcf",
    "all_pairs_inhomogeneous_cross",
    "pcf", "cross_pcf", "oring", "mark_correlation", "empty_space_hazard",
    "directional_pcf",
    # interactions
    "schmid_pairwise", "clark_evans_index", "clark_evans_per_celltype",
    "spiat_mixing_score", "compute_nhood_enrichment", "cooccur",
    "compute_local_entropy", "multiscale_clark_evans",
    "multiscale_clark_evans_per_type", "compute_icf",
    "interface_vs_core_de",
    "rhohat", "compute_centrality", "compute_network_measures",
    # ecology
    "build_hex_community_matrix", "shrink_partial_corr",
    "partial_correlation_network", "isa_metrics",
    "community_variogram", "beta_r",
    # muspan
    "topographical_correlation_map", "get_pair_by_auc",
    "weighted_pcf", "quadrat_correlation_matrix", "vectorise_persistence",
    "sliced_wasserstein_distance",
    # morphology
    "granulometry",
    "patch_size_distribution",
    # clustering
    "niche_adjacency",
    # plotting (all plot_* functions)
    "save_fig", "plot_label_map", "plot_voronoi", "plot_morans_per_celltype",
    "plot_svg_volcano", "plot_envelope", "plot_cross_k_auc_heatmap",
    "plot_strauss_gamma", "plot_nhood_zscore", "plot_funspace_curve",
    "plot_zone_map", "plot_niche_silhouette", "plot_niche_map",
    "plot_orientation_rose", "plot_ses_heatmap", "plot_anni_bar",
    "plot_swd_heatmap", "plot_morisita_heatmap", "plot_tcm",
    "plot_focal_gene_distribution", "plot_moran_scatter", "plot_lisa_map",
    "plot_top_svg_maps", "plot_bivariate_moran_heatmap",
    "plot_per_type_ripley", "plot_rstar_heatmap", "plot_dL_dr_panels",
    "plot_per_type_kinhom", "plot_per_type_pcf_inhom", "plot_csr_envelope_K",
    "plot_astropy_modes", "plot_kde_ricker", "plot_directional_pcf",
    "plot_cross_k_isotropic_heatmap", "plot_inhomogeneous_compare",
    "plot_pcf_envelope", "plot_oring", "plot_mark_correlation",
    "plot_empty_space_hazard", "plot_cooccurrence_zscore",
    "plot_schmid_pairwise", "plot_spiat_mixing", "plot_distance_shells",
    "plot_rhohat", "plot_icf_significance", "plot_simpsons_anni",
    "plot_zone_composition", "plot_interface_de", "plot_niche_adjacency",
    "plot_delaunay_angles_polar", "plot_minkowski_sweep", "plot_granulometry",
    "plot_morph_spatial", "plot_dominant_quadrat_map", "plot_patch_size_box",
    "plot_partial_corr_network", "plot_isa_pearson_forbes",
    "plot_community_variogram", "plot_beta_r", "plot_wpcf",
    "plot_persistence_diagrams",
    # backward-compat aliases
    "svg_moran_vectorised", "bivariate_spatial_morans_I",
    "schmid_pairwise_mixing", "clark_evans",
    "_shrink_partial_corr", "_get_pair_by_auc",
]
