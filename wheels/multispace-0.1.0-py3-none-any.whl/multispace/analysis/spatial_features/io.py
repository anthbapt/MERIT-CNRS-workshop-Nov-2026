"""SpatialData I/O, inventory, and picker functions.

Loads a SpatialData zarr, picks the preferred table, extracts 2-D centroid
coordinates, the phenotype column, and the feature matrix (preferring
log-normalised layers over raw counts).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import anndata as ad
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from . import config

try:
    import spatialdata as sd

    HAS_SPATIALDATA = True
except ImportError:
    sd = None
    HAS_SPATIALDATA = False


# ── Loading and inventory ─────────────────────────────────────────────────────
def load_spatialdata(zarr_path: str | None = None):
    """Read a SpatialData zarr from disk.

    Requires the optional ``spatialdata`` dependency
    (``pip install spatial_features[spatialdata]``).
    """
    if not HAS_SPATIALDATA:
        raise ImportError(
            "load_spatialdata() requires the optional 'spatialdata' package. "
            "Install it with: pip install spatial_features[spatialdata]"
        )
    path = zarr_path or config.ZARR_PATH
    print(f"Reading {path}")
    return sd.read_zarr(path)


def inventory(sdata) -> dict[str, list[str]]:
    """Return the list of containers registered in a SpatialData object."""
    inv = {
        "tables": list(sdata.tables.keys()),
        "points": list(sdata.points.keys()),
        "shapes": list(sdata.shapes.keys()),
        "images": list(sdata.images.keys()),
        "labels": list(sdata.labels.keys()),
    }
    for k, v in inv.items():
        print(f"{k.capitalize():7s}: {v}")
    return inv


# ── Picker functions ──────────────────────────────────────────────────────────
def pick_table(sdata, prefer: tuple[str, ...] = config.PREFERRED_TABLES):
    """Prefer richly-annotated tables; fall back to the largest one."""
    if not sdata.tables:
        return None, None
    for name in prefer:
        if name in sdata.tables:
            return name, sdata.tables[name]
    name = max(sdata.tables.keys(), key=lambda k: sdata.tables[k].n_obs)
    return name, sdata.tables[name]


def pick_coords(adata, sdata):
    """Extract 2-D centroid coordinates from an AnnData / SpatialData pair."""
    if "spatial" in adata.obsm:
        return np.asarray(adata.obsm["spatial"])[:, :2]
    for xn, yn in [("centroid_x", "centroid_y"),
                   ("X_centroid", "Y_centroid"),
                   ("x_centroid", "y_centroid"),
                   ("x", "y"), ("X", "Y"),
                   ("center_x", "center_y")]:
        if xn in adata.obs.columns and yn in adata.obs.columns:
            return adata.obs[[xn, yn]].to_numpy(float)
    if sdata.shapes:
        sname = next(iter(sdata.shapes))
        gdf = sdata.shapes[sname]
        c = np.array([(g.centroid.x, g.centroid.y) for g in gdf.geometry])
        if len(c) == adata.n_obs:
            return c
    raise ValueError("Could not extract 2-D centroids from SpatialData.")


def pick_phenotype(adata) -> str | None:
    """Find the most useful categorical column on `adata.obs`."""
    for c in config.PHENOTYPE_CANDIDATES:
        if c in adata.obs.columns:
            return c
    for c in adata.obs.columns:
        s = adata.obs[c]
        if s.dtype.name == "category" and 2 <= len(s.cat.categories) <= 60:
            return c
    return None


def pick_feature_matrix(adata) -> tuple[np.ndarray, str]:
    """Prefer a normalised layer over raw counts. Returns (matrix, source)."""
    for lyr in config.PREFERRED_LAYERS:
        if lyr in adata.layers:
            mat = adata.layers[lyr]
            return (np.asarray(mat.todense() if hasattr(mat, "todense") else mat,
                               float),
                    f"layers[{lyr!r}]")
    mat = adata.X
    return (np.asarray(mat.todense() if hasattr(mat, "todense") else mat, float),
            "X (raw counts — consider log1p first)")


# ── Working context ───────────────────────────────────────────────────────────
@dataclass
class AnalysisContext:
    """Bundle of working variables passed through the pipeline."""
    sdata: Any
    table_name: str
    adata: ad.AnnData
    coords: np.ndarray
    phenotype_col: str
    labels_arr: np.ndarray
    unique_labels: np.ndarray
    Xmat: np.ndarray
    X: np.ndarray
    feature_source: str
    shapes_gdf: Any = None
    label_image: Any = None
    extras: dict[str, Any] = field(default_factory=dict)


def build_context(sdata) -> AnalysisContext:
    """Pick table, coords, phenotype, and feature matrix from a SpatialData."""
    tname, adata = pick_table(sdata)
    print(f"Using table: {tname!r}  ({adata.n_obs} cells x {adata.n_vars} features)")

    coords = pick_coords(adata, sdata)
    print(f"Coords shape: {coords.shape}    "
          f"(X range [{coords[:, 0].min():.1f}, {coords[:, 0].max():.1f}], "
          f"Y range [{coords[:, 1].min():.1f}, {coords[:, 1].max():.1f}])")

    phenotype_col = pick_phenotype(adata)
    print(f"Phenotype column: {phenotype_col!r}")

    if phenotype_col is None:
        print("No categorical column found; running KMeans(8) on expression as fallback.")
        Xfb_mat, _ = pick_feature_matrix(adata)
        Xfb = StandardScaler().fit_transform(np.nan_to_num(Xfb_mat))
        adata.obs["_synth_cluster"] = KMeans(8, random_state=0, n_init=10).fit_predict(Xfb)
        adata.obs["_synth_cluster"] = adata.obs["_synth_cluster"].astype("category")
        phenotype_col = "_synth_cluster"

    labels_arr = np.asarray(adata.obs[phenotype_col].astype("category").cat.codes)
    unique_labels = np.array(adata.obs[phenotype_col].astype("category").cat.categories)
    print(f"# unique labels: {len(unique_labels)}")
    print("Label sizes (top 10): "
          f"{pd.Series(unique_labels[labels_arr]).value_counts().head(10).to_dict()}")

    Xmat, X_source = pick_feature_matrix(adata)
    print(f"Feature source: {X_source}, shape {Xmat.shape}")
    X = StandardScaler().fit_transform(np.nan_to_num(Xmat))

    shapes_gdf = sdata.shapes[next(iter(sdata.shapes))] if sdata.shapes else None
    label_image = next(iter(sdata.labels.values())) if sdata.labels else None

    return AnalysisContext(
        sdata=sdata,
        table_name=tname,
        adata=adata,
        coords=coords,
        phenotype_col=phenotype_col,
        labels_arr=labels_arr,
        unique_labels=unique_labels,
        Xmat=Xmat,
        X=X,
        feature_source=X_source,
        shapes_gdf=shapes_gdf,
        label_image=label_image,
    )


def prepare_adata_for_metrics(sdata, cluster_key: str = config.CLUSTER_KEY,
                              allowed_types=None):
    """Build a minimal AnnData (labels + coordinates) for the section-6 metrics.

    multispace patch: reads the active table (``pick_table``) and the
    ``cluster_key`` column instead of the hard-coded ``table_refined`` /
    ``cell_type``; restricting to a list of cell types is optional
    (pass ``allowed_types=config.ALLOWED_CELL_TYPES`` for the METABRIC set).
    """
    _, src = pick_table(sdata)
    raw = src.obs[cluster_key].astype(str)
    mask = raw.notna().values & (raw != "nan").values
    if allowed_types is not None:
        mask &= raw.isin(allowed_types).values
    labels = raw[mask].astype("category")
    keep_idx = src.obs_names[mask]

    obs = pd.DataFrame({cluster_key: labels.values}, index=keep_idx)
    obs[cluster_key] = obs[cluster_key].astype("category")
    spatial = np.asarray(pick_coords(src, sdata))[mask]
    n = len(obs)

    return ad.AnnData(
        X=csr_matrix((n, 1)),
        obs=obs,
        obsm={"spatial": spatial},
    )
