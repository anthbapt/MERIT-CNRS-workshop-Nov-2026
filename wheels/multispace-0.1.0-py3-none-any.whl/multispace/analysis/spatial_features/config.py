"""Configuration constants and paths for the spatial_features pipeline."""
from __future__ import annotations

import os
from pathlib import Path

# ── Filesystem ────────────────────────────────────────────────────────────────
ZARR_PATH = None  # set by the caller / multispace pipeline (was a hard-coded user path)
GRAPHML_PATH = None  # optional; set by the caller
# Default output folder. Not created at import time (multispace passes an
# explicit results_dir); created lazily by plotting.save_fig when used.
RESULTS_DIR = Path.cwd() / "results"

# ── Table preferences ─────────────────────────────────────────────────────────
# multispace: the active table is always "table" (see multispace.constants)
PREFERRED_TABLES = ("table", "table_refined", "table_original")

PHENOTYPE_CANDIDATES = (
    "cell_type_refined", "cell_type_smoothed", "cell_type_fine",
    "cell_type_coarse", "cell_type", "cell_type_celltypist",
    "cell_type_markers", "biomarker_cell_type",
    "phenotype", "celltype", "cluster", "clusters",
    "leiden", "louvain", "annotation", "category", "subtype",
)

PREFERRED_LAYERS = ("lognorm", "log1p", "normalized", "X_norm")

# ── Cell-type palette ─────────────────────────────────────────────────────────
CELL_TYPE_PALETTE = {
    "Epithelial":        "#636363",
    "CAFs":              "#d8b365",
    "T-cells":           "#5b5bd6",
    "B-cells":           "#984ea3",
    "Myeloid":           "#e6550d",
    "M1 macrophage":     "#d62728",
    "M2 macrophage":     "#ff7f0e",
    "Endothelial":       "#66c2a5",
    "Plasmablasts":      "#ce93d8",
    "Perivascular-like": "#67a9cf",
    "Unassigned":        "#bdbdbd",
}
ALLOWED_CELL_TYPES = set(CELL_TYPE_PALETTE.keys())

# ── Pipeline parameters ───────────────────────────────────────────────────────
CLUSTER_KEY = "cell_type"
RIPLEY_RADII = [25.0, 50.0, 100.0]

# Spatial weights
KNN_K = 8
DISTANCE_BAND_NN_MULTIPLIER = 4.0       # threshold = median NN distance × this
KERNEL_FUNCTION = "gaussian"

# Autocorrelation
N_PERMUTATIONS_MORAN = 999
SVG_TOP_N = 6                            # number of top SVGs to plot
HVG_TOP_N = 30                           # for bivariate Moran on gene pairs

# Point-pattern
RIPLEY_SUPPORT = 40                      # bins for univariate Ripley G/F/J/K/L
EPI_TYPE = "Epithelial"
EPI_TYPE1 = "Epithelial"
ORING_DR = 50                            # ring width in µm for O-ring
MAX_INTERACTION_R = 300.0                # µm – cap for cross-K AUCs
HOPKINS_N_ITER = 80
HOPKINS_M_FRAC = 0.1
QUADRAT_NX = 5
QUADRAT_NY = 5

# Inhomogeneous / envelopes
N_ENVELOPE_SIM = 199

# Strauss / Gibbs
STRAUSS_R = 50.0

# Interactions
N_PERMS_NHOOD = 1000
N_NEIGHBORS_ENTROPY = 15
SIMPSONS_RADIUS = 50.0                   # µm

# MuSpAn methods
TCM_RADIUS = 50.0                        # µm – local counting radius
WPCF_SUB_CAP = 5000                      # cap on B-population for wPCF
APT_N_PERMS = 500
QCM_QUADRAT_SIZE = 150.0                 # µm – matches the notebook
PERSISTENCE_MAX_DIM = 1
SWD_N_PROJECTIONS = 200

# Random seed
RANDOM_SEED = 0
