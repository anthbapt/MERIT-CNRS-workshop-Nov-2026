"""Robust statistics and bootstrap confidence intervals on Moran's I."""
from __future__ import annotations

import esda
import numpy as np
import pandas as pd
from astropy.stats import biweight_location, biweight_scale, mad_std, sigma_clipped_stats

from .. import config


def bootstrap_morans_i_ci(
    y: np.ndarray,
    w,
    n_boot: int = 500,
    seed: int = config.RANDOM_SEED,
) -> dict:
    """Bootstrap a 95% CI for Moran's I and return classical / robust descriptive stats."""
    y = np.asarray(y, dtype=float)
    n = len(y)

    classical_I = esda.moran.Moran(y, w, permutations=0).I

    # Robust descriptive statistics on y
    rob_mean = float(y.mean())
    rob_std = float(y.std())
    rob_median = float(np.median(y))
    rob_mad_std = float(mad_std(y))
    rob_biwt_loc = float(biweight_location(y))
    rob_biwt_scl = float(biweight_scale(y))
    clip_mean, clip_med, clip_std = sigma_clipped_stats(y, sigma=3, maxiters=5)

    # Bootstrap on resampled cells
    rng = np.random.default_rng(seed)
    boot_I = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        idx = rng.integers(0, n, size=n)
        boot_I[b] = esda.moran.Moran(y[idx], w, permutations=0).I

    lo, hi = np.percentile(boot_I, [2.5, 97.5])
    robust_I = float(np.median(boot_I))

    table = pd.DataFrame(
        {
            "stat": [
                "mean", "std",
                "median", "mad_std",
                "biwt_location", "biwt_scale",
                "sigma3_mean", "sigma3_median", "sigma3_std",
                "moran_I_classical", "moran_I_bootstrap_median",
                "moran_I_ci_low", "moran_I_ci_high",
            ],
            "value": [
                rob_mean, rob_std,
                rob_median, rob_mad_std,
                rob_biwt_loc, rob_biwt_scl,
                float(clip_mean), float(clip_med), float(clip_std),
                float(classical_I), robust_I,
                float(lo), float(hi),
            ],
        }
    )

    return {
        "classical_I": float(classical_I),
        "robust_I": robust_I,
        "ci_low": float(lo),
        "ci_high": float(hi),
        "n_boot": int(n_boot),
        "boot_samples": boot_I,
        "table": table,
    }
