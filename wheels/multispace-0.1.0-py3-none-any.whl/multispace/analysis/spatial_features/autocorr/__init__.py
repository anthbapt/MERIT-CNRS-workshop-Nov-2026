"""Spatial autocorrelation metrics: global, local, multivariate, SVG detection."""
from __future__ import annotations

from .global_ import (
    select_focal_gene,
    spatial_lag,
    global_moran,
    global_geary,
    global_getis_ord,
)
from .local import (
    local_moran,
    local_getis_ord,
    local_geary,
    all_local_statistics,
)
from .multivariate import (
    bivariate_moran,
    local_bivariate_moran,
    spatial_pearson,
    local_spatial_pearson,
    losh,
    smaup,
    gamma,
    join_counts,
)
from .per_celltype import (
    compute_morans_i,
    morans_to_features,
)
from .robust import bootstrap_morans_i_ci
from .svg import (
    compute_spatially_variable_genes,
    top_svgs,
    bivariate_moran_pairs,
)

__all__ = [
    "select_focal_gene",
    "spatial_lag",
    "global_moran",
    "global_geary",
    "global_getis_ord",
    "local_moran",
    "local_getis_ord",
    "local_geary",
    "all_local_statistics",
    "bivariate_moran",
    "local_bivariate_moran",
    "spatial_pearson",
    "local_spatial_pearson",
    "losh",
    "smaup",
    "gamma",
    "join_counts",
    "compute_morans_i",
    "morans_to_features",
    "bootstrap_morans_i_ci",
    "compute_spatially_variable_genes",
    "top_svgs",
    "bivariate_moran_pairs",
]
