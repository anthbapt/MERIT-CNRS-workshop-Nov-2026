"""Multivariate / bivariate spatial autocorrelation: Moran_BV, Lee's L, LOSH, Smaup, Gamma, Join Counts."""
from __future__ import annotations

import numpy as np
from esda.moran import Moran_BV, Moran_Local_BV
from esda.lee import Spatial_Pearson, Spatial_Pearson_Local
from esda.losh import LOSH
from esda.smaup import Smaup
from esda.gamma import Gamma
from esda.join_counts import Join_Counts


def bivariate_moran(
    y1: np.ndarray,
    y2: np.ndarray,
    w,
    permutations: int = 999,
) -> Moran_BV:
    """Global bivariate Moran's I_xy on (y1, y2) under weights w."""
    return Moran_BV(y1, y2, w, permutations=permutations)


def local_bivariate_moran(
    y1: np.ndarray,
    y2: np.ndarray,
    w,
    permutations: int = 200,
) -> Moran_Local_BV:
    """Local bivariate Moran's I per observation."""
    return Moran_Local_BV(y1, y2, w, permutations=permutations)


def spatial_pearson(y1: np.ndarray, y2: np.ndarray, w) -> Spatial_Pearson:
    """Lee's L: spatially-smoothed Pearson correlation between y1 and y2."""
    return Spatial_Pearson(connectivity=w.sparse).fit(
        np.asarray(y1).reshape(-1, 1), np.asarray(y2).reshape(-1, 1)
    )


def local_spatial_pearson(y1: np.ndarray, y2: np.ndarray, w) -> Spatial_Pearson_Local:
    """Local Lee's L_i for each observation."""
    return Spatial_Pearson_Local(connectivity=w.sparse).fit(
        np.asarray(y1).reshape(-1, 1), np.asarray(y2).reshape(-1, 1)
    )


def losh(y: np.ndarray, w, inference: str = "chi-square") -> LOSH:
    """Local Spatial Heteroscedasticity (LOSH) statistic."""
    return LOSH(connectivity=w, inference=inference).fit(np.asarray(y, dtype=float))


def smaup(y: np.ndarray, w, rho: float | None = None) -> Smaup:
    """Smaup statistic; if rho not provided, uses Moran's I of (y, w)."""
    import esda
    n = len(y)
    k = int(np.sqrt(n))
    if rho is None:
        rho = esda.moran.Moran(y, w).I
    return Smaup(n=n, k=k, rho=rho)


def gamma(y: np.ndarray, w, operation: str = "c") -> Gamma:
    """Gamma index of spatial autocorrelation (operation: 'c', 'a', 's', 'd')."""
    return Gamma(np.asarray(y, dtype=float), w, operation=operation)


def join_counts(y_binary: np.ndarray, w) -> Join_Counts:
    """Join Counts statistic for a binary categorical variable."""
    return Join_Counts(np.asarray(y_binary).astype(int), w)
