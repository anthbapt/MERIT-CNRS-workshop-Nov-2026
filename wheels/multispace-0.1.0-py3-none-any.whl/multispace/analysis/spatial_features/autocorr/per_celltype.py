"""Per-cell-type Moran's I (binary indicator) using exact randomisation variance."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.sparse import issparse
from scipy.stats import norm as sp_norm

from .. import config


def _morans_i_variance_randomisation(W, x, W_sum, n):
    """Exact variance of Moran's I under randomisation (Cliff & Ord 1981, eq. 1.37)."""
    if n < 4 or W_sum <= 0:
        return 1.0 / max(n - 1, 1)

    W_plus_Wt = W + W.T
    S1 = 0.5 * float(np.sum(W_plus_Wt ** 2))
    S2 = float(np.sum((W.sum(axis=1) + W.sum(axis=0)) ** 2))

    z = x - x.mean()
    m2 = float((z * z).sum())
    m4 = float((z ** 4).sum())
    if m2 <= 0:
        return 1.0 / max(n - 1, 1)
    b2 = (n * m4) / (m2 * m2)

    S0 = float(W_sum)
    num_A = n * ((n ** 2 - 3 * n + 3) * S1 - n * S2 + 3.0 * S0 ** 2)
    num_B = b2 * ((n ** 2 - n) * S1 - 2.0 * n * S2 + 6.0 * S0 ** 2)
    denom = (n - 1.0) * (n - 2.0) * (n - 3.0) * S0 ** 2
    if denom <= 0:
        return 1.0 / max(n - 1, 1)

    E_I = -1.0 / (n - 1)
    var_I = (num_A - num_B) / denom - E_I ** 2
    return max(var_I, 1e-12)


def compute_morans_i(
    ctx,
    graph,
    cluster_key: str = config.CLUSTER_KEY,
) -> pd.DataFrame:
    """Moran's I per cell type using a binary indicator and an exact randomisation variance.

    Operates on the caller's pre-built ``AnalysisContext`` so the cell set
    matches the rest of the pipeline (rather than rebuilding from the raw
    SpatialData and potentially using a different cell mask).
    """
    from ..weights import attach_graph_to_adata
    adata = ctx.adata
    attach_graph_to_adata(adata, graph)

    W = adata.obsp["spatial_connectivities"]
    if issparse(W):
        W = W.toarray().astype(float)
    W_sum = W.sum()
    if W_sum == 0:
        raise ValueError("Empty spatial weight matrix — graph has no edges.")

    n = W.shape[0]
    cats = adata.obs[cluster_key].cat.categories.tolist()
    rows = []
    for ct in cats:
        x = (adata.obs[cluster_key] == ct).astype(float).values
        if x.sum() == 0:
            continue
        z = x - x.mean()
        z_sq = float(z @ z)
        if z_sq == 0:
            continue
        I_val = (n / W_sum) * (float(z @ W @ z) / z_sq)
        E_I = -1.0 / (n - 1)
        var_I = _morans_i_variance_randomisation(W, x, W_sum, n)
        z_score = (I_val - E_I) / max(np.sqrt(var_I), 1e-10)
        pval = float(2 * sp_norm.sf(abs(z_score)))
        rows.append({"cell_type": ct, "I": I_val, "pval_norm": pval})

    return pd.DataFrame(rows).set_index("cell_type")


def morans_to_features(moran_df: pd.DataFrame) -> dict:
    """Extract scalar features from the Moran's I DataFrame keyed by `moran__<ct>`."""
    return {
        f"moran__{ct}": float(moran_df.loc[ct, "I"])
        for ct in moran_df.index
        if pd.notna(moran_df.loc[ct, "I"])
    }
