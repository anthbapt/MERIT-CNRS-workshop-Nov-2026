"""Local spatial autocorrelation: Local Moran, Gi*, Local Geary."""
from __future__ import annotations

from typing import Dict

import esda
import numpy as np
from esda.geary_local import Geary_Local


def local_moran(y: np.ndarray, w, permutations: int = 999) -> "esda.moran.Moran_Local":
    """Local Moran's I_i for each observation with permutation p-values."""
    return esda.moran.Moran_Local(y, w, permutations=permutations)


def local_getis_ord(
    y: np.ndarray,
    w,
    star: bool = True,
    permutations: int = 999,
) -> "esda.getisord.G_Local":
    """Local Getis-Ord G_i (or G_i* if star=True) for each observation."""
    return esda.getisord.G_Local(y, w, star=star, permutations=permutations)


def local_geary(y: np.ndarray, w) -> "Geary_Local":
    """Local Geary's c_i fitted on the given connectivity."""
    return Geary_Local(connectivity=w).fit(np.asarray(y, dtype=float))


def all_local_statistics(y: np.ndarray, w, permutations: int = 200) -> Dict[str, object]:
    """Return Local Moran, G_i*, and Local Geary together for a single weights object."""
    return {
        "local_moran": local_moran(y, w, permutations=permutations),
        "local_gi_star": local_getis_ord(y, w, star=True, permutations=permutations),
        "local_geary": local_geary(y, w),
    }
