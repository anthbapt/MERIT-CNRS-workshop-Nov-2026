"""Spatially Variable Gene (SVG) detection and bivariate Moran on gene pairs."""
from __future__ import annotations

from typing import List

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import norm as scipy_norm
from statsmodels.stats.multitest import multipletests

from .. import config


def _vectorised_svg_moran(
    Xmat: np.ndarray,
    coords: np.ndarray,
    k_neighbours: int = 8,
    batch_size: int = 200,
):
    """Vectorised genome-wide Moran's I with analytical p-value (Cliff & Ord normality)."""
    n, G = Xmat.shape
    tree = cKDTree(coords)
    _, nbrs = tree.query(coords, k=min(k_neighbours + 1, n))
    nbrs = nbrs[:, 1:]

    w = 1.0 / k_neighbours

    I_vals = np.zeros(G)
    p_vals = np.ones(G)

    W_sum = n * k_neighbours * w
    W2_sum = n * k_neighbours * w ** 2
    E_I = -1.0 / (n - 1)
    Var_I = (
        n * ((n ** 2 - 3 * n + 3) * W2_sum - n * W2_sum + 3 * W_sum ** 2)
        / ((n - 1) * (n - 2) * (n - 3) * W_sum ** 2)
        - E_I ** 2
    )
    Var_I = max(Var_I, 1e-12)

    for start in range(0, G, batch_size):
        end = min(start + batch_size, G)
        batch = Xmat[:, start:end].astype(float)

        mu = batch.mean(axis=0)
        sigma = batch.std(axis=0) + 1e-12
        Z = (batch - mu) / sigma

        WZ = np.zeros_like(Z)
        for i in range(n):
            WZ[i] = w * Z[nbrs[i]].sum(axis=0)

        I_batch = (Z * WZ).sum(axis=0) / n
        I_vals[start:end] = I_batch

        z_batch = (I_batch - E_I) / np.sqrt(Var_I)
        p_vals[start:end] = 2 * scipy_norm.sf(np.abs(z_batch))

    return I_vals, p_vals


def compute_spatially_variable_genes(
    adata,
    coords: np.ndarray,
    Xmat: np.ndarray,
    k_neighbours: int = 8,
    batch_size: int = 200,
) -> pd.DataFrame:
    """Per-gene Moran's I, raw / BH-adjusted p-value, variance, and SVG flag (q < 0.05)."""
    I_svg, p_svg = _vectorised_svg_moran(
        Xmat, coords, k_neighbours=k_neighbours, batch_size=batch_size
    )
    _, p_adj_svg, _, _ = multipletests(p_svg, method="fdr_bh")

    gene_names = list(adata.var_names)
    gene_var = np.asarray(np.var(Xmat, axis=0)).ravel()
    svg_df = pd.DataFrame(
        {
            "Gene": gene_names,
            "Moran's I": I_svg,
            "p_raw": p_svg,
            "p_adj": p_adj_svg,
            "variance": gene_var,
            "SVG": p_adj_svg < 0.05,
        }
    ).sort_values("Moran's I", ascending=False).reset_index(drop=True)

    return svg_df


def top_svgs(svg_df: pd.DataFrame, n: int = config.SVG_TOP_N) -> List[str]:
    """Return the top-n SVG gene names (significant first, then top by Moran's I)."""
    sig = svg_df[svg_df["SVG"]].head(n)["Gene"].tolist()
    if len(sig) >= n:
        return sig[:n]
    extras = svg_df.head(n)["Gene"].tolist()
    out: List[str] = []
    for g in sig + extras:
        if g not in out:
            out.append(g)
        if len(out) == n:
            break
    return out


def _bivariate_spatial_morans_i(
    coords: np.ndarray,
    expr_X: np.ndarray,
    expr_Y: np.ndarray,
    k_neighbours: int = 8,
    n_perms: int = 199,
    seed: int = config.RANDOM_SEED,
):
    """Bivariate spatial Moran's I_xy with permutation p-value."""
    n = len(coords)
    tree = cKDTree(coords)
    _, nbrs = tree.query(coords, k=k_neighbours + 1)
    nbrs = nbrs[:, 1:]

    w = 1.0 / k_neighbours

    z_X = (expr_X - expr_X.mean()) / (expr_X.std() + 1e-12)
    z_Y = (expr_Y - expr_Y.mean()) / (expr_Y.std() + 1e-12)

    Wz_Y = np.array([w * z_Y[nbrs[i]].sum() for i in range(n)])
    I_obs = float(np.dot(z_X, Wz_Y) / n)

    rng = np.random.default_rng(seed)
    I_perm = np.zeros(n_perms)
    for p in range(n_perms):
        z_Y_shuf = rng.permutation(z_Y)
        Wz_Y_shuf = np.array([w * z_Y_shuf[nbrs[i]].sum() for i in range(n)])
        I_perm[p] = np.dot(z_X, Wz_Y_shuf) / n

    p_val = float((np.sum(np.abs(I_perm) >= np.abs(I_obs)) + 1) / (n_perms + 1))
    return I_obs, p_val


def bivariate_moran_pairs(
    adata,
    Xmat: np.ndarray,
    coords: np.ndarray,
    top_n: int = config.HVG_TOP_N,
    k_neighbours: int = 8,
    n_perms: int = 99,
) -> pd.DataFrame:
    """Pairwise bivariate spatial Moran's I on the top-N most variable genes (long format)."""
    gene_var_all = np.asarray(np.var(Xmat, axis=0)).ravel()
    top_idx = np.argsort(gene_var_all)[::-1][:top_n]
    var_names = list(adata.var_names)
    top_names = [var_names[i] for i in top_idx]

    I_mat = np.zeros((top_n, top_n))
    p_mat = np.ones((top_n, top_n))

    for i in range(top_n):
        for j in range(i, top_n):
            I_ij, p_ij = _bivariate_spatial_morans_i(
                coords,
                Xmat[:, top_idx[i]],
                Xmat[:, top_idx[j]],
                k_neighbours=k_neighbours,
                n_perms=n_perms,
            )
            I_mat[i, j] = I_mat[j, i] = I_ij
            p_mat[i, j] = p_mat[j, i] = p_ij

    upper = np.triu_indices(top_n, k=1)
    p_flat = p_mat[upper]
    if len(p_flat) > 0:
        _, p_corr_flat, _, _ = multipletests(p_flat, method="fdr_bh")
    else:
        p_corr_flat = p_flat

    rows = []
    # diagonal (univariate)
    for i in range(top_n):
        rows.append(
            {
                "gene_1": top_names[i],
                "gene_2": top_names[i],
                "I": float(I_mat[i, i]),
                "p_raw": float(p_mat[i, i]),
                "p_adj": float("nan"),
                "is_diagonal": True,
            }
        )
    for k, (i, j) in enumerate(zip(upper[0], upper[1])):
        rows.append(
            {
                "gene_1": top_names[i],
                "gene_2": top_names[j],
                "I": float(I_mat[i, j]),
                "p_raw": float(p_mat[i, j]),
                "p_adj": float(p_corr_flat[k]),
                "is_diagonal": False,
            }
        )

    return pd.DataFrame(rows)
