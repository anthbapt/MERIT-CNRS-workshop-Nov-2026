"""Global spatial autocorrelation: focal gene, spatial lag, Moran, Geary, Getis-Ord G."""
from __future__ import annotations

from typing import Tuple

import esda
import numpy as np
from libpysal import weights

from .. import config


def select_focal_gene(adata, Xmat) -> Tuple[str, np.ndarray]:
    """Select the highest-variance gene and return (name, expression vector)."""
    var_names = list(adata.var_names)
    feat_idx = int(np.argmax(np.var(Xmat, axis=0)))
    feat_name = var_names[feat_idx]
    y = np.asarray(Xmat[:, feat_idx], dtype=float)
    return feat_name, y


def spatial_lag(y: np.ndarray, w) -> np.ndarray:
    """Compute the spatial lag of vector y under weights w (row-standardised)."""
    w.transform = "R"
    return weights.spatial_lag.lag_spatial(w, y)


def global_moran(
    y: np.ndarray,
    w,
    n_permutations: int = config.N_PERMUTATIONS_MORAN,
) -> "esda.moran.Moran":
    """Global Moran's I with permutation pseudo-p-value."""
    return esda.moran.Moran(y, w, permutations=n_permutations)


def global_geary(y: np.ndarray, w) -> "esda.geary.Geary":
    """Global Geary's C with permutation pseudo-p-value."""
    return esda.geary.Geary(y, w)


def global_getis_ord(y: np.ndarray, w) -> "esda.getisord.G":
    """Global Getis-Ord G (requires distance-band/binary weights ideally)."""
    return esda.getisord.G(y, w)
