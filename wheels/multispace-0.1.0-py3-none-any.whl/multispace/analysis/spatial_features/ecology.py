"""Ecological models: partial-correlation networks, ISA metrics, community variogram, β(r)."""
from __future__ import annotations

import networkx as nx
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.spatial.distance import cdist, pdist, squareform
from scipy.stats import spearmanr
from sklearn.covariance import LedoitWolf
from statsmodels.stats.multitest import multipletests

from . import config


# ── Hexagonal community matrix ────────────────────────────────────────────────
def build_hex_community_matrix(coords: np.ndarray, labels: np.ndarray,
                               hex_radius: float = 150.0) -> tuple[np.ndarray, list[str], np.ndarray]:
    """Tile the FOV with a hex grid and count cells per type per window."""
    labels = np.asarray(labels)
    cell_types = list(np.unique(labels))
    C = len(cell_types)

    x_range = coords[:, 0].max() - coords[:, 0].min()
    y_range = coords[:, 1].max() - coords[:, 1].min()
    nx_hex = max(4, int(x_range / (hex_radius * np.sqrt(3))))
    ny_hex = max(4, int(y_range / (hex_radius * 1.5)))
    xs = np.linspace(coords[:, 0].min() + hex_radius,
                     coords[:, 0].max() - hex_radius, nx_hex)
    ys = np.linspace(coords[:, 1].min() + hex_radius,
                     coords[:, 1].max() - hex_radius, ny_hex)
    centres = np.array([[x + (j % 2) * hex_radius * np.sqrt(3) / 2, y]
                        for j, y in enumerate(ys)
                        for x in xs])

    tree = cKDTree(coords)
    O = np.zeros((len(centres), C), dtype=float)
    for h, hc in enumerate(centres):
        for i in tree.query_ball_point(hc, hex_radius):
            t = cell_types.index(labels[i])
            O[h, t] += 1
    nonempty = O.sum(axis=1) > 0
    return O[nonempty], cell_types, centres[nonempty]


# ── Partial-correlation network ──────────────────────────────────────────────
def shrink_partial_corr(X: np.ndarray) -> np.ndarray:
    """Ledoit-Wolf shrinkage covariance → partial correlations."""
    lw = LedoitWolf().fit(X)
    prec = lw.precision_
    d = np.sqrt(np.diag(prec))
    C = -prec / np.outer(d, d)
    np.fill_diagonal(C, 1.0)
    return C


def partial_correlation_network(O: np.ndarray, cell_types: list[str],
                                k_null: int = 199,
                                fdr: float = 0.05,
                                seed: int = 42) -> dict:
    """Partial-corr network with SES against label-permutation nulls and FDR cut."""
    n_types = O.shape[1]
    rng = np.random.default_rng(seed)
    C_obs = shrink_partial_corr(O)

    null_stack = np.zeros((k_null, n_types, n_types))
    for k in range(k_null):
        O_perm = O.copy()
        for col in range(n_types):
            rng.shuffle(O_perm[:, col])
        null_stack[k] = shrink_partial_corr(O_perm)

    mu = null_stack.mean(axis=0)
    sd = null_stack.std(axis=0) + 1e-9
    SES = (C_obs - mu) / sd

    triu = np.triu_indices(n_types, k=1)
    pvals = np.array([
        (1 + np.sum(np.abs(null_stack[:, i, j]) >= abs(C_obs[i, j]))) / (k_null + 1)
        for i, j in zip(*triu)
    ])
    _, padj, _, _ = multipletests(pvals, method="fdr_bh")
    A = np.zeros((n_types, n_types))
    for idx, (i, j) in enumerate(zip(*triu)):
        if padj[idx] < fdr:
            A[i, j] = SES[i, j]
            A[j, i] = SES[i, j]

    G = nx.Graph()
    G.add_nodes_from(cell_types)
    for i, ci in enumerate(cell_types):
        for j, cj in enumerate(cell_types):
            if j <= i:
                continue
            if A[i, j] != 0:
                G.add_edge(ci, cj, weight=float(A[i, j]),
                           sign="positive" if A[i, j] > 0 else "negative")

    deg_pos = {ct: sum(1 for _, _, d in G.edges(ct, data=True) if d["sign"] == "positive")
               for ct in cell_types}
    deg_neg = {ct: sum(1 for _, _, d in G.edges(ct, data=True) if d["sign"] == "negative")
               for ct in cell_types}
    roles = {ct: ("aggregator" if deg_pos[ct] > deg_neg[ct]
                  else "segregator" if deg_neg[ct] > deg_pos[ct]
                  else "neutral")
             for ct in cell_types}

    return {
        "C_obs": C_obs, "SES": SES, "A": A, "G": G,
        "p_adj": padj, "deg_pos": deg_pos, "deg_neg": deg_neg, "roles": roles,
        "A_df": pd.DataFrame(A, index=cell_types, columns=cell_types),
    }


# ── ISA metrics (Keil et al. 2021) ───────────────────────────────────────────
def isa_metrics(O: np.ndarray, cell_types: list[str]) -> tuple[pd.DataFrame, float]:
    """C-score, Togetherness, Forbes, Jaccard, Pearson, Spearman + variance ratio."""
    O_bin = (O > 0).astype(float)
    n_sites, n = O_bin.shape

    def c_score(x, y):
        return float(((x == 1) & (y == 0)).sum() * ((x == 0) & (y == 1)).sum())

    def togetherness(x, y):
        return float(((x == 1) & (y == 1)).sum() * ((x == 0) & (y == 0)).sum())

    def forbes(x, y, n_):
        a = ((x == 1) & (y == 1)).sum()
        b = ((x == 0) & (y == 1)).sum()
        c = ((x == 1) & (y == 0)).sum()
        denom = (a + b) * (a + c)
        return float(a * n_ / denom) if denom > 0 else float("nan")

    def jaccard(x, y):
        a = ((x == 1) & (y == 1)).sum()
        b = ((x == 0) & (y == 1)).sum()
        c = ((x == 1) & (y == 0)).sum()
        return float(a / (a + b + c)) if (a + b + c) > 0 else float("nan")

    rows = []
    for i, ci in enumerate(cell_types):
        for j, cj in enumerate(cell_types):
            if j <= i:
                continue
            xi, xj = O_bin[:, i], O_bin[:, j]
            ai, aj = O[:, i], O[:, j]
            rows.append({
                "type_A": ci, "type_B": cj,
                "C_score": c_score(xi, xj),
                "Togetherness": togetherness(xi, xj),
                "Forbes": forbes(xi, xj, n_sites),
                "Jaccard": jaccard(xi, xj),
                "Pearson_r": float(np.corrcoef(ai, aj)[0, 1]),
                "Spearman_r": float(spearmanr(ai, aj).statistic),
            })

    S2_T = float(np.var(O_bin.sum(axis=1), ddof=1))
    sum_s2 = float(np.sum([np.var(O_bin[:, i], ddof=1) for i in range(n)]))
    var_ratio = S2_T / sum_s2 if sum_s2 > 0 else float("nan")

    return pd.DataFrame(rows), var_ratio


# ── Community variogram ──────────────────────────────────────────────────────
def community_variogram(O: np.ndarray, hex_centres: np.ndarray,
                        lag_bins: np.ndarray | None = None) -> dict:
    """Within-type and between-type covariances by hex-window distance lag.

    Mirrors the notebook (cell 281): default ``lag_bins = linspace(0, 600, 13)``
    and the full pairwise distance matrix is used (self-pairs in the first
    lag are accepted as in the notebook).
    """
    if lag_bins is None:
        lag_bins = np.linspace(0, 600, 13)
    lag_mids = 0.5 * (lag_bins[:-1] + lag_bins[1:])
    n_lags = len(lag_mids)
    n = O.shape[1]

    D = squareform(pdist(hex_centres))
    cov_within = np.zeros((n_lags, n))
    cov_between = np.zeros((n_lags, n, n))
    counts = np.zeros(n_lags, dtype=int)

    for b in range(n_lags):
        lo, hi = lag_bins[b], lag_bins[b + 1]
        mask_lag = (D >= lo) & (D < hi)
        pairs = np.argwhere(mask_lag)
        counts[b] = len(pairs)
        if len(pairs) == 0:
            continue
        for iw, jw in pairs:
            diff = O[iw] - O[jw]
            cov_within[b] += diff ** 2 / 2
            cov_between[b] += np.outer(diff, diff) / 2
        cov_within[b] /= len(pairs)
        cov_between[b] /= len(pairs)

    return {
        "lag_mids": lag_mids,
        "cov_within": cov_within,
        "cov_between": cov_between,
        "counts": counts,
    }


# ── Spatially explicit β(r) Simpson ──────────────────────────────────────────
def beta_r(coords: np.ndarray, labels: np.ndarray,
           r_bins: np.ndarray | None = None,
           chunk: int = 300) -> tuple[np.ndarray, np.ndarray, float]:
    """Spatially explicit β(r) — Keil et al. 2021, Eq. 2 (chunked, no subsampling)."""
    coords = np.asarray(coords, dtype=float)
    labels = np.asarray(labels)
    n = len(coords)
    if r_bins is None:
        r_bins = np.linspace(0, 500, 21)

    cell_types = np.unique(labels)
    n_bins = len(r_bins) - 1
    r_mids = 0.5 * (r_bins[:-1] + r_bins[1:])

    n_m = np.array([(labels == ct).sum() for ct in cell_types], dtype=float)
    f = n_m / n
    baseline = float(1.0 - np.sum(f ** 2))

    all_pairs = np.zeros(n_bins, dtype=np.int64)
    within = np.zeros((n_bins, len(cell_types)), dtype=np.int64)

    for start in range(0, n, chunk):
        end = min(start + chunk, n)
        D_row = cdist(coords[start:end], coords)
        L_row = labels[start:end]
        for b in range(n_bins):
            lo, hi = r_bins[b], r_bins[b + 1]
            in_bin = (D_row >= lo) & (D_row < hi)
            for li in range(end - start):
                in_bin[li, start + li] = False
            all_pairs[b] += int(in_bin.sum())
            for m_idx, ct in enumerate(cell_types):
                focal_mask = L_row == ct
                nbr_mask = labels == ct
                within[b, m_idx] += int(in_bin[focal_mask][:, nbr_mask].sum())

    n_total = n * (n - 1)
    beta = np.full(n_bins, np.nan)
    for b in range(n_bins):
        A = all_pairs[b]
        if A == 0:
            continue
        g_ratio = np.zeros(len(cell_types))
        for m_idx in range(len(cell_types)):
            nm = n_m[m_idx]
            if nm < 2:
                continue
            g_ratio[m_idx] = (within[b, m_idx] / (nm * (nm - 1))) / (A / n_total)
        beta[b] = 1.0 - np.sum(f ** 2 * g_ratio)
    return r_mids, beta, baseline
