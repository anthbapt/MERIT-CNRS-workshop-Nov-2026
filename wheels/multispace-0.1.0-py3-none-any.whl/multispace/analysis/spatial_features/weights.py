"""Spatial weights and graph construction.

KNN, DistanceBand, adaptive Gaussian kernel, Voronoi-Queen, higher-order
contiguity, and a NetworkX→libpysal weights bridge.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import geopandas as gpd
import networkx as nx
import numpy as np
import pandas as pd
from libpysal import weights as lw
from libpysal.cg import voronoi_frames
from libpysal.graph import Graph
from libpysal.weights import higher_order_sp
from scipy.spatial import cKDTree
from scipy.sparse import lil_matrix
from shapely.geometry import Point

from . import config


# ── Helpers ───────────────────────────────────────────────────────────────────
def coords_to_gdf(coords: np.ndarray) -> gpd.GeoDataFrame:
    """Wrap point coordinates in a GeoDataFrame so libpysal sees points."""
    return gpd.GeoDataFrame(
        pd.DataFrame({"id": np.arange(len(coords))}),
        geometry=[Point(xy) for xy in coords],
        crs=None,
    )


def median_nn_distance(coords: np.ndarray) -> float:
    """Median nearest-neighbour distance — useful threshold reference."""
    nn_dist = cKDTree(coords).query(coords, k=2)[0][:, 1]
    return float(np.median(nn_dist))


# ── KNN / DistanceBand / Kernel ───────────────────────────────────────────────
def build_knn_weights(cells_gdf: gpd.GeoDataFrame, k: int = config.KNN_K):
    """Row-standardised KNN weights."""
    w = lw.KNN.from_dataframe(cells_gdf, k=k)
    w.transform = "R"
    return w


def build_distance_band_weights(
    cells_gdf: gpd.GeoDataFrame,
    coords: np.ndarray,
    nn_multiplier: float = config.DISTANCE_BAND_NN_MULTIPLIER,
):
    """DistanceBand with threshold = median NN distance × multiplier."""
    thr = median_nn_distance(coords) * nn_multiplier
    w = lw.distance.DistanceBand.from_dataframe(cells_gdf, threshold=thr, binary=True)
    return w, thr


def build_min_threshold_distance_band(
    cells_gdf: gpd.GeoDataFrame,
    coords: np.ndarray,
):
    """DistanceBand with threshold = min_threshold_distance (every cell ≥ 1 nbr).

    Mirrors the notebook's cell 38 used by Getis-Ord G.
    """
    xys = np.asarray(coords, float)
    thr = float(lw.util.min_threshold_distance(xys))
    w = lw.distance.DistanceBand.from_dataframe(cells_gdf, threshold=thr, binary=True)
    return w, thr


def build_kernel_weights(
    cells_gdf: gpd.GeoDataFrame,
    k: int = config.KNN_K,
    function: str = config.KERNEL_FUNCTION,
):
    """Adaptive Gaussian kernel — bandwidth = distance to k-th NN."""
    return lw.distance.Kernel.from_dataframe(
        cells_gdf, fixed=False, k=k, function=function,
    )


# ── Voronoi-Queen ─────────────────────────────────────────────────────────────
def build_voronoi_queen_weights(coords: np.ndarray):
    """Voronoi tessellation → Queen contiguity weights.

    Returns (weights, regions_gdf, points_gdf) on success, or
    ``(None, None, None)`` on failure.
    """
    try:
        regions, pts_gdf = voronoi_frames(coords, clip="bounding_box")
        w = lw.contiguity.Queen.from_dataframe(regions)
        return w, regions, pts_gdf
    except Exception as e:
        print(f"Voronoi failed: {e}")
        return None, None, None


# ── Higher-order ──────────────────────────────────────────────────────────────
def higher_order(w, k: int = 2, lower_order: bool = False):
    """k-th order neighbours on a base weights object."""
    return higher_order_sp(w, k=k, lower_order=lower_order)


# ── NetworkX → libpysal bridge ────────────────────────────────────────────────
def nx_to_pysal_weights(G: nx.Graph, valid_nodes=None, weight: str = "weight"):
    """Convert a NetworkX graph into a `libpysal.weights.W`."""
    valid_nodes = set(valid_nodes) if valid_nodes is not None else set(G.nodes())
    neighbors: dict = {}
    weights_dict: dict = {}
    for u in valid_nodes:
        if u not in G:
            continue
        nbrs, wts = [], []
        for v in G.neighbors(u):
            if v in valid_nodes:
                w = G[u][v].get(weight, 1.0)
                try:
                    w = float(w)
                except Exception:
                    w = 1.0
                if np.isfinite(w):
                    nbrs.append(v)
                    wts.append(w)
        neighbors[u] = nbrs
        weights_dict[u] = wts
    return lw.W(neighbors, weights_dict)


# ── Disparity-filtered graph (loaded from disk) ───────────────────────────────
def load_disparity_graph(graphml_path: str | None = None,
                         coords: np.ndarray | None = None) -> nx.Graph:
    """Load a precomputed disparity-filtered graph and patch isolated nodes."""
    path = graphml_path or config.GRAPHML_PATH
    G = nx.read_graphml(path)
    G = nx.relabel_nodes(G, lambda x: int(x))

    if coords is not None:
        ids = np.arange(len(coords))
        missing = list(set(ids.tolist()) - set(G.nodes()))
        for m in missing:
            G.add_node(m, x=float(coords[m, 0]), y=float(coords[m, 1]))
            existing = [i for i in G.nodes() if i != m]
            xy = coords[existing]
            nearest = existing[int(np.argmin(np.linalg.norm(xy - coords[m], axis=1)))]
            G.add_edge(m, nearest)
    return G


# ── Modern Graph API equivalents ──────────────────────────────────────────────
def build_modern_graphs(cells_gdf: gpd.GeoDataFrame, k: int = config.KNN_K):
    """Build the libpysal.graph equivalents of KNN and Delaunay."""
    out: dict[str, Any] = {}
    try:
        out["knn"] = Graph.build_knn(cells_gdf, k=k)
        out["delaunay"] = Graph.build_triangulation(cells_gdf, method="delaunay")
    except Exception as e:
        print(f"Graph API unavailable: {e}")
    return out


# ── Bundle returned by build_all ──────────────────────────────────────────────
@dataclass
class WeightsBundle:
    cells_gdf: gpd.GeoDataFrame
    w_knn: Any
    w_db: Any
    w_db_min: Any
    w_kern: Any
    w_vor: Any
    db_threshold: float
    db_min_threshold: float
    voronoi_regions: Any
    voronoi_points: Any
    higher_order_2: Any
    higher_order_3: Any
    graph_disparity_nx: nx.Graph
    g_dis: Any
    modern_graphs: dict[str, Any]


def build_all(coords: np.ndarray) -> WeightsBundle:
    """Build every weights object used downstream in the notebook."""
    cells_gdf = coords_to_gdf(coords)

    G_dis_nx = load_disparity_graph(coords=coords)

    w_knn = build_knn_weights(cells_gdf)
    print(f"KNN({config.KNN_K}): mean cardinality "
          f"{np.mean(list(w_knn.cardinalities.values())):.2f}")

    w_db, thr = build_distance_band_weights(cells_gdf, coords)
    print(f"DistanceBand(thr={thr:.1f}): mean card "
          f"{np.mean(list(w_db.cardinalities.values())):.2f}")

    w_db_min, thr_min = build_min_threshold_distance_band(cells_gdf, coords)
    print(f"DistanceBand(min_thr={thr_min:.1f}): mean card "
          f"{np.mean(list(w_db_min.cardinalities.values())):.2f}")

    w_kern = build_kernel_weights(cells_gdf)
    print(f"Adaptive Gaussian kernel: mean card "
          f"{np.mean(list(w_kern.cardinalities.values())):.2f}")

    w_vor, regions, pts_gdf = build_voronoi_queen_weights(coords)
    if w_vor is not None:
        print(f"Voronoi-Queen: mean card "
              f"{np.mean(list(w_vor.cardinalities.values())):.2f}")

    w2 = higher_order(w_db, k=2)
    w3 = higher_order(w_db, k=3)
    print(f"Order 2: mean card {np.mean(list(w2.cardinalities.values())):.2f}")
    print(f"Order 3: mean card {np.mean(list(w3.cardinalities.values())):.2f}")

    g_dis = nx_to_pysal_weights(G_dis_nx)
    modern = build_modern_graphs(cells_gdf)

    return WeightsBundle(
        cells_gdf=cells_gdf,
        w_knn=w_knn,
        w_db=w_db,
        w_db_min=w_db_min,
        w_kern=w_kern,
        w_vor=w_vor,
        db_threshold=thr,
        db_min_threshold=thr_min,
        voronoi_regions=regions,
        voronoi_points=pts_gdf,
        higher_order_2=w2,
        higher_order_3=w3,
        graph_disparity_nx=G_dis_nx,
        g_dis=g_dis,
        modern_graphs=modern,
    )


def attach_graph_to_adata(adata, G: nx.Graph):
    """Inject a NetworkX adjacency into AnnData.obsp for squidpy metrics."""
    pos = adata.obsm["spatial"].astype(float)
    n = len(pos)

    conn = lil_matrix((n, n), dtype=float)
    dist = lil_matrix((n, n), dtype=float)
    for u, v, d in G.edges(data=True):
        if u < n and v < n:
            w = d.get("weight", 1.0)
            conn[u, v] = conn[v, u] = 1.0
            dist[u, v] = dist[v, u] = float(w)

    adata.obsp["spatial_connectivities"] = conn.tocsr()
    adata.obsp["spatial_distances"] = dist.tocsr()
    adata.uns["spatial_neighbors"] = {
        "connectivities_key": "spatial_connectivities",
        "distances_key": "spatial_distances",
        "params": {"method": "disparity", "alpha": 0.0005},
    }
    return adata
