"""Module 7 — spatial analysis on the annotated SpatialData.

One entry point, :func:`run_spatial_analysis`, runs a list of *sections* on
the whole image or per grid tile / tissue region and writes one CSV per result
to ``results_dir``. Sections:

=============== ============================================== ==================
section         what                                            backend
=============== ============================================== ==================
composition     cell-type counts per group (region / grid)      pandas
neighborhood    neighbourhood enrichment z-scores               squidpy
autocorr        Moran's I of genes (spatially variable genes)   squidpy
ligrec          ligand–receptor permutation test                squidpy (+omnipath)
pseudobulk      summed counts per cell type × group             anndata
ssgsea          ssGSEA scores on the pseudobulk                 gseapy
niches          cellular niches (neighbourhood composition)     spatial_features
ripley          per-type Ripley L(r) − r                        spatial_features
mixing          Schmid pairwise mixing + Clark–Evans            spatial_features
=============== ============================================== ==================

Distances are given in **microns** and converted with the object's
``um_per_unit``. The full notebook port (autocorrelation family, point
patterns, morphology, ecology, MuSpAn) stays available as
:mod:`multispace.analysis.spatial_features` for deeper analyses.
"""
from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from pathlib import Path

import numpy as np
import pandas as pd

from .._sdata import ContractError, ensure_spatial, get_table, record_step, require, um_per_unit
from ..constants import Keys, Obs

logger = logging.getLogger(__name__)

__all__ = ["run_spatial_analysis", "add_grid", "pseudobulk", "SECTIONS", "DEFAULT_SECTIONS"]

GRID_KEY = "grid_id"
NICHE_KEY = "niche"


# ── grouping helpers ─────────────────────────────────────────────────────────
def add_grid(sdata, size_um: float = 200.0, *, table: str = Keys.TABLE, key: str = GRID_KEY):
    """Assign each cell to a square tile of ``size_um`` (``obs[key]`` = ``"r{row}_c{col}"``)."""
    adata = get_table(sdata, table)
    xy = ensure_spatial(sdata, table)
    size = size_um / um_per_unit(sdata, default=1.0)
    finite = np.isfinite(xy).all(1)
    x0, y0 = np.nanmin(xy[:, 0]), np.nanmin(xy[:, 1])
    col = np.floor((xy[:, 0] - x0) / size)
    row = np.floor((xy[:, 1] - y0) / size)
    ids = np.array([f"r{int(r)}_c{int(c)}" if f else "nan" for r, c, f in zip(row, col, finite, strict=True)], dtype=object)
    adata.obs[key] = pd.Categorical(ids)
    return sdata


def pseudobulk(adata, groupby: Sequence[str], layer: str | None = Obs.COUNTS_LAYER, min_cells: int = 10):
    """Sum counts over every combination of ``groupby`` columns → AnnData (groups × genes)."""
    import anndata as ad
    from scipy import sparse

    X = adata.layers[layer] if layer and layer in adata.layers else adata.X
    keys = adata.obs[list(groupby)].astype(str).agg("|".join, axis=1)
    codes, uniques = pd.factorize(keys)
    ind = sparse.csr_matrix((np.ones(len(codes)), (codes, np.arange(len(codes)))), shape=(len(uniques), len(codes)))
    summed = ind @ (X if sparse.issparse(X) else sparse.csr_matrix(X))
    n = np.bincount(codes, minlength=len(uniques))
    obs = pd.DataFrame([u.split("|") for u in uniques], columns=list(groupby), index=uniques)
    obs["n_cells"] = n
    out = ad.AnnData(X=sparse.csr_matrix(summed), obs=obs, var=pd.DataFrame(index=adata.var_names))
    return out[out.obs["n_cells"] >= min_cells].copy()


# ── sections ─────────────────────────────────────────────────────────────────
def _labels(adata, cluster_key):
    if cluster_key not in adata.obs:
        raise ContractError(f"table.obs['{cluster_key}'] missing: run cell typing first.")
    return adata.obs[cluster_key].astype(str).to_numpy()


def _sec_composition(ctx):
    adata, out = ctx["adata"], {}
    for g in ctx["groups"]:
        out[f"composition_by_{g}"] = pd.crosstab(adata.obs[g], adata.obs[ctx["cluster_key"]])
    if not ctx["groups"]:
        out["composition"] = adata.obs[ctx["cluster_key"]].value_counts().to_frame("n_cells")
    return out


def _squidpy_view(ctx):
    sq = require("squidpy", "analysis")
    a = ctx["adata"]
    view = a.copy()
    view.obsm["spatial"] = ctx["xy"]
    view = view[np.isfinite(ctx["xy"]).all(1)].copy()
    view.obs[ctx["cluster_key"]] = view.obs[ctx["cluster_key"]].astype("category")
    sq.gr.spatial_neighbors(view, coord_type="generic", delaunay=True)
    return sq, view


def _sec_neighborhood(ctx):
    sq, view = _squidpy_view(ctx)
    ck = ctx["cluster_key"]
    sq.gr.nhood_enrichment(view, cluster_key=ck, seed=0, show_progress_bar=False)
    cats = view.obs[ck].cat.categories
    z = pd.DataFrame(view.uns[f"{ck}_nhood_enrichment"]["zscore"], index=cats, columns=cats)
    return {"nhood_enrichment_zscore": z}


def _sec_autocorr(ctx):
    import scanpy as sc

    sq, view = _squidpy_view(ctx)
    if Obs.COUNTS_LAYER in view.layers:
        view.X = view.layers[Obs.COUNTS_LAYER].copy()
    sc.pp.normalize_total(view)
    sc.pp.log1p(view)
    genes = view.var_names[: ctx["params"].get("max_genes", 500)]
    sq.gr.spatial_autocorr(view, mode="moran", genes=list(genes), n_perms=None, show_progress_bar=False)
    return {"moran_genes": view.uns["moranI"].sort_values("I", ascending=False)}


def _sec_ligrec(ctx):
    sq, view = _squidpy_view(ctx)
    import scanpy as sc

    if Obs.COUNTS_LAYER in view.layers:
        view.X = view.layers[Obs.COUNTS_LAYER].copy()
    sc.pp.normalize_total(view)
    sc.pp.log1p(view)
    res = sq.gr.ligrec(view, cluster_key=ctx["cluster_key"], use_raw=False, copy=True, seed=0,
                       n_perms=ctx["params"].get("n_perms", 500), show_progress_bar=False,
                       **ctx["params"].get("ligrec_kwargs", {}))
    pv = res["pvalues"].stack(level=[0, 1], future_stack=True).rename("pvalue")
    mean = res["means"].stack(level=[0, 1], future_stack=True).rename("mean")
    df = pd.concat([mean, pv], axis=1).reset_index()
    return {"ligrec": df[df["pvalue"] < ctx["params"].get("alpha", 0.05)]}


def _sec_pseudobulk(ctx):
    groups = [ctx["cluster_key"], *ctx["groups"]]
    pb = pseudobulk(ctx["adata"], groups, min_cells=ctx["params"].get("min_cells", 10))
    ctx["pseudobulk"] = pb
    path = ctx["results_dir"] / "pseudobulk.h5ad"
    pb.write_h5ad(path)
    return {"pseudobulk_groups": pb.obs}


def _sec_ssgsea(ctx):
    gp = require("gseapy", "analysis")
    gene_sets = ctx["params"].get("gene_sets")
    if gene_sets is None:
        raise ValueError("ssgsea needs params.gene_sets (a .gmt path or {name: [genes]}).")
    pb = ctx.get("pseudobulk")
    if pb is None:
        pb = pseudobulk(ctx["adata"], [ctx["cluster_key"], *ctx["groups"]])
    X = pb.X.toarray() if hasattr(pb.X, "toarray") else np.asarray(pb.X)
    cpm = np.log1p(X / np.maximum(X.sum(1, keepdims=True), 1) * 1e6)
    expr = pd.DataFrame(cpm.T, index=pb.var_names, columns=pb.obs_names)
    res = gp.ssgsea(data=expr, gene_sets=gene_sets, outdir=None, sample_norm_method="rank",
                    min_size=ctx["params"].get("min_size", 5), no_plot=True, verbose=False)
    scores = res.res2d.pivot(index="Name", columns="Term", values="NES")
    return {"ssgsea_nes": scores}


def _sec_niches(ctx):
    require("libpysal", "analysis")
    from .spatial_features import clustering

    p = ctx["params"]
    radius = p.get("niche_radius_um", 50.0) / ctx["upu"]
    ok = np.isfinite(ctx["xy"]).all(1)
    comp, valid, types = clustering.compute_neighbourhood_composition(ctx["xy"][ok], ctx["labels"][ok], radius=radius)
    k = p.get("n_niches")
    scores = {}
    if k is None:
        k, scores = clustering.select_n_niches(comp[valid], k_range=range(2, p.get("max_niches", 8) + 1))
    fit = clustering.fit_niches(comp, valid, types, k)
    lab = np.full(len(ctx["xy"]), "unassigned", dtype=object)
    sub = np.array([fit["names"].get(i, "unassigned") if i >= 0 else "unassigned" for i in fit["niche_labels"]],
                   dtype=object)
    lab[ok] = sub
    ctx["adata"].obs[NICHE_KEY] = pd.Categorical(lab)
    out = {"niche_profiles": fit["profiles"]}
    if scores:
        out["niche_silhouette"] = pd.Series(scores, name="silhouette").to_frame()
    return out


def _sec_ripley(ctx):
    require("pointpats", "analysis")
    from .spatial_features.pointpat import engine

    p = ctx["params"]
    upu = ctx["upu"]
    res = engine.compute_ripley(ctx["sdata_view"], cluster_key=ctx["cluster_key"],
                                r_max=p.get("ripley_rmax_um", 200.0) / upu, min_cells=p.get("min_cells", 30))
    rows = []
    for ct, d in res.items():
        for r, lval, lr in zip(d["bins"], d["L"], d["L_minus_r"], strict=False):
            rows.append({"cell_type": ct, "r_um": r * upu, "L": lval * upu, "L_minus_r_um": lr * upu})
    return {"ripley_L": pd.DataFrame(rows)}


def _sec_mixing(ctx):
    require("libpysal", "analysis")
    from .spatial_features.interactions import mixing

    ok = np.isfinite(ctx["xy"]).all(1)
    xy, lab = ctx["xy"][ok], ctx["labels"][ok]
    return {"schmid_pairwise": mixing.schmid_pairwise(xy, lab),
            "clark_evans": mixing.clark_evans_per_celltype(xy, lab)}


SECTIONS: dict[str, Callable] = {
    "composition": _sec_composition, "neighborhood": _sec_neighborhood, "autocorr": _sec_autocorr,
    "ligrec": _sec_ligrec, "pseudobulk": _sec_pseudobulk, "ssgsea": _sec_ssgsea,
    "niches": _sec_niches, "ripley": _sec_ripley, "mixing": _sec_mixing,
}
DEFAULT_SECTIONS = ("composition", "neighborhood", "pseudobulk")


class _TableView:
    """Minimal SpatialData stand-in for spatial_features functions."""

    def __init__(self, adata, xy):
        a = adata.copy()
        a.obsm["spatial"] = xy
        self.tables = {Keys.TABLE: a}
        self.shapes, self.labels = {}, {}


# ── entry point ──────────────────────────────────────────────────────────────
def run_spatial_analysis(
    sdata,
    *,
    results_dir: str | Path,
    sections: Sequence[str] = DEFAULT_SECTIONS,
    cluster_key: str = Obs.CELL_TYPE,
    groupby: Sequence[str] | None = None,
    grid_size_um: float | None = None,
    table: str = Keys.TABLE,
    params: dict | None = None,
    strict: bool = False,
) -> dict[str, pd.DataFrame]:
    """Run analysis ``sections`` and write ``<results_dir>/<name>.csv`` per result.

    Parameters
    ----------
    groupby
        obs columns to stratify by (composition, pseudobulk, ssGSEA). Default:
        ``tissue_region`` when present, plus ``grid_id`` when ``grid_size_um`` is set.
    grid_size_um
        Tile the image into squares of this size and analyse per tile.
    params
        Section options, e.g. ``niche_radius_um``, ``n_niches``, ``ripley_rmax_um``,
        ``gene_sets``, ``n_perms``, ``min_cells``.
    strict
        Raise on the first failing section instead of logging and continuing.
    """
    unknown = set(sections) - set(SECTIONS)
    if unknown:
        raise ValueError(f"Unknown sections {sorted(unknown)}; choose from {sorted(SECTIONS)}")
    results_dir = Path(results_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    adata = get_table(sdata, table)
    xy = ensure_spatial(sdata, table)
    if grid_size_um:
        add_grid(sdata, grid_size_um, table=table)
    if groupby is None:
        groupby = [c for c in (Obs.TISSUE_REGION,) if c in adata.obs] + ([GRID_KEY] if grid_size_um else [])
    ctx = {"adata": adata, "xy": xy, "cluster_key": cluster_key, "labels": _labels(adata, cluster_key),
           "groups": list(groupby), "params": dict(params or {}), "results_dir": results_dir,
           "upu": um_per_unit(sdata, default=1.0), "sdata_view": _TableView(adata, xy)}

    results: dict[str, pd.DataFrame] = {}
    status: dict[str, str] = {}
    for name in sections:
        try:
            out = SECTIONS[name](ctx)
            for key, df in out.items():
                df.to_csv(results_dir / f"{key}.csv")
                results[key] = df
            status[name] = "ok"
            logger.info("analysis section '%s' done (%s)", name, ", ".join(out))
        except Exception as err:
            if strict:
                raise
            status[name] = f"failed: {type(err).__name__}: {err}"
            logger.warning("analysis section '%s' failed: %s", name, err)
    record_step(sdata, "spatial_analysis", {"sections": list(sections), "cluster_key": cluster_key,
                                            "groupby": list(groupby), "grid_size_um": grid_size_um},
                results_dir=str(results_dir), status=status)
    return results
