"""
Visualization Functions for Cell Type Annotation
=================================================

This module provides plotting functions for visualizing cell type
annotations, confidence scores, and marker expression in single-cell
and spatial transcriptomics data.

Functions
---------
- plot_celltype_distribution: Bar chart of cell type frequencies
- plot_celltype_spatial: Spatial scatter plot colored by cell type
- plot_confidence_spatial: Spatial scatter plot colored by confidence
- plot_marker_heatmap: Heatmap of marker expression by cell type
- plot_marker_dotplot: Dot plot of marker expression

Example
-------
>>> from multispace.celltyping.plotting import plot_celltype_spatial
>>> fig, ax = plot_celltype_spatial(adata, cell_type_key="cell_type")
>>> plt.savefig("spatial_celltypes.png")
"""

from __future__ import annotations

import os
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse

# NOTE: sc.settings.figdir is intentionally NOT set here.
# Changing it at import time would silently override any figdir the caller
# already configured.  Use save_figure() or set sc.settings.figdir yourself
# before calling scanpy plotting functions.

try:
    import anndata as ad
except ImportError:
    ad = None

from .constants import CELL_TYPE_PALETTE, Colors, ColumnNames
from .core_utils import _parse_marker_entry

__all__ = [
    "plot_celltype_distribution",
    "plot_celltype_spatial",
    "plot_confidence_spatial",
    "plot_marker_heatmap",
    "plot_marker_dotplot",
    "save_figure",
]


def plot_celltype_distribution(
    adata,
    cell_type_key: str = None,
    palette: dict[str, str] | None = None,
    orientation: str = "horizontal",
    ax: plt.Axes | None = None,
    figsize: tuple[float, float] = (10, 6),
    title: str | None = None,
    **kwargs,
) -> plt.Axes:
    """
    Plot cell type distribution as bar chart.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type assignments.
    cell_type_key : str, optional
        Column name for cell types. Default: ColumnNames.CELL_TYPE.
    palette : dict, optional
        Color palette mapping cell types to colors.
    orientation : str
        'horizontal' or 'vertical'. Default: 'horizontal'.
    ax : plt.Axes, optional
        Axes to plot on. Creates new figure if None.
    figsize : tuple
        Figure size if creating new figure.
    title : str, optional
        Plot title.
    **kwargs
        Additional arguments passed to pandas plot.

    Returns
    -------
    plt.Axes
        The axes object.

    Examples
    --------
    >>> ax = plot_celltype_distribution(adata, cell_type_key="consensus_cell_type")
    >>> plt.savefig("celltype_distribution.png")
    """
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE
    if palette is None:
        palette = CELL_TYPE_PALETTE

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)

    # Count cell types
    counts = adata.obs[cell_type_key].value_counts()

    # Get colors
    colors = [palette.get(ct, Colors.FALLBACK_GREY) for ct in counts.index]

    # Plot
    if orientation == "horizontal":
        counts.plot(kind="barh", ax=ax, color=colors, **kwargs)
        ax.set_xlabel("Number of cells")
        ax.set_ylabel("Cell type")
        ax.invert_yaxis()
    else:
        counts.plot(kind="bar", ax=ax, color=colors, **kwargs)
        ax.set_ylabel("Number of cells")
        ax.set_xlabel("Cell type")
        plt.xticks(rotation=45, ha="right")

    if title:
        ax.set_title(title)

    plt.tight_layout()
    return ax


def plot_celltype_spatial(
    adata,
    cell_type_key: str = None,
    coord_keys: tuple[str, str] = ("centroid_x", "centroid_y"),
    palette: dict[str, str] | None = None,
    ax: plt.Axes | None = None,
    figsize: tuple[float, float] = (10, 10),
    point_size: float = 1,
    alpha: float = 0.7,
    show_legend: bool = True,
    title: str | None = None,
    **kwargs,
) -> plt.Axes:
    """
    Plot cell types in spatial coordinates.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type assignments and spatial coordinates.
    cell_type_key : str, optional
        Column name for cell types. Default: ColumnNames.CELL_TYPE.
    coord_keys : tuple
        Column names for (x, y) coordinates.
    palette : dict, optional
        Color palette mapping cell types to colors.
    ax : plt.Axes, optional
        Axes to plot on.
    figsize : tuple
        Figure size if creating new figure.
    point_size : float
        Size of scatter points.
    alpha : float
        Transparency of points.
    show_legend : bool
        Whether to show legend.
    title : str, optional
        Plot title.
    **kwargs
        Additional arguments passed to scatter.

    Returns
    -------
    plt.Axes
        The axes object.

    Examples
    --------
    >>> ax = plot_celltype_spatial(
    ...     adata,
    ...     coord_keys=("centroid_x", "centroid_y"),
    ...     point_size=2
    ... )
    """
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE
    if palette is None:
        palette = CELL_TYPE_PALETTE

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)

    x_key, y_key = coord_keys

    # Check coordinates exist
    if x_key not in adata.obs.columns or y_key not in adata.obs.columns:
        raise ValueError(
            f"Coordinate columns {coord_keys} not found in adata.obs. "
            f"Available: {list(adata.obs.columns)}"
        )

    # Plot each cell type
    cell_types = adata.obs[cell_type_key].unique()

    for ct in sorted(cell_types):
        mask = adata.obs[cell_type_key] == ct
        color = palette.get(ct, Colors.FALLBACK_GREY)
        ax.scatter(
            adata.obs.loc[mask, x_key],
            adata.obs.loc[mask, y_key],
            c=color,
            s=point_size,
            label=ct,
            alpha=alpha,
            **kwargs,
        )

    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_aspect("equal")

    if show_legend:
        ax.legend(bbox_to_anchor=(1.05, 1), loc="upper left", markerscale=3, frameon=False)

    if title:
        ax.set_title(title)

    plt.tight_layout()
    return ax


def plot_confidence_spatial(
    adata,
    confidence_key: str = None,
    coord_keys: tuple[str, str] = ("centroid_x", "centroid_y"),
    ax: plt.Axes | None = None,
    figsize: tuple[float, float] = (10, 10),
    point_size: float = 1,
    cmap: str = "viridis",
    vmin: float = 0,
    vmax: float = 1,
    alpha: float = 0.7,
    title: str | None = None,
    **kwargs,
) -> plt.Axes:
    """
    Plot confidence scores in spatial coordinates.

    Parameters
    ----------
    adata : AnnData
        Annotated data with confidence scores and spatial coordinates.
    confidence_key : str, optional
        Column name for confidence scores. Default: ColumnNames.CONFIDENCE.
    coord_keys : tuple
        Column names for (x, y) coordinates.
    ax : plt.Axes, optional
        Axes to plot on.
    figsize : tuple
        Figure size if creating new figure.
    point_size : float
        Size of scatter points.
    cmap : str
        Colormap name.
    vmin, vmax : float
        Color scale limits.
    alpha : float
        Transparency of points.
    title : str, optional
        Plot title.
    **kwargs
        Additional arguments passed to scatter.

    Returns
    -------
    plt.Axes
        The axes object.
    """
    if confidence_key is None:
        confidence_key = ColumnNames.CONFIDENCE

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)

    x_key, y_key = coord_keys

    scatter = ax.scatter(
        adata.obs[x_key],
        adata.obs[y_key],
        c=adata.obs[confidence_key],
        s=point_size,
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        alpha=alpha,
        **kwargs,
    )

    plt.colorbar(scatter, ax=ax, label="Confidence", shrink=0.8)
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_aspect("equal")

    if title:
        ax.set_title(title)

    plt.tight_layout()
    return ax


def plot_marker_heatmap(
    adata,
    marker_dict: dict[str, list[str]],
    cell_type_key: str = None,
    layer: str | None = None,
    figsize: tuple[float, float] = (12, 8),
    cmap: str = "viridis",
    show_gene_labels: bool = True,
    title: str | None = None,
    biomarkers_df: pd.DataFrame | None = None,
    sort_cell_types: bool = True,
    show_group_labels: bool = True,
    **kwargs,
) -> plt.Figure:
    """Heatmap of mean marker expression per cell type.

    Markers are grouped by their primary cell type on the y-axis for
    readability.  Horizontal separator lines and optional left-side group
    labels make the grouping immediately visible.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type labels in ``adata.obs``.
    marker_dict : dict
        Mapping of cell type → marker gene list.
    cell_type_key : str, optional
        Column in ``adata.obs`` containing cell type labels.
    layer : str, optional
        AnnData layer to use for expression. ``None`` uses ``adata.X``.
    figsize : tuple of float
        Figure size ``(width, height)``. Default: ``(12, 8)``.
    cmap : str
        Matplotlib colormap name. Default: ``"viridis"``.
    show_gene_labels : bool
        Whether to label individual genes on the y-axis. Default: ``True``.
    title : str, optional
        Figure title.
    biomarkers_df : pd.DataFrame, optional
        Optional CSV-derived DataFrame with ``Gene_Symbol_Resolved`` and
        ``Primary_Cell_Type`` columns. When provided, gene labels are
        annotated with their primary cell type from the CSV.
    sort_cell_types : bool
        Sort marker groups alphabetically by cell type name. Default: ``True``.
    show_group_labels : bool
        Add a cell-type group label to the left of each marker group.
        Default: ``True``.

    Returns
    -------
    plt.Figure
    """
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE

    # Build gene → cell_type lookup from CSV if provided
    csv_marker_to_type: dict[str, str] = {}
    if biomarkers_df is not None:
        csv_marker_to_type = (
            biomarkers_df.dropna(subset=["Gene_Symbol_Resolved", "Primary_Cell_Type"])
            .drop_duplicates(subset="Gene_Symbol_Resolved")
            .set_index("Gene_Symbol_Resolved")["Primary_Cell_Type"]
            .to_dict()
        )

    # ── Build marker list grouped by cell type ─────────────────────────────
    # Markers are ordered cell-type by cell-type (alphabetically when
    # sort_cell_types=True) so the heatmap rows are visually clustered.
    # Shared markers are placed under the first cell type that lists them.
    dict_cell_types = sorted(marker_dict.keys()) if sort_cell_types else list(marker_dict.keys())

    all_markers: list[str] = []
    marker_to_type: dict[str, str] = {}
    # Each entry: (group_start_row, group_end_row, cell_type_name)
    group_spans: list[tuple[int, int, str]] = []

    for ct in dict_cell_types:
        group_start = len(all_markers)
        pos_genes, _ = _parse_marker_entry(marker_dict[ct])  # positives only for display
        for m in pos_genes:
            if m in adata.var_names and m not in marker_to_type:
                all_markers.append(m)
                marker_to_type[m] = ct
        group_end = len(all_markers)
        if group_end > group_start:
            group_spans.append((group_start, group_end, ct))

    if not all_markers:
        raise ValueError("No markers found in data")

    # ── Expression matrix ──────────────────────────────────────────────────
    X = adata[:, all_markers].layers[layer] if layer is not None else adata[:, all_markers].X
    if sparse.issparse(X):
        X = X.toarray()

    # Compute mean expression per cell type (columns = observed cell types)
    cell_types = sorted(adata.obs[cell_type_key].unique())
    mean_expr = np.zeros((len(all_markers), len(cell_types)))
    for j, ct in enumerate(cell_types):
        mask = adata.obs[cell_type_key] == ct
        if mask.sum() > 0:
            mean_expr[:, j] = X[mask].mean(axis=0)

    # ── Row-wise z-score so the heatmap shows differential expression ──────
    # Raw mean lognorm values are dominated by absolute expression level —
    # a housekeeping gene expressed at 2.0 everywhere looks "bright" even
    # with no subtype specificity.  Z-scoring each gene (row) to mean=0,
    # std=1 across subtypes reveals which genes are genuinely enriched in
    # each subtype relative to the others.
    row_mean = mean_expr.mean(axis=1, keepdims=True)
    row_std = mean_expr.std(axis=1, keepdims=True)
    plot_expr = (mean_expr - row_mean) / (row_std + 1e-8)

    # ── Y-axis labels ──────────────────────────────────────────────────────
    def _make_ylabel(gene: str) -> str:
        cell_type = csv_marker_to_type.get(gene) or marker_to_type.get(gene)
        return f"{gene} ({cell_type})" if cell_type else gene

    # ── Plot ───────────────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(plot_expr, aspect="auto", cmap=cmap, **kwargs)

    ax.set_xticks(range(len(cell_types)))
    ax.set_xticklabels(cell_types, rotation=45, ha="right", fontsize=9)

    if show_gene_labels:
        ax.set_yticks(range(len(all_markers)))
        ax.set_yticklabels([_make_ylabel(m) for m in all_markers], fontsize=8)
    else:
        ax.set_yticks([])

    # ── Separator lines between cell-type groups ───────────────────────────
    for start, end, ct_name in group_spans:
        if start > 0:
            # Draw a white dashed line just above this group's first row.
            # imshow y-coordinates: row i spans [i-0.5, i+0.5].
            ax.axhline(start - 0.5, color="white", linewidth=1.2, linestyle="--", alpha=0.8)

        # ── Group label on the left ────────────────────────────────────────
        if show_group_labels:
            mid_row = (start + end - 1) / 2
            # Place the label just to the left of the heatmap in axes coordinates.
            # We use ax.transData for y (row index) and convert via annotate.
            ax.annotate(
                ct_name,
                xy=(-0.5, mid_row),  # data coords: left edge of col 0
                xycoords="data",
                xytext=(-6, 0),  # offset in points (left of axis)
                textcoords="offset points",
                ha="right",
                va="center",
                fontsize=7,
                fontstyle="italic",
                color="#444444",
                annotation_clip=False,
            )

    fig.colorbar(im, ax=ax, label="Mean expression (z-score)", shrink=0.8)
    if title:
        ax.set_title(title)

    fig.tight_layout()

    return fig


def plot_marker_dotplot(
    adata,
    marker_dict: dict[str, list[str]],
    cell_type_key: str = None,
    max_markers: int = 50,
    save: str = None,
    **kwargs,
) -> None:
    """
    Plot dot plot of marker expression using scanpy.

    Parameters
    ----------
    adata : AnnData
        Annotated data.
    marker_dict : dict
        Marker dictionary mapping cell types to gene lists.
    cell_type_key : str, optional
        Column name for cell types.
    max_markers : int
        Maximum number of markers to show.
    **kwargs
        Additional arguments passed to sc.pl.dotplot.
    """
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE

    # Get available markers (positive genes only for display)
    all_markers = []
    for entry in marker_dict.values():
        pos_genes, _ = _parse_marker_entry(entry)
        for m in pos_genes:
            if m in adata.var_names and m not in all_markers:
                all_markers.append(m)

    if not all_markers:
        raise ValueError("No markers found in data")

    # Limit markers
    markers_to_plot = all_markers[:max_markers] if max_markers is not None else all_markers

    kwargs.pop("save", None)  # prevent save from leaking into sc.pl.dotplot
    sc.pl.dotplot(adata, var_names=markers_to_plot, groupby=cell_type_key, show=False, **kwargs)

    if save:
        dirpath = os.path.dirname(save)
        if dirpath:
            os.makedirs(dirpath, exist_ok=True)
        plt.savefig(f"{save}.png", dpi=300, bbox_inches="tight")
        plt.close()


def save_figure(
    filename: str,
    output_dir: str | Path,
    formats: list[str] | None = None,
    dpi: int = 300,
    **kwargs,
) -> list[Path]:
    """
    Save current figure to file(s).

    Parameters
    ----------
    filename : str
        Base filename (without extension).
    output_dir : str or Path
        Output directory.
    formats : list, optional
        List of formats to save. Default: ['png', 'svg'].
    dpi : int
        Resolution for raster formats.
    **kwargs
        Additional arguments passed to savefig.

    Returns
    -------
    List[Path]
        List of saved file paths.

    Examples
    --------
    >>> plt.figure()
    >>> plt.plot([1, 2, 3])
    >>> paths = save_figure("my_plot", "/results/figures")
    """
    if formats is None:
        formats = ["png", "svg"]

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    saved_paths = []
    for fmt in formats:
        filepath = output_dir / f"{filename}.{fmt}"
        plt.savefig(filepath, dpi=dpi, bbox_inches="tight", **kwargs)
        saved_paths.append(filepath)

    return saved_paths
