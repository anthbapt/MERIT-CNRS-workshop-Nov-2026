"""
Configuration Module for Cell Type Annotation Workflow
======================================================

Refactored configuration using centralized constants and improved validation.

This module provides:
- ConfidenceConfig: Confidence threshold settings
- PathConfig: File path settings
- PlotConfig: Visualization settings
- AnnotationMethodConfig: Annotation method settings
- WorkflowConfig: Master configuration combining all sub-configs

Usage:
------
    from config import WorkflowConfig, ConfidenceConfig

    # Use defaults
    config = WorkflowConfig()

    # Customize
    config = WorkflowConfig(
        confidence=ConfidenceConfig(celltypist_threshold=0.85),
        core_ids=["MB-GU-1168"]
    )

"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

# Import from centralized constants
from .constants import (
    AnnotationMethod,
    CalibrationMethod,
    ConsensusMethod,
    Defaults,
)

# =============================================================================
# CONFIDENCE CONFIGURATION
# =============================================================================


@dataclass
class ConfidenceConfig:
    """
    Configuration for confidence score thresholds.

    All thresholds are on a 0-1 scale where higher = more confident.

    Attributes
    ----------
    celltypist_threshold : float
        Minimum CellTypist confidence to trust the prediction.
        Cells below this threshold may be reassigned using biomarkers.
        Default: 0.9 (high confidence required)

    biomarker_threshold : float
        Minimum biomarker score confidence to use for reassignment.
        Default: 0.6

    neighborhood_consensus : float
        Minimum fraction of neighbors that must agree for neighborhood-based
        reassignment of low-confidence cells.
        Default: 0.7 (70% of neighbors must agree)

    n_neighbors : int
        Number of neighbors to consider for neighborhood consensus refinement.
        Default: 10
    """

    celltypist_threshold: float = Defaults.CELLTYPIST_THRESHOLD
    biomarker_threshold: float = Defaults.BIOMARKER_THRESHOLD
    neighborhood_consensus: float = Defaults.NEIGHBORHOOD_CONSENSUS
    n_neighbors: int = Defaults.N_NEIGHBORS

    def __post_init__(self):
        """Validate threshold values."""
        self._validate_range("celltypist_threshold", self.celltypist_threshold)
        self._validate_range("biomarker_threshold", self.biomarker_threshold)
        self._validate_range("neighborhood_consensus", self.neighborhood_consensus)

        if self.n_neighbors < 1:
            raise ValueError(f"n_neighbors must be >= 1, got {self.n_neighbors}")

    @staticmethod
    def _validate_range(name: str, value: float) -> None:
        """Validate that a value is in [0, 1] range."""
        if not 0 <= value <= 1:
            raise ValueError(f"{name} must be between 0 and 1, got {value}")

    @classmethod
    def strict(cls) -> ConfidenceConfig:
        """Create a strict configuration (high confidence required)."""
        return cls(
            celltypist_threshold=0.95,
            biomarker_threshold=0.8,
            neighborhood_consensus=0.8,
            n_neighbors=15,
        )

    @classmethod
    def relaxed(cls) -> ConfidenceConfig:
        """Create a relaxed configuration (more permissive)."""
        return cls(
            celltypist_threshold=0.7,
            biomarker_threshold=0.4,
            neighborhood_consensus=0.6,
            n_neighbors=10,
        )

    @classmethod
    def balanced(cls) -> ConfidenceConfig:
        """Create a balanced configuration (default)."""
        return cls()

    def summary(self) -> str:
        """Return a formatted summary of the configuration."""
        return (
            f"ConfidenceConfig:\n"
            f"  CellTypist threshold:     {self.celltypist_threshold:.2f}\n"
            f"  Biomarker threshold:      {self.biomarker_threshold:.2f}\n"
            f"  Neighborhood consensus:   {self.neighborhood_consensus:.2f}\n"
            f"  N neighbors:              {self.n_neighbors}"
        )


# =============================================================================
# PATH CONFIGURATION
# =============================================================================


@dataclass
class PathConfig:
    """
    Configuration for file paths.

    Attributes
    ----------
    base_dir : Path
        Base directory for all data.
    zarr_dir : Path
        Directory containing QC'd Zarr files.
    model_dir : Path
        Directory containing CellTypist model.
    output_dir : Path
        Directory for output files.
    metadata_path : Path
        Path to metadata CSV file.
    biomarkers_csv : Path
        Path to biomarkers CSV file.
    biomarker_matrix_csv : Path
        Path to biomarker-cell type matrix CSV.
    gene_list_csv : Path
        Path to 10X gene list CSV.
    """

    base_dir: Path = field(default_factory=lambda: Path("."))
    zarr_dir: Path = field(default_factory=lambda: Path("./data/zarr"))
    model_dir: Path = field(default_factory=lambda: Path("./models"))
    output_dir: Path = field(default_factory=lambda: Path("./output"))
    metadata_path: Path | None = None
    biomarkers_csv: Path | None = None
    biomarker_matrix_csv: Path | None = None
    gene_list_csv: Path | None = None

    def __post_init__(self):
        """Convert string paths to Path objects."""
        path_attrs = [
            "base_dir",
            "zarr_dir",
            "model_dir",
            "output_dir",
            "metadata_path",
            "biomarkers_csv",
            "biomarker_matrix_csv",
            "gene_list_csv",
        ]
        for attr in path_attrs:
            value = getattr(self, attr)
            if isinstance(value, str):
                setattr(self, attr, Path(value))

    def ensure_output_dir(self) -> None:
        """Create output directory if it doesn't exist."""
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def core_output_dir(self, core_id: str) -> Path:
        """Get output directory for a specific core."""
        path = self.output_dir / core_id
        path.mkdir(parents=True, exist_ok=True)
        return path

    def validate_paths(self) -> list[str]:
        """
        Validate that required paths exist.

        Returns
        -------
        List[str]
            List of validation warnings.
        """
        warnings = []

        if not self.base_dir.exists():
            warnings.append(f"Base directory does not exist: {self.base_dir}")

        if not self.zarr_dir.exists():
            warnings.append(f"Zarr directory does not exist: {self.zarr_dir}")

        if not self.model_dir.exists():
            warnings.append(f"Model directory does not exist: {self.model_dir}")

        return warnings


# =============================================================================
# PLOT CONFIGURATION
# =============================================================================


@dataclass
class PlotConfig:
    """
    Configuration for plotting parameters.

    Attributes
    ----------
    font_size : int
        Base font size for plots.
    axes_label_size : int
        Font size for axis labels.
    tick_label_size : int
        Font size for tick labels.
    figure_dpi : int
        DPI for saved figures.
    umap_point_size : Optional[float]
        Point size for UMAP plots (None = auto-calculate).
    cmap : str
        Default colormap for expression plots.
    """

    font_size: int = Defaults.FONT_SIZE
    axes_label_size: int = Defaults.FONT_SIZE
    tick_label_size: int = 8
    figure_dpi: int = Defaults.FIGURE_DPI
    umap_point_size: float | None = None
    cmap: str = "YlOrRd"

    def apply_rcparams(self) -> None:
        """Apply matplotlib rcParams."""
        import matplotlib.pyplot as plt

        plt.rcParams["font.size"] = self.font_size
        plt.rcParams["axes.labelsize"] = self.axes_label_size
        plt.rcParams["xtick.labelsize"] = self.tick_label_size
        plt.rcParams["ytick.labelsize"] = self.tick_label_size

    def calculate_point_size(self, n_cells: int) -> float:
        """
        Calculate appropriate point size based on number of cells.

        Parameters
        ----------
        n_cells : int
            Number of cells to plot.

        Returns
        -------
        float
            Recommended point size.
        """
        if self.umap_point_size is not None:
            return self.umap_point_size

        return max(1, min(Defaults.POINT_SIZE_DIVISOR / n_cells, Defaults.POINT_SIZE_MAX))


# =============================================================================
# ANNOTATION METHOD CONFIGURATION
# =============================================================================


@dataclass
class AnnotationMethodConfig:
    """
    Configuration for cell type annotation methods.

    Attributes
    ----------
    methods : List[str]
        List of annotation methods to run. Available methods:
        - 'celltypist': CellTypist machine learning-based annotation
        - 'biomarker': Simple marker gene scoring
        - 'sctype': scType specificity-weighted scoring
        - 'hierarchy': Hierarchical marker-based classification
        - 'overcluster': Overclustering + marker annotation

    sctype_min_score : float
        Minimum scType score for cell type assignment.

    use_negative_markers : bool
        Whether to use negative markers in scType.

    hierarchy_use_clustering : bool
        Whether to use clustering to guide hierarchy method.

    overcluster_resolution : float
        Leiden clustering resolution for overcluster method.

    overcluster_merge_similar : bool
        Whether to merge similar clusters.

    overcluster_merge_threshold : float
        Correlation threshold for merging clusters.

    confidence_temperature : float
        Temperature for softmax in entropy-based confidence calculation.
        Lower values make confidence more decisive.

    consensus_method : str
        Method for combining predictions: 'majority', 'weighted', 'unanimous'.

    consensus_min_agreement : float
        Minimum agreement fraction for consensus.

    refined_mode : bool
        Enable refined annotation strategy.

    celltypist_confidence_threshold : float
        CellTypist confidence below this triggers refinement.

    consensus_confidence_threshold : float
        Consensus confidence below this marks as "unknown".

    unknown_label : str
        Label for cells that cannot be confidently annotated.

    calibration_method : str
        Method for calibrating confidence scores.

    use_conformal : bool
        Enable conformal prediction for confidence estimation.

    conformal_alpha : float
        Miscoverage rate for conformal prediction.

    conformal_method : str
        Conformal prediction method: 'simple', 'aps', 'raps'.
    """

    # Methods to run
    methods: list[str] = field(
        default_factory=lambda: [
            AnnotationMethod.CELLTYPIST.value,
            AnnotationMethod.BIOMARKER.value,
        ]
    )

    # scType parameters
    sctype_min_score: float = Defaults.MIN_SCORE_THRESHOLD
    use_negative_markers: bool = False

    # Hierarchy method parameters
    hierarchy_use_clustering: bool = True

    # Overcluster method parameters
    overcluster_resolution: float = Defaults.OVERCLUSTER_RESOLUTION
    overcluster_merge_similar: bool = True
    overcluster_merge_threshold: float = Defaults.MERGE_THRESHOLD

    # Confidence temperature parameters
    confidence_temperature: float = Defaults.TEMPERATURE
    biomarker_temperature: float | None = None
    sctype_temperature: float | None = None
    hierarchy_temperature: float | None = None
    overcluster_temperature: float | None = None

    # Consensus parameters
    consensus_method: str = ConsensusMethod.WEIGHTED.value
    consensus_min_agreement: float = 0.5

    # Refined annotation parameters
    refined_mode: bool = True
    celltypist_confidence_threshold: float = Defaults.CELLTYPIST_THRESHOLD
    consensus_confidence_threshold: float = Defaults.CONSENSUS_CONFIDENCE_THRESHOLD
    unknown_label: str = Defaults.UNKNOWN_LABEL
    refinement_methods: list[str] = field(
        default_factory=lambda: [
            AnnotationMethod.BIOMARKER.value,
            AnnotationMethod.SCTYPE.value,
            AnnotationMethod.HIERARCHY.value,
            AnnotationMethod.OVERCLUSTER.value,
        ]
    )

    # Calibration parameters
    calibration_method: str = CalibrationMethod.ISOTONIC.value

    # Conformal prediction parameters
    use_conformal: bool = False
    conformal_alpha: float = 0.1
    conformal_method: str = "aps"

    def __post_init__(self):
        """Validate configuration."""
        # Validate methods
        valid_methods = set(AnnotationMethod.all_methods())
        for method in self.methods:
            if method not in valid_methods:
                raise ValueError(f"Unknown method '{method}'. Valid methods: {valid_methods}")

        # Validate consensus method
        valid_consensus = {m.value for m in ConsensusMethod}
        if self.consensus_method not in valid_consensus:
            raise ValueError(
                f"Unknown consensus method '{self.consensus_method}'. "
                f"Valid methods: {valid_consensus}"
            )

        # Validate thresholds
        if not 0 <= self.celltypist_confidence_threshold <= 1:
            raise ValueError(
                f"celltypist_confidence_threshold must be 0-1, "
                f"got {self.celltypist_confidence_threshold}"
            )
        if not 0 <= self.consensus_confidence_threshold <= 1:
            raise ValueError(
                f"consensus_confidence_threshold must be 0-1, "
                f"got {self.consensus_confidence_threshold}"
            )

        # Validate calibration method
        valid_calibration = {m.value for m in CalibrationMethod}
        if self.calibration_method not in valid_calibration:
            raise ValueError(
                f"Unknown calibration method '{self.calibration_method}'. "
                f"Valid methods: {valid_calibration}"
            )

        # Validate conformal parameters
        if not 0 < self.conformal_alpha < 1:
            raise ValueError(f"conformal_alpha must be in (0, 1), got {self.conformal_alpha}")

        valid_conformal = {"simple", "aps", "raps"}
        if self.conformal_method not in valid_conformal:
            raise ValueError(
                f"Unknown conformal method '{self.conformal_method}'. "
                f"Valid methods: {valid_conformal}"
            )

    @classmethod
    def all_methods(cls) -> AnnotationMethodConfig:
        """Create configuration with all annotation methods enabled."""
        return cls(methods=AnnotationMethod.all_methods())

    @classmethod
    def fast(cls) -> AnnotationMethodConfig:
        """Create configuration with fast methods only (no CellTypist)."""
        return cls(methods=AnnotationMethod.fast_methods())

    @classmethod
    def celltypist_only(cls) -> AnnotationMethodConfig:
        """Create configuration with CellTypist only."""
        return cls(methods=[AnnotationMethod.CELLTYPIST.value])

    @classmethod
    def refined(
        cls, celltypist_threshold: float = 0.9, consensus_threshold: float = 0.5
    ) -> AnnotationMethodConfig:
        """
        Create configuration for refined annotation strategy.

        Strategy:
        1. Run CellTypist as primary method
        2. For cells with confidence < celltypist_threshold, run refinement methods
        3. Compute weighted consensus from refinement methods
        4. If consensus confidence >= consensus_threshold, use consensus
        5. Otherwise, mark as "unknown"
        """
        return cls(
            methods=AnnotationMethod.all_methods(),
            refined_mode=True,
            celltypist_confidence_threshold=celltypist_threshold,
            consensus_confidence_threshold=consensus_threshold,
            consensus_method=ConsensusMethod.WEIGHTED.value,
        )

    def get_temperature(self, method: str) -> float:
        """
        Get the temperature for a specific method.

        Parameters
        ----------
        method : str
            Method name.

        Returns
        -------
        float
            Temperature value for the method.
        """
        method_temps = {
            AnnotationMethod.BIOMARKER.value: self.biomarker_temperature,
            AnnotationMethod.SCTYPE.value: self.sctype_temperature,
            AnnotationMethod.HIERARCHY.value: self.hierarchy_temperature,
            AnnotationMethod.OVERCLUSTER.value: self.overcluster_temperature,
        }
        temp = method_temps.get(method)
        return temp if temp is not None else self.confidence_temperature

    def summary(self) -> str:
        """Return a formatted summary of the configuration."""
        lines = [
            "AnnotationMethodConfig:",
            f"  Methods:              {', '.join(self.methods)}",
            f"  scType min score:     {self.sctype_min_score:.2f}",
            f"  Confidence temp:      {self.confidence_temperature:.2f}",
            f"  Consensus method:     {self.consensus_method}",
            f"  Min agreement:        {self.consensus_min_agreement:.2f}",
        ]

        if self.refined_mode:
            lines.extend(
                [
                    "",
                    "  Refined Annotation:",
                    f"    Enabled:              {self.refined_mode}",
                    f"    CellTypist threshold: {self.celltypist_confidence_threshold:.2f}",
                    f"    Consensus threshold:  {self.consensus_confidence_threshold:.2f}",
                    f"    Unknown label:        '{self.unknown_label}'",
                ]
            )

        return "\n".join(lines)


# =============================================================================
# MASTER WORKFLOW CONFIGURATION
# =============================================================================


@dataclass
class WorkflowConfig:
    """
    Master configuration combining all sub-configurations.

    This is the main configuration class to use in the workflow.

    Attributes
    ----------
    confidence : ConfidenceConfig
        Confidence threshold settings.
    paths : PathConfig
        File path settings.
    plots : PlotConfig
        Plotting settings.
    annotation : AnnotationMethodConfig
        Annotation method settings.
    core_ids : Optional[List[str]]
        Specific core IDs to process (None = all available).
    use_neighborhood_refinement : bool
        Whether to apply neighborhood-based refinement.
    verbose : bool
        Enable verbose logging.
    save_intermediate : bool
        Save intermediate results.

    Examples
    --------
    >>> # Default configuration
    >>> config = WorkflowConfig()

    >>> # Custom configuration
    >>> config = WorkflowConfig(
    ...     confidence=ConfidenceConfig.relaxed(),
    ...     annotation=AnnotationMethodConfig.all_methods(),
    ...     core_ids=["MB-GU-1168", "MB-GU-1196"]
    ... )
    """

    confidence: ConfidenceConfig = field(default_factory=ConfidenceConfig)
    paths: PathConfig = field(default_factory=PathConfig)
    plots: PlotConfig = field(default_factory=PlotConfig)
    annotation: AnnotationMethodConfig = field(default_factory=AnnotationMethodConfig)
    core_ids: list[str] | None = None
    use_neighborhood_refinement: bool = True
    verbose: bool = False
    save_intermediate: bool = False

    def summary(self) -> str:
        """Return a formatted summary of all configurations."""
        lines = [
            "=" * 60,
            "WORKFLOW CONFIGURATION",
            "=" * 60,
            "",
            self.confidence.summary(),
            "",
            self.annotation.summary(),
            "",
            "Paths:",
            f"  Base dir:     {self.paths.base_dir}",
            f"  Output dir:   {self.paths.output_dir}",
            "",
            "Processing:",
            f"  Core IDs:     {self.core_ids or 'All available'}",
            f"  Neighborhood refinement: {self.use_neighborhood_refinement}",
            f"  Verbose:      {self.verbose}",
            "",
            "=" * 60,
        ]
        return "\n".join(lines)

    def validate(self) -> list[str]:
        """
        Validate the complete configuration.

        Returns
        -------
        List[str]
            List of validation warnings/errors.
        """
        issues = []
        issues.extend(self.paths.validate_paths())
        return issues

    @classmethod
    def from_dict(cls, config_dict: dict) -> WorkflowConfig:
        """
        Create configuration from dictionary.

        Parameters
        ----------
        config_dict : Dict
            Configuration dictionary.

        Returns
        -------
        WorkflowConfig
            Configured instance.
        """
        confidence = ConfidenceConfig(**config_dict.get("confidence", {}))
        paths = PathConfig(**config_dict.get("paths", {}))
        plots = PlotConfig(**config_dict.get("plots", {}))
        annotation = AnnotationMethodConfig(**config_dict.get("annotation", {}))

        return cls(
            confidence=confidence,
            paths=paths,
            plots=plots,
            annotation=annotation,
            core_ids=config_dict.get("core_ids"),
            use_neighborhood_refinement=config_dict.get("use_neighborhood_refinement", True),
            verbose=config_dict.get("verbose", False),
            save_intermediate=config_dict.get("save_intermediate", False),
        )

    def to_dict(self) -> dict:
        """
        Convert configuration to dictionary.

        Returns
        -------
        Dict
            Configuration as dictionary.
        """
        from dataclasses import asdict

        return asdict(self)


# =============================================================================
# PRESET CONFIGURATIONS
# =============================================================================


def get_default_config() -> WorkflowConfig:
    """Get the default workflow configuration."""
    return WorkflowConfig()


def get_strict_config() -> WorkflowConfig:
    """Get a strict configuration with high confidence thresholds."""
    return WorkflowConfig(confidence=ConfidenceConfig.strict())


def get_relaxed_config() -> WorkflowConfig:
    """Get a relaxed configuration for exploratory analysis."""
    return WorkflowConfig(confidence=ConfidenceConfig.relaxed())


def get_fast_config() -> WorkflowConfig:
    """Get a fast configuration without CellTypist."""
    return WorkflowConfig(annotation=AnnotationMethodConfig.fast())


# =============================================================================
# EXAMPLE USAGE
# =============================================================================

if __name__ == "__main__":
    print("Default configuration:")
    print(get_default_config().summary())

    print("\n\nStrict configuration:")
    print(get_strict_config().summary())

    print("\n\nFast configuration:")
    print(get_fast_config().summary())
