"""
Constants and Enums for Cell Type Annotation Workflow
======================================================

Centralized definitions for:
- Column names used throughout the workflow
- Default parameter values
- Color palettes for visualization
- Cell type hierarchies and mappings

This module eliminates magic strings and numbers scattered throughout the codebase.
"""

from enum import Enum

# =============================================================================
# COLUMN NAME CONSTANTS
# =============================================================================


class ColumnNames:
    """Standardized column names used in AnnData.obs throughout the workflow."""

    # Primary cell type columns
    CELL_TYPE = "cell_type"
    CONSENSUS_CELL_TYPE = "consensus_cell_type"

    # CellTypist specific
    CELLTYPIST_PREDICTION = "predicted_labels"
    CELLTYPIST_MAJORITY = "majority_voting"

    # Confidence columns
    CONFIDENCE = "confidence"
    CONF_SCORE = "conf_score"
    CONSENSUS_CONFIDENCE = "consensus_confidence"

    # Hierarchical annotations
    CELL_TYPE_COARSE = "cell_type_coarse"
    CELL_TYPE_FINE = "cell_type_fine"

    # Clustering
    LEIDEN_CLUSTER = "leiden"

    # Normalization
    SIZE_FACTORS_DESEQ2 = "size_factors_deseq2"
    TMM_FACTORS = "tmm_factors"
    CELL_AREA = "cell_area"

    # Gene mapping
    GENE_SYMBOL = "gene_symbol"


class ObsmKeys:
    """Standardized keys for AnnData.obsm."""

    PCA = "X_pca"
    UMAP = "X_umap"
    SPATIAL = "spatial"


# =============================================================================
# DEFAULT VALUES
# =============================================================================


class Defaults:
    """Default parameter values used throughout the workflow."""

    # Confidence thresholds
    CELLTYPIST_THRESHOLD: float = 0.9
    BIOMARKER_THRESHOLD: float = 0.6
    NEIGHBORHOOD_CONSENSUS: float = 0.7
    CONSENSUS_CONFIDENCE_THRESHOLD: float = 0.5
    # General-purpose confidence threshold used by save_annotation_statistics
    # and any code that needs a single default threshold.
    CONFIDENCE_THRESHOLD: float = 0.5

    # Clustering parameters
    N_NEIGHBORS: int = 15
    N_PCS: int = 30
    LEIDEN_RESOLUTION: float = 1.0
    OVERCLUSTER_RESOLUTION: float = 2.5

    # Scoring parameters
    TEMPERATURE: float = 0.5
    MIN_SCORE_THRESHOLD: float = 0.0

    # Validation parameters
    MERGE_THRESHOLD: float = 0.8

    # Visualization
    FIGURE_DPI: int = 300
    FONT_SIZE: int = 10
    POINT_SIZE_MAX: int = 20
    POINT_SIZE_DIVISOR: int = 120000

    # Labels
    UNKNOWN_LABEL: str = "Unknown"


# =============================================================================
# COLOR PALETTES
# =============================================================================


class Colors:
    """Color constants for visualization."""

    # Fallback color for unknown cell types
    FALLBACK_GREY = "#bdbdbd"


# Base color palette for common cell types
CELL_TYPE_PALETTE: dict[str, str] = {
    # ── T cells (blues / purples) ─────────────────────────────────────────────
    "T_cell": "#5b5bd6",
    "T-cells": "#5b5bd6",
    "T cell": "#5b5bd6",
    "CD4_T_cell": "#4a90e2",
    "CD4+ T cell": "#4a90e2",
    "CD4-positive helper T cell": "#4a90e2",
    "helper T cell": "#4a90e2",
    "effector memory CD4-positive, alpha-beta T cell": "#7575e0",
    "T follicular helper cell": "#4a4abf",
    "CD4-positive, CD25-positive, CCR4-positive, alpha-beta regulatory T cell": "#8f8fea",
    "Treg": "#8f8fea",
    "Regulatory T cell": "#8f8fea",
    "CD8_T_cell": "#7b68ee",
    "CD8+ T cell": "#7b68ee",
    "cytotoxic T cell": "#7b68ee",
    "effector memory CD8-positive, alpha-beta T cell": "#1e88e5",
    "CD8-positive, alpha-beta regulatory T cell": "#3949ab",
    "exhausted T cell": "#90caf9",
    "naive T cell": "#a8a8f0",
    "cycling T cell": "#6a5acd",
    # ── NK cells (dark burnt orange) ──────────────────────────────────────────
    "NK_cell": "#a63603",
    "NK cell": "#a63603",
    "natural killer cell": "#a63603",
    "NKT_cell": "#a63603",
    "mature NK T cell": "#9370db",
    # ── B cells / plasma (purples / magentas) ─────────────────────────────────
    "B_cell": "#984ea3",
    "B cell": "#984ea3",
    "B-cells": "#984ea3",
    "memory B cell": "#984ea3",
    "naive B cell": "#ab82c5",
    "Memory_B_cell": "#8b6ba8",
    "Plasma_cell": "#ce93d8",
    "Plasma cell": "#ce93d8",
    "IgG plasma cell": "#ce93d8",
    "Plasmablasts": "#ce93d8",
    "plasmablast": "#c77ddb",
    # ── Macrophages (oranges / reds) ──────────────────────────────────────────
    "Macrophage": "#e6550d",
    "macrophage": "#e6550d",
    "Myeloid": "#e6550d",
    "M1_Macrophage": "#d62728",
    "M1 Macrophage": "#d62728",
    "M1 macrophage": "#d62728",
    "M2_Macrophage": "#ff7f0e",
    "M2 Macrophage": "#ff7f0e",
    "M2 macrophage": "#ff7f0e",
    "TAM": "#e6550d",
    "cycling macrophage": "#fd8d3c",
    # ── Monocytes / pan-myeloid ───────────────────────────────────────────────
    "Monocyte": "#ff7f0e",
    "monocyte": "#ff7f0e",
    "myeloid cell": "#e6550d",
    "Pan-Myeloid": "#e6550d",
    "MDSC": "#e6550d",
    # ── Dendritic cells ───────────────────────────────────────────────────────
    "Dendritic_cell": "#d62728",
    "Dendritic cell": "#d62728",
    "dendritic cell": "#d62728",
    "DC": "#d62728",
    "conventional dendritic cell": "#d62728",
    "myeloid dendritic cell": "#ff7f0e",
    "plasmacytoid dendritic cell": "#20b2aa",
    "cDC1": "#d62728",
    "cDC2": "#d62728",
    "pDC": "#20b2aa",
    # ── Mast cells (yellow) ───────────────────────────────────────────────────
    "Mast_cell": "#ffd92f",
    "Mast cell": "#ffd92f",
    "mast cell": "#ffd92f",
    # ── Endothelial (greens / teals) ──────────────────────────────────────────
    "Endothelial": "#66c2a5",
    "Endothelial cell": "#66c2a5",
    "endothelial cell": "#66c2a5",
    "Vascular_Endothelial": "#2ca02c",
    "capillary endothelial cell": "#2ca02c",
    "endothelial cell of artery": "#1b9e77",
    "endothelial cell of vascular tree": "#4daf4a",
    "vein endothelial cell": "#88d8b0",
    "Lymphatic_Endothelial": "#5aae9e",
    "endothelial cell of lymphatic vessel": "#5aae9e",
    "Tip_cell": "#66c2a5",
    "Stalk_cell": "#66c2a5",
    # ── Fibroblast / CAF / stromal (warm browns / golds) ─────────────────────
    "Stromal": "#d8b365",
    "Fibroblast": "#d8b365",
    "fibroblast": "#d8b365",
    "CAFs": "#d8b365",
    "fibroblast of breast": "#d8b365",
    "cycling stromal cell": "#e6c88a",
    "CAF": "#c49a6c",
    "Cancer-associated fibroblast": "#c49a6c",
    "Myofibroblast": "#c49a6c",
    "myofibroblast cell": "#c49a6c",
    # ── Pericyte / perivascular (steel blue) ──────────────────────────────────
    "Pericyte": "#67a9cf",
    "pericyte": "#67a9cf",
    "Perivascular-like": "#67a9cf",
    # ── Smooth muscle (dark brown) ────────────────────────────────────────────
    "Smooth_muscle": "#8c6d31",
    "vascular associated smooth muscle cell": "#8c6d31",
    # ── Adipocyte ─────────────────────────────────────────────────────────────
    "Adipocyte": "#f4a582",
    "adipocyte": "#f4a582",
    # ── Epithelial (greys) ────────────────────────────────────────────────────
    "Epithelial": "#636363",
    "Epithelial cell": "#636363",
    "mammary gland epithelial cell": "#636363",
    "luminal epithelial cell of mammary gland": "#7f7f7f",
    "basal-myoepithelial cell of mammary gland": "#4a4a4a",
    "Tumor_Epithelial": "#636363",
    "Tumor Epithelial": "#636363",
    "Cancer_Epithelial": "#636363",
    "Normal_Epithelial": "#7f7f7f",
    "Myoepithelial": "#4a4a4a",
    "Ductal": "#636363",
    "Lobular": "#636363",
    "Luminal_A": "#636363",
    "Luminal_B": "#636363",
    "HER2+": "#636363",
    "Triple_Negative": "#636363",
    "Basal": "#4a4a4a",
    # ── Malignant (medium grey) ───────────────────────────────────────────────
    "Malignant": "#999999",
    "malignant cell": "#999999",
    "Malignant cell": "#999999",
    # ── Other ─────────────────────────────────────────────────────────────────
    "Unknown": "#bdbdbd",
    "unknown": "#bdbdbd",
    "Unassigned": "#bdbdbd",
    "Megakaryocyte": "#fb9a99",
}


def get_color_palette(extended: bool = True) -> dict[str, str]:
    """
    Get the cell type color palette.

    Parameters
    ----------
    extended : bool
        If True, returns full palette. If False, returns base palette only.

    Returns
    -------
    Dict[str, str]
        Dictionary mapping cell type names to hex color codes.
    """
    return CELL_TYPE_PALETTE.copy()


def resolve_color(cell_type: str, palette: dict[str, str] = None) -> str:
    """
    Resolve color for a cell type, handling case mismatches.

    Parameters
    ----------
    cell_type : str
        Cell type name to look up.
    palette : Dict[str, str], optional
        Color palette to use. If None, uses default CELL_TYPE_PALETTE.

    Returns
    -------
    str
        Hex color code.
    """
    if palette is None:
        palette = CELL_TYPE_PALETTE

    # Try exact match
    if cell_type in palette:
        return palette[cell_type]

    # Try case-insensitive match
    lower_map = {k.lower(): v for k, v in palette.items()}
    if cell_type.lower() in lower_map:
        return lower_map[cell_type.lower()]

    # Try with underscore/space conversion
    alt_name = cell_type.replace("_", " ")
    if alt_name in palette:
        return palette[alt_name]
    alt_name = cell_type.replace(" ", "_")
    if alt_name in palette:
        return palette[alt_name]

    return Colors.FALLBACK_GREY


def resolve_palette_for_types(
    cell_types: list[str], palette: dict[str, str] = None
) -> dict[str, str]:
    """
    Build a color dict for a list of cell types.

    Parameters
    ----------
    cell_types : List[str]
        List of cell types to resolve colors for.
    palette : Dict[str, str], optional
        Color palette to use.

    Returns
    -------
    Dict[str, str]
        Resolved color mapping for each cell type.
    """
    return {ct: resolve_color(ct, palette) for ct in cell_types}


# =============================================================================
# CELL TYPE HIERARCHY
# =============================================================================

# Standardized cell type hierarchy mapping
# Format: {fine_type: (medium_type, coarse_type)}
CELL_TYPE_HIERARCHY: dict[str, tuple[str, str]] = {
    # Epithelial cells
    "Epithelial": ("Epithelial", "Epithelial"),  # unified label (Cancer + Normal merged)
    "Cancer_Epithelial": ("Epithelial", "Epithelial"),  # Wu-model alias → safety net
    "Normal_Epithelial": ("Epithelial", "Epithelial"),  # Wu-model alias → safety net
    "Tumor_Epithelial": ("Epithelial", "Epithelial"),
    "Luminal_A": ("Tumor_Epithelial", "Epithelial"),
    "Luminal_B": ("Tumor_Epithelial", "Epithelial"),
    "HER2+": ("Tumor_Epithelial", "Epithelial"),
    "Triple_Negative": ("Tumor_Epithelial", "Epithelial"),
    "Basal": ("Tumor_Epithelial", "Epithelial"),
    "Myoepithelial": ("Epithelial", "Epithelial"),
    "Ductal": ("Epithelial", "Epithelial"),
    "Lobular": ("Epithelial", "Epithelial"),
    "malignant cell": ("Epithelial", "Epithelial"),
    # Immune cells - T cells
    "T_cell": ("T_cell", "Immune"),
    "CD4_T_cell": ("T_cell", "Immune"),
    "CD8_T_cell": ("T_cell", "Immune"),
    "Treg": ("T_cell", "Immune"),
    "NK_cell": ("NK_cell", "Immune"),
    "NKT_cell": ("NK_cell", "Immune"),
    "Gamma_delta_T": ("T_cell", "Immune"),
    "naive T cell": ("T_cell", "Immune"),
    "exhausted T cell": ("T_cell", "Immune"),
    "CD4-positive helper T cell": ("T_cell", "Immune"),
    "effector memory CD8-positive, alpha-beta T cell": ("T_cell", "Immune"),
    "natural killer cell": ("NK_cell", "Immune"),
    # Immune cells - B cells
    "B_cell": ("B_cell", "Immune"),
    "Plasma_cell": ("B_cell", "Immune"),
    "Memory_B_cell": ("B_cell", "Immune"),
    "memory B cell": ("B_cell", "Immune"),
    "IgG plasma cell": ("B_cell", "Immune"),
    # Immune cells - Myeloid
    "Macrophage": ("Myeloid", "Immune"),
    "macrophage": ("Myeloid", "Immune"),
    "M1_Macrophage": ("Macrophage", "Immune"),
    "M2_Macrophage": ("Macrophage", "Immune"),
    "TAM": ("Macrophage", "Immune"),
    "Monocyte": ("Myeloid", "Immune"),
    "Dendritic_cell": ("Myeloid", "Immune"),
    "DC": ("Myeloid", "Immune"),
    "cDC1": ("Dendritic_cell", "Immune"),
    "cDC2": ("Dendritic_cell", "Immune"),
    "pDC": ("Dendritic_cell", "Immune"),
    "conventional dendritic cell": ("Myeloid", "Immune"),
    "plasmacytoid dendritic cell": ("Myeloid", "Immune"),
    "Mast_cell": ("Myeloid", "Immune"),
    "mast cell": ("Myeloid", "Immune"),
    "Neutrophil": ("Myeloid", "Immune"),
    "MDSC": ("Myeloid", "Immune"),
    "Myeloid": ("Myeloid", "Immune"),
    # Stromal cells
    "Stromal": ("Stromal", "Stromal"),
    "Fibroblast": ("Fibroblast", "Stromal"),
    "fibroblast": ("Fibroblast", "Stromal"),
    "CAF": ("Fibroblast", "Stromal"),
    "Myofibroblast": ("Fibroblast", "Stromal"),
    "myofibroblast cell": ("Fibroblast", "Stromal"),
    "Pericyte": ("Pericyte", "Stromal"),
    "pericyte": ("Pericyte", "Stromal"),
    "Smooth_muscle": ("Smooth_muscle", "Stromal"),
    "Adipocyte": ("Adipocyte", "Stromal"),
    # Endothelial cells
    "Endothelial": ("Endothelial", "Endothelial"),
    "endothelial cell": ("Endothelial", "Endothelial"),
    "Vascular_Endothelial": ("Endothelial", "Endothelial"),
    "Lymphatic_Endothelial": ("Endothelial", "Endothelial"),
    "Tip_cell": ("Endothelial", "Endothelial"),
    "Stalk_cell": ("Endothelial", "Endothelial"),
    "capillary endothelial cell": ("Endothelial", "Endothelial"),
    # Other
    "Unknown": ("Unknown", "Unknown"),
    "unknown": ("Unknown", "Unknown"),
    "Unassigned": ("Unknown", "Unknown"),
}


def get_hierarchy_mapping(cell_type: str) -> tuple[str, str]:
    """
    Get the medium and coarse level for a cell type.

    Parameters
    ----------
    cell_type : str
        Fine-grained cell type name.

    Returns
    -------
    Tuple[str, str]
        (medium_type, coarse_type). Returns (cell_type, cell_type) if not found.
    """
    if cell_type in CELL_TYPE_HIERARCHY:
        return CELL_TYPE_HIERARCHY[cell_type]

    # Try case-insensitive match
    for key, value in CELL_TYPE_HIERARCHY.items():
        if key.lower() == cell_type.lower():
            return value

    # Default: self-mapping
    return (cell_type, cell_type)


# =============================================================================
# MARKER GENE DEFINITIONS
# =============================================================================

# =============================================================================
# XENIUM TME MARKERS AND BREAST TME MARKERS
# =============================================================================

# XENIUM_TME_MARKERS — derived from biomarker_cell_type_matrix.csv
# 11 cell types, positive markers only. Use as a lightweight default.
XENIUM_TME_MARKERS = {
    "Memory_B_cell": [
        "AICDA",
        "BCL6",
        "CD19",
        "CD22",
        "CD27",
        "CD38",
        "CD40",
        "CD79A",
        "CD79B",
        "CXCR5",
        "IGHE",
        "JCHAIN",
        "MS4A1",
        "MZB1",
        "PAX5",
        "PRDM1",
        "SDC1",
        "XBP1",
    ],
    "cDC": ["ANPEP", "IL3RA", "ITGAX", "PTPRC", "SIGLEC3"],
    "Endothelial": [
        "ANGPT2",
        "CD34",
        "CDH5",
        "CLDN5",
        "DLL4",
        "ENG",
        "ERG",
        "FLI1",
        "ICAM1",
        "KDR",
        "MCAM",
        "NOS3",
        "NOTCH1",
        "PDPN",
        "PECAM1",
        "PLVAP",
        "TEK",
        "VCAM1",
        "VWF",
    ],
    "NK": [
        "B3GAT1",
        "CD96",
        "EOMES",
        "FCGR3A",
        "GZMA",
        "GZMB",
        "IFNG",
        "KIR2DL1",
        "KIR3DL1",
        "KLRC1",
        "KLRC2",
        "KLRD1",
        "KLRK1",
        "LAG3",
        "NCAM1",
        "NCR1",
        "NCR2",
        "NCR3",
        "PRF1",
        "TBX21",
        "TIGIT",
    ],
    "Pericyte": ["ABCC9", "CD248", "CSPG4", "KCNJ8", "MCAM", "NOTCH3", "PDGFB", "RGS5"],
    "pDC": ["CLEC4C", "IFNA1", "IFNB1", "IL3RA", "IRF7", "IRF8", "LILRA4", "MX1", "NRP1", "TCF4"],
    "T_cell": [
        "BCL2",
        "CCR4",
        "CCR6",
        "CCR7",
        "CD2",
        "CD28",
        "CD3D",
        "CD3E",
        "CD3G",
        "CD4",
        "CD5",
        "CD7",
        "CD8A",
        "CD8B",
        "CLEC2D",
        "CRTAM",
        "CTLA4",
        "CX3CR1",
        "CXCR3",
        "FOXP3",
        "HAVCR2",
        "IL17A",
        "IL2",
        "IL2RA",
        "KLRB1",
        "KLRG1",
        "LEF1",
        "PDCD1",
        "RORC",
        "SELL",
        "TCF7",
    ],
    "Fibroblast": [
        "ACTA2",
        "ADH1B",
        "ADIPOQ",
        "CD36",
        "CXCL12",
        "FABP4",
        "FAP",
        "FBLN1",
        "IL6",
        "LEP",
        "LPL",
        "MMP11",
        "NR2F1",
        "PDGFRA",
        "PDGFRB",
        "PLIN1",
        "PLIN4",
        "POSTN",
        "THY1",
        "TWIST1",
        "VIM",
    ],
    "Macrophage": [
        "ARG1",
        "CCL18",
        "CCL22",
        "CD14",
        "CD163",
        "CD68",
        "CD80",
        "CD86",
        "CSF1R",
        "CXCL10",
        "CXCL9",
        "IL10",
        "IL12A",
        "IL12B",
        "IL1B",
        "IRF4",
        "IRF5",
        "ITGAM",
        "MMP9",
        "MRC1",
        "MSR1",
        "NOS2",
        "PTPRC",
        "STAT1",
        "STAT6",
        "TGFB1",
        "TNF",
        "VEGFA",
    ],
    "Malignant": [
        "ACTA2",
        "ALDH1A1",
        "AR",
        "BRCA1",
        "CAV1",
        "CCND1",
        "CD14",
        "CD24",
        "CD44",
        "CDH1",
        "CNN1",
        "CTNND1",
        "EGFR",
        "EPCAM",
        "ERBB2",
        "ESR1",
        "FOXA1",
        "GATA3",
        "ITGB1",
        "KRT14",
        "KRT17",
        "KRT18",
        "KRT19",
        "KRT20",
        "KRT5",
        "KRT7",
        "KRT8",
        "MKI67",
        "MMP7",
        "MUC1",
        "MYH11",
        "PGR",
        "PTGS2",
        "SLFN11",
        "SLPI",
        "TAGLN",
        "TP53",
        "TP63",
    ],
    "Mast_cell": [
        "CMA1",
        "ENPP3",
        "FCER1A",
        "GATA1",
        "GATA2",
        "HDC",
        "ITGA2B",
        "ITGB3",
        "KIT",
        "MPL",
        "MRGPRX2",
        "SELP",
    ],
}


# BREAST_TME_MARKERS — curated canonical short-list (literature-derived).
# Useful as a lightweight cross-check or when panel coverage is low.
BREAST_TME_MARKERS = {
    "Luminal": ["ESR1", "GATA3", "FOXA1", "KRT8", "KRT18"],
    "Basal": ["KRT5", "KRT14", "KRT17", "TP63"],
    "HER2": ["ERBB2", "GRB7"],
    "CAF": ["FAP", "ACTA2", "PDGFRA", "COL1A1", "VIM"],
    "Endothelial": ["PECAM1", "VWF", "CDH5"],
    "Macrophage": ["CD68", "CD163", "CSF1R", "MRC1"],
    "T_cell": ["CD3D", "CD3E", "CD8A", "CD4"],
    "B_cell": ["CD19", "MS4A1", "CD79A"],
    "NK": ["NKG7", "GNLY", "KLRD1"],
    "Plasma": ["MZB1", "JCHAIN", "IGHG1"],
    "pDC": ["CLEC4C", "IL3RA", "LILRA4"],
}


# Default marker genes for common cell types
DEFAULT_MARKERS: dict[str, list[str]] = {
    # T cells
    "T_cell": ["CD3D", "CD3E", "CD3G", "CD2"],
    "CD4_T_cell": ["CD4", "IL7R", "CCR7"],
    "CD8_T_cell": ["CD8A", "CD8B", "GZMB", "PRF1"],
    "Treg": ["FOXP3", "IL2RA", "CTLA4"],
    "exhausted T cell": ["PDCD1", "LAG3", "HAVCR2", "TIGIT"],
    # NK cells
    "NK_cell": ["NCAM1", "NKG7", "GNLY", "KLRD1"],
    "natural killer cell": ["NCAM1", "NKG7", "GNLY", "KLRD1"],
    # B cells
    "B_cell": ["CD19", "CD79A", "MS4A1", "CD27"],
    "memory B cell": ["CD19", "CD79A", "MS4A1", "CD27"],
    "Plasma_cell": ["SDC1", "MZB1", "XBP1", "IGHG1"],
    # Myeloid
    "Macrophage": ["CD14", "CD68", "CD163", "CSF1R"],
    "macrophage": ["CD14", "CD68", "CD163", "CSF1R"],
    "Monocyte": ["CD14", "FCGR3A", "S100A8", "S100A9"],
    "Dendritic_cell": ["CD1C", "CLEC9A", "FCER1A", "CD83"],
    "conventional dendritic cell": ["CD1C", "CLEC9A", "FCER1A", "CD83"],
    "plasmacytoid dendritic cell": ["IL3RA", "CLEC4C", "TCF4", "IRF7"],
    "Mast_cell": ["KIT", "TPSAB1", "CPA3", "MS4A2"],
    "mast cell": ["KIT", "TPSAB1", "CPA3", "MS4A2"],
    # Stromal
    "Fibroblast": ["COL1A1", "COL1A2", "FAP", "PDGFRA", "DCN"],
    "fibroblast": ["COL1A1", "COL1A2", "FAP", "PDGFRA", "DCN"],
    "myofibroblast cell": ["ACTA2", "TAGLN", "MYL9", "CNN1"],
    "Pericyte": ["ACTA2", "RGS5", "PDGFRB", "CSPG4"],
    "pericyte": ["ACTA2", "RGS5", "PDGFRB", "CSPG4"],
    # Endothelial
    "Endothelial": ["PECAM1", "VWF", "CDH5", "ERG"],
    "endothelial cell": ["PECAM1", "VWF", "CDH5", "ERG"],
    # Epithelial/Malignant
    "malignant cell": ["EPCAM", "KRT8", "KRT18", "KRT19", "MUC1"],
    "Epithelial": ["EPCAM", "KRT8", "KRT18", "KRT19"],
}


def get_markers_for_type(cell_type: str) -> list[str]:
    """
    Get marker genes for a cell type.

    Parameters
    ----------
    cell_type : str
        Cell type name.

    Returns
    -------
    List[str]
        List of marker gene symbols.
    """
    if cell_type in DEFAULT_MARKERS:
        return DEFAULT_MARKERS[cell_type].copy()

    # Try case-insensitive match
    for key, markers in DEFAULT_MARKERS.items():
        if key.lower() == cell_type.lower():
            return markers.copy()

    return []


# =============================================================================
# ANNOTATION METHOD ENUM
# =============================================================================


class AnnotationMethod(Enum):
    """Available cell type annotation methods."""

    CELLTYPIST = "celltypist"
    BIOMARKER = "biomarker"
    SCTYPE = "sctype"
    HIERARCHY = "hierarchy"
    OVERCLUSTER = "overcluster"

    @classmethod
    def all_methods(cls) -> list[str]:
        """Return all method names as strings."""
        return [m.value for m in cls]

    @classmethod
    def fast_methods(cls) -> list[str]:
        """Return fast methods (no ML model loading)."""
        return [cls.BIOMARKER.value, cls.SCTYPE.value]


class ConsensusMethod(Enum):
    """Methods for combining predictions from multiple annotators."""

    MAJORITY = "majority"
    WEIGHTED = "weighted"
    UNANIMOUS = "unanimous"


class CalibrationMethod(Enum):
    """Methods for calibrating confidence scores."""

    NONE = "none"
    MINMAX = "minmax"
    PLATT = "platt"
    ISOTONIC = "isotonic"
    QUANTILE = "quantile"
