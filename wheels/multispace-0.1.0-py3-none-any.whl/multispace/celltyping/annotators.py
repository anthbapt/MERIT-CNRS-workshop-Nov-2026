"""
Cell Type Annotators
====================

Abstract base class and concrete implementations for cell type annotation methods.

This module provides a unified interface for different annotation approaches:
- BiomarkerAnnotator: Simple marker gene scoring
- ScTypeAnnotator: Specificity-weighted scoring (scType algorithm)
- HierarchyAnnotator: Hierarchical marker-based classification
- OverclusterAnnotator: Overclustering + marker annotation

Each annotator implements the same interface:
- annotate(adata, marker_dict) -> AnnData
- get_predictions() -> np.ndarray
- get_confidences() -> np.ndarray
- get_scores() -> pd.DataFrame

"""

from __future__ import annotations

import copy
import itertools
import logging
from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd
import scanpy as sc

# Local imports
from .constants import (
    AnnotationMethod,
    ColumnNames,
    Defaults,
)
from .core_utils import (
    _parse_marker_entry,
    compute_entropy_confidence,
    compute_marker_specificity,
    find_markers_in_data,
    get_expression_matrix,
    zscore_normalize,
)

# Configure module logger
logger = logging.getLogger(__name__)


# =============================================================================
# ANNOTATOR RESULT DATACLASS
# =============================================================================


@dataclass
class AnnotationResult:
    """
    Standardized result from a cell type annotator.

    Attributes
    ----------
    predictions : np.ndarray
        Cell type predictions for each cell.
    confidences : np.ndarray
        Confidence scores for each prediction (0-1).
    scores : pd.DataFrame
        Full score matrix (cells x cell_types).
    method : str
        Name of the annotation method.
    metadata : Dict[str, Any]
        Additional method-specific metadata.
    """

    predictions: np.ndarray
    confidences: np.ndarray
    scores: pd.DataFrame
    method: str
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def n_cells(self) -> int:
        """Number of cells annotated."""
        return len(self.predictions)

    @property
    def n_types(self) -> int:
        """Number of unique cell types predicted."""
        return len(np.unique(self.predictions))

    @property
    def cell_types(self) -> list[str]:
        """List of unique cell types."""
        return list(np.unique(self.predictions))

    def summary(self) -> str:
        """Return formatted summary."""
        lines = [
            f"AnnotationResult ({self.method})",
            f"  Cells: {self.n_cells}",
            f"  Cell types: {self.n_types}",
            f"  Confidence: mean={self.confidences.mean():.3f}, "
            f"median={np.median(self.confidences):.3f}",
        ]

        # Top cell types
        unique, counts = np.unique(self.predictions, return_counts=True)
        sorted_idx = np.argsort(-counts)[:5]
        lines.append("  Top types:")
        for idx in sorted_idx:
            pct = counts[idx] / self.n_cells * 100
            lines.append(f"    {unique[idx]}: {counts[idx]} ({pct:.1f}%)")

        return "\n".join(lines)


# =============================================================================
# ABSTRACT BASE CLASS
# =============================================================================


class CellTypeAnnotator(ABC):
    """
    Abstract base class for cell type annotation methods.

    All annotators must implement:
    - annotate(): Run annotation on AnnData
    - get_predictions(): Return cell type predictions
    - get_confidences(): Return confidence scores
    - get_scores(): Return full score matrix

    Parameters
    ----------
    temperature : float
        Temperature for entropy-based confidence calculation.
    min_score_threshold : float
        Minimum score for cell type assignment.
    unknown_label : str
        Label for cells that cannot be confidently assigned.
    """

    def __init__(
        self,
        temperature: float = Defaults.TEMPERATURE,
        min_score_threshold: float = Defaults.MIN_SCORE_THRESHOLD,
        unknown_label: str = Defaults.UNKNOWN_LABEL,
    ):
        self.temperature = temperature
        self.min_score_threshold = min_score_threshold
        self.unknown_label = unknown_label

        # Results (populated after annotate())
        self._predictions: np.ndarray | None = None
        self._confidences: np.ndarray | None = None
        self._scores: pd.DataFrame | None = None
        self._is_fitted: bool = False

    @property
    @abstractmethod
    def method_name(self) -> str:
        """Return the name of this annotation method."""
        pass

    @abstractmethod
    def _compute_scores(self, adata, marker_dict: dict[str, list[str]]) -> pd.DataFrame:
        """
        Compute scores for each cell type.

        Parameters
        ----------
        adata : AnnData
            Annotated data matrix.
        marker_dict : Dict[str, List[str]]
            Dictionary mapping cell types to marker genes.

        Returns
        -------
        pd.DataFrame
            Score matrix (cells x cell_types).
        """
        pass

    def annotate(
        self, adata, marker_dict: dict[str, list[str]], store_in_adata: bool = True
    ) -> AnnotationResult:
        """
        Run cell type annotation.

        Parameters
        ----------
        adata : AnnData
            Annotated data matrix (should be log-normalized).
        marker_dict : Dict[str, List[str]]
            Dictionary mapping cell types to marker genes.
        store_in_adata : bool
            Whether to store results in adata.obs.

        Returns
        -------
        AnnotationResult
            Annotation results.
        """
        logger.info(f"Running {self.method_name} annotation...")

        # Reset state so a failed previous call never leaves stale results
        # visible via get_predictions() / get_confidences() / get_scores().
        self._predictions = None
        self._confidences = None
        self._scores = None
        self._is_fitted = False

        # Compute scores
        self._scores = self._compute_scores(adata, marker_dict)

        if self._scores.empty:
            logger.warning(f"No scores computed for {self.method_name}")
            self._predictions = np.array([self.unknown_label] * adata.n_obs)
            self._confidences = np.zeros(adata.n_obs)
        else:
            # Get predictions (highest score)
            self._predictions = self._scores.idxmax(axis=1).values

            # Apply threshold
            max_scores = self._scores.max(axis=1).values
            below_threshold = max_scores < self.min_score_threshold
            self._predictions[below_threshold] = self.unknown_label

            # Compute confidence
            self._confidences = compute_entropy_confidence(
                self._scores.values, temperature=self.temperature
            )

        self._is_fitted = True

        # Store in adata if requested
        if store_in_adata:
            self._store_results(adata)

        # Log summary
        self._log_summary()

        return AnnotationResult(
            predictions=self._predictions.copy(),
            confidences=self._confidences.copy(),
            scores=self._scores.copy(),
            method=self.method_name,
            metadata=self._get_metadata(),
        )

    def _store_results(self, adata) -> None:
        """Store results in adata.obs."""
        prefix = self.method_name.lower()

        adata.obs[f"{prefix}_cell_type"] = self._predictions
        adata.obs[f"{prefix}_confidence"] = self._confidences

        # Store individual scores
        # "/" is not allowed in h5ad / zarr keys (e.g. "Hepatocyte/tumour"),
        # so it is replaced in the column name; the label itself is unchanged.
        for col in self._scores.columns:
            safe = str(col).replace("/", "_")
            adata.obs[f"{prefix}_{safe}_score"] = self._scores[col].values

    def _log_summary(self) -> None:
        """Log annotation summary."""
        unique, counts = np.unique(self._predictions, return_counts=True)
        n_cells = len(self._predictions)

        logger.info(f"\n{self.method_name} predictions:")
        sorted_idx = np.argsort(-counts)[:5]
        for idx in sorted_idx:
            pct = counts[idx] / n_cells * 100
            logger.info(f"  {unique[idx]:30s}: {counts[idx]:5d} ({pct:5.2f}%)")

        if len(unique) > 5:
            logger.info(f"  ... and {len(unique) - 5} more cell types")

        logger.info(
            f"\nConfidence: mean={self._confidences.mean():.3f}, "
            f"median={np.median(self._confidences):.3f}"
        )

    def _get_metadata(self) -> dict[str, Any]:
        """Return method-specific metadata."""
        return {
            "temperature": self.temperature,
            "min_score_threshold": self.min_score_threshold,
            "unknown_label": self.unknown_label,
        }

    def get_predictions(self) -> np.ndarray:
        """Return cell type predictions."""
        if not self._is_fitted:
            raise RuntimeError("Annotator not fitted. Call annotate() first.")
        return self._predictions.copy()

    def get_confidences(self) -> np.ndarray:
        """Return confidence scores."""
        if not self._is_fitted:
            raise RuntimeError("Annotator not fitted. Call annotate() first.")
        return self._confidences.copy()

    def get_scores(self) -> pd.DataFrame:
        """Return full score matrix."""
        if not self._is_fitted:
            raise RuntimeError("Annotator not fitted. Call annotate() first.")
        return self._scores.copy()


# =============================================================================
# BIOMARKER ANNOTATOR
# =============================================================================


class BiomarkerAnnotator(CellTypeAnnotator):
    """
    Simple marker gene scoring using scanpy's score_genes.

    For each cell type, computes a score based on the mean expression
    of its marker genes relative to a random background.

    Parameters
    ----------
    temperature : float
        Temperature for confidence calculation.
    min_score_threshold : float
        Minimum score for assignment.
    unknown_label : str
        Label for unassigned cells.
    use_raw : bool
        Whether to use raw counts for scoring.
    ctrl_size : int
        Number of control genes per expression bin used by
        ``sc.tl.score_genes``. The scanpy default (50) is calibrated for
        full transcriptomes (~20 000 genes). For targeted spatial panels
        (Xenium ~280–5 000 genes) a much smaller value avoids the control
        set dominating the signal. Recommended: 10–15 for Xenium panels.
        Default: 10.
    neg_weight : float
        Penalty multiplier applied to the negative-marker score before
        subtraction: ``net = pos_score − neg_weight × neg_score``.
        Use 0 to ignore negative markers entirely, 1.0 for full subtraction.
        Default: 0.25 (quarter-weight — prevents large negative gene lists
        from overwhelming the positive signal).

    Examples
    --------
    >>> annotator = BiomarkerAnnotator(temperature=0.5)
    >>> result = annotator.annotate(adata, marker_dict)
    >>> print(result.summary())
    >>>
    >>> # For Xenium / targeted panels:
    >>> annotator = BiomarkerAnnotator(ctrl_size=15)
    >>> result = annotator.annotate(adata, marker_dict)
    >>>
    >>> # Stronger negative-marker penalty:
    >>> annotator = BiomarkerAnnotator(neg_weight=0.5)
    >>> result = annotator.annotate(adata, marker_dict)
    """

    def __init__(
        self,
        temperature: float = Defaults.TEMPERATURE,
        min_score_threshold: float = Defaults.MIN_SCORE_THRESHOLD,
        unknown_label: str = Defaults.UNKNOWN_LABEL,
        use_raw: bool = False,
        ctrl_size: int = 10,
        neg_weight: float = 0.25,
        cluster_key: str | None = None,
    ):
        if ctrl_size < 1:
            raise ValueError(
                f"ctrl_size must be >= 1 (got {ctrl_size}). "
                "sc.tl.score_genes requires at least one control gene per bin."
            )
        if neg_weight < 0:
            raise ValueError(
                f"neg_weight must be >= 0 (got {neg_weight}). "
                "Use 0 to ignore negative markers, 1.0 for full subtraction."
            )
        super().__init__(temperature, min_score_threshold, unknown_label)
        self.use_raw = use_raw
        self.ctrl_size = ctrl_size
        self.neg_weight = neg_weight
        self.cluster_key = cluster_key
        self._markers_found: dict[str, list[str]] = {}
        self._markers_missing: dict[str, list[str]] = {}

    @property
    def method_name(self) -> str:
        return "biomarker"

    def _compute_scores(self, adata, marker_dict: dict) -> pd.DataFrame:
        """Compute biomarker scores using sc.tl.score_genes.

        Supports both positive-only (list) and signed (dict with 'positive' /
        'negative' keys) marker entries.  When negative markers are present the
        net score is: positive_score − negative_score, matching the signed
        scoring in batch_correction_workflow_1.py / cluster_annotation.py.
        """
        logger.info("=== Biomarker Scoring ===")

        self._markers_found = {}
        self._markers_missing = {}

        scores_dict = {}
        var_names = adata.var_names
        gene_symbol_col = adata.var.get(ColumnNames.GENE_SYMBOL)

        for cell_type, entry in marker_dict.items():
            pos_genes, neg_genes = _parse_marker_entry(entry)

            found_pos, missing_pos = find_markers_in_data(pos_genes, var_names, gene_symbol_col)
            found_neg, _ = find_markers_in_data(neg_genes, var_names, gene_symbol_col)

            self._markers_found[cell_type] = found_pos
            self._markers_missing[cell_type] = missing_pos

            if not found_pos:
                logger.warning(f"{cell_type}: No positive markers found in data")
                continue

            if len(found_pos) < 3:
                logger.warning(
                    f"{cell_type}: only {len(found_pos)} positive marker(s) found — "
                    "score_genes background will dominate; consider adding more markers."
                )

            score_col_pos = f"_temp_{cell_type}_pos_score"
            score_col_neg = f"_temp_{cell_type}_neg_score"
            try:
                sc.tl.score_genes(
                    adata,
                    gene_list=found_pos,
                    score_name=score_col_pos,
                    use_raw=self.use_raw,
                    ctrl_size=self.ctrl_size,
                )
                if found_neg:
                    sc.tl.score_genes(
                        adata,
                        gene_list=found_neg,
                        score_name=score_col_neg,
                        use_raw=self.use_raw,
                        ctrl_size=self.ctrl_size,
                    )
                    scores_dict[cell_type] = (
                        adata.obs[score_col_pos].values.copy()
                        - self.neg_weight * adata.obs[score_col_neg].values.copy()
                    )
                else:
                    scores_dict[cell_type] = adata.obs[score_col_pos].values.copy()
            finally:
                # Always clean up temp columns even if score_genes raises.
                for col in (score_col_pos, score_col_neg):
                    if col in adata.obs.columns:
                        del adata.obs[col]

            neg_str = f", {len(found_neg)} neg" if found_neg else ""
            logger.info(f"{cell_type:30s}: {len(found_pos):3d}/{len(pos_genes):3d} pos{neg_str}")

        if not scores_dict:
            return pd.DataFrame()

        scores_df = pd.DataFrame(scores_dict, index=adata.obs_names)

        # Cluster-level mode: replace each cell's score with its cluster's mean
        # score so that all cells in the same Leiden cluster receive the same
        # label.  This eliminates per-cell noise and produces spatially coherent
        # annotations matching the UMAP cluster structure.
        if self.cluster_key and self.cluster_key in adata.obs.columns:
            cluster_labels = adata.obs[self.cluster_key].astype(str)
            scores_df = scores_df.groupby(cluster_labels).transform("mean")
            logger.info(
                f"  cluster_key='{self.cluster_key}': scores averaged over "
                f"{cluster_labels.nunique()} clusters → broadcast to cells"
            )

        return scores_df

    def _get_metadata(self) -> dict[str, Any]:
        """Return metadata including marker coverage."""
        metadata = super()._get_metadata()
        metadata.update(
            {
                "use_raw": self.use_raw,
                "ctrl_size": self.ctrl_size,
                "neg_weight": self.neg_weight,
                "cluster_key": self.cluster_key,
                "markers_found": self._markers_found,
                "markers_missing": self._markers_missing,
            }
        )
        return metadata


# =============================================================================
# SCTYPE ANNOTATOR
# =============================================================================


class ScTypeAnnotator(CellTypeAnnotator):
    """
    scType specificity-weighted scoring.

    Markers that are unique to fewer cell types receive higher weights,
    making the scoring more specific.

    Scoring formula (per cell, per cell type)::

        score = sum(specificity_i * z_expr_i  for i in available_markers)
                / n_available_markers
              - neg_weight * (
                    sum(neg_specificity_j * z_expr_j  for j in neg_markers)
                    / n_neg_markers
                )

    ``specificity_i = 1 / (number of cell types that list marker i)``;
    the same formula applies to negative markers using their own
    cross-cell-type specificity.
    Dividing by ``n_available_markers`` (rather than normalising weights
    to sum=1) preserves absolute specificity magnitudes, so a cell type
    whose markers are all unique scores higher than one whose markers are
    widely shared, even if the raw expression levels are identical.

    Parameters
    ----------
    temperature : float
        Temperature for confidence calculation.
    min_score_threshold : float
        Minimum score for assignment.
    unknown_label : str
        Label for unassigned cells.
    negative_markers : Dict[str, List[str]], optional
        Negative markers that reduce scores.
    scale : bool
        Whether to z-score scale expression before scoring.
    neg_weight : float
        Penalty multiplier applied to the specificity-weighted mean
        expression of negative markers. Higher values make the penalty
        more aggressive. Default: 0.25 (quarter-weight — prevents large
        negative gene lists from overwhelming the positive signal).

    Examples
    --------
    >>> annotator = ScTypeAnnotator(temperature=0.5)
    >>> result = annotator.annotate(adata, marker_dict)
    >>>
    >>> # Stricter negative-marker penalty:
    >>> annotator = ScTypeAnnotator(neg_weight=1.0)
    >>> result = annotator.annotate(adata, marker_dict)
    """

    def __init__(
        self,
        temperature: float = Defaults.TEMPERATURE,
        min_score_threshold: float = Defaults.MIN_SCORE_THRESHOLD,
        unknown_label: str = Defaults.UNKNOWN_LABEL,
        negative_markers: dict[str, list[str]] | None = None,
        scale: bool = True,
        neg_weight: float = 0.25,
        cluster_key: str | None = None,
    ):
        if neg_weight < 0:
            raise ValueError(
                f"neg_weight must be >= 0 (got {neg_weight}). "
                "A negative value would convert the negative-marker penalty into a bonus."
            )
        super().__init__(temperature, min_score_threshold, unknown_label)
        # Shallow copy: marker lists are only iterated, never mutated, so a
        # one-level copy is sufficient to prevent the caller's dict from
        # affecting annotator state if it is mutated after construction.
        self.negative_markers = dict(negative_markers) if negative_markers else {}
        self.scale = scale
        self.neg_weight = neg_weight
        self.cluster_key = cluster_key
        self._specificity_weights: dict[str, float] = {}
        self._neg_specificity_weights: dict[str, float] = {}
        self._markers_found: dict[str, list[str]] = {}
        self._markers_missing: dict[str, list[str]] = {}
        self._neg_markers_found: dict[str, list[str]] = {}
        self._neg_markers_missing: dict[str, list[str]] = {}

    @property
    def method_name(self) -> str:
        return "sctype"

    def _compute_scores(self, adata, marker_dict: dict[str, list[str]]) -> pd.DataFrame:
        """Compute scType specificity-weighted scores.

        Memory-efficient: only the union of marker and negative-marker genes
        is materialised as a dense matrix.  For a targeted Xenium panel
        (≈ 280–5 000 genes, 100 k cells) this reduces peak memory by up to 20×
        compared with materialising the full panel.

        Z-scores use ``ddof=0`` (numpy / population std) to match the original
        scType implementation and the ``zscore_normalize`` utility in
        ``core_utils``.

        Negative markers are penalised with the same specificity-weighting
        scheme as positive markers, so markers that are negative for many cell
        types contribute less to the penalty than lineage-specific ones.
        """
        logger.info("=== scType Cell Typing ===")

        # Reset all mutable state up front so stale values are never visible
        # if an exception fires partway through (e.g. during matrix materialisation
        # or specificity computation).
        self._specificity_weights = {}
        self._neg_specificity_weights = {}
        self._markers_found = {}
        self._markers_missing = {}
        self._neg_markers_found = {}
        self._neg_markers_missing = {}

        # ------------------------------------------------------------------
        # 1.  Collect only the genes we actually need and subset adata.
        #
        #     Marker dict entries may be plain lists (positive-only) or signed
        #     dicts {"positive": [...], "negative": [...]}.  Negative genes
        #     from the signed format are merged with self.negative_markers so
        #     both sources of negative information are honoured.
        # ------------------------------------------------------------------

        # Parse every entry and collect positive + signed-negative genes.
        _parsed: dict[str, tuple[list, list]] = {
            ct: _parse_marker_entry(entry) for ct, entry in marker_dict.items()
        }
        # Effective positive marker lists (used for scoring)
        _pos_only: dict[str, list[str]] = {ct: pos for ct, (pos, _) in _parsed.items()}
        # Merge signed-negative genes with explicit self.negative_markers
        _effective_neg: dict[str, list[str]] = {}
        for ct in marker_dict:
            _, signed_neg = _parsed[ct]
            explicit_neg = self.negative_markers.get(ct, [])
            # Union of both sources, preserving order (signed first)
            seen: set = set()
            merged = []
            for g in signed_neg + explicit_neg:
                if g not in seen:
                    merged.append(g)
                    seen.add(g)
            if merged:
                _effective_neg[ct] = merged

        all_pos_genes: set[str] = set()
        for markers in _pos_only.values():
            all_pos_genes.update(markers)

        all_neg_genes: set[str] = set()
        for markers in _effective_neg.values():
            all_neg_genes.update(markers)

        needed_genes = all_pos_genes | all_neg_genes
        genes_in_data = [g for g in adata.var_names if g in needed_genes]

        if not genes_in_data:
            logger.warning("No marker genes found in adata.var_names — returning empty scores.")
            # Populate tracking so _get_metadata() reflects all-missing state
            # rather than empty dicts that give no per-cell-type information.
            for cell_type, (pos, _) in _parsed.items():
                self._markers_found[cell_type] = []
                self._markers_missing[cell_type] = list(pos)
            for cell_type, neg_markers in _effective_neg.items():
                self._neg_markers_found[cell_type] = []
                self._neg_markers_missing[cell_type] = list(neg_markers)
            return pd.DataFrame()

        adata_sub = adata[:, genes_in_data]

        # ------------------------------------------------------------------
        # 2.  Materialise dense sub-matrix; z-score with ddof=0 (numpy)
        # ------------------------------------------------------------------
        X = get_expression_matrix(adata_sub, use_raw=False, as_dense=True)

        if self.scale:
            X = zscore_normalize(X)  # numpy ddof=0, per-gene across cells

        expr_df = pd.DataFrame(X, index=adata.obs_names, columns=adata_sub.var_names)

        # ------------------------------------------------------------------
        # 3.  Specificity weights
        # ------------------------------------------------------------------
        # Positive markers: specificity = 1 / (# cell types listing that marker).
        # Use the parsed positive-only dict so specificity reflects the actual
        # positive gene lists, not signed dicts.
        self._specificity_weights = compute_marker_specificity(_pos_only)

        # Negative markers get their own cross-cell-type specificity so that
        # a marker used as a negative for many cell types penalises less.
        self._neg_specificity_weights = (
            compute_marker_specificity(_effective_neg) if _effective_neg else {}
        )

        # Warn about effective-negative keys that have no match in marker_dict
        # (can happen if self.negative_markers has a mismatched key name).
        orphan_neg_types = [ct for ct in _effective_neg if ct not in marker_dict]
        if orphan_neg_types:
            logger.warning(
                "negative_markers contains cell types not present in marker_dict — "
                f"their penalties will never be applied: {orphan_neg_types}"
            )

        # ------------------------------------------------------------------
        # 4.  Score each cell type
        # ------------------------------------------------------------------
        scores_dict: dict[str, np.ndarray] = {}

        for cell_type, markers in _pos_only.items():
            available = [m for m in markers if m in expr_df.columns]
            missing = [m for m in markers if m not in expr_df.columns]

            self._markers_found[cell_type] = available
            self._markers_missing[cell_type] = missing

            # Track effective negative marker availability unconditionally so
            # metadata is complete even for cell types with no positive markers.
            if cell_type in _effective_neg:
                all_neg = _effective_neg[cell_type]
                self._neg_markers_found[cell_type] = [m for m in all_neg if m in expr_df.columns]
                self._neg_markers_missing[cell_type] = [
                    m for m in all_neg if m not in expr_df.columns
                ]

            if not available:
                logger.warning(f"{cell_type}: No markers found in data")
                continue

            if len(available) < 3:
                logger.warning(
                    f"{cell_type}: only {len(available)} marker(s) found — "
                    "specificity score will be noisy."
                )

            # Absolute specificity weights — do NOT normalise to sum=1.
            weights = np.array([self._specificity_weights[m] for m in available])
            n_available = len(available)

            marker_expr = expr_df[available].values
            positive_score = np.dot(marker_expr, weights) / n_available

            # Specificity-weighted negative-marker penalty
            if cell_type in _effective_neg:
                neg_found = self._neg_markers_found[cell_type]
                neg_missing = self._neg_markers_missing[cell_type]
                if neg_missing:
                    logger.warning(
                        f"{cell_type}: {len(neg_missing)} negative marker(s) not in panel "
                        f"— {neg_missing}"
                    )
                if not neg_found:
                    logger.warning(f"{cell_type}: No negative markers found in data")
                else:
                    neg_weights = np.array([self._neg_specificity_weights[m] for m in neg_found])
                    n_neg = len(neg_found)
                    neg_expr = np.dot(expr_df[neg_found].values, neg_weights) / n_neg
                    positive_score = positive_score - self.neg_weight * neg_expr

            scores_dict[cell_type] = positive_score
            neg_str = (
                f", {len(self._neg_markers_found.get(cell_type, []))} neg"
                if cell_type in _effective_neg
                else ""
            )
            logger.info(f"{cell_type:30s}: {len(available):3d}/{len(markers):3d} pos{neg_str}")

        if not scores_dict:
            return pd.DataFrame()

        scores_df = pd.DataFrame(scores_dict, index=adata.obs_names)

        if self.cluster_key and self.cluster_key in adata.obs.columns:
            cluster_labels = adata.obs[self.cluster_key].astype(str)
            scores_df = scores_df.groupby(cluster_labels).transform("mean")
            logger.info(
                f"  cluster_key='{self.cluster_key}': scores averaged over "
                f"{cluster_labels.nunique()} clusters → broadcast to cells"
            )

        return scores_df

    def _get_metadata(self) -> dict[str, Any]:
        """Return metadata including specificity weights and marker coverage."""
        metadata = super()._get_metadata()
        metadata.update(
            {
                "scale": self.scale,
                "neg_weight": self.neg_weight,
                "cluster_key": self.cluster_key,
                "specificity_weights": self._specificity_weights,
                "negative_markers": dict(self.negative_markers),
                "neg_specificity_weights": self._neg_specificity_weights,
                "markers_found": self._markers_found,
                "markers_missing": self._markers_missing,
                "neg_markers_found": self._neg_markers_found,
                "neg_markers_missing": self._neg_markers_missing,
            }
        )
        return metadata


# =============================================================================
# HIERARCHY ANNOTATOR
# =============================================================================


class HierarchyAnnotator(CellTypeAnnotator):
    """
    Hierarchical marker-based classification.

    Classifies cells in a top-down manner:

    - **Level 1** — broad lineage split (e.g. Malignant vs Non-malignant).
      ``min_score_threshold`` is applied; cells below it are labelled Unknown.
    - **Level 2** — sub-lineage split for each Level 1 group (e.g. Immune vs
      Stromal within Non-malignant). All children of the same parent are scored
      simultaneously and the winner is assigned only to cells in that parent
      group. ``min_score_threshold`` is applied here as well.
    - **Level 3** — specific cell types from ``marker_dict``.  If
      ``level3_groups`` is provided the score matrix is masked so each cell
      only competes within its Level 2 group, enforcing the full hierarchy.

    Parameters
    ----------
    temperature : float
        Temperature for confidence calculation.
    min_score_threshold : float
        Minimum score for Level 1 and Level 2 assignment. Cells below this
        threshold receive ``unknown_label`` at that level instead of being
        forced into the best-scoring category.
    unknown_label : str
        Label for unassigned cells.
    hierarchy : Dict, optional
        Custom hierarchy definition. Uses ``DEFAULT_HIERARCHY`` if omitted.
    level3_groups : Dict[str, List[str]], optional
        Maps each Level 2 label to the list of ``marker_dict`` cell types that
        belong to it. When provided, Level 3 scoring is constrained so each
        cell is only assigned a cell type within its Level 2 group. Example::

            level3_groups = {
                "Malignant": ["Malignant"],
                "Immune":    ["CD8 T cell", "CD4 T cell", "B cell", "NK cell"],
                "Stromal":   ["Fibroblast", "Endothelial cell"],
            }

        If ``None`` (default), all cells are scored against all cell types
        (original behaviour, no hierarchy enforcement at Level 3).
    ctrl_size : int
        Number of control genes per expression bin for ``sc.tl.score_genes``.
        Use 10–15 for targeted spatial panels (Xenium). Default: 10.

    Examples
    --------
    >>> annotator = HierarchyAnnotator()
    >>> result = annotator.annotate(adata, marker_dict)
    >>>
    >>> # Full hierarchy enforcement + Xenium panel:
    >>> annotator = HierarchyAnnotator(
    ...     ctrl_size=15,
    ...     level3_groups={
    ...         "Malignant": ["Malignant"],
    ...         "Immune": ["CD8 T cell", "CD4 T cell", "B cell"],
    ...         "Stromal": ["Fibroblast", "Endothelial cell"],
    ...     },
    ... )
    >>> result = annotator.annotate(adata, marker_dict)
    """

    # Default hierarchy structure (breast-cancer-oriented defaults).
    # Override via the ``hierarchy`` constructor argument for other tissues.
    DEFAULT_HIERARCHY = {
        "Level1": {
            "Malignant": {
                "markers": ["EPCAM", "KRT8", "KRT18", "KRT19", "MUC1"],
            },
            "Non-malignant": {
                "markers": ["PTPRC", "VIM", "COL1A1", "PECAM1"],
            },
        },
        "Level2": {
            "Immune": {
                "parent": "Non-malignant",
                "markers": ["PTPRC", "CD3D", "CD19", "CD14", "CD68"],
            },
            "Stromal": {
                "parent": "Non-malignant",
                "markers": ["VIM", "COL1A1", "COL1A2", "PECAM1", "ACTA2"],
            },
        },
    }

    def __init__(
        self,
        temperature: float = Defaults.TEMPERATURE,
        min_score_threshold: float = Defaults.MIN_SCORE_THRESHOLD,
        unknown_label: str = Defaults.UNKNOWN_LABEL,
        hierarchy: dict | None = None,
        level3_groups: dict[str, list[str]] | None = None,
        ctrl_size: int = 10,
        cluster_key: str | None = None,
    ):
        if ctrl_size < 1:
            raise ValueError(
                f"ctrl_size must be >= 1 (got {ctrl_size}). "
                "sc.tl.score_genes requires at least one control gene per bin."
            )
        super().__init__(temperature, min_score_threshold, unknown_label)
        self.cluster_key = cluster_key
        self.hierarchy = (
            copy.deepcopy(hierarchy) if hierarchy else copy.deepcopy(self.DEFAULT_HIERARCHY)
        )
        self.level3_groups = (
            {k: list(v) for k, v in level3_groups.items()} if level3_groups else None
        )
        self.ctrl_size = ctrl_size

        # Level assignments (populated by _compute_scores)
        self._level1: np.ndarray | None = None
        self._level2: np.ndarray | None = None
        self._level3: np.ndarray | None = None
        # Level 3 marker coverage (marker_dict genes)
        self._markers_found: dict[str, list[str]] = {}
        self._markers_missing: dict[str, list[str]] = {}
        # Level 1 / Level 2 hierarchy marker coverage
        self._level1_markers_found: dict[str, list[str]] = {}
        self._level1_markers_missing: dict[str, list[str]] = {}
        self._level2_markers_found: dict[str, list[str]] = {}
        self._level2_markers_missing: dict[str, list[str]] = {}

    @property
    def method_name(self) -> str:
        return "hierarchy"

    def _score_markers_for_group(
        self, adata, markers: list[str], _counter: Iterator[int] | None = None
    ) -> np.ndarray:
        """Score all cells for a set of markers using sc.tl.score_genes.

        Parameters
        ----------
        markers :
            Marker gene names to score. Genes absent from ``adata.var_names``
            are silently skipped.
        _counter :
            An ``itertools.count()`` iterator shared across all calls within
            one ``_compute_scores`` invocation, used to generate unique temp
            column names. Pass ``None`` only in isolated unit tests.
        """
        available = [m for m in markers if m in adata.var_names]

        if not available:
            return np.zeros(adata.n_obs)

        idx = next(_counter) if _counter is not None else 0
        score_col = f"_tmp_hier_{idx}"
        try:
            sc.tl.score_genes(
                adata,
                available,
                score_name=score_col,
                use_raw=False,
                ctrl_size=self.ctrl_size,
            )
            scores = adata.obs[score_col].values.copy()
        finally:
            # Always remove the temp column so adata.obs stays clean even if
            # score_genes raises (e.g. all control genes filtered out).
            if score_col in adata.obs.columns:
                del adata.obs[score_col]

        return scores

    def _compute_scores(self, adata, marker_dict: dict[str, list[str]]) -> pd.DataFrame:
        """Compute hierarchical scores across three levels."""
        logger.info("=== Hierarchical Cell Type Annotation ===")

        n_cells = adata.n_obs
        var_names_set = set(adata.var_names)
        merged_hierarchy = self._merge_markers(marker_dict)

        # Shared counter for unique temp column names across all score_genes calls
        _counter = itertools.count()

        # Reset level assignments and all marker-coverage tracking dicts
        self._level1 = None
        self._level2 = None
        self._level3 = None
        self._markers_found = {}
        self._markers_missing = {}
        self._level1_markers_found = {}
        self._level1_markers_missing = {}
        self._level2_markers_found = {}
        self._level2_markers_missing = {}

        # ── Level 1: broad lineage split ──────────────────────────────────────
        logger.info("\n  Level 1: broad lineage split")
        level1_scores = {}
        level1_data = merged_hierarchy.get("Level1", {})

        for category, cat_data in level1_data.items():
            markers = cat_data.get("markers", [])
            l1_avail = [m for m in markers if m in var_names_set]
            l1_miss = [m for m in markers if m not in var_names_set]
            self._level1_markers_found[category] = l1_avail
            self._level1_markers_missing[category] = l1_miss
            if not markers:
                continue
            if not l1_avail:
                logger.warning(f"    {category}: No Level 1 markers found in data — skipping")
                continue
            scores = self._score_markers_for_group(adata, markers, _counter)
            level1_scores[category] = scores
            logger.info(f"    {category}: {len(l1_avail)}/{len(markers)} markers")

        # Assign Level 1 with Unknown fallback when score < min_score_threshold
        self._level1 = np.full(n_cells, self.unknown_label, dtype=object)
        if level1_scores:
            score_matrix = np.column_stack(list(level1_scores.values()))
            categories = list(level1_scores.keys())
            best_idx = np.argmax(score_matrix, axis=1)
            max_scores = score_matrix[np.arange(n_cells), best_idx]
            confident = max_scores >= self.min_score_threshold
            self._level1[confident] = np.array([categories[i] for i in best_idx])[confident]
            n_unknown_l1 = int((~confident).sum())
            if n_unknown_l1:
                logger.info(f"    {n_unknown_l1} cells below threshold → Unknown at Level 1")

        # ── Level 2: sub-lineage split within each Level 1 group ──────────────
        logger.info("\n  Level 2: sub-lineage split")
        level2_data = merged_hierarchy.get("Level2", {})
        self._level2 = self._level1.copy()

        # Group Level 2 categories by their declared parent (module-level import)
        level2_by_parent: dict = defaultdict(dict)
        for category, cat_data in level2_data.items():
            parent = cat_data.get("parent")
            if parent:
                level2_by_parent[parent][category] = cat_data
            else:
                # Still record marker coverage so metadata is complete.
                node_markers = cat_data.get("markers", [])
                self._level2_markers_found[category] = [
                    m for m in node_markers if m in var_names_set
                ]
                self._level2_markers_missing[category] = [
                    m for m in node_markers if m not in var_names_set
                ]
                logger.warning(
                    f"Level 2 node '{category}' has no 'parent' key — "
                    "it will be skipped during Level 2 scoring."
                )

        for parent, children in level2_by_parent.items():
            # Always track marker coverage — even when no cells reach this parent.
            for child_name, child_data in children.items():
                markers_c = child_data.get("markers", [])
                self._level2_markers_found[child_name] = [
                    m for m in markers_c if m in var_names_set
                ]
                self._level2_markers_missing[child_name] = [
                    m for m in markers_c if m not in var_names_set
                ]

            parent_mask = self._level1 == parent
            if not parent_mask.any():
                logger.info(f"    No cells assigned to '{parent}' — skipping Level 2 split")
                continue

            # Score all children simultaneously for cells under this parent
            child_scores: dict[str, np.ndarray] = {}
            for child_name, child_data in children.items():
                markers = child_data.get("markers", [])
                if not markers:
                    continue
                l2_avail = self._level2_markers_found[child_name]
                if not l2_avail:
                    logger.warning(
                        f"    {child_name} (parent={parent}): "
                        "No Level 2 markers found in data — skipping"
                    )
                    continue
                all_scores = self._score_markers_for_group(adata, markers, _counter)
                child_scores[child_name] = all_scores
                logger.info(
                    f"    {child_name} (parent={parent}): {len(l2_avail)}/{len(markers)} markers"
                )

            if not child_scores:
                continue

            score_matrix_l2 = np.column_stack(list(child_scores.values()))
            child_names = list(child_scores.keys())
            parent_indices = np.where(parent_mask)[0]
            parent_scores = score_matrix_l2[parent_mask]
            best_child_idx = np.argmax(parent_scores, axis=1)
            max_child_scores = parent_scores[np.arange(len(parent_indices)), best_child_idx]

            # Vectorized assignment: only update cells that meet the threshold.
            # Cells below it keep the parent label already written by _level1.
            confident_l2 = max_child_scores >= self.min_score_threshold
            if confident_l2.any():
                child_labels = np.array([child_names[i] for i in best_child_idx])
                self._level2[parent_indices[confident_l2]] = child_labels[confident_l2]

        # ── Level 3: specific cell types from marker_dict ─────────────────────
        # Signed format is supported: only positive markers are used for scoring.
        # (Negative markers are not applied at Level 3 — hierarchy scoring does
        # not currently have a specificity-weighted negative penalty pathway.)
        logger.info("\n  Level 3: specific cell types")
        final_scores: dict[str, np.ndarray] = {}

        for cell_type, entry in marker_dict.items():
            pos_genes, _ = _parse_marker_entry(entry)
            available = [m for m in pos_genes if m in var_names_set]
            missing = [m for m in pos_genes if m not in var_names_set]
            self._markers_found[cell_type] = available
            self._markers_missing[cell_type] = missing

            if not available:
                logger.warning(f"    {cell_type}: No markers found in data")
                continue

            if len(available) < 3:
                logger.warning(
                    f"    {cell_type}: only {len(available)} marker(s) found — "
                    "score_genes background will dominate."
                )

            # Pass the already-filtered list directly; _score_markers_for_group
            # will find all of them in var_names and skip its internal re-filter.
            final_scores[cell_type] = self._score_markers_for_group(adata, available, _counter)
            logger.info(f"    {cell_type}: {len(available)}/{len(pos_genes)} markers")

        if not final_scores:
            return pd.DataFrame()

        scores_df = pd.DataFrame(final_scores, index=adata.obs_names)

        # Apply Level 2 hierarchy mask if level3_groups mapping is provided.
        # Cells are only allowed to compete within their Level 2 group;
        # out-of-group scores are set to -inf before idxmax() in the base class.
        if self.level3_groups:
            scores_df = self._apply_hierarchy_mask(scores_df)

        # Cluster-level mode: replace each cell's score with its cluster's mean
        # so that all cells in the same Leiden cluster receive the same label.
        if self.cluster_key and self.cluster_key in adata.obs.columns:
            cluster_labels = adata.obs[self.cluster_key].astype(str)
            scores_df = scores_df.groupby(cluster_labels).transform("mean")
            logger.info(
                f"  cluster_key='{self.cluster_key}': hierarchy scores averaged over "
                f"{cluster_labels.nunique()} clusters → broadcast to cells"
            )

        # NOTE: _level3 is NOT set here. It is set in _store_results() using
        # self._predictions, which is the threshold-applied version from the
        # base class. This ensures hierarchy_level3 and hierarchy_cell_type
        # are always consistent.

        return scores_df

    def _apply_hierarchy_mask(self, scores_df: pd.DataFrame) -> pd.DataFrame:
        """Mask Level 3 scores to enforce the Level 2 hierarchy.

        Vectorized: groups cells by their Level 2 label and applies the
        column mask in bulk for all cells sharing the same label, avoiding
        an O(n_cells × n_types) Python loop.

        Cells whose Level 2 label has no entry in ``level3_groups`` are left
        unmasked (graceful fallback to unconstrained scoring).

        If a group's ``level3_groups`` entry contains types not present in
        ``scores_df`` (e.g. a typo), those types are silently ignored and a
        warning is emitted. Cells whose entire row becomes -inf (i.e. all
        allowed types are absent from ``marker_dict``) are reset to all-zero
        scores so the base class can apply ``min_score_threshold`` and label
        them Unknown rather than silently returning column 0.
        """
        cols = list(scores_df.columns)
        col_set = set(cols)
        scores_arr = scores_df.values.copy().astype(float)

        # Pre-build per-group boolean mask of columns to KEEP (True = keep)
        group_keep_mask: dict[str, np.ndarray] = {}
        for l2_label, allowed in self.level3_groups.items():
            allowed_in_df = [t for t in allowed if t in col_set]
            if len(allowed_in_df) < len(allowed):
                missing_types = [t for t in allowed if t not in col_set]
                logger.warning(
                    f"level3_groups['{l2_label}']: {missing_types} not found in "
                    "marker_dict — those types will be ignored in masking."
                )
            keep = np.array([col in allowed_in_df for col in cols], dtype=bool)
            group_keep_mask[l2_label] = keep

        # Apply masks in bulk per unique Level 2 label
        level2_arr = np.asarray(self._level2)
        for l2_label, keep in group_keep_mask.items():
            cell_mask = level2_arr == l2_label
            if not cell_mask.any():
                continue
            block = scores_arr[cell_mask]  # shape (n_in_group, n_types)
            block[:, ~keep] = -np.inf

            # Guard: if all columns masked (no valid types for this group),
            # reset to zero so min_score_threshold labels these cells Unknown
            all_masked = np.all(~np.isfinite(block), axis=1)
            if all_masked.any():
                logger.warning(
                    f"level3_groups['{l2_label}']: all allowed types absent from "
                    f"marker_dict for {all_masked.sum()} cells — resetting to zero "
                    "(they will receive Unknown via min_score_threshold)."
                )
                block[all_masked] = 0.0

            scores_arr[cell_mask] = block

        # Log cells whose Level 2 label has no entry in level3_groups — they
        # compete across all cell types (graceful fallback / unconstrained).
        known_labels = set(group_keep_mask.keys())
        unmasked = np.array([lbl not in known_labels for lbl in level2_arr])
        if unmasked.any():
            logger.info(
                f"    {int(unmasked.sum())} cells have a Level 2 label not in "
                "level3_groups (e.g. Unknown) — their Level 3 scoring is unconstrained."
            )

        return pd.DataFrame(scores_arr, index=scores_df.index, columns=scores_df.columns)

    def _merge_markers(self, marker_dict: dict[str, list[str]]) -> dict:
        """Merge user markers into hierarchy Level 1 / Level 2 nodes.

        Uses a deep copy of each node so that DEFAULT_HIERARCHY is never
        mutated, even if downstream code appends to a marker list in-place.
        """
        merged = {}
        for level_name, level_data in self.hierarchy.items():
            merged[level_name] = {}
            for category, cat_data in level_data.items():
                # Deep copy to prevent accidental mutation of DEFAULT_HIERARCHY
                merged[level_name][category] = copy.deepcopy(cat_data)

                # Enrich node markers with user-supplied markers for matching keys
                if category in marker_dict:
                    existing = merged[level_name][category].get("markers", [])
                    # Preserve order: existing first, then new user markers
                    user_extra = [m for m in marker_dict[category] if m not in existing]
                    merged[level_name][category]["markers"] = existing + user_extra

        return merged

    def _store_results(self, adata) -> None:
        """Store hierarchical level assignments alongside the base results.

        ``_level3`` is derived from ``_predictions`` (already threshold-applied
        by the base class) so ``hierarchy_level3`` and ``hierarchy_cell_type``
        are always consistent — both reflect the Unknown threshold.
        """
        # Capture Level 3 from the thresholded base-class predictions
        # before super() writes them to adata.obs.
        if self._predictions is not None:
            self._level3 = self._predictions.copy()

        super()._store_results(adata)

        if self._level1 is not None:
            adata.obs["hierarchy_level1"] = self._level1
        if self._level2 is not None:
            adata.obs["hierarchy_level2"] = self._level2
        if self._level3 is not None:
            adata.obs["hierarchy_level3"] = self._level3

    def _get_metadata(self) -> dict[str, Any]:
        """Return metadata including hierarchy structure and marker coverage."""
        metadata = super()._get_metadata()
        metadata.update(
            {
                "ctrl_size": self.ctrl_size,
                "level3_groups": self.level3_groups,
                "markers_found": self._markers_found,
                "markers_missing": self._markers_missing,
                "level1_markers_found": self._level1_markers_found,
                "level1_markers_missing": self._level1_markers_missing,
                "level2_markers_found": self._level2_markers_found,
                "level2_markers_missing": self._level2_markers_missing,
            }
        )
        return metadata


# =============================================================================
# OVERCLUSTER ANNOTATOR
# =============================================================================


class OverclusterAnnotator(CellTypeAnnotator):
    """
    Overclustering followed by marker-based cluster annotation.

    1. Clusters cells at high resolution (Leiden)
    2. Scores each cluster for marker expression
    3. Assigns cell types to clusters

    Parameters
    ----------
    temperature : float
        Temperature for confidence calculation.
    min_score_threshold : float
        Minimum score for assignment.
    unknown_label : str
        Label for unassigned cells.
    resolution : float
        Leiden clustering resolution.
    n_neighbors : int
        Number of neighbors for clustering.
    ctrl_size : int
        Number of control genes per expression bin for ``sc.tl.score_genes``.
        Use 10–15 for targeted spatial panels (Xenium). Default: 10.

    .. note::
        **Batch-corrected AnnData**: this annotator checks for ``"X_pca"``
        and ``"neighbors"`` by their default scanpy keys.  If your AnnData
        was produced by a batch-correction step that stores the corrected
        graph under a different key (e.g. ``"neighbours_corrected"``), run
        ``sc.pp.neighbors(adata, use_rep="X_pca_harmony")`` beforehand so
        the default ``"neighbors"`` key is present; otherwise the annotator
        will recompute neighbours from uncorrected PCA.

    Examples
    --------
    >>> annotator = OverclusterAnnotator(resolution=2.5)
    >>> result = annotator.annotate(adata, marker_dict)
    """

    def __init__(
        self,
        temperature: float = Defaults.TEMPERATURE,
        min_score_threshold: float = Defaults.MIN_SCORE_THRESHOLD,
        unknown_label: str = Defaults.UNKNOWN_LABEL,
        resolution: float = Defaults.OVERCLUSTER_RESOLUTION,
        n_neighbors: int = Defaults.N_NEIGHBORS,
        ctrl_size: int = 10,
    ):
        if ctrl_size < 1:
            raise ValueError(
                f"ctrl_size must be >= 1 (got {ctrl_size}). "
                "sc.tl.score_genes requires at least one control gene per bin."
            )
        super().__init__(temperature, min_score_threshold, unknown_label)
        self.resolution = resolution
        self.n_neighbors = n_neighbors
        self.ctrl_size = ctrl_size

        self._cluster_assignments: np.ndarray | None = None
        self._cluster_to_type: dict[str, str] = {}

    @property
    def method_name(self) -> str:
        return "overcluster"

    def _compute_scores(self, adata, marker_dict: dict[str, list[str]]) -> pd.DataFrame:
        """Compute scores via overclustering.

        All temporary columns (cluster key and per-cell-type score columns)
        are removed from ``adata.obs`` in ``finally`` blocks so the AnnData
        is never left in a dirty state if an exception is raised mid-loop.
        """
        logger.info("=== Overcluster Cell Type Annotation ===")

        # Ensure PCA and neighbors are computed.
        # NOTE: checks the default scanpy keys ("X_pca", "neighbors").
        # If batch-corrected representations live under different keys,
        # the caller must ensure these default keys are populated first.
        # Resolve which neighbor graph to use — prefer the batch-corrected one.
        # Batch correction stores the graph under "neighbours_corrected"
        # (British spelling); fall back to the scanpy default "neighbors".
        _neighbour_keys = ["neighbours_corrected", "neighbors"]
        _neighbours_key = next((k for k in _neighbour_keys if k in adata.uns), None)
        if _neighbours_key is None:
            # Neither key found — need a PCA + neighbor graph first.
            if "X_pca_harmony" in adata.obsm:
                logger.info("  Computing neighbors from X_pca_harmony...")
                sc.pp.neighbors(adata, n_neighbors=self.n_neighbors, use_rep="X_pca_harmony")
            elif "X_pca_corrected" in adata.obsm:
                logger.info("  Computing neighbors from X_pca_corrected...")
                sc.pp.neighbors(adata, n_neighbors=self.n_neighbors, use_rep="X_pca_corrected")
            else:
                if "X_pca" not in adata.obsm:
                    logger.info("  Computing PCA...")
                    sc.pp.pca(adata, n_comps=min(50, adata.n_obs - 1, adata.n_vars - 1))
                logger.info("  Computing neighbors from X_pca...")
                sc.pp.neighbors(adata, n_neighbors=self.n_neighbors)
            _neighbours_key = "neighbors"
        else:
            logger.info(f"  Using existing neighbor graph: '{_neighbours_key}'")

        # High-resolution clustering — wrap everything so cluster_key is
        # always cleaned up even if an exception fires inside the loop.
        cluster_key = "_overcluster_temp"
        try:
            logger.info(
                f"  Clustering at resolution {self.resolution} "
                f"(neighbors='{_neighbours_key}')..."
            )
            sc.tl.leiden(
                adata,
                resolution=self.resolution,
                key_added=cluster_key,
                neighbors_key=_neighbours_key,
            )

            self._cluster_assignments = adata.obs[cluster_key].values.copy()
            clusters = adata.obs[cluster_key].unique()
            logger.info(f"  Found {len(clusters)} clusters")

            # Score each cluster for each cell type
            cluster_scores: dict[str, pd.Series] = {}

            for cell_type, entry in marker_dict.items():
                pos_genes, _ = _parse_marker_entry(entry)  # positives only for clustering
                available = [m for m in pos_genes if m in adata.var_names]
                if not available:
                    continue

                # O5: pass ctrl_size so panel-size behaviour is consistent
                # with BiomarkerAnnotator and HierarchyAnnotator.
                score_col = f"_temp_{cell_type}"
                try:
                    sc.tl.score_genes(
                        adata,
                        available,
                        score_name=score_col,
                        use_raw=False,
                        ctrl_size=self.ctrl_size,
                    )
                    # Average score per cluster
                    cluster_means = adata.obs.groupby(cluster_key)[score_col].mean()
                    cluster_scores[cell_type] = cluster_means
                finally:
                    # O1: always remove temp score column even on exception
                    if score_col in adata.obs.columns:
                        del adata.obs[score_col]

            if not cluster_scores:
                return pd.DataFrame()

            # Create cluster score matrix
            cluster_score_df = pd.DataFrame(cluster_scores)

            # Assign cell type to each cluster
            self._cluster_to_type = cluster_score_df.idxmax(axis=1).to_dict()

            # O3: the original code computed this mapping but discarded the
            # result (dead list comprehension).  Store it properly.
            cell_type_per_cell = np.array(
                [
                    self._cluster_to_type.get(c, self.unknown_label)
                    for c in self._cluster_assignments
                ]
            )
            logger.info(
                f"  Assigned {len(self._cluster_to_type)} clusters → "
                f"{len(set(cell_type_per_cell))} cell types"
            )

            # Create cell-level score matrix by broadcasting cluster scores
            # back to individual cells.
            cell_scores: dict[str, np.ndarray] = {}
            for cell_type in cluster_scores:
                cell_scores[cell_type] = np.array(
                    [
                        cluster_score_df.loc[c, cell_type] if c in cluster_score_df.index else 0.0
                        for c in self._cluster_assignments
                    ]
                )

        finally:
            # O2: always remove the cluster column regardless of success/failure
            if cluster_key in adata.obs.columns:
                del adata.obs[cluster_key]

        return pd.DataFrame(cell_scores, index=adata.obs_names)

    def _get_metadata(self) -> dict[str, Any]:
        """Return metadata including cluster info."""
        metadata = super()._get_metadata()
        metadata.update(
            {
                "resolution": self.resolution,
                "ctrl_size": self.ctrl_size,
                "n_clusters": (
                    len(set(self._cluster_assignments))
                    if self._cluster_assignments is not None
                    else 0
                ),
                "cluster_to_type": self._cluster_to_type,
            }
        )
        return metadata


# =============================================================================
# ANNOTATOR FACTORY
# =============================================================================


def create_annotator(method: str | AnnotationMethod, **kwargs) -> CellTypeAnnotator:
    """
    Factory function to create annotators.

    Parameters
    ----------
    method : str or AnnotationMethod
        Annotation method name.
    **kwargs
        Additional arguments passed to annotator constructor.

    Returns
    -------
    CellTypeAnnotator
        Configured annotator instance.

    Examples
    --------
    >>> annotator = create_annotator("biomarker", temperature=0.5)
    >>> annotator = create_annotator(AnnotationMethod.SCTYPE)
    """
    if isinstance(method, AnnotationMethod):
        method = method.value

    annotators = {
        "biomarker": BiomarkerAnnotator,
        "sctype": ScTypeAnnotator,
        "hierarchy": HierarchyAnnotator,
        "overcluster": OverclusterAnnotator,
    }

    if method not in annotators:
        raise ValueError(f"Unknown method '{method}'. Available: {list(annotators.keys())}")

    return annotators[method](**kwargs)


# =============================================================================
# MULTI-METHOD ANNOTATION
# =============================================================================


class MultiMethodAnnotator:
    """
    Run multiple annotation methods and compute consensus.

    Parameters
    ----------
    methods : List[str]
        List of method names to run.
    method_weights : Dict[str, float], optional
        Per-method weights for the ``'weighted'`` consensus. Default: equal
        weights (1.0 for all methods).
    consensus_method : str
        How to combine predictions: ``'weighted'`` (confidence-weighted vote)
        or ``'majority'`` (equal vote per method, ignores confidence).
    calibrate : bool
        Whether to minmax-calibrate confidence scores before consensus.
    **kwargs
        Additional arguments passed to all individual annotators.

    Examples
    --------
    >>> multi = MultiMethodAnnotator(
    ...     methods=["biomarker", "sctype", "hierarchy"],
    ...     consensus_method="weighted"
    ... )
    >>> result = multi.annotate(adata, marker_dict)
    """

    _VALID_CONSENSUS_METHODS = ("weighted", "majority")

    def __init__(
        self,
        methods: list[str] = None,
        method_weights: dict[str, float] | None = None,
        consensus_method: str = "weighted",
        calibrate: bool = True,
        **kwargs,
    ):
        if consensus_method not in self._VALID_CONSENSUS_METHODS:
            raise ValueError(
                f"consensus_method must be one of {self._VALID_CONSENSUS_METHODS}, "
                f"got '{consensus_method}'."
            )
        self.methods = methods or ["biomarker", "sctype"]
        self.method_weights = method_weights or {}
        self.consensus_method = consensus_method
        self.calibrate = calibrate
        self.kwargs = kwargs  # These are passed to individual annotators

        self._annotators: dict[str, CellTypeAnnotator] = {}
        self._results: dict[str, AnnotationResult] = {}
        self._consensus_predictions: np.ndarray | None = None
        self._consensus_confidences: np.ndarray | None = None

    def annotate(
        self, adata, marker_dict: dict[str, list[str]], store_in_adata: bool = True
    ) -> dict[str, AnnotationResult]:
        """
        Run all annotation methods.

        Parameters
        ----------
        adata : AnnData
            Annotated data.
        marker_dict : Dict[str, List[str]]
            Marker dictionary.
        store_in_adata : bool
            Store results in adata.obs.

        Returns
        -------
        Dict[str, AnnotationResult]
            Results from each method.
        """
        logger.info(f"Running multi-method annotation: {self.methods}")

        # Run each method
        for method in self.methods:
            annotator = create_annotator(method, **self.kwargs)
            self._annotators[method] = annotator
            self._results[method] = annotator.annotate(
                adata, marker_dict, store_in_adata=store_in_adata
            )

        # Compute consensus
        self._compute_consensus(adata)

        # Store consensus
        if store_in_adata:
            adata.obs[ColumnNames.CONSENSUS_CELL_TYPE] = self._consensus_predictions
            adata.obs[ColumnNames.CONSENSUS_CONFIDENCE] = self._consensus_confidences

        return self._results

    def _compute_consensus(self, adata) -> None:
        """Compute consensus from all methods."""
        # Note: compute_majority_vote was removed from core_utils (it was a
        # near-duplicate of compute_weighted_consensus).  The 'majority' path
        # below reimplements it via compute_weighted_consensus with uniform
        # confidence weights (1.0 per cell), which is the correct equivalent.
        from .core_utils import (
            calibrate_confidences,
            compute_weighted_consensus,
        )

        # Gather predictions and confidences
        predictions = {m: r.predictions for m, r in self._results.items()}
        confidences = {m: r.confidences for m, r in self._results.items()}

        # Calibrate if requested.
        # 'isotonic' and 'platt' require ground-truth labels (fix A7 in
        # core_utils); calibrate_confidences is called without labels here so
        # we use 'minmax', which is always safe and still rescales each
        # method's confidence range to [0, 1] before combining.
        if self.calibrate:
            confidences = calibrate_confidences(confidences, method="minmax")

        # Get all cell types
        all_types = set()
        for preds in predictions.values():
            all_types.update(preds)
        cell_types = sorted(all_types)

        # Compute consensus
        if self.consensus_method == "weighted":
            # Apply method weights if provided
            method_weights = self.method_weights if self.method_weights else None
            self._consensus_predictions, self._consensus_confidences = compute_weighted_consensus(
                predictions, confidences, cell_types, method_weights=method_weights
            )
        elif self.consensus_method == "majority":
            # Pure majority vote: replace each method's confidence with 1.0 so
            # every cell casts an equal vote regardless of confidence magnitude.
            # compute_weighted_consensus with equal method weights then reduces
            # to a simple vote count, which is the correct majority-vote behaviour.
            uniform_confidences = {
                m: np.ones(len(preds), dtype=float) for m, preds in predictions.items()
            }
            self._consensus_predictions, self._consensus_confidences = compute_weighted_consensus(
                predictions, uniform_confidences, cell_types, method_weights=None
            )
        else:
            raise ValueError(f"Unknown consensus method: {self.consensus_method}")

    def get_consensus_predictions(self) -> np.ndarray:
        """Return consensus predictions."""
        if self._consensus_predictions is None:
            raise RuntimeError("No consensus computed yet. Call annotate() first.")
        return self._consensus_predictions.copy()

    def get_consensus_confidences(self) -> np.ndarray:
        """Return consensus confidences."""
        if self._consensus_confidences is None:
            raise RuntimeError("No consensus computed yet. Call annotate() first.")
        return self._consensus_confidences.copy()

    def get_method_result(self, method: str) -> AnnotationResult:
        """Return result for a specific method."""
        return self._results[method]
