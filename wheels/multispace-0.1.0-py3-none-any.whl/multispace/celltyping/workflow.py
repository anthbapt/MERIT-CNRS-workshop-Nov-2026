"""
Cell Type Annotation Workflow
=============================

This module provides the main workflow orchestration for cell type annotation,
combining multiple methods, consensus computation, and result generation.

Functions
---------
- run_annotation_workflow: Main workflow function
- run_multi_method_annotation: Run multiple annotation methods
- run_refinement_pipeline: Complete refinement pipeline
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import scanpy as sc

from .annotators import (
    MultiMethodAnnotator,
    create_annotator,
)
from .celltypist_integration import (
    combine_celltypist_with_consensus,
    get_celltypist_predictions,
)
from .consensus import (
    compute_refinement_consensus,
    create_marker_dict_with_validation,
    refine_with_neighborhood,
)
from .constants import (
    DEFAULT_MARKERS,
    ColumnNames,
    Defaults,
)
from .core_utils import _parse_marker_entry, filter_spatially_variable_markers
from .qc import (
    add_hierarchical_annotations,
    compute_annotation_qc_metrics,
    validate_annotations_with_markers,
)

logger = logging.getLogger(__name__)


__all__ = [
    "run_annotation_workflow",
    "run_multi_method_annotation",
    "run_refinement_pipeline",
]


def run_multi_method_annotation(
    adata: sc.AnnData,
    marker_dict: dict[str, list[str]],
    methods: list[str] = None,
    consensus_method: str = "weighted",
    store_in_adata: bool = True,
) -> tuple[sc.AnnData, dict[str, Any]]:
    """
    Run multiple annotation methods and compute consensus.

    Parameters
    ----------
    adata : AnnData
        Annotated data with gene expression.
    marker_dict : dict
        Dictionary mapping cell types to marker genes.
    methods : list, optional
        Methods to run. Default: ["biomarker", "sctype", "hierarchy"]
    consensus_method : str
        How to combine predictions: ``"weighted"`` or ``"majority"``.
    store_in_adata : bool
        Whether to store results in adata.obs.

    Returns
    -------
    adata : AnnData
        Data with annotations.
    results : dict
        Dictionary of AnnotationResult objects per method.

    Examples
    --------
    >>> adata, results = run_multi_method_annotation(adata, marker_dict)
    >>> print(adata.obs["consensus_cell_type"].value_counts())
    """
    if methods is None:
        methods = ["biomarker", "sctype", "hierarchy"]
    elif isinstance(methods, str):
        # Coerce a bare string so callers can write methods="biomarker" without
        # triggering iteration over individual characters.
        methods = [methods]

    logger.info(f"Running {len(methods)} annotation methods: {methods}")

    # Create multi-method annotator
    multi_annotator = MultiMethodAnnotator(methods=methods, consensus_method=consensus_method)

    # Run all methods
    results = multi_annotator.annotate(adata, marker_dict, store_in_adata=store_in_adata)

    # Log results
    for method, result in results.items():
        n_types = len(set(result.predictions))
        mean_conf = result.confidences.mean()
        logger.info(f"  {method}: {n_types} types, mean_conf={mean_conf:.3f}")

    return adata, results


def run_refinement_pipeline(
    adata: sc.AnnData,
    marker_dict: dict[str, list[str]],
    methods: list[str] = None,
    celltypist_threshold: float = 0.9,
    consensus_threshold: float = 0.5,
    biomarker_threshold: float = None,
    neighborhood_consensus: float = None,
    calibration_method: str = "minmax",
    use_neighborhood: bool = True,
    n_neighbors: int = 10,
    celltypist_key: str = "majority_voting",
    filter_spatial_markers: bool = False,
    min_morans_i: float = 0.025,
    threshold_mode: str = "zscore",
    n_std: float = 0.25,
    top_pct: float = 25.0,
    sctype_negative_markers: dict[str, list[str]] | None = None,
    sctype_neg_weight: float = 0.25,
    biomarker_neg_weight: float = 0.25,
    annotation_cluster_key: str | None = None,
    sctype_cell_types: list[str] | None = None,
    sctype_min_score_threshold: float | None = None,
) -> sc.AnnData:
    """
    Run complete refinement pipeline.

    This pipeline:
    1. (Optional) Filters markers to spatially variable genes only
    2. Extracts CellTypist predictions (if available)
    3. Runs refinement methods (biomarker, sctype, etc.)
    4. Computes consensus from refinement methods
    5. Combines CellTypist with consensus
    6. Optionally refines with neighborhood consensus

    Parameters
    ----------
    adata : AnnData
        Data with CellTypist predictions and gene expression.
    marker_dict : dict
        Dictionary mapping cell types to marker genes.
    methods : list, optional
        Refinement methods to run.
    celltypist_threshold : float
        Confidence threshold for CellTypist predictions.
    consensus_threshold : float
        Minimum confidence for consensus.  Cells whose consensus score falls
        below this value are labelled "Unknown".  Also used as the
        ``confidence_threshold`` for neighborhood refinement (i.e., cells
        below this value are candidates for reassignment).
    biomarker_threshold : float, optional
        Minimum score threshold applied to every annotator before storing
        predictions.  Cells whose best-score falls below this value are
        assigned the unknown label.  If ``None``, uses
        ``Defaults.BIOMARKER_THRESHOLD`` (0.6).
    neighborhood_consensus : float, optional
        Minimum fraction of neighbors that must agree on a cell type before
        the neighborhood reassignment is accepted.  If ``None``, uses
        ``Defaults.NEIGHBORHOOD_CONSENSUS`` (0.7).
    calibration_method : str
        Method to calibrate confidence scores before consensus.
        Forwarded to ``compute_refinement_consensus``.  Supported values:
        ``'minmax'`` (default), ``'quantile'``, ``'none'``.
        ``'isotonic'`` and ``'platt'`` require ground-truth labels and will
        fall back to ``'minmax'`` with a warning.
    use_neighborhood : bool
        Whether to apply neighborhood refinement.
    n_neighbors : int
        Number of neighbors for refinement.
    celltypist_key : str
        Column in adata.obs to use as CellTypist predictions.
        Use 'majority_voting' (default) for cluster-level consensus
        or 'predicted_labels' for per-cell granular predictions.
    filter_spatial_markers : bool
        If True, remove markers with low spatial autocorrelation (Moran's I)
        before running annotation. Genes expressed uniformly across the tissue
        add noise rather than signal. Requires ``adata.obsm['spatial']``.
        Default: False.
    min_morans_i : float
        Hard floor on the Moran's I cut-off used when
        ``filter_spatial_markers=True``.  Genes below this value are always
        removed regardless of ``threshold_mode``. Default: 0.025.
    threshold_mode : str
        Strategy for computing the effective Moran's I cut-off per core.
        ``"zscore"`` (default) sets the cut-off at ``mean + n_std × std``
        of the core's own Moran's I distribution, automatically adapting to
        tissue heterogeneity.  ``"percentile"`` keeps the top ``top_pct``%
        of genes.  ``"fixed"`` uses ``min_morans_i`` directly (original
        behaviour). Default: ``"zscore"``.
    n_std : float
        Standard deviations above the mean used with
        ``threshold_mode="zscore"``. Default: 0.25.
    top_pct : float
        Percentage of top-ranked genes retained with
        ``threshold_mode="percentile"``. Default: 25.0.
    sctype_negative_markers : dict, optional
        Negative (down-regulated) markers for the scType annotator.  Keys
        must match those in ``marker_dict``.  When provided, genes listed
        here will *penalise* the scType score for that cell type (cells
        that express them score lower).  The easiest way to populate this
        is from the ``< 0`` entries of your biomarker matrix via
        ``create_marker_dict_with_validation``.  Default: ``None``
        (no penalty applied).
    sctype_neg_weight : float
        Penalty multiplier for negative markers in the scType scorer.
        ``net = pos_score − sctype_neg_weight × neg_score``.
        Use 0 to ignore negatives, 1.0 for full subtraction.
        Default: 0.25.
    biomarker_neg_weight : float
        Penalty multiplier for negative markers in the Biomarker scorer.
        ``net = pos_score − biomarker_neg_weight × neg_score``.
        Use 0 to ignore negatives, 1.0 for full subtraction.
        Default: 0.25.
    annotation_cluster_key : str, optional
        Column in ``adata.obs`` containing Leiden cluster labels (e.g.
        ``"leiden_corrected"``). When provided, Biomarker, ScType, and
        Hierarchy annotators average their per-cell scores within each
        cluster and broadcast the cluster mean back to all member cells.
        This produces spatially coherent, cluster-consistent labels that
        match the UMAP structure. Default: ``None`` (per-cell scoring).

    Returns
    -------
    AnnData
        Data with refined annotations.

    Examples
    --------
    >>> adata = run_refinement_pipeline(adata, marker_dict)
    >>> print(adata.obs["cell_type"].value_counts())

    >>> # Adaptive spatial filtering (recommended for TMA multi-core workflows)
    >>> adata = run_refinement_pipeline(
    ...     adata, marker_dict,
    ...     filter_spatial_markers=True,
    ...     threshold_mode="zscore",
    ...     n_std=0.25,
    ...     min_morans_i=0.025,
    ... )

    >>> # Fixed threshold (original behaviour)
    >>> adata = run_refinement_pipeline(
    ...     adata, marker_dict,
    ...     filter_spatial_markers=True,
    ...     threshold_mode="fixed",
    ...     min_morans_i=0.1,
    ... )
    """
    if methods is None:
        methods = ["biomarker", "sctype", "hierarchy"]
    elif isinstance(methods, str):
        # Coerce a bare string so callers can write methods="biomarker" without
        # triggering iteration over individual characters.
        methods = [methods]
    if biomarker_threshold is None:
        biomarker_threshold = Defaults.BIOMARKER_THRESHOLD
    if neighborhood_consensus is None:
        neighborhood_consensus = Defaults.NEIGHBORHOOD_CONSENSUS

    # If the marker_dict uses the signed format (entries are dicts with
    # "positive"/"negative" keys) and no explicit sctype_negative_markers were
    # supplied, auto-extract the negative genes so ScTypeAnnotator benefits
    # from them automatically — matching the behaviour in
    # batch_correction_workflow_1.py and cluster_annotation.py.
    if sctype_negative_markers is None:
        auto_neg: dict[str, list[str]] = {}
        for ct, entry in marker_dict.items():
            _, neg_genes = _parse_marker_entry(entry)
            if neg_genes:
                auto_neg[ct] = neg_genes
        if auto_neg:
            sctype_negative_markers = auto_neg
            logger.info(
                f"  run_refinement_pipeline: auto-extracted negative markers for "
                f"{len(auto_neg)} cell type(s) from signed marker dict."
            )

    adata = adata.copy()
    logger.info("Starting refinement pipeline")

    # Step 0 (optional): Filter markers to spatially variable genes only
    if filter_spatial_markers:
        if "spatial" not in adata.obsm:
            logger.warning(
                "filter_spatial_markers=True but no spatial coordinates found in "
                "adata.obsm['spatial'] – skipping spatial marker filter."
            )
        else:
            logger.info(
                f"Step 0: Filtering spatially uniform markers "
                f"(mode={threshold_mode}, floor={min_morans_i}) …"
            )
            marker_dict, spatial_report = filter_spatially_variable_markers(
                adata,
                marker_dict,
                min_morans_i=min_morans_i,
                n_neighbors=6,
                verbose=True,
                threshold_mode=threshold_mode,
                n_std=n_std,
                top_pct=top_pct,
            )
            # Store the report for inspection
            adata.uns["spatial_marker_filter_report"] = spatial_report.to_dict(orient="list")

            # Identify any cell types that were dropped (had 0 spatially-variable markers)
            # by comparing the original marker_dict keys to what was returned.
            # (marker_dict was already overwritten above, so we compare to spatial_report.)
            retained_types = set(marker_dict.keys())
            logger.info(
                f"  Marker dict after spatial filter ({len(retained_types)} types retained): "
                + ", ".join(f"{ct}: {len(m)}" for ct, m in marker_dict.items())
            )
            if not marker_dict:
                logger.warning(
                    "  All cell types were excluded by the spatial marker filter — "
                    "marker-based annotation will be skipped. CellTypist predictions "
                    "will be used as the final labels. Lower min_morans_i or disable "
                    "filter_spatial_markers to enable marker-based refinement."
                )

    # Flag set to True when all markers were removed by the spatial filter so
    # that Steps 2–4 (marker annotation + consensus) are safely skipped.
    skip_marker_annotation = filter_spatial_markers and not marker_dict

    # Step 1: Check for CellTypist predictions
    has_celltypist = any(
        col in adata.obs.columns
        for col in ["predicted_labels", "majority_voting", "celltypist_cell_type"]
    )

    if has_celltypist:
        # Align the chosen key to predicted_labels so get_celltypist_predictions
        # always reads from a consistent column
        if celltypist_key in adata.obs.columns:
            adata.obs["predicted_labels"] = adata.obs[celltypist_key]
            logger.info(f"Step 1: Extracting CellTypist predictions from '{celltypist_key}'")
        else:
            logger.warning(
                f"Step 1: '{celltypist_key}' not found in adata.obs, "
                f"falling back to default CellTypist column"
            )
        ct_preds, ct_conf, needs_refinement = get_celltypist_predictions(
            adata, confidence_threshold=celltypist_threshold
        )
    else:
        logger.info("Step 1: No CellTypist predictions found, using all cells")
        _needs_refinement = np.ones(adata.n_obs, dtype=bool)
        ct_preds = np.array(["Unknown"] * adata.n_obs)
        ct_conf = np.zeros(adata.n_obs)

    if skip_marker_annotation:
        # All markers were removed by the spatial filter — skip Steps 2–4 and
        # fall back directly to CellTypist predictions (or all-Unknown if
        # CellTypist was not run).
        logger.warning(
            "Step 2–4: Skipped (no spatially-variable markers remain after filtering). "
            "Final labels taken from CellTypist predictions."
        )
        refined_preds = ct_preds
        refined_conf = ct_conf
        adata.obs["consensus_cell_type"] = ct_preds
        adata.obs["consensus_confidence"] = ct_conf
        adata.uns["method_agreement"] = {}
        adata.obs["refined_source"] = "celltypist_only_spatial_filter_excluded_all"
    else:
        # Step 2: Run refinement methods
        logger.info(f"Step 2: Running refinement methods: {methods}")
        predictions = {}
        confidences = {}

        for method_name in methods:
            try:
                annotator_kwargs: dict = {"min_score_threshold": biomarker_threshold}
                if method_name == "biomarker":
                    annotator_kwargs["neg_weight"] = biomarker_neg_weight
                    if annotation_cluster_key:
                        annotator_kwargs["cluster_key"] = annotation_cluster_key
                if method_name == "sctype":
                    # ScType z-scores internally so its score scale differs from
                    # raw score_genes output.  Override threshold if provided.
                    if sctype_min_score_threshold is not None:
                        annotator_kwargs["min_score_threshold"] = sctype_min_score_threshold
                    if annotation_cluster_key:
                        annotator_kwargs["cluster_key"] = annotation_cluster_key
                    if sctype_negative_markers:
                        annotator_kwargs["negative_markers"] = sctype_negative_markers
                        annotator_kwargs["neg_weight"] = sctype_neg_weight
                if method_name == "hierarchy" and annotation_cluster_key:
                    annotator_kwargs["cluster_key"] = annotation_cluster_key
                annotator = create_annotator(method_name, **annotator_kwargs)
                # Apply per-method marker dict overrides
                _method_marker_dict = marker_dict
                if method_name == "sctype" and sctype_cell_types is not None:
                    _method_marker_dict = {
                        ct: v for ct, v in marker_dict.items() if ct in sctype_cell_types
                    }
                    if not _method_marker_dict:
                        logger.warning(
                            "sctype_cell_types whitelist produced an empty marker dict "
                            "— falling back to full marker_dict."
                        )
                        _method_marker_dict = marker_dict
                    else:
                        logger.info(
                            f"  sctype: restricted to {len(_method_marker_dict)} / "
                            f"{len(marker_dict)} cell types via sctype_cell_types whitelist"
                        )
                result = annotator.annotate(adata, _method_marker_dict, store_in_adata=True)
                predictions[method_name] = result.predictions
                confidences[method_name] = result.confidences
                logger.info(f"  {method_name}: {len(set(result.predictions))} types")
            except Exception as e:
                logger.warning(f"  {method_name} failed: {e}")

        # Step 3: Compute consensus
        logger.info("Step 3: Computing consensus")
        consensus_preds, consensus_conf, agreement_df = compute_refinement_consensus(
            predictions,
            confidences,
            consensus_threshold=consensus_threshold,
            calibration_method=calibration_method,
        )

        adata.obs["consensus_cell_type"] = consensus_preds
        adata.obs["consensus_confidence"] = consensus_conf
        adata.uns["method_agreement"] = agreement_df

        # Step 4: Combine with CellTypist
        if has_celltypist:
            logger.info("Step 4: Combining CellTypist with consensus")
            refined_preds, refined_conf, source = combine_celltypist_with_consensus(
                ct_preds,
                ct_conf,
                celltypist_threshold,
                consensus_preds,
                consensus_conf,
                consensus_threshold=consensus_threshold,
            )
            adata.obs["refined_source"] = source
        else:
            refined_preds = consensus_preds
            refined_conf = consensus_conf
            adata.obs["refined_source"] = "consensus"

    # Store final results
    adata.obs[ColumnNames.CELL_TYPE] = refined_preds
    adata.obs[ColumnNames.CONFIDENCE] = refined_conf

    # Step 5: Neighborhood refinement (optional)
    if use_neighborhood and "X_umap" in adata.obsm:
        logger.info(
            f"Step 5: Applying neighborhood refinement "
            f"(confidence_threshold={consensus_threshold}, "
            f"neighborhood_consensus={neighborhood_consensus})"
        )
        adata = refine_with_neighborhood(
            adata,
            cell_type_key=ColumnNames.CELL_TYPE,
            confidence_key=ColumnNames.CONFIDENCE,
            n_neighbors=n_neighbors,
            confidence_threshold=consensus_threshold,
            neighborhood_consensus=neighborhood_consensus,
            inplace=False,
        )

    logger.info("Refinement pipeline complete")
    return adata


def run_annotation_workflow(
    adata: sc.AnnData,
    marker_dict: dict[str, list[str]] = None,
    biomarker_df: pd.DataFrame = None,
    methods: list[str] = None,
    normalize_data: bool = True,
    normalization_method: str = "library_size",
    compute_qc: bool = True,
    add_hierarchy: bool = True,
    output_dir: Path | None = None,
    verbose: bool = True,
) -> tuple[sc.AnnData, dict[str, Any]]:
    """
    Run complete cell type annotation workflow.

    This is the main entry point for annotation, handling:
    1. Data normalization (optional)
    2. Marker validation
    3. Multi-method annotation
    4. QC metrics computation
    5. Hierarchical annotation (optional)
    6. Result saving (optional)

    Parameters
    ----------
    adata : AnnData
        Input data with gene expression.
    marker_dict : dict, optional
        Dictionary mapping cell types to marker genes.
    biomarker_df : DataFrame, optional
        Biomarker matrix (genes x cell types). Used if marker_dict not provided.
    methods : list, optional
        Annotation methods to run.
    normalize_data : bool
        Whether to normalize data first.
    normalization_method : str
        Normalization method to use.
    compute_qc : bool
        Whether to compute QC metrics.
    add_hierarchy : bool
        Whether to add hierarchical annotations.
    output_dir : Path, optional
        Directory to save results.
    verbose : bool
        Whether to print progress.

    Returns
    -------
    adata : AnnData
        Annotated data.
    workflow_results : dict
        Dictionary containing:
        - 'annotation_results': Results from each method
        - 'qc_metrics': QC metrics (if computed)
        - 'validation_results': Marker validation results

    Notes
    -----
    This function runs marker-based multi-method annotation via
    ``run_multi_method_annotation``.  For CellTypist-based refinement
    (which uses a ``celltypist_key`` parameter), use
    ``run_refinement_pipeline`` instead.

    Examples
    --------
    >>> adata, results = run_annotation_workflow(
    ...     adata,
    ...     marker_dict=markers,
    ...     methods=["biomarker", "sctype"]
    ... )
    >>> print(results["qc_metrics"].summary())
    """
    start_time = time.time()
    workflow_results = {}

    if verbose:
        print("=" * 60)
        print("CELL TYPE ANNOTATION WORKFLOW")
        print("=" * 60)

    # Step 1: Prepare marker dictionary
    if marker_dict is None:
        if biomarker_df is not None:
            if verbose:
                print("\n[Step 1] Creating marker dictionary from biomarker matrix...")
            # W1: create_marker_dict_with_validation returns a 4-tuple;
            # the fourth element is the negative marker dict.
            marker_dict, complete_types, missing, neg_markers = create_marker_dict_with_validation(
                biomarker_df, adata
            )
            workflow_results["complete_cell_types"] = complete_types
            workflow_results["missing_markers"] = missing
            workflow_results["negative_marker_dict"] = neg_markers
        else:
            if verbose:
                print("\n[Step 1] Using default marker dictionary...")
            marker_dict = DEFAULT_MARKERS
    else:
        if verbose:
            print(f"\n[Step 1] Using provided marker dictionary ({len(marker_dict)} cell types)")

    # Step 2: Normalize (optional)
    if normalize_data:
        if verbose:
            print(f"\n[Step 2] Normalizing data ({normalization_method})...")
        from .normalization import normalize

        adata = normalize(adata, method=normalization_method, log_transform=True, inplace=False)
    else:
        adata = adata.copy()

    # Step 3: Run annotation
    if verbose:
        print("\n[Step 3] Running annotation methods...")

    adata, annotation_results = run_multi_method_annotation(
        adata, marker_dict, methods=methods, store_in_adata=True
    )
    workflow_results["annotation_results"] = annotation_results

    # Copy consensus to standard columns
    if "consensus_cell_type" in adata.obs.columns:
        adata.obs[ColumnNames.CELL_TYPE] = adata.obs["consensus_cell_type"]
        adata.obs[ColumnNames.CONFIDENCE] = adata.obs["consensus_confidence"]

    # Step 4: Compute QC metrics
    if compute_qc:
        if verbose:
            print("\n[Step 4] Computing QC metrics...")
        qc_metrics = compute_annotation_qc_metrics(adata)
        workflow_results["qc_metrics"] = qc_metrics

        if verbose:
            print(f"  {qc_metrics.summary()}")

        # Validate with markers
        validation_results = validate_annotations_with_markers(adata, marker_dict)
        workflow_results["validation_results"] = validation_results
        n_valid = sum(1 for r in validation_results if r.is_valid())

        if verbose:
            print(f"  Marker validation: {n_valid}/{len(validation_results)} pass")

    # Step 5: Add hierarchical annotations
    if add_hierarchy:
        if verbose:
            print("\n[Step 5] Adding hierarchical annotations...")
        adata = add_hierarchical_annotations(adata, inplace=False)

    # Step 6: Save results (optional)
    if output_dir is not None:
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        if verbose:
            print(f"\n[Step 6] Saving results to {output_dir}...")

        # Save annotated data
        adata.write_h5ad(output_dir / "annotated_data.h5ad")

        # Save cell type assignments
        cols_to_save = [ColumnNames.CELL_TYPE, ColumnNames.CONFIDENCE]
        if "refined_source" in adata.obs.columns:
            cols_to_save.append("refined_source")
        adata.obs[cols_to_save].to_csv(output_dir / "cell_types.csv")

    # Summary
    elapsed = time.time() - start_time

    if verbose:
        print("\n" + "=" * 60)
        print("WORKFLOW COMPLETE")
        print("=" * 60)
        print(f"\n  Total time: {elapsed:.1f}s")
        print(f"  Cells annotated: {adata.n_obs}")
        print(f"  Cell types identified: {adata.obs[ColumnNames.CELL_TYPE].nunique()}")

        if ColumnNames.CONFIDENCE in adata.obs.columns:
            mean_conf = adata.obs[ColumnNames.CONFIDENCE].mean()
            print(f"  Mean confidence: {mean_conf:.3f}")

    return adata, workflow_results


def run_combined_annotation_workflow(
    adata: sc.AnnData,
    marker_dict: dict,
    celltypist_predictions: np.ndarray | None = None,
    celltypist_confidences: np.ndarray | None = None,
    cluster_predictions: np.ndarray | None = None,
    cluster_confidences: np.ndarray | None = None,
    mode: str = "confidence_priority",
    priority_order: list[str] | None = None,
    resolve_unknown: bool = True,
    consensus_threshold: float = 0.5,
    verbose: bool = True,
) -> tuple[sc.AnnData, Any]:
    """
    Run the full combined annotation workflow (Pillar 4).

    Accepts predictions from any combination of:
    - Cell-level marker annotators (run automatically if marker_dict provided)
    - Cluster-level annotation (provided externally as cluster_predictions)
    - CellTypist (provided externally as celltypist_predictions)

    Parameters
    ----------
    adata : AnnData
        Input data to annotate.
    marker_dict : dict
        Marker gene dictionary for marker-based annotation.
    celltypist_predictions : np.ndarray | None
        Pre-computed CellTypist predictions (one per cell).
    celltypist_confidences : np.ndarray | None
        Pre-computed CellTypist confidence scores.
    cluster_predictions : np.ndarray | None
        Pre-computed cluster-level predictions.
    cluster_confidences : np.ndarray | None
        Pre-computed cluster-level confidences.
    mode : str
        Combination mode ("confidence_priority" or "ranked_priority").
    priority_order : list[str] | None
        For ranked_priority mode, order to try methods.
    resolve_unknown : bool
        Whether to try resolving Unknown cells (default True).
    consensus_threshold : float
        Minimum confidence threshold (default 0.5).
    verbose : bool
        Whether to print progress (default True).

    Returns
    -------
    adata : AnnData
        Annotated data with 'cell_type' and 'cell_type_confidence' in .obs.
    ensemble_result
        EnsembleResult containing detailed ensemble information.

    Examples
    --------
    >>> adata, ensemble_result = run_combined_annotation_workflow(
    ...     adata,
    ...     marker_dict=markers,
    ...     celltypist_predictions=ct_preds,
    ...     celltypist_confidences=ct_confs,
    ... )
    >>> print(ensemble_result.summary())
    """
    from .ensemble import build_ensemble

    if verbose:
        print("=" * 60)
        print("COMBINED ANNOTATION WORKFLOW (Pillar 4)")
        print("=" * 60)

    # Assemble predictions and confidences from provided sources
    predictions_dict = {}
    confidences_dict = {}

    # 1. Marker-based annotation (run if marker_dict provided)
    if marker_dict is not None:
        if verbose:
            print("\n[Step 1] Running marker-based annotation...")
        from .annotators import BiomarkerAnnotator

        annotator = BiomarkerAnnotator()
        result = annotator.annotate(adata, marker_dict, store_in_adata=False)
        predictions_dict["marker"] = result.predictions
        confidences_dict["marker"] = result.confidences
        if verbose:
            print(f"  Marker annotation: {len(np.unique(result.predictions))} types")

    # 2. CellTypist predictions (if provided)
    if celltypist_predictions is not None:
        if celltypist_confidences is None:
            # Default confidence if not provided
            celltypist_confidences = np.full(len(celltypist_predictions), 0.5)
        predictions_dict["celltypist"] = celltypist_predictions
        confidences_dict["celltypist"] = celltypist_confidences
        if verbose:
            print(f"  CellTypist predictions: {len(np.unique(celltypist_predictions))} types")

    # 3. Cluster-level predictions (if provided)
    if cluster_predictions is not None:
        if cluster_confidences is None:
            cluster_confidences = np.full(len(cluster_predictions), 0.5)
        predictions_dict["cluster"] = cluster_predictions
        confidences_dict["cluster"] = cluster_confidences
        if verbose:
            print(f"  Cluster predictions: {len(np.unique(cluster_predictions))} types")

    if not predictions_dict:
        raise ValueError(
            "No predictions provided. Supply at least one of: "
            "marker_dict, celltypist_predictions, or cluster_predictions."
        )

    # Run ensemble
    if verbose:
        print(f"\n[Step 2] Building ensemble (mode={mode})...")
    ensemble_result = build_ensemble(
        predictions_dict,
        confidences_dict,
        mode=mode,
        priority_order=priority_order,
        resolve_unknown=resolve_unknown,
        consensus_threshold=consensus_threshold,
    )

    # Store results in adata
    adata.obs["cell_type"] = ensemble_result.predictions
    adata.obs["cell_type_confidence"] = ensemble_result.confidences
    adata.obs["cell_type_source"] = ensemble_result.source

    if verbose:
        print("\n" + "=" * 60)
        print("ENSEMBLE COMPLETE")
        print("=" * 60)
        print(f"\n{ensemble_result.summary()}")

    return adata, ensemble_result
