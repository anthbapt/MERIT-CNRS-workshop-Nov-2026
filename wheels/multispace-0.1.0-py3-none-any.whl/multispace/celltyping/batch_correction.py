"""
Batch Correction Module
=======================

Pillar 0 of the celltype package.

Merges per-core SpatialData objects into a single batch-corrected AnnData,
ready for downstream cell typing.  Supports Harmony (default) and scVI.

Key design point — spatial coordinates
---------------------------------------
During ``ad.concat`` each per-core AnnData's ``obsm['spatial']`` is carried
across so the merged object retains cell-level spatial coordinates.  Because
``ad.concat`` concatenates obsm arrays from all constituent objects, and
coordinates are in their original per-core reference frames, they must NOT
be used for cross-core spatial analyses.  They ARE valid for per-batch
operations such as computing Moran's I on a core-by-core subset of the
merged object (see ``filter_spatially_variable_markers`` in core_utils).

Functions
---------
- batch_correction              : merge + preprocess + Harmony/scVI
- attach_batch_corrected_clusters : propagate labels back to per-core tables
- calculate_shannon_entropy_cluster : diagnostic batch-mixing metric
"""

import logging
import os
from pathlib import Path

import anndata as ad
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns
from scipy.stats import entropy

from .constants import Defaults
from .io import _get_table

logger = logging.getLogger(__name__)

__all__ = [
    "batch_correction",
    "attach_batch_corrected_clusters",
    "calculate_shannon_entropy_cluster",
]


# =============================================================================
# Diagnostic
# =============================================================================


def calculate_shannon_entropy_cluster(
    merged_adata, cluster_key: str, sample_id: str = "metabric_ID"
):
    """
    Normalised Shannon entropy per cluster across samples.

    A value of 1 means the cluster is evenly distributed across all samples;
    lower values may reflect genuine biology rather than poor batch correction.

    Parameters
    ----------
    merged_adata : AnnData
    cluster_key  : str   obs column for cluster labels
    sample_id    : str   obs column for sample identity

    Returns
    -------
    list of float  normalised entropy values, one per cluster
    """
    results = []
    log_n_samples = np.log(merged_adata.obs[sample_id].nunique())
    for _, subdf in merged_adata.obs.groupby(cluster_key):
        counts = subdf[sample_id].value_counts()
        H = entropy(counts / counts.sum())
        results.append(H / log_n_samples if log_n_samples > 0 else np.nan)
    return results


# =============================================================================
# Batch correction
# =============================================================================


def batch_correction(
    spatial_data: dict,
    key: str,
    output_folder: str,
    method: str = "harmony",
    n_top_genes: int = 2000,
    theta: float = 2.0,
    lamb: float = 0.1,
    table_key: str = "table",
) -> ad.AnnData:
    """
    Merge per-core SpatialData objects and apply batch correction.

    Supports ``'harmony'`` (default) and ``'scvi'``.

    Returns a merged AnnData with:
    - ``layers``  : ``counts``, ``lognorm`` (+ ``X_scVI_corrected`` for scvi)
    - ``obsm``    : ``spatial`` (concatenated per-core coords, local frames),
                    ``X_umap_uncorrected``, ``X_umap_corrected``,
                    corrected latent rep (``X_pca_harmony`` or ``X_scVI``)
    - ``obs``     : ``leiden_uncorrected``, ``leiden_corrected``,
                    ``_cell_id_orig`` (pre-concat obs_names for realignment)
    - ``uns``     : ``batch_correction_method``, ``corrected_rep``,
                    ``corrected_expr_layer``

    Spatial coordinates note
    ------------------------
    Each core's ``obsm['spatial']`` is copied into the per-core AnnData before
    ``ad.concat`` so the merged object retains per-cell spatial coordinates.
    These are in each core's local coordinate frame and should only be used
    for per-batch (per-core) spatial analyses.  The ``filter_spatially_variable_markers``
    function in ``core_utils`` automatically subsets by batch when called on
    the merged object.

    Parameters
    ----------
    spatial_data  : dict  ``{core_id: SpatialData}``
    key           : str   obs column used as batch identifier (e.g. 'metabric_ID')
    output_folder : str   directory for diagnostic plots and entropy CSV
    method        : str   ``'harmony'`` or ``'scvi'``
    n_top_genes   : int   number of HVGs for PCA (default 2000)
    theta         : float Harmony diversity penalty (default 2.0)
    lamb          : float Harmony ridge-regression penalty (default 0.1)
    table_key     : str   AnnData table name inside each SpatialData object

    Returns
    -------
    merged_adata : AnnData
    """
    os.makedirs(output_folder, exist_ok=True)

    # ── Merge per-core AnnData objects ────────────────────────────────────────
    core_ids = list(spatial_data.keys())
    adatas = []
    for core_id, sdata in spatial_data.items():
        src = _get_table(sdata, table_key=table_key)
        a = ad.AnnData(X=src.X.copy(), obs=src.obs.copy(), var=src.var.copy())

        # Batch label
        if key not in a.obs.columns:
            a.obs[key] = core_id

        # Store original obs_names before concat mangles them.
        # Core IDs contain hyphens (e.g. "MB-GU-1001") so post-hoc string
        # splitting on the concatenated index is unreliable.
        a.obs["_cell_id_orig"] = a.obs_names.astype(str)

        # ── Transfer spatial coordinates ─────────────────────────────────────
        # This is the key addition: carry obsm['spatial'] into the merged
        # object so downstream spatial analyses (e.g. Moran's I) can be run
        # per-batch on merged_adata without needing to reload core_sdata.
        if "spatial" in src.obsm:
            a.obsm["spatial"] = np.array(src.obsm["spatial"])
        elif hasattr(sdata, "shapes"):
            # Attempt to derive centroids from cell boundaries as a fallback
            try:
                import geopandas as gpd  # noqa: F401  -- imported for its geometry/centroid accessor side effect, not used by name

                boundaries = next(iter(sdata.shapes.values()))
                centroids = boundaries.geometry.centroid
                a.obsm["spatial"] = np.column_stack([centroids.x.values, centroids.y.values])
                logger.info(f"  {core_id}: derived spatial coords from cell boundaries")
            except Exception:
                logger.debug(f"  {core_id}: no spatial coords available — skipping")

        adatas.append(a)

    print(f"Merging {len(adatas)} cores …")
    merged_adata = ad.concat(adatas, keys=core_ids, index_unique="-")
    print(f"  Merged shape: {merged_adata.shape[0]:,} cells × " f"{merged_adata.shape[1]:,} genes")

    has_spatial = "spatial" in merged_adata.obsm
    if has_spatial:
        print(f"  obsm['spatial'] transferred ✓  " f"(shape: {merged_adata.obsm['spatial'].shape})")
    else:
        print(
            "  WARNING: obsm['spatial'] not transferred — "
            "per-core Moran's I filtering will fall back to core_sdata."
        )

    # ── Preprocessing ─────────────────────────────────────────────────────────
    merged_adata.layers["counts"] = merged_adata.X.copy()
    # target_sum=1e4 puts counts on the scale CellTypist expects
    sc.pp.normalize_total(merged_adata, target_sum=1e4, inplace=True)
    sc.pp.log1p(merged_adata)
    merged_adata.layers["lognorm"] = merged_adata.X.copy()
    sc.pp.highly_variable_genes(merged_adata, n_top_genes=n_top_genes, batch_key=key)
    sc.pp.pca(merged_adata, n_comps=Defaults.N_PCS)

    # ── Uncorrected neighbours / UMAP / Leiden ────────────────────────────────
    print("Dimensional reduction without batch correction …")
    sc.pp.neighbors(
        merged_adata,
        n_neighbors=Defaults.N_NEIGHBORS,
        use_rep="X_pca",
        key_added="neighbours_uncorrected",
    )
    sc.tl.umap(merged_adata, neighbors_key="neighbours_uncorrected")
    merged_adata.obsm["X_umap_uncorrected"] = merged_adata.obsm["X_umap"].copy()
    sc.tl.leiden(
        merged_adata,
        key_added="leiden_uncorrected",
        neighbors_key="neighbours_uncorrected",
        resolution=Defaults.LEIDEN_RESOLUTION,
    )

    # ── Batch correction ──────────────────────────────────────────────────────
    print(f"Applying batch correction (method='{method}') …")
    merged_adata.obs[key] = merged_adata.obs[key].astype("category")

    if method == "harmony":
        sc.external.pp.harmony_integrate(
            merged_adata, key=key, max_iter_harmony=25, theta=theta, lamb=lamb
        )
        print("Dimensional reduction with Harmony correction …")
        sc.pp.neighbors(
            merged_adata,
            n_neighbors=Defaults.N_NEIGHBORS,
            use_rep="X_pca_harmony",
            key_added="neighbours_corrected",
        )
        sc.tl.umap(merged_adata, neighbors_key="neighbours_corrected")
        corrected_rep = "X_pca_harmony"
        corrected_expr_layer = "lognorm"

    elif method == "scvi":
        try:
            import scvi as _scvi
        except ImportError as e:
            raise ImportError(
                "scvi-tools is required for method='scvi'. " "Install with: pip install scvi-tools"
            ) from e

        _scvi.model.SCVI.setup_anndata(merged_adata, layer="counts", batch_key=key)
        arches_params = {
            "use_layer_norm": "both",
            "use_batch_norm": "none",
            "encode_covariates": True,
            "dropout_rate": 0.1,
            "n_layers": 2,
        }
        vae = _scvi.model.SCVI(
            merged_adata,
            n_hidden=96,
            n_latent=10,
            gene_likelihood="nb",
            dispersion="gene-batch",
            **arches_params,
        )
        vae.train(
            early_stopping=True,
            train_size=0.9,
            early_stopping_patience=30,
            max_epochs=200,
            batch_size=512,
            plan_kwargs={"lr": 5e-4, "weight_decay": 1e-5},
            accelerator="gpu",
        )
        merged_adata.obsm["X_scVI"] = vae.get_latent_representation()
        merged_adata.layers["X_scVI_corrected"] = vae.get_normalized_expression(
            library_size=1e4
        ).values
        print("Dimensional reduction with scVI correction …")
        sc.pp.neighbors(
            merged_adata,
            n_neighbors=Defaults.N_NEIGHBORS,
            use_rep="X_scVI",
            key_added="neighbours_corrected",
        )
        sc.tl.umap(merged_adata, neighbors_key="neighbours_corrected")
        corrected_rep = "X_scVI"
        corrected_expr_layer = "X_scVI_corrected"

    else:
        raise ValueError(f"method must be 'harmony' or 'scvi', got {method!r}")

    # ── Corrected Leiden ──────────────────────────────────────────────────────
    merged_adata.obsm["X_umap_corrected"] = merged_adata.obsm["X_umap"].copy()
    sc.tl.leiden(
        merged_adata,
        key_added="leiden_corrected",
        neighbors_key="neighbours_corrected",
        resolution=Defaults.LEIDEN_RESOLUTION,
    )

    # Store method info for downstream functions
    merged_adata.uns["batch_correction_method"] = method
    merged_adata.uns["corrected_rep"] = corrected_rep
    merged_adata.uns["corrected_expr_layer"] = corrected_expr_layer

    # ── Diagnostic plots ──────────────────────────────────────────────────────
    print("Saving diagnostic plots …")
    palette = sns.color_palette("husl", merged_adata.obs[key].nunique())

    fig, axs = plt.subplots(1, 2, figsize=(16, 8))
    sc.pl.embedding(
        merged_adata, basis="umap_uncorrected", color="leiden_uncorrected", ax=axs[0], show=False
    )
    sc.pl.embedding(
        merged_adata, basis="umap_uncorrected", color=key, ax=axs[1], show=False, palette=palette
    )
    plt.tight_layout()
    plt.savefig(Path(output_folder) / "umap_uncorrected.png", dpi=150)
    plt.close()

    fig, axs = plt.subplots(1, 2, figsize=(16, 8))
    sc.pl.embedding(
        merged_adata, basis="umap_corrected", color="leiden_corrected", ax=axs[0], show=False
    )
    sc.pl.embedding(
        merged_adata, basis="umap_corrected", color=key, ax=axs[1], show=False, palette=palette
    )
    plt.tight_layout()
    plt.savefig(Path(output_folder) / "umap_corrected.png", dpi=150)
    plt.close()

    results_uncorr = sorted(
        calculate_shannon_entropy_cluster(merged_adata, "leiden_uncorrected", sample_id=key),
        reverse=True,
    )
    results_corr = sorted(
        calculate_shannon_entropy_cluster(merged_adata, "leiden_corrected", sample_id=key),
        reverse=True,
    )
    entropy_df = pd.DataFrame(
        {
            "type": (["uncorrected"] * len(results_uncorr) + ["corrected"] * len(results_corr)),
            "ordered_cluster": (list(range(len(results_uncorr))) + list(range(len(results_corr)))),
            "normalised_shannon_entropy": results_uncorr + results_corr,
        }
    )
    sns.lmplot(
        data=entropy_df,
        x="ordered_cluster",
        y="normalised_shannon_entropy",
        hue="type",
        lowess=True,
        height=5,
        aspect=1.5,
        markers=["o", "s"],
    )
    plt.savefig(Path(output_folder) / "shannon_entropy.png", dpi=150)
    plt.close()

    entropy_df.to_csv(Path(output_folder) / "shannon_entropy.csv", index=False)
    print(f"  Diagnostic plots saved to {output_folder}/")

    return merged_adata


# =============================================================================
# Label propagation
# =============================================================================


def attach_batch_corrected_clusters(
    spatial_data: dict,
    merged_adata: ad.AnnData,
    output_folder: str,
    cluster_column: str = "leiden_corrected",
    table_key: str = "table",
):
    """
    Propagate corrected cluster labels and embeddings from merged_adata back
    to each individual per-core SpatialData table.

    Uses ``_cell_id_orig`` stored before ``ad.concat`` to align cells via
    vectorised ``get_indexer`` (O(n log n)).  Propagates:

    - ``obs``    : cluster_column
    - ``obsm``   : corrected_rep, X_umap_corrected, X_umap_uncorrected
    - ``layers`` : lognorm, X_scVI_corrected (scVI only)
    - ``X``      : set to corrected_expr_layer

    Parameters
    ----------
    spatial_data   : dict ``{core_id: SpatialData}``
    merged_adata   : AnnData  output of :func:`batch_correction`
    output_folder  : str      directory for per-core spatial scatter plots
    cluster_column : str      obs column to propagate (default 'leiden_corrected')
    table_key      : str      AnnData table name inside each SpatialData object
    """
    import scipy.sparse as sp

    try:
        import squidpy as sq

        _has_squidpy = True
    except ImportError:
        _has_squidpy = False

    os.makedirs(str(Path(output_folder) / "clusters_per_core"), exist_ok=True)
    corrected_rep = merged_adata.uns.get("corrected_rep", "X_pca_harmony")
    corrected_expr_layer = merged_adata.uns.get("corrected_expr_layer", "lognorm")

    for core_id, sdata in spatial_data.items():
        table = _get_table(sdata, table_key=table_key)

        mask = merged_adata.obs["_cell_id_orig"].str.startswith(str(core_id) + "-") | (
            merged_adata.obs.get("metabric_ID", pd.Series(dtype=str)).astype(str) == str(core_id)
        )
        # Prefer batch-key mask if available; fall back to prefix match
        batch_col = merged_adata.uns.get("batch_key")
        if batch_col and batch_col in merged_adata.obs.columns:
            mask = merged_adata.obs[batch_col].astype(str) == str(core_id)

        core_merged = merged_adata[mask]
        cluster_map = core_merged.obs.set_index("_cell_id_orig")[cluster_column]

        obs_copy = table.obs.copy()
        obs_copy[cluster_column] = obs_copy.index.map(cluster_map)
        table.obs = obs_copy

        merged_index = core_merged.obs.set_index("_cell_id_orig").index
        loc = merged_index.get_indexer(table.obs_names)

        n_unmatched = (loc < 0).sum()
        if n_unmatched > 0:
            print(
                f"  WARNING {core_id}: {n_unmatched} cells not found "
                f"in merged_adata — embeddings will be NaN for those cells"
            )

        valid_mask = loc >= 0  # Boolean mask of matched cells

        for obsm_key in (corrected_rep, "X_umap_corrected", "X_umap_uncorrected"):
            if obsm_key in core_merged.obsm:
                arr = core_merged.obsm[obsm_key]
                out = np.full((len(loc), arr.shape[1]), np.nan, dtype=arr.dtype)
                out[valid_mask] = arr[loc[valid_mask]]
                table.obsm[obsm_key] = out

        for layer_key in ("lognorm", "X_scVI_corrected"):
            if layer_key in core_merged.layers:
                src = core_merged.layers[layer_key]
                if sp.issparse(src):
                    src = src.toarray()
                out = np.full((len(loc), src.shape[1]), np.nan, dtype=src.dtype)
                out[valid_mask] = src[loc[valid_mask]]
                subset = sp.csr_matrix(out)
                table.layers[layer_key] = subset

        if corrected_expr_layer in table.layers:
            table.X = table.layers[corrected_expr_layer].copy()

        # Per-core spatial scatter
        fig, ax = plt.subplots(figsize=(6, 6))
        plotted = False
        if _has_squidpy:
            try:
                sq.pl.spatial_scatter(
                    table, library_id="spatial", shape=None, size=20, color=cluster_column, ax=ax
                )
                plotted = True
            except Exception:
                pass
        if not plotted:
            coords = table.obsm.get("spatial")
            if coords is not None:
                labels = table.obs[cluster_column].astype("category")
                for cat in labels.cat.categories:
                    idx = labels == cat
                    ax.scatter(coords[idx, 0], coords[idx, 1], s=4, label=cat)
                ax.legend(fontsize=5, ncol=2, loc="upper right")
        ax.set_facecolor("black")
        ax.set_title(str(core_id), fontsize=9)
        plt.savefig(
            Path(output_folder) / "clusters_per_core" / f"{core_id}_corrected_clusters.png",
            dpi=300,
            bbox_inches="tight",
        )
        plt.close()
        print(f"  {core_id}: labels propagated ✓")
