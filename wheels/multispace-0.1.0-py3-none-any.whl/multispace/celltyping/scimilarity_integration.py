"""
SCimilarity Integration
=======================

This module provides integration with SCimilarity for cell type annotation,
including model loading, embedding, prediction extraction, and combining with
other methods.

SCimilarity uses a metric-learning encoder (triplet loss) to embed cells into
a shared latent space, then annotates via kNN search against a labelled
reference index (~23M cells).  Confidence is derived from the minimum cosine
distance to the nearest reference neighbour (``min_dist``): lower distance →
higher confidence.

Architecture
------------
CellEmbedding          — loads encoder.ckpt + gene_order.tsv, runs inference
  └─ CellSearchKNN     — loads hnswlib kNN index
       └─ CellAnnotation — loads labelled_kNN.bin + reference_labels.tsv,
                           exposes get_predictions_knn() and annotate_dataset()

Key data requirements
---------------------
- ``adata.layers["counts"]``  raw integer counts (mandatory for lognorm_counts)
- ``adata.var.index``         HGNC gene symbols (not Ensembl IDs)
- Gene overlap ≥ 5 000 genes with the model's gene_order (enforced by align_dataset)

Obs columns written
-------------------
celltype_hint              : predicted cell type label
min_dist                   : cosine distance to nearest reference neighbour
                             (primary uncertainty metric; lower = more confident)
celltype_hint_stat         : vsAll score (fraction of k neighbours voting for winner)
celltype_hint_weighted_stat: distance-weighted vsAll score
celltype_hits              : JSON string of raw vote counts per class
celltype_hits_weighted     : JSON string of distance-weighted vote counts
X_scimilarity (obsm)       : 128-dim embedding

Functions
---------
- load_scimilarity_model        : Load a CellAnnotation model
- run_scimilarity               : Full annotation pipeline (align → lognorm → embed → kNN)
- get_scimilarity_predictions   : Extract predictions + confidence from annotated data
- combine_scimilarity_with_consensus : Merge with consensus refinement (same logic as CellTypist)
- diagnose_scimilarity          : Pre-flight gene overlap and obs column checks
- cell_typing_scimilarity       : High-level entry point with diagnostics and plots
"""

from __future__ import annotations

import logging
from typing import Any

import numpy as np
import scanpy as sc

from .core_utils import combine_primary_with_consensus, compute_feature_overlap

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Optional dependency guard
# ---------------------------------------------------------------------------
try:
    import scimilarity  # noqa: F401

    HAS_SCIMILARITY = True
except ImportError:
    HAS_SCIMILARITY = False


__all__ = [
    "HAS_SCIMILARITY",
    "load_scimilarity_model",
    "run_scimilarity",
    "get_scimilarity_predictions",
    "combine_scimilarity_with_consensus",
    "diagnose_scimilarity",
    "cell_typing_scimilarity",
]


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Cosine distance threshold below which a prediction is considered
# high-confidence.  Empirically, min_dist < 0.1 corresponds to very close
# reference matches; > 0.25 is typically unreliable.
_DEFAULT_DIST_THRESHOLD: float = 0.15

# Minimum vsAll score (fraction of k neighbours voting for the winner) to
# accept a prediction without refinement.
_DEFAULT_VSALL_THRESHOLD: float = 0.5


# ---------------------------------------------------------------------------
# 1. Model loading
# ---------------------------------------------------------------------------


def load_scimilarity_model(
    model_path: str,
    use_gpu: bool = False,
) -> Any:
    """
    Load a SCimilarity CellAnnotation model from a local directory.

    The directory must contain:
      - ``encoder.ckpt``                  (encoder weights)
      - ``gene_order.tsv``                (model gene vocabulary)
      - ``layer_sizes.json``              (network architecture)
      - ``label_ints.csv``                (int → cell-type label mapping)
      - ``annotation/labelled_kNN.bin``   (hnswlib reference index)
      - ``annotation/reference_labels.tsv`` (reference cell-type labels)

    Parameters
    ----------
    model_path : str
        Path to the SCimilarity model directory.
    use_gpu : bool, default False
        Run the encoder on GPU.

    Returns
    -------
    scimilarity.CellAnnotation
        Loaded annotation model.

    Raises
    ------
    ImportError
        If scimilarity is not installed.
    FileNotFoundError
        If the model directory or required files are missing.

    Examples
    --------
    >>> ca = load_scimilarity_model("/opt/data/scimilarity_model")
    >>> print(f"Model covers {len(ca.gene_order)} genes and "
    ...       f"{len(ca.classes)} cell types")
    """
    if not HAS_SCIMILARITY:
        raise ImportError(
            "scimilarity is required for this function. " "Install with: pip install scimilarity"
        )

    import os

    from scimilarity import CellAnnotation

    if not os.path.isdir(model_path):
        raise FileNotFoundError(f"SCimilarity model directory not found: {model_path}")

    logger.info(f"Loading SCimilarity model from {model_path}")
    ca = CellAnnotation(model_path=model_path, use_gpu=use_gpu)

    n_genes = len(ca.gene_order)
    n_types = len(ca.classes)
    logger.info(f"SCimilarity model loaded: {n_genes} genes, {n_types} cell types")

    return ca


# ---------------------------------------------------------------------------
# 2. Main annotation pipeline
# ---------------------------------------------------------------------------


def run_scimilarity(
    adata: sc.AnnData,
    model: Any = None,
    model_path: str | None = None,
    use_gpu: bool = False,
    k: int = 50,
    weighting: bool = True,
    target_celltypes: list[str] | None = None,
    layer: str = "counts",
    inplace: bool = False,
) -> sc.AnnData:
    """
    Run SCimilarity cell type annotation on an AnnData object.

    Pipeline
    --------
    1. Align gene space to model vocabulary via ``align_dataset``
       (zero-pads missing genes; raises if overlap < 5 000).
    2. Log-normalise counts (TP10k + log1p) via ``lognorm_counts``.
       Requires ``adata.layers["counts"]`` to contain raw integer counts.
    3. Embed cells with the metric-learning encoder → ``obsm["X_scimilarity"]``.
    4. kNN search against the labelled reference index.
    5. Optionally restrict predictions to ``target_celltypes`` via safelist.

    Parameters
    ----------
    adata : AnnData
        Input data.  Must have raw counts in ``layers["counts"]`` and
        HGNC gene symbols as ``var.index``.
    model : scimilarity.CellAnnotation, optional
        Pre-loaded model.  If None, ``model_path`` must be provided.
    model_path : str, optional
        Path to model directory (used when ``model`` is None).
    use_gpu : bool, default False
        Run encoder on GPU.
    k : int, default 50
        Number of nearest neighbours for kNN voting.
    weighting : bool, default True
        Use distance-weighted voting (recommended; reduces noise from
        distant neighbours).
    target_celltypes : list of str, optional
        Restrict predictions to this subset of cell types via safelist.
        Use ``ca.classes`` to see all available labels.
        Pass None to use the full reference (default).
    layer : str, default "counts"
        Layer containing raw integer counts.  ``lognorm_counts`` reads
        ``layers["counts"]`` specifically; this parameter renames the
        layer to "counts" temporarily if it differs.
    inplace : bool, default False
        Modify ``adata`` in place.

    Returns
    -------
    AnnData
        Annotated data with the following additions:

        ``obs`` columns:
          - ``celltype_hint``               predicted cell type
          - ``min_dist``                    cosine distance to nearest neighbour
          - ``celltype_hint_stat``          vsAll score (unweighted)
          - ``celltype_hint_weighted_stat`` vsAll score (distance-weighted)
          - ``celltype_hits``               JSON vote counts
          - ``celltype_hits_weighted``      JSON weighted vote counts

        ``obsm``:
          - ``X_scimilarity``               128-dim embedding

    Raises
    ------
    ImportError
        If scimilarity is not installed.
    ValueError
        If neither ``model`` nor ``model_path`` is provided.
    RuntimeError
        If gene overlap with the model is below 5 000.

    Examples
    --------
    >>> ca = load_scimilarity_model("/opt/data/scimilarity_model")
    >>> adata = run_scimilarity(adata, model=ca, weighting=True)
    >>> print(adata.obs["celltype_hint"].value_counts())
    """
    if not HAS_SCIMILARITY:
        raise ImportError(
            "scimilarity is required for this function. " "Install with: pip install scimilarity"
        )

    from scimilarity.utils import align_dataset, lognorm_counts

    if not inplace:
        adata = adata.copy()

    # -- Load model if needed -------------------------------------------------
    if model is None:
        if model_path is None:
            raise ValueError("Either model or model_path must be provided.")
        model = load_scimilarity_model(model_path, use_gpu=use_gpu)

    # -- Normalise layer name so lognorm_counts always finds "counts" ---------
    _layer_renamed = False
    if layer != "counts" and layer in adata.layers:
        adata.layers["counts"] = adata.layers[layer]
        _layer_renamed = True
        logger.info(f"Temporarily aliasing layer '{layer}' → 'counts'")

    # -- Apply safelist if requested ------------------------------------------
    if target_celltypes is not None:
        invalid = set(target_celltypes) - model.classes
        if invalid:
            logger.warning(
                f"The following target_celltypes are not in the model and will "
                f"be ignored: {sorted(invalid)}"
            )
        valid = [ct for ct in target_celltypes if ct in model.classes]
        if not valid:
            raise ValueError(
                "None of the requested target_celltypes are present in the model. "
                f"Available classes: {sorted(model.classes)}"
            )
        logger.info(f"Applying safelist: {len(valid)} cell types")
        model.safelist_celltypes(valid)
    else:
        # Ensure no stale safelist/blocklist from a previous call
        model.reset_knn()

    # -- Step 1: align gene space ---------------------------------------------
    logger.info(
        f"Aligning gene space: {adata.n_vars} panel genes → " f"{len(model.gene_order)} model genes"
    )
    aligned = align_dataset(adata, model.gene_order)
    gene_overlap = sum(adata.var.index.isin(model.gene_order))
    logger.info(f"Gene overlap: {gene_overlap} / {adata.n_vars} panel genes")

    # -- Step 2: log-normalise ------------------------------------------------
    logger.info("Log-normalising counts (TP10k + log1p)")
    aligned = lognorm_counts(aligned)

    # -- Step 3: embed --------------------------------------------------------
    logger.info("Computing SCimilarity embeddings")
    embeddings = model.get_embeddings(aligned.X)
    adata.obsm["X_scimilarity"] = embeddings

    # -- Step 4: kNN annotation -----------------------------------------------
    logger.info(f"Running kNN annotation (k={k}, weighting={weighting})")
    predictions, _nn_idxs, _nn_dists, nn_stats = model.get_predictions_knn(
        embeddings, k=k, weighting=weighting, disable_progress=False
    )

    adata.obs["celltype_hint"] = predictions.values
    adata.obs["min_dist"] = nn_stats["min_dist"].values
    adata.obs["celltype_hint_stat"] = nn_stats["vsAll"].values
    adata.obs["celltype_hint_weighted_stat"] = nn_stats["vsAll_weighted"].values
    adata.obs["celltype_hits"] = nn_stats["hits"].values
    adata.obs["celltype_hits_weighted"] = nn_stats["hits_weighted"].values

    # -- Clean up temporary layer alias ---------------------------------------
    if _layer_renamed:
        del adata.layers["counts"]

    n_types = adata.obs["celltype_hint"].nunique()
    logger.info(f"SCimilarity identified {n_types} cell types")

    return adata


# ---------------------------------------------------------------------------
# 3. Prediction extraction
# ---------------------------------------------------------------------------


def get_scimilarity_predictions(
    adata: sc.AnnData,
    dist_threshold: float = _DEFAULT_DIST_THRESHOLD,
    vsall_threshold: float = _DEFAULT_VSALL_THRESHOLD,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Extract SCimilarity predictions and flag cells needing refinement.

    Confidence is derived from ``min_dist`` (cosine distance to the nearest
    reference neighbour).  A cell needs refinement when **either**:
      - ``min_dist >= dist_threshold``  (far from any reference cell), or
      - ``celltype_hint_stat < vsall_threshold``  (weak kNN consensus).

    Parameters
    ----------
    adata : AnnData
        Data with SCimilarity predictions (output of ``run_scimilarity``).
    dist_threshold : float, default 0.15
        Cosine distance above which a prediction is considered uncertain.
        Typical range: 0.05 (very strict) – 0.25 (permissive).
    vsall_threshold : float, default 0.5
        Minimum vsAll score (fraction of k neighbours voting for the winner)
        to accept a prediction without refinement.

    Returns
    -------
    predictions : np.ndarray of str
        Cell type label for each cell.
    confidences : np.ndarray of float
        Confidence score in [0, 1]: ``1 - min_dist`` clipped to [0, 1].
        Higher is better.
    needs_refinement : np.ndarray of bool
        True for cells that should be refined by a secondary method.

    Raises
    ------
    ValueError
        If SCimilarity predictions are not found in ``adata.obs``.

    Examples
    --------
    >>> preds, confs, needs_refine = get_scimilarity_predictions(adata)
    >>> print(f"{needs_refine.sum()} / {len(needs_refine)} cells need refinement")
    """
    if "celltype_hint" not in adata.obs.columns:
        raise ValueError(
            "No SCimilarity predictions found in adata.obs. " "Run run_scimilarity() first."
        )

    predictions = adata.obs["celltype_hint"].values

    # Convert min_dist → confidence: closer = more confident
    if "min_dist" in adata.obs.columns:
        min_dist = adata.obs["min_dist"].values.astype(float)
        confidences = np.clip(1.0 - min_dist, 0.0, 1.0)
    else:
        logger.warning("min_dist not found in adata.obs; defaulting confidence to 0.5")
        min_dist = np.full(len(predictions), 0.5)
        confidences = np.full(len(predictions), 0.5)

    # vsAll score (unweighted) — fraction of k neighbours voting for winner
    if "celltype_hint_stat" in adata.obs.columns:
        vsall = adata.obs["celltype_hint_stat"].values.astype(float)
    else:
        logger.warning("celltype_hint_stat not found; skipping vsAll filter")
        vsall = np.ones(len(predictions))

    # A cell needs refinement if it is far from the reference OR has weak consensus
    needs_refinement = (min_dist >= dist_threshold) | (vsall < vsall_threshold)

    n_high = (~needs_refinement).sum()
    n_low = needs_refinement.sum()
    logger.info(
        f"SCimilarity: {n_high} high-confidence, {n_low} need refinement "
        f"(dist_threshold={dist_threshold}, vsall_threshold={vsall_threshold})"
    )

    return predictions, confidences, needs_refinement


# ---------------------------------------------------------------------------
# 4. Combine with consensus
# ---------------------------------------------------------------------------


def combine_scimilarity_with_consensus(
    scimilarity_predictions: np.ndarray,
    scimilarity_confidences: np.ndarray,
    needs_refinement: np.ndarray,
    consensus_predictions: np.ndarray,
    consensus_confidences: np.ndarray,
    consensus_threshold: float = 0.5,
    unknown_label: str = "Unknown",
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Combine SCimilarity predictions with consensus refinement.

    Decision logic (mirrors ``combine_celltypist_with_consensus``):
      - SCimilarity high-confidence  → keep SCimilarity label
      - SCimilarity low-confidence AND consensus conf ≥ threshold → use consensus
      - Both low-confidence → mark as ``unknown_label``

    Parameters
    ----------
    scimilarity_predictions : np.ndarray
        Cell type predictions from SCimilarity.
    scimilarity_confidences : np.ndarray
        Confidence scores from SCimilarity (``1 - min_dist``).
    needs_refinement : np.ndarray of bool
        Boolean mask from ``get_scimilarity_predictions``.
    consensus_predictions : np.ndarray
        Cell type predictions from the consensus method.
    consensus_confidences : np.ndarray
        Confidence scores from the consensus method.
    consensus_threshold : float, default 0.5
        Minimum consensus confidence to accept a consensus label.
    unknown_label : str, default "Unknown"
        Label assigned when both methods are low-confidence.

    Returns
    -------
    refined_predictions : np.ndarray of str
        Final cell type label per cell.
    refined_confidences : np.ndarray of float
        Final confidence score per cell.
    source : np.ndarray of str
        Origin of each prediction: ``"scimilarity"``, ``"consensus"``,
        or ``"unknown"``.

    Examples
    --------
    >>> refined, conf, source = combine_scimilarity_with_consensus(
    ...     sc_preds, sc_conf, needs_refine,
    ...     consensus_preds, consensus_conf
    ... )
    >>> import pandas as pd
    >>> print(pd.Series(source).value_counts().to_dict())
    """
    # Delegate to the shared vectorised helper.
    # needs_refinement is a boolean mask; convert to a confidence proxy
    # (1.0 = high-confidence, 0.0 = needs refinement) so the shared helper
    # can apply its threshold-based logic uniformly.
    primary_conf_proxy = np.where(needs_refinement, 0.0, 1.0)
    return combine_primary_with_consensus(
        primary_predictions=scimilarity_predictions,
        primary_confidences=primary_conf_proxy,
        primary_threshold=0.5,  # proxy: 1.0 = keep, 0.0 = refine
        consensus_predictions=consensus_predictions,
        consensus_confidences=consensus_confidences,
        consensus_threshold=consensus_threshold,
        unknown_label=unknown_label,
        source_label="scimilarity",
    )


# ---------------------------------------------------------------------------
# 5. Pre-flight diagnostics
# ---------------------------------------------------------------------------


def diagnose_scimilarity(
    adata: sc.AnnData,
    model: Any,
    output_folder: str,
) -> dict:
    """
    Run pre-flight checks before SCimilarity annotation.

    Checks
    ------
    1. Gene overlap between ``adata.var.index`` and ``model.gene_order``.
       SCimilarity requires ≥ 5 000 overlapping HGNC gene symbols.
    2. Presence of ``layers["counts"]`` (raw integer counts).
    3. Absence of negative values in the count matrix.
    4. Whether ``var.index`` looks like Ensembl IDs (starts with "ENSG") —
       SCimilarity requires gene symbols, not Ensembl IDs.

    Parameters
    ----------
    adata : AnnData
        Query dataset to check.
    model : scimilarity.CellAnnotation
        Loaded SCimilarity model.
    output_folder : str
        Directory to save the text diagnostic report.

    Returns
    -------
    dict with keys:
        ``gene_overlap``      : int   — number of overlapping genes
        ``panel_coverage_pct``: float — % of panel genes in model vocabulary
        ``model_coverage_pct``: float — % of model genes covered by panel
        ``has_counts_layer``  : bool  — whether layers["counts"] exists
        ``looks_like_ensembl``: bool  — whether var.index looks like Ensembl IDs
        ``passes_overlap``    : bool  — whether overlap ≥ 5 000

    Examples
    --------
    >>> ca = load_scimilarity_model("/opt/data/scimilarity_model")
    >>> info = diagnose_scimilarity(adata, ca, output_folder="qc/")
    >>> if not info["passes_overlap"]:
    ...     raise RuntimeError("Insufficient gene overlap with SCimilarity model")
    """
    import os
    from pathlib import Path

    os.makedirs(output_folder, exist_ok=True)

    model_genes = set(model.gene_order)
    panel_genes = set(adata.var.index)
    _stats = compute_feature_overlap(model_genes, panel_genes)
    gene_overlap = _stats["n_overlap"]
    panel_coverage = _stats["panel_coverage"]
    model_coverage = _stats["model_coverage"]
    passes_overlap = gene_overlap >= 5000

    has_counts_layer = "counts" in adata.layers

    # Heuristic: if >10% of var_names start with "ENSG", likely Ensembl IDs
    sample = list(adata.var.index)[:50]
    n_ensembl = sum(1 for g in sample if str(g).startswith("ENSG"))
    looks_like_ensembl = n_ensembl > len(sample) * 0.1

    sep = "=" * 60
    lines = [
        sep,
        "SCimilarity pre-flight diagnostic",
        sep,
        f"  Panel genes          : {len(panel_genes)}",
        f"  Model genes          : {len(model_genes)}",
        f"  Gene overlap         : {gene_overlap}",
        f"  Panel coverage       : {panel_coverage:.1f}%  [KEY metric]",
        f"  Model coverage       : {model_coverage:.1f}%  " f"[expected low for targeted panels]",
        f"  Passes overlap (≥5k) : {'YES' if passes_overlap else 'NO  ← PROBLEM'}",
        "",
        f"  layers['counts'] present : {'YES' if has_counts_layer else 'NO  ← PROBLEM'}",
        f"  var.index looks like Ensembl IDs : "
        f"{'YES  ← PROBLEM — SCimilarity needs gene symbols' if looks_like_ensembl else 'NO (good)'}",
    ]

    if not passes_overlap:
        lines += [
            "",
            "  !! ALERT: gene overlap < 5 000.",
            "     Possible causes:",
            "       - var.index uses Ensembl IDs instead of HGNC gene symbols",
            "       - Panel is too small (< 5 000 genes)",
            "       - Wrong organism (model trained on human data)",
        ]
    if not has_counts_layer:
        lines += [
            "",
            "  !! ALERT: layers['counts'] not found.",
            "     SCimilarity requires raw integer counts in layers['counts'].",
            "     Fix: adata.layers['counts'] = adata.X.copy()  (if X is raw counts)",
        ]
    if looks_like_ensembl:
        lines += [
            "",
            "  !! ALERT: var.index appears to contain Ensembl IDs.",
            "     SCimilarity requires HGNC gene symbols.",
            "     Fix: remap var.index using a gene ID mapping table.",
        ]

    lines.append(sep)
    report = "\n".join(lines)
    print(report)

    report_path = Path(output_folder) / "scimilarity_diagnostic.txt"
    with open(report_path, "w") as fh:
        fh.write(report + "\n")
    print(f"  Report saved → {report_path}")

    return {
        "gene_overlap": gene_overlap,
        "panel_coverage_pct": panel_coverage,
        "model_coverage_pct": model_coverage,
        "has_counts_layer": has_counts_layer,
        "looks_like_ensembl": looks_like_ensembl,
        "passes_overlap": passes_overlap,
    }


# ---------------------------------------------------------------------------
# 6. High-level entry point
# ---------------------------------------------------------------------------


def cell_typing_scimilarity(
    merged_adata: sc.AnnData,
    model_path: str,
    output_folder: str,
    use_gpu: bool = False,
    k: int = 50,
    weighting: bool = True,
    target_celltypes: list[str] | None = None,
    dist_threshold: float = _DEFAULT_DIST_THRESHOLD,
    vsall_threshold: float = _DEFAULT_VSALL_THRESHOLD,
    layer: str = "counts",
) -> sc.AnnData:
    """
    High-level SCimilarity annotation with diagnostics and QC plots.

    This is the recommended entry point.  It mirrors the structure of
    ``cell_typing_celltypist``:

    Steps
    -----
    1. Load model.
    2. Run ``diagnose_scimilarity`` — aborts with a clear error if gene
       overlap < 5 000 or ``layers["counts"]`` is missing.
    3. Run ``run_scimilarity`` (align → lognorm → embed → kNN).
    4. Save diagnostic plots to ``output_folder``:
       - UMAP coloured by ``celltype_hint``, ``min_dist``, ``celltype_hint_stat``
       - ``min_dist`` histogram with threshold line
       - Cell type composition bar chart

    Adds to ``merged_adata.obs``
    ----------------------------
    celltype_hint               : predicted cell type label
    min_dist                    : cosine distance to nearest reference neighbour
    celltype_hint_stat          : vsAll score (unweighted)
    celltype_hint_weighted_stat : vsAll score (distance-weighted)
    celltype_hits               : JSON vote counts
    celltype_hits_weighted      : JSON weighted vote counts

    Adds to ``merged_adata.obsm``
    -----------------------------
    X_scimilarity               : 128-dim embedding

    Parameters
    ----------
    merged_adata : AnnData
        Output of batch correction.  Must have:
          - ``layers["counts"]`` (or the layer specified by ``layer``)
          - HGNC gene symbols as ``var.index``
          - ``obsm["umap_corrected"]`` for UMAP plots (optional but recommended)
    model_path : str
        Path to the SCimilarity model directory.
    output_folder : str
        Directory for diagnostic plots and text report.
    use_gpu : bool, default False
        Run encoder on GPU.
    k : int, default 50
        Number of nearest neighbours for kNN voting.
    weighting : bool, default True
        Use distance-weighted kNN voting.
    target_celltypes : list of str, optional
        Restrict predictions to this subset via safelist.
        Pass None to use the full reference.
    dist_threshold : float, default 0.15
        Cosine distance threshold for flagging uncertain predictions
        (used only for the diagnostic plot; does not filter predictions).
    vsall_threshold : float, default 0.5
        vsAll threshold for flagging uncertain predictions
        (used only for the diagnostic plot; does not filter predictions).
    layer : str, default "counts"
        Layer containing raw integer counts.

    Returns
    -------
    AnnData
        ``merged_adata`` with SCimilarity annotations in ``.obs`` and
        ``.obsm["X_scimilarity"]``.

    Examples
    --------
    >>> merged_adata = cell_typing_scimilarity(
    ...     merged_adata,
    ...     model_path="/opt/data/scimilarity_model",
    ...     output_folder="results/scimilarity/",
    ... )
    >>> merged_adata.obs["celltype_hint"].value_counts()
    """
    if not HAS_SCIMILARITY:
        raise ImportError(
            "scimilarity is required for this function. " "Install with: pip install scimilarity"
        )

    import os
    from pathlib import Path

    import matplotlib.pyplot as plt

    os.makedirs(output_folder, exist_ok=True)

    # -- 1. Load model --------------------------------------------------------
    print("Loading SCimilarity model...")
    ca = load_scimilarity_model(model_path, use_gpu=use_gpu)
    print(f"  Model: {len(ca.gene_order)} genes, {len(ca.classes)} cell types")

    # -- 2. Pre-flight diagnostics --------------------------------------------
    print("Running pre-flight diagnostics...")
    diag = diagnose_scimilarity(merged_adata, ca, output_folder)

    if not diag["passes_overlap"]:
        raise RuntimeError(
            f"SCimilarity requires ≥ 5 000 overlapping genes, but only "
            f"{diag['gene_overlap']} were found.\n"
            f"Panel coverage: {diag['panel_coverage_pct']:.1f}%.\n"
            f"Check that var.index uses HGNC gene symbols (not Ensembl IDs) "
            f"and that the dataset has sufficient transcriptomic depth."
        )
    if not diag["has_counts_layer"]:
        raise RuntimeError(
            "layers['counts'] not found in merged_adata. "
            "SCimilarity requires raw integer counts in layers['counts'].\n"
            "Fix: adata.layers['counts'] = adata.X.copy()  (if X is raw counts)"
        )
    if diag["looks_like_ensembl"]:
        raise RuntimeError(
            "var.index appears to contain Ensembl IDs. "
            "SCimilarity requires HGNC gene symbols. "
            "Remap var.index before calling cell_typing_scimilarity()."
        )

    # -- 3. Run annotation ----------------------------------------------------
    print(
        f"Running SCimilarity annotation "
        f"(k={k}, weighting={weighting}, "
        f"target_celltypes={'all' if target_celltypes is None else len(target_celltypes)})..."
    )
    merged_adata = run_scimilarity(
        merged_adata,
        model=ca,
        k=k,
        weighting=weighting,
        target_celltypes=target_celltypes,
        layer=layer,
        inplace=False,
    )

    n_types = merged_adata.obs["celltype_hint"].nunique()
    print(f"  SCimilarity identified {n_types} cell types")

    # Report uncertain cells
    _, _, needs_refinement = get_scimilarity_predictions(
        merged_adata,
        dist_threshold=dist_threshold,
        vsall_threshold=vsall_threshold,
    )
    pct_uncertain = 100.0 * needs_refinement.sum() / max(len(needs_refinement), 1)
    print(
        f"  Uncertain cells (dist≥{dist_threshold} or vsAll<{vsall_threshold}): "
        f"{needs_refinement.sum()} ({pct_uncertain:.1f}%)"
    )

    # -- 4. Diagnostic plots --------------------------------------------------
    umap_key = "umap_corrected" if "umap_corrected" in merged_adata.obsm else "X_umap"
    has_umap = umap_key in merged_adata.obsm

    # 4a. UMAP panel: celltype_hint | min_dist | celltype_hint_stat
    if has_umap:
        fig, axs = plt.subplots(1, 3, figsize=(21, 6), gridspec_kw={"wspace": 0.4})

        sc.pl.embedding(
            merged_adata,
            basis=umap_key,
            color="celltype_hint",
            ax=axs[0],
            show=False,
            title=f"SCimilarity predictions ({n_types} types)",
            legend_loc="on data",
            legend_fontsize=5,
            legend_fontoutline=1,
            frameon=False,
        )
        sc.pl.embedding(
            merged_adata,
            basis=umap_key,
            color="min_dist",
            ax=axs[1],
            show=False,
            color_map="viridis_r",
            vmin=0,
            vmax=0.4,
            title="min_dist (lower = more confident)",
            frameon=False,
        )
        sc.pl.embedding(
            merged_adata,
            basis=umap_key,
            color="celltype_hint_stat",
            ax=axs[2],
            show=False,
            color_map="plasma",
            vmin=0,
            vmax=1,
            title="vsAll score (higher = stronger consensus)",
            frameon=False,
        )
        plt.savefig(
            Path(output_folder) / "scimilarity_umap.png",
            dpi=150,
            bbox_inches="tight",
        )
        plt.close()
        print("  Saved: scimilarity_umap.png")
    else:
        print(
            f"  NOTE: '{umap_key}' not found in obsm — skipping UMAP plots. "
            f"Run sc.tl.umap() or batch correction first."
        )

    # 4b. min_dist histogram
    fig, ax = plt.subplots(figsize=(8, 4))
    merged_adata.obs["min_dist"].hist(bins=60, ax=ax, color="steelblue", edgecolor="white")
    ax.axvline(
        dist_threshold,
        color="red",
        linestyle="--",
        label=f"dist_threshold = {dist_threshold}",
    )
    ax.set_xlabel("min_dist (cosine distance to nearest reference cell)")
    ax.set_ylabel("Cell count")
    ax.set_title("SCimilarity min_dist distribution")
    ax.legend()
    plt.tight_layout()
    plt.savefig(
        Path(output_folder) / "scimilarity_min_dist_dist.png",
        dpi=150,
    )
    plt.close()
    print("  Saved: scimilarity_min_dist_dist.png")

    # 4c. Cell type composition bar chart
    ct_counts = merged_adata.obs["celltype_hint"].value_counts().sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(8, max(4, len(ct_counts) * 0.35)))
    ct_counts.plot(kind="barh", ax=ax, color="steelblue", edgecolor="white")
    ax.set_xlabel("Cell count")
    ax.set_title("Cell type composition (SCimilarity)")
    plt.tight_layout()
    plt.savefig(
        Path(output_folder) / "scimilarity_composition.png",
        dpi=150,
    )
    plt.close()
    print("  Saved: scimilarity_composition.png")

    return merged_adata
