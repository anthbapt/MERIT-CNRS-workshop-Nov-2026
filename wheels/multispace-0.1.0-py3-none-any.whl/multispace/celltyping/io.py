"""
Data I/O and Gene Mapping Utilities
====================================

This module provides utilities for loading spatial transcriptomics data
and mapping between gene identifier formats.

Functions
---------
- load_spatial_data: Load spatial data from zarr files
- gene_symbol_to_ensembl: Convert gene symbols to Ensembl IDs
- load_marker_file: Load marker gene definitions from file

Example
-------
>>> from multispace.celltyping.io import load_spatial_data, gene_symbol_to_ensembl
>>>
>>> # Load spatial data
>>> data = load_spatial_data(metadata_path, zarr_dir)
>>>
>>> # Convert gene symbols
>>> mapping = gene_symbol_to_ensembl(["TP53", "BRCA1", "EGFR"])
"""

from __future__ import annotations

import warnings
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pandas as pd

if TYPE_CHECKING:
    import anndata as ad

__all__ = [
    "load_data",
    "load_spatial_data",
    "load_spatialdata_zarr",
    "save_to_spatialdata",
    "update_spatialdata_table",
    "gene_symbol_to_ensembl",
    "gene_symbol_to_ensembl_mygene",
    "load_marker_file",
    "create_marker_dict",
    "load_gene_mapping",
    "rename_var_to_ensembl",
    "rename_var_to_gene_name",
    "attach_cell_types",
]


def load_data(
    path: str | Path,
    table_name: str = "table",
) -> ad.AnnData:
    """
    Load data from h5ad or zarr (SpatialData) file.

    This is a convenience function that automatically detects the file type
    and returns an AnnData object.

    Parameters
    ----------
    path : str or Path
        Path to .h5ad file or .zarr directory.
    table_name : str
        Name of the table to extract from SpatialData. Default: "table".

    Returns
    -------
    AnnData
        The loaded AnnData object.

    Examples
    --------
    >>> # Load from h5ad
    >>> adata = load_data("sample.h5ad")
    >>>
    >>> # Load from zarr (SpatialData)
    >>> adata = load_data("sample.zarr")
    """
    import scanpy as sc

    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Path not found: {path}")

    # Detect file type
    if path.suffix == ".h5ad":
        return sc.read_h5ad(path)

    elif path.suffix == ".zarr" or path.is_dir():
        return load_spatialdata_zarr(path, table_name=table_name)

    else:
        # Try h5ad first, then zarr
        try:
            return sc.read_h5ad(path)
        except Exception:
            return load_spatialdata_zarr(path, table_name=table_name)


def load_spatialdata_zarr(
    zarr_path: str | Path,
    table_name: str = "table",
    return_sdata: bool = False,
) -> ad.AnnData | tuple[ad.AnnData, Any]:
    """
    Load AnnData from a SpatialData zarr file.

    Parameters
    ----------
    zarr_path : str or Path
        Path to .zarr directory.
    table_name : str
        Name of the table to extract. Default: "table".
    return_sdata : bool
        If True, also return the SpatialData object. Default: False.

    Returns
    -------
    AnnData or tuple
        The AnnData table, or (AnnData, SpatialData) if return_sdata=True.

    Examples
    --------
    >>> # Load just the AnnData
    >>> adata = load_spatialdata_zarr("sample.zarr")
    >>>
    >>> # Load both AnnData and SpatialData
    >>> adata, sdata = load_spatialdata_zarr("sample.zarr", return_sdata=True)
    """
    try:
        import spatialdata as sd
    except ImportError as err:
        raise ImportError(
            "spatialdata is required for loading zarr files. "
            "Install with: pip install spatialdata"
        ) from err

    zarr_path = Path(zarr_path)

    if not zarr_path.exists():
        raise FileNotFoundError(f"Zarr path not found: {zarr_path}")

    # Load SpatialData
    sdata = sd.read_zarr(zarr_path)

    # Extract AnnData table
    if not hasattr(sdata, "tables") or sdata.tables is None:
        raise ValueError(f"No tables found in SpatialData: {zarr_path}")

    available_tables = list(sdata.tables.keys())

    if table_name not in sdata.tables:
        if len(available_tables) == 1:
            # Use the only available table
            table_name = available_tables[0]
            warnings.warn(
                f"Table '{table_name}' not found, using '{available_tables[0]}'", stacklevel=2
            )
        else:
            raise ValueError(
                f"Table '{table_name}' not found. " f"Available tables: {available_tables}"
            )

    adata = sdata.tables[table_name]

    if return_sdata:
        return adata, sdata
    return adata


def save_to_spatialdata(
    adata: ad.AnnData,
    output_path: str | Path,
    sdata: Any | None = None,
    table_name: str = "table",
    overwrite: bool = False,
) -> None:
    """
    Save annotated AnnData back to SpatialData zarr format.

    This function either updates an existing SpatialData object or creates
    a new one containing just the table.

    Parameters
    ----------
    adata : AnnData
        Annotated AnnData object to save.
    output_path : str or Path
        Path for output .zarr directory.
    sdata : SpatialData, optional
        Existing SpatialData object to update. If None, creates a new one.
    table_name : str
        Name for the table in SpatialData. Default: "table".
    overwrite : bool
        Whether to overwrite existing zarr. Default: False.

    Examples
    --------
    >>> # Save to new zarr
    >>> save_to_spatialdata(adata_annotated, "output.zarr")
    >>>
    >>> # Update existing SpatialData
    >>> adata, sdata = load_spatialdata_zarr("input.zarr", return_sdata=True)
    >>> # ... run annotation ...
    >>> save_to_spatialdata(adata_annotated, "output.zarr", sdata=sdata)
    """
    try:
        import spatialdata as sd
    except ImportError as err:
        raise ImportError(
            "spatialdata is required for saving to zarr. " "Install with: pip install spatialdata"
        ) from err

    output_path = Path(output_path)

    # Check if output exists
    if output_path.exists() and not overwrite:
        raise FileExistsError(
            f"Output path already exists: {output_path}. " "Set overwrite=True to replace."
        )

    if sdata is not None:
        # Update existing SpatialData with new table
        if table_name in sdata.tables:
            del sdata.tables[table_name]
        sdata.tables[table_name] = adata
    else:
        # Create new SpatialData with just the table
        sdata = sd.SpatialData(tables={table_name: adata})

    # Write to zarr
    if output_path.exists() and overwrite:
        import shutil

        shutil.rmtree(output_path)

    sdata.write(output_path)
    print(f"Saved SpatialData to: {output_path}")


def update_spatialdata_table(
    zarr_path: str | Path,
    adata: ad.AnnData,
    table_name: str = "table",
    output_path: str | Path | None = None,
    columns_to_add: list[str] | None = None,
) -> None:
    """
    Update specific columns in a SpatialData table without rewriting everything.

    This is useful for adding annotation results to an existing SpatialData
    while preserving all other elements (images, shapes, etc.).

    Parameters
    ----------
    zarr_path : str or Path
        Path to existing .zarr directory.
    adata : AnnData
        AnnData with new columns to add.
    table_name : str
        Name of the table to update. Default: "table".
    output_path : str or Path, optional
        Output path. If None, updates in place.
    columns_to_add : list of str, optional
        Specific columns to add from adata.obs. If None, adds all columns
        that don't exist in the original table.

    Examples
    --------
    >>> # Add annotation columns to existing zarr
    >>> update_spatialdata_table(
    ...     "sample.zarr",
    ...     adata_annotated,
    ...     columns_to_add=["cell_type", "confidence", "low_quality"]
    ... )
    """
    try:
        import spatialdata as sd
    except ImportError as err:
        raise ImportError("spatialdata is required. Install with: pip install spatialdata") from err

    zarr_path = Path(zarr_path)
    if not zarr_path.exists():
        raise FileNotFoundError(f"Zarr path not found: {zarr_path}")

    # Load existing SpatialData
    sdata = sd.read_zarr(zarr_path)

    if table_name not in sdata.tables:
        raise ValueError(f"Table '{table_name}' not found in SpatialData")

    original_table = sdata.tables[table_name]

    # Determine which columns to add
    if columns_to_add is None:
        # Add all new columns from adata.obs
        columns_to_add = [col for col in adata.obs.columns if col not in original_table.obs.columns]

    # Verify cell indices match
    if not adata.obs.index.equals(original_table.obs.index):
        # Try to align by index
        common_idx = adata.obs.index.intersection(original_table.obs.index)
        if len(common_idx) == 0:
            raise ValueError(
                "No matching cell indices between adata and original table. "
                "Ensure the AnnData was derived from this SpatialData."
            )
        if len(common_idx) < len(original_table.obs.index):
            warnings.warn(
                f"Only {len(common_idx)}/{len(original_table.obs.index)} cells match. "
                "Unmatched cells will have NaN values.",
                stacklevel=2,
            )

    # Add columns to original table
    for col in columns_to_add:
        if col in adata.obs.columns:
            original_table.obs[col] = adata.obs[col].reindex(original_table.obs.index)
            print(f"  Added column: {col}")

    # Update the table in SpatialData
    sdata.tables[table_name] = original_table

    # Write output
    if output_path is None:
        output_path = zarr_path

    output_path = Path(output_path)

    if output_path != zarr_path:
        sdata.write(output_path)
        print(f"Saved updated SpatialData to: {output_path}")
    else:
        # Overwrite in place
        import shutil

        temp_path = zarr_path.parent / f"{zarr_path.stem}_temp.zarr"
        sdata.write(temp_path)
        shutil.rmtree(zarr_path)
        temp_path.rename(zarr_path)
        print(f"Updated SpatialData in place: {zarr_path}")


def load_spatial_data(
    metadata_path: str | Path, zarr_dir: str | Path, load_tables: bool = True
) -> dict[str, Any]:
    """
    Load spatial transcriptomics data from zarr files.

    Parameters
    ----------
    metadata_path : str or Path
        Path to metadata CSV file with sample information.
    zarr_dir : str or Path
        Directory containing .zarr files.
    load_tables : bool
        Whether to extract AnnData tables from SpatialData objects.

    Returns
    -------
    Dict[str, Any]
        Dictionary with keys:
        - 'metadata': DataFrame with sample metadata
        - 'samples': Dict mapping sample_id to loaded data

    Examples
    --------
    >>> data = load_spatial_data("metadata.csv", "/path/to/zarr/")
    >>> adata = data['samples']['sample1']['adata']
    """
    try:
        import spatialdata as sd
    except ImportError as err:
        raise ImportError(
            "spatialdata is required for loading spatial data. "
            "Install with: pip install spatialdata"
        ) from err

    metadata_path = Path(metadata_path)
    zarr_dir = Path(zarr_dir)

    if not metadata_path.exists():
        raise FileNotFoundError(f"Metadata file not found: {metadata_path}")
    if not zarr_dir.exists():
        raise FileNotFoundError(f"Zarr directory not found: {zarr_dir}")

    metadata = pd.read_csv(metadata_path)
    samples = {}

    # Determine sample ID column
    id_col = None
    for col in ["core_id", "sample_id", "id", "name"]:
        if col in metadata.columns:
            id_col = col
            break

    if id_col is None:
        raise ValueError("Could not find sample ID column in metadata")

    for _, row in metadata.iterrows():
        sample_id = row[id_col]
        zarr_path = zarr_dir / f"{sample_id}.zarr"

        if zarr_path.exists():
            try:
                sdata = sd.read_zarr(zarr_path)
                sample_data = {"sdata": sdata, "metadata": row.to_dict()}

                # Extract AnnData table if available
                if load_tables and hasattr(sdata, "tables"):
                    table = sdata.tables.get("table")
                    if table is not None:
                        sample_data["adata"] = table

                samples[sample_id] = sample_data

            except Exception as e:
                warnings.warn(f"Could not load {sample_id}: {e}", stacklevel=2)
        else:
            warnings.warn(f"Zarr file not found for {sample_id}: {zarr_path}", stacklevel=2)

    return {"metadata": metadata, "samples": samples}


def gene_symbol_to_ensembl(
    xenium_table: pd.DataFrame, symbol_col: str = "Name", ensembl_col: str = "Ensembl ID"
) -> dict[str, str]:
    """
    Create gene symbol to Ensembl ID mapping from Xenium panel table.

    Parameters
    ----------
    xenium_table : pd.DataFrame
        Xenium gene panel table.
    symbol_col : str
        Column name for gene symbols. Default: "Name".
    ensembl_col : str
        Column name for Ensembl IDs. Default: "Ensembl ID".

    Returns
    -------
    Dict[str, str]
        Mapping from gene symbol to Ensembl ID.

    Examples
    --------
    >>> panel = pd.read_csv("xenium_panel.csv")
    >>> mapping = gene_symbol_to_ensembl(panel)
    >>> mapping["TP53"]
    'ENSG00000141510'
    """
    mapping = {}

    # Try alternative column names
    symbol_cols = [symbol_col, "gene_name", "symbol", "gene_symbol"]
    ensembl_cols = [ensembl_col, "gene_id", "ensembl_id", "ensembl"]

    actual_symbol_col = None
    actual_ensembl_col = None

    for col in symbol_cols:
        if col in xenium_table.columns:
            actual_symbol_col = col
            break

    for col in ensembl_cols:
        if col in xenium_table.columns:
            actual_ensembl_col = col
            break

    if actual_symbol_col is None or actual_ensembl_col is None:
        raise ValueError(
            f"Could not find required columns. " f"Available: {list(xenium_table.columns)}"
        )

    for _, row in xenium_table.iterrows():
        symbol = row[actual_symbol_col]
        ensembl = row[actual_ensembl_col]
        if pd.notna(symbol) and pd.notna(ensembl):
            mapping[symbol] = ensembl

    return mapping


def gene_symbol_to_ensembl_mygene(
    gene_symbols: list[str], species: str = "human"
) -> dict[str, str | None]:
    """
    Convert gene symbols to Ensembl IDs using MyGene.info API.

    Parameters
    ----------
    gene_symbols : List[str]
        List of gene symbols to convert.
    species : str
        Species for gene lookup. Default: "human".

    Returns
    -------
    Dict[str, Optional[str]]
        Mapping from gene symbol to Ensembl ID (None if not found).

    Examples
    --------
    >>> mapping = gene_symbol_to_ensembl_mygene(["TP53", "BRCA1", "FAKE_GENE"])
    >>> mapping["TP53"]
    'ENSG00000141510'
    >>> mapping["FAKE_GENE"]
    None
    """
    try:
        import mygene
    except ImportError:
        warnings.warn(
            "mygene not installed. Install with: pip install mygene. " "Returning empty mapping.",
            stacklevel=2,
        )
        return dict.fromkeys(gene_symbols)

    mg = mygene.MyGeneInfo()

    results = mg.querymany(
        gene_symbols, scopes="symbol", fields="ensembl.gene", species=species, returnall=True
    )

    mapping = {}
    for hit in results.get("out", []):
        query = hit.get("query")
        ensembl = hit.get("ensembl", {})

        # Handle multiple Ensembl IDs
        if isinstance(ensembl, list):
            ensembl = ensembl[0] if ensembl else {}

        gene_id = ensembl.get("gene") if isinstance(ensembl, dict) else None
        mapping[query] = gene_id

    # Add missing genes as None
    for gene in gene_symbols:
        if gene not in mapping:
            mapping[gene] = None

    return mapping


def load_marker_file(filepath: str | Path, format: str = "auto") -> dict[str, list[str]]:
    """
    Load marker gene definitions from file.

    Supports multiple formats:
    - CSV/TSV with cell_type and gene columns
    - JSON with {cell_type: [genes]} structure
    - Excel with cell_type and gene columns

    Parameters
    ----------
    filepath : str or Path
        Path to marker file.
    format : str
        File format: 'auto', 'csv', 'tsv', 'json', 'excel'.

    Returns
    -------
    Dict[str, List[str]]
        Marker dictionary mapping cell types to gene lists.

    Examples
    --------
    >>> markers = load_marker_file("markers.csv")
    >>> markers["T_cell"]
    ['CD3D', 'CD3E', 'CD4', 'CD8A']
    """
    import json

    filepath = Path(filepath)

    if not filepath.exists():
        raise FileNotFoundError(f"Marker file not found: {filepath}")

    # Auto-detect format
    if format == "auto":
        suffix = filepath.suffix.lower()
        format_map = {
            ".csv": "csv",
            ".tsv": "tsv",
            ".txt": "tsv",
            ".json": "json",
            ".xlsx": "excel",
            ".xls": "excel",
        }
        format = format_map.get(suffix, "csv")

    if format == "json":
        with open(filepath) as f:
            return json.load(f)

    elif format in ("csv", "tsv", "excel"):
        sep = "\t" if format == "tsv" else ","

        df = pd.read_excel(filepath) if format == "excel" else pd.read_csv(filepath, sep=sep)

        # Find cell type and gene columns
        ct_col = None
        gene_col = None

        for col in df.columns:
            col_lower = col.lower()
            if "cell" in col_lower and "type" in col_lower:
                ct_col = col
            elif col_lower in ("gene", "marker", "gene_symbol", "symbol"):
                gene_col = col

        if ct_col is None or gene_col is None:
            # Try first two columns
            if len(df.columns) >= 2:
                ct_col, gene_col = df.columns[0], df.columns[1]
            else:
                raise ValueError(
                    f"Could not identify cell_type and gene columns. "
                    f"Available: {list(df.columns)}"
                )

        # Build marker dict
        marker_dict = {}
        for _, row in df.iterrows():
            ct = row[ct_col]
            gene = row[gene_col]
            if pd.notna(ct) and pd.notna(gene):
                if ct not in marker_dict:
                    marker_dict[ct] = []
                marker_dict[ct].append(gene)

        return marker_dict

    else:
        raise ValueError(f"Unknown format: {format}")


def create_marker_dict(biomarker_df: pd.DataFrame, min_markers: int = 2) -> dict[str, list[str]]:
    """
    Create marker dictionary from biomarker matrix.

    Parameters
    ----------
    biomarker_df : pd.DataFrame
        Matrix with genes as rows, cell types as columns.
        Non-zero values indicate marker genes.
    min_markers : int
        Minimum markers required per cell type. Default: 2.

    Returns
    -------
    Dict[str, List[str]]
        Marker dictionary.

    Examples
    --------
    >>> # biomarker_df has genes as index, cell types as columns
    >>> markers = create_marker_dict(biomarker_df)
    """
    # Columns that are aggregate/metadata fields, not real cell types.
    # These arise when the CSV has a row-sum or total column that would
    # otherwise create a phantom cell type containing every marker gene.
    _SKIP_COLUMNS = {
        "Total_Cell_Types",
        "Total",
        "total",
        "total_cell_types",
        "Sum",
        "Count",
    }

    marker_dict = {}

    for cell_type in biomarker_df.columns:
        if cell_type in _SKIP_COLUMNS:
            import logging

            logging.getLogger(__name__).warning(
                f"create_marker_dict: skipping column '{cell_type}' — "
                "looks like an aggregate/metadata column, not a cell type."
            )
            continue

        markers = biomarker_df[biomarker_df[cell_type] > 0].index.tolist()
        if len(markers) >= min_markers:
            marker_dict[cell_type] = markers

    return marker_dict


# === Gene name / Ensembl ID remapping ===


def load_gene_mapping(gene_list_path: str):
    """
    Load gene_name <-> Ensembl ID mapping from the 10X Xenium gene list CSV.

    The CSV must contain at minimum 'gene_name' and 'gene_id' columns.
    The Xenium panel mapping is 1:1 (5001 genes, no duplicates).

    Returns
    -------
    name_to_ensembl : dict  {gene_name -> ENSG...}
    ensembl_to_name : dict  {ENSG...   -> gene_name}
    """
    df = pd.read_csv(gene_list_path, usecols=["gene_name", "gene_id"])
    df = df.dropna(subset=["gene_name", "gene_id"])
    name_to_ensembl = dict(zip(df["gene_name"], df["gene_id"]))
    ensembl_to_name = dict(zip(df["gene_id"], df["gene_name"]))
    return name_to_ensembl, ensembl_to_name


def rename_var_to_ensembl(adata, name_to_ensembl, gene_name_col="_gene_name_orig"):
    """
    Rename adata.var_names from gene symbols to Ensembl IDs in-place.

    Unmapped genes keep their original symbol.  Original symbols are backed
    up to adata.var[gene_name_col] for safe restoration.

    Returns
    -------
    adata          : AnnData  var_names now Ensembl IDs (where mappable)
    original_names : pd.Index original var_names for safe restoration
    """
    original_names = adata.var_names.copy()
    adata.var[gene_name_col] = original_names.values
    new_names = [name_to_ensembl.get(g, g) for g in original_names]
    adata.var_names = pd.Index(new_names)
    n_mapped = sum(n != o for n, o in zip(new_names, original_names))
    print(f"  Gene name -> Ensembl: {n_mapped}/{len(original_names)} features remapped")
    return adata, original_names


def rename_var_to_gene_name(adata, original_names, gene_name_col="_gene_name_orig"):
    """
    Restore adata.var_names to original gene symbols after CellTypist.

    Parameters
    ----------
    adata          : AnnData  var_names are currently Ensembl IDs
    original_names : pd.Index returned by rename_var_to_ensembl()
    gene_name_col  : str      temporary column to remove from adata.var

    Returns
    -------
    adata : AnnData  var_names restored to gene symbols
    """
    adata.var_names = original_names
    if gene_name_col in adata.var.columns:
        adata.var.drop(columns=[gene_name_col], inplace=True)
    print("  Gene name <- Ensembl: var_names restored to gene symbols")
    return adata


# =============================================================================
# SpatialData label propagation
# =============================================================================


def _get_table(sdata, table_key: str = "table"):
    """
    Safe accessor for the AnnData table inside a SpatialData object.
    Tries sdata.tables[key] first (spatialdata >= 0.1), then sdata[key].
    Falls back to the first available table if key is not found.
    """
    import logging as _logging

    _logger = _logging.getLogger(__name__)
    if hasattr(sdata, "tables"):
        tables = sdata.tables
        if table_key in tables:
            return tables[table_key]
        first = next(iter(tables))
        _logger.warning(f"_get_table: '{table_key}' not found; using '{first}' instead.")
        return tables[first]
    return sdata[table_key]


def attach_cell_types(
    spatial_data: dict,
    merged_adata,
    output_folder: str,
    cell_type_col: str = "cell_type_smoothed",
    conf_col: str = "conf_score",
    table_key: str = "table",
) -> None:
    """
    Propagate cell type labels from merged_adata back to each SpatialData table.

    Uses the ``_cell_id_orig`` column stored before ``ad.concat`` to align cells
    via their original obs_names.  Propagates the cell type label (and optionally
    a confidence score) from the merged AnnData into each per-core SpatialData
    table and saves a spatial scatter plot for each core.

    Parameters
    ----------
    spatial_data : dict
        Mapping of ``{core_id: SpatialData}``.
    merged_adata : AnnData
        Output of the cell typing step (must contain ``_cell_id_orig`` and
        a ``metabric_ID`` column in ``.obs``).
    output_folder : str
        Directory for per-core scatter plots. A subdirectory
        ``cell_types_per_core/`` is created automatically.
    cell_type_col : str
        obs column to propagate.
        ``"cell_type_smoothed"`` — CellTypist per-cell + KNN smoothing.
        ``"cell_type_markers"``  — marker-driven cluster annotation.
    conf_col : str
        obs column carrying confidence scores; propagated when present.
    table_key : str
        AnnData table name inside each SpatialData.

    Examples
    --------
    >>> from multispace.celltyping.io import attach_cell_types
    >>> attach_cell_types(
    ...     core_sdata, merged_adata, output_folder="results/",
    ...     cell_type_col="cell_type_smoothed",
    ... )
    """
    import os

    import matplotlib.pyplot as plt
    import seaborn as sns

    os.makedirs(output_folder + "/cell_types_per_core", exist_ok=True)

    for metabric_ID, sdata in spatial_data.items():
        table = _get_table(sdata, table_key=table_key)

        mask = merged_adata.obs["metabric_ID"].astype(str) == str(metabric_ID)
        core_merged = merged_adata[mask]

        cluster_map = core_merged.obs.set_index("_cell_id_orig")[cell_type_col]
        conf_map = (
            core_merged.obs.set_index("_cell_id_orig")[conf_col]
            if conf_col in core_merged.obs.columns
            else None
        )

        obs_copy = table.obs.copy()
        obs_copy[cell_type_col] = obs_copy.index.map(cluster_map)
        if conf_map is not None:
            obs_copy[conf_col] = obs_copy.index.map(conf_map)
        table.obs = obs_copy

        fig, ax = plt.subplots(figsize=(6, 6))
        coords = table.obsm.get("spatial")
        if coords is not None:
            labels = table.obs[cell_type_col].astype("category")
            cmap = sns.color_palette("husl", len(labels.cat.categories))
            for i, cat in enumerate(labels.cat.categories):
                idx = labels == cat
                ax.scatter(coords[idx, 0], coords[idx, 1], s=4, label=cat, color=cmap[i])
            ax.legend(fontsize=5, ncol=2, loc="upper right", markerscale=2)
        ax.set_facecolor("black")
        ax.set_title(metabric_ID, fontsize=9)
        plt.savefig(
            output_folder + "/cell_types_per_core/" + str(metabric_ID) + "_cell_types.png",
            dpi=300,
            bbox_inches="tight",
        )
        plt.close()
        print(f"  {metabric_ID}: cell types attached and saved")
