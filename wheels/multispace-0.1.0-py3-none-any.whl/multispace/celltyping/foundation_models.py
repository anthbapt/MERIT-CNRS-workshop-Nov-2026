"""
Foundation Model Integration (Nicheformer)
==========================================

This module provides integration with Nicheformer for cell type annotation
and spatial niche analysis on spatial transcriptomics data (Xenium, CosMx,
MERFISH) and dissociated single-cell data.

Nicheformer is a transformer-based foundation model (12 layers, 512 hidden
dim, 16 attention heads) pre-trained with masked language modelling on a
large corpus of spatial + dissociated single-cell data.  It tokenises cells
by ranking genes according to their normalised expression and encodes
technology/modality/species context via auxiliary tokens prepended to each
sequence.

Architecture overview
---------------------
Input: raw counts → TP10k normalisation → divide by per-gene technology
       median → rank genes by score → top-4096 gene indices as token IDs
       (offset by 30 reserved auxiliary tokens)

Auxiliary tokens prepended per cell (in order):
  specie  token  (human=5, mouse=6)
  assay   token  (Xenium=9, CosMx=8, MERFISH=7, 10x 3'v3=11, …)
  modality token (spatial=4, dissociated=3)

Fine-tuning tasks
-----------------
  niche_regression          – predict niche composition vector (MSE)
  density_regression        – predict scalar cell density (MSE)
  niche_classification      – classify niche label (CrossEntropy)
  niche_binary_classification
  niche_multiclass_classification

Required obs columns
--------------------
  nicheformer_split   : "train" | "val" | "test"
  assay               : integer technology token (see TECHNOLOGY_DICT)
  specie              : integer species token (see SPECIE_DICT)
  modality            : integer modality token (see MODALITY_DICT)
  author_cell_type    : ground-truth cell type label (for supervised tasks)
  library_key         : sample / slide identifier
  condition_id        : experimental condition string
  tissue_type         : "tissue" | "organoid"

Functions
---------
- prepare_nicheformer_obs      : add required obs columns to an AnnData
- tokenize_for_nicheformer     : tokenise raw counts → NicheformerDataset
- load_nicheformer_model       : load pre-trained backbone checkpoint
- get_nicheformer_embeddings   : extract 512-dim cell embeddings
- fine_tune_nicheformer        : fine-tune on a downstream task
- get_nicheformer_predictions  : extract predictions + confidences
- diagnose_nicheformer         : pre-flight obs schema and gene overlap checks
- cell_typing_nicheformer      : high-level entry point with diagnostics + plots
"""

from __future__ import annotations

import logging
from typing import Any

import numpy as np
import scanpy as sc

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Optional dependency guard
# ---------------------------------------------------------------------------
try:
    import nicheformer  # noqa: F401

    HAS_NICHEFORMER = True
except ImportError:
    HAS_NICHEFORMER = False

try:
    import pytorch_lightning as pl

    HAS_PL = True
except ImportError:
    HAS_PL = False


# ---------------------------------------------------------------------------
# Token dictionaries (from xenium_human_colon.ipynb)
# ---------------------------------------------------------------------------

MODALITY_DICT: dict[str, int] = {
    "dissociated": 3,
    "spatial": 4,
}

SPECIE_DICT: dict[str, int] = {
    "human": 5,
    "Homo sapiens": 5,
    "Mus musculus": 6,
    "mouse": 6,
}

TECHNOLOGY_DICT: dict[str, int] = {
    "merfish": 7,
    "MERFISH": 7,
    "cosmx": 8,
    "NanoString digital spatial profiling": 8,
    "Xenium": 9,
    "10x 5' v2": 10,
    "10x 3' v3": 11,
    "10x 3' v2": 12,
    "10x 5' v1": 13,
    "10x 3' v1": 14,
    "10x 3' transcription profiling": 15,
    "10x transcription profiling": 15,
    "10x 5' transcription profiling": 16,
    "CITE-seq": 17,
    "Smart-seq v4": 18,
}

# Required obs columns and their expected dtypes / value sets
_REQUIRED_OBS_COLS: list[str] = [
    "nicheformer_split",
    "assay",
    "specie",
    "modality",
    "author_cell_type",
    "library_key",
    "condition_id",
    "tissue_type",
]

_VALID_SPLITS: set[str] = {"train", "val", "test"}
_VALID_TISSUE_TYPES: set[str] = {"tissue", "organoid"}


__all__ = [
    "HAS_NICHEFORMER",
    "MODALITY_DICT",
    "SPECIE_DICT",
    "TECHNOLOGY_DICT",
    "prepare_nicheformer_obs",
    "tokenize_for_nicheformer",
    "load_nicheformer_model",
    "get_nicheformer_embeddings",
    "fine_tune_nicheformer",
    "get_nicheformer_predictions",
    "diagnose_nicheformer",
    "cell_typing_nicheformer",
]


# ---------------------------------------------------------------------------
# 1. Prepare obs columns
# ---------------------------------------------------------------------------


def prepare_nicheformer_obs(
    adata: sc.AnnData,
    technology: str,
    specie: str = "human",
    modality: str = "spatial",
    split_ratios: tuple[float, float, float] = (0.8, 0.1, 0.1),
    split_key: str | None = None,
    author_cell_type_key: str = "author_cell_type",
    library_key: str = "library_key",
    condition_id_key: str = "condition_id",
    tissue_type: str = "tissue",
    random_state: int = 42,
    inplace: bool = True,
) -> sc.AnnData:
    """
    Add the obs columns required by Nicheformer to an AnnData object.

    Nicheformer requires integer token IDs for technology (assay), species
    (specie), and modality stored in ``adata.obs``.  This helper encodes
    those tokens and optionally creates a ``nicheformer_split`` column.

    Parameters
    ----------
    adata : AnnData
        Input data.  Must have raw counts in ``X`` or ``layers["counts"]``.
    technology : str
        Technology name.  Must be a key in ``TECHNOLOGY_DICT``.
        For Xenium data use ``"Xenium"``.
    specie : str, default "human"
        Species name.  Must be a key in ``SPECIE_DICT``.
    modality : str, default "spatial"
        Modality.  Must be a key in ``MODALITY_DICT``.
    split_ratios : tuple of float, default (0.8, 0.1, 0.1)
        (train, val, test) fractions.  Used only when ``split_key`` is None.
    split_key : str, optional
        Existing obs column to use as ``nicheformer_split``.  If provided,
        ``split_ratios`` is ignored.  Values must be in {"train","val","test"}.
    author_cell_type_key : str, default "author_cell_type"
        Obs column containing ground-truth cell type labels.  If the column
        does not exist, it is created with placeholder value "unknown".
    library_key : str, default "library_key"
        Obs column containing sample / slide identifiers.  If missing,
        defaults to "sample_0" for all cells.
    condition_id_key : str, default "condition_id"
        Obs column containing experimental condition strings.  If missing,
        defaults to "condition_0" for all cells.
    tissue_type : str, default "tissue"
        Must be "tissue" or "organoid".
    random_state : int, default 42
        Random seed for train/val/test split.
    inplace : bool, default True
        Modify ``adata`` in place.

    Returns
    -------
    AnnData
        AnnData with the following obs columns added / updated:
          - ``nicheformer_split``
          - ``assay``   (integer token)
          - ``specie``  (integer token)
          - ``modality`` (integer token)
          - ``author_cell_type``
          - ``library_key``
          - ``condition_id``
          - ``tissue_type``

    Raises
    ------
    ValueError
        If ``technology``, ``specie``, or ``modality`` are not recognised.

    Examples
    --------
    >>> adata = prepare_nicheformer_obs(
    ...     adata,
    ...     technology="Xenium",
    ...     specie="human",
    ...     modality="spatial",
    ... )
    """
    if not inplace:
        adata = adata.copy()

    # -- Validate token keys --------------------------------------------------
    if technology not in TECHNOLOGY_DICT:
        raise ValueError(
            f"Unknown technology '{technology}'. "
            f"Valid options: {sorted(TECHNOLOGY_DICT.keys())}"
        )
    if specie not in SPECIE_DICT:
        raise ValueError(
            f"Unknown specie '{specie}'. " f"Valid options: {sorted(SPECIE_DICT.keys())}"
        )
    if modality not in MODALITY_DICT:
        raise ValueError(
            f"Unknown modality '{modality}'. " f"Valid options: {sorted(MODALITY_DICT.keys())}"
        )
    if tissue_type not in _VALID_TISSUE_TYPES:
        raise ValueError(f"tissue_type must be one of {_VALID_TISSUE_TYPES}, got '{tissue_type}'")

    # -- Assign integer tokens ------------------------------------------------
    adata.obs["assay"] = TECHNOLOGY_DICT[technology]
    adata.obs["specie"] = SPECIE_DICT[specie]
    adata.obs["modality"] = MODALITY_DICT[modality]
    adata.obs["tissue_type"] = tissue_type

    # -- Optional obs columns (create defaults if missing) --------------------
    if author_cell_type_key not in adata.obs.columns:
        logger.warning(
            f"'{author_cell_type_key}' not found in obs; " f"setting author_cell_type = 'unknown'"
        )
        adata.obs["author_cell_type"] = "unknown"
    elif author_cell_type_key != "author_cell_type":
        adata.obs["author_cell_type"] = adata.obs[author_cell_type_key]

    if library_key not in adata.obs.columns:
        logger.warning(f"'{library_key}' not found in obs; " f"setting library_key = 'sample_0'")
        adata.obs["library_key"] = "sample_0"
    elif library_key != "library_key":
        adata.obs["library_key"] = adata.obs[library_key]

    if condition_id_key not in adata.obs.columns:
        logger.warning(
            f"'{condition_id_key}' not found in obs; " f"setting condition_id = 'condition_0'"
        )
        adata.obs["condition_id"] = "condition_0"
    elif condition_id_key != "condition_id":
        adata.obs["condition_id"] = adata.obs[condition_id_key]

    # -- Train / val / test split ---------------------------------------------
    if split_key is not None:
        if split_key not in adata.obs.columns:
            raise ValueError(f"split_key='{split_key}' not found in adata.obs")
        invalid = set(adata.obs[split_key].unique()) - _VALID_SPLITS
        if invalid:
            raise ValueError(
                f"split_key column contains invalid values: {invalid}. "
                f"Must be in {_VALID_SPLITS}."
            )
        adata.obs["nicheformer_split"] = adata.obs[split_key]
    else:
        rng = np.random.default_rng(random_state)
        n = adata.n_obs
        perm = rng.permutation(n)
        n_train = int(n * split_ratios[0])
        n_val = int(n * split_ratios[1])
        splits = np.empty(n, dtype=object)
        splits[perm[:n_train]] = "train"
        splits[perm[n_train : n_train + n_val]] = "val"
        splits[perm[n_train + n_val :]] = "test"
        adata.obs["nicheformer_split"] = splits

    logger.info(
        f"prepare_nicheformer_obs: technology={technology} (token={TECHNOLOGY_DICT[technology]}), "
        f"specie={specie} (token={SPECIE_DICT[specie]}), "
        f"modality={modality} (token={MODALITY_DICT[modality]})"
    )
    split_counts = adata.obs["nicheformer_split"].value_counts().to_dict()
    logger.info(f"  Split counts: {split_counts}")

    return adata


# ---------------------------------------------------------------------------
# 2. Tokenisation
# ---------------------------------------------------------------------------


def tokenize_for_nicheformer(
    adata: sc.AnnData,
    technology_mean: np.ndarray,
    split: str = "train",
    max_seq_len: int = 4096,
    chunk_size: int = 1000,
    metadata_fields: dict | None = None,
) -> Any:
    """
    Tokenise an AnnData object into a ``NicheformerDataset``.

    Tokenisation pipeline (mirrors ``NicheformerDataset._process_chunk``):
      1. TP10k normalise raw counts.
      2. Divide by per-gene technology median (``technology_mean``).
      3. Rank genes by normalised score (descending).
      4. Keep top ``max_seq_len`` gene indices, offset by 30 reserved tokens.

    Parameters
    ----------
    adata : AnnData
        Input data.  Must have ``nicheformer_split`` in obs (call
        ``prepare_nicheformer_obs`` first).
    technology_mean : np.ndarray
        Per-gene median counts for the target technology.  Shape: (n_genes,).
        Load from the ``model_means/`` directory distributed with Nicheformer
        (e.g. ``xenium_mean_script.npy``).
    split : str, default "train"
        Which split to tokenise: "train", "val", or "test".
    max_seq_len : int, default 4096
        Maximum number of gene tokens per cell.
    chunk_size : int, default 1000
        Number of cells to process per chunk (controls peak memory usage).
    metadata_fields : dict, optional
        Extra obs / obsm fields to include in each dataset item.
        Format: ``{"obs": ["field1"], "obsm": ["X_niche"]}``.

    Returns
    -------
    nicheformer.data.dataset.NicheformerDataset
        PyTorch Dataset ready for use with a DataLoader.

    Raises
    ------
    ImportError
        If nicheformer is not installed.
    ValueError
        If ``nicheformer_split`` is missing from obs.

    Examples
    --------
    >>> technology_mean = np.load("model_means/xenium_mean_script.npy")
    >>> technology_mean = np.nan_to_num(technology_mean)
    >>> technology_mean = np.where(technology_mean == 0, 1, technology_mean)
    >>> dataset = tokenize_for_nicheformer(adata, technology_mean, split="train")
    >>> loader = torch.utils.data.DataLoader(dataset, batch_size=64)
    """
    if not HAS_NICHEFORMER:
        raise ImportError(
            "nicheformer is required for this function. "
            "Install from https://github.com/theislab/nicheformer"
        )

    from nicheformer.data.dataset import NicheformerDataset

    if "nicheformer_split" not in adata.obs.columns:
        raise ValueError(
            "adata.obs is missing 'nicheformer_split'. " "Call prepare_nicheformer_obs() first."
        )

    # Sanitise technology_mean: replace NaN with 0, replace 0 with 1
    technology_mean = np.nan_to_num(technology_mean).copy()
    technology_mean = np.where(technology_mean == 0, 1.0, technology_mean)

    dataset = NicheformerDataset(
        adata=adata,
        technology_mean=technology_mean,
        split=split,
        max_seq_len=max_seq_len,
        chunk_size=chunk_size,
        metadata_fields=metadata_fields or {"obs": [], "obsm": []},
    )

    logger.info(f"tokenize_for_nicheformer: {len(dataset)} cells in split='{split}'")
    return dataset


# ---------------------------------------------------------------------------
# 3. Load pre-trained backbone
# ---------------------------------------------------------------------------


def load_nicheformer_model(
    checkpoint_path: str,
    use_gpu: bool = False,
) -> Any:
    """
    Load a pre-trained Nicheformer backbone from a Lightning checkpoint.

    Parameters
    ----------
    checkpoint_path : str
        Path to the ``.ckpt`` file (pre-trained backbone, NOT fine-tuned).
    use_gpu : bool, default False
        Move the model to GPU after loading.

    Returns
    -------
    nicheformer.models.Nicheformer
        Loaded backbone model in eval mode.

    Raises
    ------
    ImportError
        If nicheformer or pytorch_lightning are not installed.
    FileNotFoundError
        If the checkpoint file does not exist.

    Examples
    --------
    >>> model = load_nicheformer_model("checkpoints/nicheformer.ckpt")
    >>> print(model.hparams)
    """
    if not HAS_NICHEFORMER:
        raise ImportError(
            "nicheformer is required for this function. "
            "Install from https://github.com/theislab/nicheformer"
        )
    if not HAS_PL:
        raise ImportError(
            "pytorch_lightning is required for this function. "
            "Install with: pip install pytorch_lightning"
        )

    import os

    from nicheformer.models._nicheformer import Nicheformer

    if not os.path.isfile(checkpoint_path):
        raise FileNotFoundError(f"Nicheformer checkpoint not found: {checkpoint_path}")

    logger.info(f"Loading Nicheformer backbone from {checkpoint_path}")
    model = Nicheformer.load_from_checkpoint(checkpoint_path=checkpoint_path)
    model.eval()

    if use_gpu:

        model = model.cuda()

    logger.info(
        f"Nicheformer loaded: dim_model={model.hparams.dim_model}, "
        f"nlayers={model.hparams.nlayers}, "
        f"context_length={model.hparams.context_length}"
    )
    return model


# ---------------------------------------------------------------------------
# 4. Extract embeddings
# ---------------------------------------------------------------------------


def get_nicheformer_embeddings(
    adata: sc.AnnData,
    checkpoint_path: str | None = None,
    model: Any = None,
    technology_mean: np.ndarray | None = None,
    split: str = "test",
    batch_size: int = 64,
    use_gpu: bool = False,
    layer: int = -1,
    obsm_key: str = "X_nicheformer",
    inplace: bool = False,
) -> sc.AnnData:
    """
    Extract 512-dim Nicheformer embeddings for all cells in a given split.

    The embeddings are the mean-pooled hidden states from the last (or
    specified) transformer layer, excluding the 3 auxiliary context tokens
    (specie, assay, modality).

    Parameters
    ----------
    adata : AnnData
        Input data.  Must have been prepared with ``prepare_nicheformer_obs``
        and have ``nicheformer_split`` in obs.
    checkpoint_path : str, optional
        Path to the pre-trained backbone checkpoint.  Required if ``model``
        is None.
    model : Nicheformer, optional
        Pre-loaded backbone.  If None, ``checkpoint_path`` must be provided.
    technology_mean : np.ndarray
        Per-gene technology median counts.  Required.
    split : str, default "test"
        Which split to embed.
    batch_size : int, default 64
        Inference batch size.
    use_gpu : bool, default False
        Run inference on GPU.
    layer : int, default -1
        Transformer layer to extract embeddings from (-1 = last layer).
    obsm_key : str, default "X_nicheformer"
        Key under which embeddings are stored in ``adata.obsm``.
    inplace : bool, default False
        Modify ``adata`` in place.

    Returns
    -------
    AnnData
        ``adata`` with embeddings stored in ``obsm[obsm_key]`` for cells
        in the requested split.

    Raises
    ------
    ImportError
        If nicheformer or pytorch_lightning are not installed.
    ValueError
        If neither ``model`` nor ``checkpoint_path`` is provided, or if
        ``technology_mean`` is None.

    Examples
    --------
    >>> technology_mean = np.load("model_means/xenium_mean_script.npy")
    >>> adata = get_nicheformer_embeddings(
    ...     adata,
    ...     checkpoint_path="checkpoints/nicheformer.ckpt",
    ...     technology_mean=technology_mean,
    ...     split="test",
    ... )
    >>> print(adata.obsm["X_nicheformer"].shape)
    """
    if not HAS_NICHEFORMER:
        raise ImportError(
            "nicheformer is required for this function. "
            "Install from https://github.com/theislab/nicheformer"
        )
    if not HAS_PL:
        raise ImportError(
            "pytorch_lightning is required for this function. "
            "Install with: pip install pytorch_lightning"
        )

    import torch
    from nicheformer.models._nicheformer_fine_tune import NicheformerFineTune

    if technology_mean is None:
        raise ValueError("technology_mean must be provided.")
    if model is None:
        if checkpoint_path is None:
            raise ValueError("Either model or checkpoint_path must be provided.")
        model = load_nicheformer_model(checkpoint_path, use_gpu=use_gpu)

    if not inplace:
        adata = adata.copy()

    # Tokenise the requested split
    dataset = tokenize_for_nicheformer(
        adata,
        technology_mean=technology_mean,
        split=split,
        metadata_fields={
            "obs": ["assay", "specie", "modality"],
            "obsm": [],
        },
    )

    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        drop_last=False,
    )

    device = "cuda" if use_gpu else "cpu"
    model = model.to(device)
    model.eval()

    # Wrap backbone in a minimal fine-tune shell to reuse on_after_batch_transfer
    # and get_embeddings.  We use a dummy task that won't be called.
    fine_tune = NicheformerFineTune(
        backbone=model,
        supervised_task="niche_regression",
        extract_layers=[model.hparams.nlayers - 1],
        function_layers="mean",
        lr=1e-4,
        warmup=100,
        max_epochs=1,
        dim_prediction=1,
        freeze=True,
        without_context=True,
    ).to(device)
    fine_tune.eval()

    all_embeddings = []
    with torch.no_grad():
        for batch in loader:
            # Move to device
            batch = {
                k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()
            }
            # Prepend auxiliary tokens (specie, assay, modality)
            batch = fine_tune.on_after_batch_transfer(batch, 0)
            # Extract embeddings from the specified layer
            emb = fine_tune.get_embeddings(batch, layer=layer)
            # Mean-pool over gene tokens (skip first 3 auxiliary tokens)
            emb = emb[:, 3:, :].mean(dim=1)
            all_embeddings.append(emb.detach().cpu().numpy())

    embeddings = np.concatenate(all_embeddings, axis=0)

    # Write back to the correct cells in adata
    split_mask = adata.obs["nicheformer_split"] == split
    adata.obsm[obsm_key] = np.zeros((adata.n_obs, embeddings.shape[1]), dtype=np.float32)
    adata.obsm[obsm_key][split_mask.values] = embeddings

    logger.info(
        f"get_nicheformer_embeddings: {embeddings.shape[0]} cells embedded "
        f"(split='{split}'), stored in obsm['{obsm_key}']"
    )
    return adata


# ---------------------------------------------------------------------------
# 5. Fine-tuning
# ---------------------------------------------------------------------------


def fine_tune_nicheformer(
    adata: sc.AnnData,
    checkpoint_path: str,
    technology_mean: np.ndarray,
    supervised_task: str,
    label_key: str,
    output_dir: str,
    dim_prediction: int = 1,
    n_classes: int = 10,
    freeze: bool = False,
    extract_layers: list[int] | None = None,
    function_layers: str = "mean",
    lr: float = 1e-4,
    warmup: int = 500,
    max_epochs: int = 10,
    batch_size: int = 64,
    use_gpu: bool = False,
    regress_distribution: bool = False,
    pool: str = "mean",
    predict_density: bool = False,
    ignore_zeros: bool = False,
) -> Any:
    """
    Fine-tune a pre-trained Nicheformer backbone on a downstream task.

    Supported tasks
    ---------------
    ``niche_regression``
        Predict a continuous niche composition vector (MSE loss).
        Set ``dim_prediction`` to the number of niche components.
    ``density_regression``
        Predict scalar cell density (MSE loss).
    ``niche_classification``
        Classify cells into ``n_classes`` niche categories (CrossEntropy).
    ``niche_binary_classification``
        Binary classification per niche component (CrossEntropy).
    ``niche_multiclass_classification``
        Multi-class classification (CrossEntropy).

    Parameters
    ----------
    adata : AnnData
        Input data prepared with ``prepare_nicheformer_obs``.
    checkpoint_path : str
        Path to the pre-trained backbone ``.ckpt`` file.
    technology_mean : np.ndarray
        Per-gene technology median counts.
    supervised_task : str
        One of the supported task strings listed above.
    label_key : str
        obs or obsm column to use as the prediction target.
        Must be present in the dataset items (add to ``metadata_fields``).
    output_dir : str
        Directory to save fine-tuned model checkpoints.
    dim_prediction : int, default 1
        Output dimension (number of niche components for regression tasks).
    n_classes : int, default 10
        Number of classes for classification tasks.
    freeze : bool, default False
        If True, freeze backbone weights and only train the linear head.
    extract_layers : list of int, optional
        Transformer layer indices to extract features from.
        Defaults to [last_layer].
    function_layers : str, default "mean"
        How to combine extracted layers: "mean", "sum", or "concat".
    lr : float, default 1e-4
        Learning rate.
    warmup : int, default 500
        Number of warmup steps for cosine LR schedule.
    max_epochs : int, default 10
        Maximum training epochs.
    batch_size : int, default 64
        Training batch size.
    use_gpu : bool, default False
        Train on GPU.
    regress_distribution : bool, default False
        If True, apply softmax to predictions (for distribution regression).
    pool : str, default "mean"
        Pooling strategy: "mean" or "cls".
    predict_density : bool, default False
        If True, predict scalar density from the label sum.
    ignore_zeros : bool, default False
        If True, ignore zero labels in classification loss.

    Returns
    -------
    NicheformerFineTune
        Trained fine-tuning model.

    Raises
    ------
    ImportError
        If nicheformer or pytorch_lightning are not installed.

    Examples
    --------
    >>> fine_tune_model = fine_tune_nicheformer(
    ...     adata,
    ...     checkpoint_path="checkpoints/nicheformer.ckpt",
    ...     technology_mean=technology_mean,
    ...     supervised_task="niche_classification",
    ...     label_key="niche",
    ...     output_dir="fine_tuned/",
    ...     n_classes=5,
    ...     max_epochs=5,
    ... )
    """
    if not HAS_NICHEFORMER:
        raise ImportError(
            "nicheformer is required for this function. "
            "Install from https://github.com/theislab/nicheformer"
        )
    if not HAS_PL:
        raise ImportError(
            "pytorch_lightning is required for this function. "
            "Install with: pip install pytorch_lightning"
        )

    import os

    from nicheformer.models._nicheformer_fine_tune import NicheformerFineTune
    from pytorch_lightning.callbacks import LearningRateMonitor, ModelCheckpoint
    from torch.utils.data import DataLoader

    os.makedirs(output_dir, exist_ok=True)

    # -- Load backbone --------------------------------------------------------
    backbone = load_nicheformer_model(checkpoint_path, use_gpu=use_gpu)

    # -- Determine extract_layers default ------------------------------------
    if extract_layers is None:
        extract_layers = [backbone.hparams.nlayers - 1]

    # -- Build fine-tune model ------------------------------------------------
    fine_tune_model = NicheformerFineTune(
        backbone=backbone,
        supervised_task=supervised_task,
        extract_layers=extract_layers,
        function_layers=function_layers,
        lr=lr,
        warmup=warmup,
        max_epochs=max_epochs,
        dim_prediction=dim_prediction,
        n_classes=n_classes,
        freeze=freeze,
        regress_distribution=regress_distribution,
        pool=pool,
        predict_density=predict_density,
        ignore_zeros=ignore_zeros,
        label=label_key,
        without_context=True,
    )

    # -- Build datasets -------------------------------------------------------
    metadata_fields = {"obs": ["assay", "specie", "modality", label_key], "obsm": []}
    train_ds = tokenize_for_nicheformer(
        adata,
        technology_mean,
        split="train",
        metadata_fields=metadata_fields,
    )
    val_ds = tokenize_for_nicheformer(
        adata,
        technology_mean,
        split="val",
        metadata_fields=metadata_fields,
    )

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, drop_last=False)

    # -- Trainer --------------------------------------------------------------
    accelerator = "gpu" if use_gpu else "cpu"
    callbacks = [
        ModelCheckpoint(
            dirpath=output_dir,
            monitor=(
                "val/regression_loss"
                if "regression" in supervised_task
                else "val/classification_loss"
            ),
            save_top_k=1,
            mode="min",
        ),
        LearningRateMonitor(logging_interval="step"),
    ]

    trainer = pl.Trainer(
        accelerator=accelerator,
        max_epochs=max_epochs,
        devices=1,
        callbacks=callbacks,
        gradient_clip_val=1.0,
        precision="bf16-mixed" if use_gpu else 32,
    )

    logger.info(
        f"Fine-tuning Nicheformer: task={supervised_task}, "
        f"label={label_key}, epochs={max_epochs}, freeze={freeze}"
    )
    trainer.fit(
        model=fine_tune_model,
        train_dataloaders=train_loader,
        val_dataloaders=val_loader,
    )

    return fine_tune_model


# ---------------------------------------------------------------------------
# 6. Prediction extraction
# ---------------------------------------------------------------------------


def get_nicheformer_predictions(
    adata: sc.AnnData,
    fine_tune_model: Any,
    technology_mean: np.ndarray,
    split: str = "test",
    batch_size: int = 64,
    use_gpu: bool = False,
    confidence_threshold: float = 0.5,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Run inference with a fine-tuned Nicheformer model and extract predictions.

    For classification tasks, predictions are the argmax class index and
    confidence is the softmax probability of the winning class.

    For regression tasks, predictions are the raw output vectors and
    confidence is set to 1.0 for all cells (no natural confidence metric).

    Parameters
    ----------
    adata : AnnData
        Input data prepared with ``prepare_nicheformer_obs``.
    fine_tune_model : NicheformerFineTune
        Fine-tuned model (output of ``fine_tune_nicheformer``).
    technology_mean : np.ndarray
        Per-gene technology median counts.
    split : str, default "test"
        Which split to run inference on.
    batch_size : int, default 64
        Inference batch size.
    use_gpu : bool, default False
        Run inference on GPU.
    confidence_threshold : float, default 0.5
        Minimum softmax confidence to accept a classification prediction
        without refinement.  Only used for classification tasks.

    Returns
    -------
    predictions : np.ndarray
        Predicted class indices (classification) or output vectors (regression).
    confidences : np.ndarray of float
        Confidence scores in [0, 1].
    needs_refinement : np.ndarray of bool
        True for cells below ``confidence_threshold`` (classification only;
        always False for regression tasks).

    Raises
    ------
    ImportError
        If nicheformer or pytorch_lightning are not installed.

    Examples
    --------
    >>> preds, confs, needs_refine = get_nicheformer_predictions(
    ...     adata, fine_tune_model, technology_mean, split="test"
    ... )
    >>> print(f"{needs_refine.sum()} cells need refinement")
    """
    if not HAS_NICHEFORMER:
        raise ImportError(
            "nicheformer is required for this function. "
            "Install from https://github.com/theislab/nicheformer"
        )

    import torch
    from torch.utils.data import DataLoader

    dataset = tokenize_for_nicheformer(
        adata,
        technology_mean=technology_mean,
        split=split,
        metadata_fields={"obs": ["assay", "specie", "modality"], "obsm": []},
    )
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, drop_last=False)

    device = "cuda" if use_gpu else "cpu"
    fine_tune_model = fine_tune_model.to(device)
    fine_tune_model.eval()

    all_logits = []

    with torch.no_grad():
        for batch in loader:
            batch = {
                k: v.to(device) if isinstance(v, torch.Tensor) else v for k, v in batch.items()
            }
            batch = fine_tune_model.on_after_batch_transfer(batch, 0)
            out = fine_tune_model.forward(batch["X"], batch.get("attention_mask"))
            logits = out["cls_prediction"]
            all_logits.append(logits.detach().cpu())

    logits_all = torch.cat(all_logits, dim=0)
    task = fine_tune_model.task  # "classification" or "regression"

    if task == "classification":
        probs = torch.softmax(logits_all, dim=-1)
        confidences = probs.max(dim=-1).values.numpy()
        predictions = probs.argmax(dim=-1).numpy()
        needs_refinement = confidences < confidence_threshold
    else:
        predictions = logits_all.numpy()
        confidences = np.ones(len(predictions), dtype=float)
        needs_refinement = np.zeros(len(predictions), dtype=bool)

    n_high = (~needs_refinement).sum()
    n_low = needs_refinement.sum()
    logger.info(
        f"get_nicheformer_predictions: {n_high} high-confidence, "
        f"{n_low} need refinement (threshold={confidence_threshold})"
    )

    return predictions, confidences, needs_refinement


# ---------------------------------------------------------------------------
# 7. Pre-flight diagnostics
# ---------------------------------------------------------------------------


def diagnose_nicheformer(
    adata: sc.AnnData,
    model_h5ad_path: str,
    output_folder: str,
) -> dict:
    """
    Run pre-flight checks before Nicheformer tokenisation.

    Checks
    ------
    1. Required obs columns are present.
    2. ``nicheformer_split`` values are in {"train", "val", "test"}.
    3. ``tissue_type`` values are in {"tissue", "organoid"}.
    4. Gene overlap between ``adata.var.index`` and the model gene vocabulary
       (loaded from ``model_h5ad_path``).  Nicheformer zero-pads missing genes,
       so low overlap reduces information but does not raise an error.
    5. Whether ``adata.X`` appears to contain raw counts (non-negative integers).

    Parameters
    ----------
    adata : AnnData
        Query dataset to check.
    model_h5ad_path : str
        Path to the model reference h5ad (``model_means/model.h5ad``).
        Used to load the model gene vocabulary.
    output_folder : str
        Directory to save the text diagnostic report.

    Returns
    -------
    dict with keys:
        ``missing_obs_cols``   : list of missing required obs columns
        ``gene_overlap``       : int
        ``panel_coverage_pct`` : float — % of panel genes in model vocabulary
        ``model_coverage_pct`` : float — % of model genes covered by panel
        ``looks_like_raw``     : bool — whether X appears to be raw counts
        ``passes_obs``         : bool — all required obs columns present
        ``passes_split``       : bool — nicheformer_split values are valid

    Examples
    --------
    >>> info = diagnose_nicheformer(
    ...     adata,
    ...     model_h5ad_path="model_means/model.h5ad",
    ...     output_folder="qc/",
    ... )
    """
    import os
    from pathlib import Path

    from scipy.sparse import issparse

    os.makedirs(output_folder, exist_ok=True)

    # -- 1. Required obs columns ----------------------------------------------
    missing_obs = [c for c in _REQUIRED_OBS_COLS if c not in adata.obs.columns]
    passes_obs = len(missing_obs) == 0

    # -- 2. Split values ------------------------------------------------------
    passes_split = True
    if "nicheformer_split" in adata.obs.columns:
        invalid_splits = set(adata.obs["nicheformer_split"].unique()) - _VALID_SPLITS
        passes_split = len(invalid_splits) == 0
    else:
        invalid_splits = set()

    # -- 3. tissue_type values ------------------------------------------------
    passes_tissue = True
    if "tissue_type" in adata.obs.columns:
        invalid_tissue = set(adata.obs["tissue_type"].unique()) - _VALID_TISSUE_TYPES
        passes_tissue = len(invalid_tissue) == 0
    else:
        invalid_tissue = set()

    # -- 4. Gene overlap with model vocabulary --------------------------------
    gene_overlap = 0
    panel_coverage = 0.0
    model_coverage = 0.0
    model_genes: set[str] = set()

    if os.path.isfile(model_h5ad_path):
        model_ref = sc.read_h5ad(model_h5ad_path)
        model_genes = set(model_ref.var.index)
        panel_genes = set(adata.var.index)
        overlap = model_genes & panel_genes
        gene_overlap = len(overlap)
        panel_coverage = 100.0 * gene_overlap / max(len(panel_genes), 1)
        model_coverage = 100.0 * gene_overlap / max(len(model_genes), 1)
    else:
        logger.warning(
            f"model_h5ad_path not found: {model_h5ad_path}. " f"Skipping gene overlap check."
        )

    # -- 5. Raw counts check --------------------------------------------------
    X = adata.X
    if issparse(X):
        sample = X[: min(100, adata.n_obs), :].toarray()
    else:
        sample = np.array(X[: min(100, adata.n_obs), :])
    looks_like_raw = (
        np.all(sample >= 0) and np.all(sample == np.floor(sample)) and sample.max() > 1.0
    )

    sep = "=" * 60
    lines = [
        sep,
        "Nicheformer pre-flight diagnostic",
        sep,
        f"  Required obs columns present : {'YES' if passes_obs else 'NO'}",
    ]
    if missing_obs:
        lines.append(f"    Missing: {missing_obs}")
    lines += [
        f"  nicheformer_split valid      : {'YES' if passes_split else 'NO'}",
    ]
    if invalid_splits:
        lines.append(f"    Invalid values: {invalid_splits}")
    lines += [
        f"  tissue_type valid            : {'YES' if passes_tissue else 'NO'}",
    ]
    if invalid_tissue:
        lines.append(f"    Invalid values: {invalid_tissue}")
    lines += [
        "",
        f"  Panel genes                  : {adata.n_vars}",
        f"  Model genes                  : {len(model_genes) if model_genes else 'N/A (model.h5ad not found)'}",
        f"  Gene overlap                 : {gene_overlap}",
        f"  Panel coverage               : {panel_coverage:.1f}%",
        f"  Model coverage               : {model_coverage:.1f}%",
        "",
        f"  X looks like raw counts      : {'YES' if looks_like_raw else 'NO  ← WARNING: Nicheformer expects raw counts'}",
        sep,
    ]

    report = "\n".join(lines)
    print(report)

    report_path = Path(output_folder) / "nicheformer_diagnostic.txt"
    with open(report_path, "w") as fh:
        fh.write(report + "\n")
    print(f"  Report saved → {report_path}")

    return {
        "missing_obs_cols": missing_obs,
        "gene_overlap": gene_overlap,
        "panel_coverage_pct": panel_coverage,
        "model_coverage_pct": model_coverage,
        "looks_like_raw": looks_like_raw,
        "passes_obs": passes_obs,
        "passes_split": passes_split,
    }


# ---------------------------------------------------------------------------
# 8. High-level entry point
# ---------------------------------------------------------------------------


def cell_typing_nicheformer(
    merged_adata: sc.AnnData,
    checkpoint_path: str,
    technology_mean_path: str,
    output_folder: str,
    model_h5ad_path: str | None = None,
    technology: str = "Xenium",
    specie: str = "human",
    modality: str = "spatial",
    supervised_task: str = "niche_classification",
    label_key: str = "author_cell_type",
    n_classes: int = 10,
    dim_prediction: int = 1,
    freeze: bool = False,
    max_epochs: int = 10,
    batch_size: int = 64,
    use_gpu: bool = False,
    confidence_threshold: float = 0.5,
    split_ratios: tuple[float, float, float] = (0.8, 0.1, 0.1),
    author_cell_type_key: str = "author_cell_type",
    library_key: str = "library_key",
    condition_id_key: str = "condition_id",
    tissue_type: str = "tissue",
) -> sc.AnnData:
    """
    High-level Nicheformer annotation pipeline with diagnostics and QC plots.

    This is the recommended entry point.  It mirrors the structure of
    ``cell_typing_celltypist`` and ``cell_typing_scimilarity``:

    Steps
    -----
    1. Prepare obs columns (``prepare_nicheformer_obs``).
    2. Run pre-flight diagnostics (``diagnose_nicheformer``).
    3. Fine-tune the backbone on the downstream task (``fine_tune_nicheformer``).
    4. Extract predictions on the test split (``get_nicheformer_predictions``).
    5. Extract embeddings and store in ``obsm["X_nicheformer"]``.
    6. Save diagnostic plots to ``output_folder``.

    Adds to ``merged_adata.obs``
    ----------------------------
    nicheformer_prediction   : predicted class index (classification) or
                               raw output (regression)
    nicheformer_confidence   : confidence score [0, 1]
    nicheformer_split        : train / val / test assignment

    Adds to ``merged_adata.obsm``
    -----------------------------
    X_nicheformer            : 512-dim embedding

    Parameters
    ----------
    merged_adata : AnnData
        Output of batch correction.  Must have raw counts in ``X`` and
        HGNC gene symbols as ``var.index``.
    checkpoint_path : str
        Path to the pre-trained Nicheformer backbone ``.ckpt`` file.
    technology_mean_path : str
        Path to the per-gene technology median ``.npy`` file
        (e.g. ``model_means/xenium_mean_script.npy``).
    output_folder : str
        Directory for diagnostic plots and text report.
    model_h5ad_path : str, optional
        Path to ``model_means/model.h5ad`` for gene overlap diagnostics.
        If None, the gene overlap check is skipped.
    technology : str, default "Xenium"
        Technology name (see ``TECHNOLOGY_DICT``).
    specie : str, default "human"
        Species (see ``SPECIE_DICT``).
    modality : str, default "spatial"
        Modality (see ``MODALITY_DICT``).
    supervised_task : str, default "niche_classification"
        Fine-tuning task.
    label_key : str, default "author_cell_type"
        obs column to use as the prediction target.
    n_classes : int, default 10
        Number of classes for classification tasks.
    dim_prediction : int, default 1
        Output dimension for regression tasks.
    freeze : bool, default False
        Freeze backbone during fine-tuning.
    max_epochs : int, default 10
        Fine-tuning epochs.
    batch_size : int, default 64
        Batch size for training and inference.
    use_gpu : bool, default False
        Use GPU.
    confidence_threshold : float, default 0.5
        Minimum confidence to accept a prediction without refinement.
    split_ratios : tuple, default (0.8, 0.1, 0.1)
        Train / val / test split fractions.
    author_cell_type_key : str, default "author_cell_type"
        obs column with ground-truth cell type labels.
    library_key : str, default "library_key"
        obs column with sample identifiers.
    condition_id_key : str, default "condition_id"
        obs column with condition strings.
    tissue_type : str, default "tissue"
        "tissue" or "organoid".

    Returns
    -------
    AnnData
        ``merged_adata`` with Nicheformer annotations in ``.obs`` and
        ``.obsm["X_nicheformer"]``.

    Examples
    --------
    >>> merged_adata = cell_typing_nicheformer(
    ...     merged_adata,
    ...     checkpoint_path="checkpoints/nicheformer.ckpt",
    ...     technology_mean_path="model_means/xenium_mean_script.npy",
    ...     output_folder="results/nicheformer/",
    ...     technology="Xenium",
    ...     supervised_task="niche_classification",
    ...     label_key="author_cell_type",
    ...     n_classes=8,
    ...     max_epochs=5,
    ... )
    """
    if not HAS_NICHEFORMER:
        raise ImportError(
            "nicheformer is required for this function. "
            "Install from https://github.com/theislab/nicheformer"
        )

    import os
    from pathlib import Path

    import matplotlib.pyplot as plt

    os.makedirs(output_folder, exist_ok=True)

    # -- 1. Prepare obs columns -----------------------------------------------
    print("Preparing Nicheformer obs columns...")
    merged_adata = prepare_nicheformer_obs(
        merged_adata,
        technology=technology,
        specie=specie,
        modality=modality,
        split_ratios=split_ratios,
        author_cell_type_key=author_cell_type_key,
        library_key=library_key,
        condition_id_key=condition_id_key,
        tissue_type=tissue_type,
        inplace=False,
    )

    # -- 2. Load technology mean ----------------------------------------------
    print(f"Loading technology mean from {technology_mean_path}...")
    technology_mean = np.load(technology_mean_path)
    technology_mean = np.nan_to_num(technology_mean)
    # Round to nearest integer, replace 0 with 1 (as in xenium_human_colon.ipynb)
    rounded = np.where(
        (technology_mean % 1) >= 0.5,
        np.ceil(technology_mean),
        np.floor(technology_mean),
    )
    technology_mean = np.where(technology_mean == 0, 1.0, rounded)

    # -- 3. Pre-flight diagnostics --------------------------------------------
    print("Running pre-flight diagnostics...")
    diag = diagnose_nicheformer(
        merged_adata,
        model_h5ad_path=model_h5ad_path or "",
        output_folder=output_folder,
    )

    if not diag["passes_obs"]:
        raise RuntimeError(
            f"Missing required obs columns: {diag['missing_obs_cols']}. "
            f"Call prepare_nicheformer_obs() first."
        )

    # -- 4. Fine-tune ---------------------------------------------------------
    print(
        f"Fine-tuning Nicheformer (task={supervised_task}, "
        f"label={label_key}, epochs={max_epochs})..."
    )
    fine_tune_model = fine_tune_nicheformer(
        merged_adata,
        checkpoint_path=checkpoint_path,
        technology_mean=technology_mean,
        supervised_task=supervised_task,
        label_key=label_key,
        output_dir=str(Path(output_folder) / "checkpoints"),
        dim_prediction=dim_prediction,
        n_classes=n_classes,
        freeze=freeze,
        max_epochs=max_epochs,
        batch_size=batch_size,
        use_gpu=use_gpu,
    )

    # -- 5. Predictions on test split -----------------------------------------
    print("Extracting predictions on test split...")
    predictions, confidences, needs_refinement = get_nicheformer_predictions(
        merged_adata,
        fine_tune_model=fine_tune_model,
        technology_mean=technology_mean,
        split="test",
        batch_size=batch_size,
        use_gpu=use_gpu,
        confidence_threshold=confidence_threshold,
    )

    # Write predictions back to the test cells
    test_mask = merged_adata.obs["nicheformer_split"] == "test"
    merged_adata.obs["nicheformer_prediction"] = np.nan
    merged_adata.obs["nicheformer_confidence"] = np.nan
    merged_adata.obs.loc[test_mask, "nicheformer_prediction"] = predictions
    merged_adata.obs.loc[test_mask, "nicheformer_confidence"] = confidences

    pct_uncertain = 100.0 * needs_refinement.sum() / max(len(needs_refinement), 1)
    print(
        f"  Test cells: {test_mask.sum()} | "
        f"Uncertain (conf<{confidence_threshold}): "
        f"{needs_refinement.sum()} ({pct_uncertain:.1f}%)"
    )

    # -- 6. Embeddings --------------------------------------------------------
    print("Extracting embeddings on test split...")
    merged_adata = get_nicheformer_embeddings(
        merged_adata,
        model=fine_tune_model.backbone,
        technology_mean=technology_mean,
        split="test",
        batch_size=batch_size,
        use_gpu=use_gpu,
        obsm_key="X_nicheformer",
        inplace=True,
    )

    # -- 7. Diagnostic plots --------------------------------------------------
    umap_key = "umap_corrected" if "umap_corrected" in merged_adata.obsm else "X_umap"
    has_umap = umap_key in merged_adata.obsm

    if has_umap:
        fig, axs = plt.subplots(1, 2, figsize=(14, 6), gridspec_kw={"wspace": 0.4})
        sc.pl.embedding(
            merged_adata[test_mask],
            basis=umap_key,
            color="nicheformer_prediction",
            ax=axs[0],
            show=False,
            title="Nicheformer predictions (test split)",
            legend_loc="on data",
            legend_fontsize=6,
            legend_fontoutline=1,
            frameon=False,
        )
        sc.pl.embedding(
            merged_adata[test_mask],
            basis=umap_key,
            color="nicheformer_confidence",
            ax=axs[1],
            show=False,
            color_map="plasma",
            vmin=0,
            vmax=1,
            title="Nicheformer confidence (test split)",
            frameon=False,
        )
        plt.savefig(
            Path(output_folder) / "nicheformer_umap.png",
            dpi=150,
            bbox_inches="tight",
        )
        plt.close()
        print("  Saved: nicheformer_umap.png")
    else:
        print(f"  NOTE: '{umap_key}' not found in obsm — skipping UMAP plots.")

    # Confidence histogram
    conf_vals = merged_adata.obs.loc[test_mask, "nicheformer_confidence"].dropna()
    fig, ax = plt.subplots(figsize=(8, 4))
    conf_vals.hist(bins=50, ax=ax, color="steelblue", edgecolor="white")
    ax.axvline(
        confidence_threshold,
        color="red",
        linestyle="--",
        label=f"threshold = {confidence_threshold}",
    )
    ax.set_xlabel("Confidence score")
    ax.set_ylabel("Cell count")
    ax.set_title("Nicheformer confidence distribution (test split)")
    ax.legend()
    plt.tight_layout()
    plt.savefig(
        Path(output_folder) / "nicheformer_confidence_dist.png",
        dpi=150,
    )
    plt.close()
    print("  Saved: nicheformer_confidence_dist.png")

    return merged_adata
