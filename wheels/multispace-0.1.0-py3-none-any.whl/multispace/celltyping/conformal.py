"""
Conformal Prediction for Cell Type Annotation
==============================================

This module provides conformal prediction methods for uncertainty quantification
in cell type annotation. Conformal prediction provides statistically valid
prediction sets with coverage guarantees.

Methods implemented:
- Simple nonconformity (1 - predicted probability)
- APS (Adaptive Prediction Sets) - Romano et al. 2020
- RAPS (Regularized APS) - Angelopoulos et al. 2021

Example
-------
>>> from multispace.celltyping.conformal import ConformalPredictor
>>>
>>> # Create and calibrate predictor
>>> cp = ConformalPredictor(alpha=0.1, method="aps")
>>> cp.calibrate(calibration_scores, calibration_labels)
>>>
>>> # Get prediction sets with coverage guarantee
>>> predictions, confidences, pred_sets = cp.predict_with_confidence(
...     test_scores, class_names
... )

References
----------
- Romano et al. (2020) "Classification with Valid and Adaptive Coverage"
- Angelopoulos et al. (2021) "Uncertainty Sets for Image Classifiers using
  Conformal Prediction"
"""

from __future__ import annotations

import numpy as np
from sklearn.model_selection import KFold

__all__ = [
    "ConformalPredictor",
    "compute_nonconformity_scores",
    "calibrate_threshold",
    "predict_sets",
    "set_size_to_confidence",
    "cross_conformal_calibrate",
]


class ConformalPredictor:
    """
    Conformal prediction wrapper for cell type annotation.

    Provides statistically valid prediction sets with coverage guarantees.
    Given a miscoverage rate alpha, the prediction sets are guaranteed to
    contain the true class with probability >= (1 - alpha).

    Parameters
    ----------
    alpha : float
        Miscoverage rate. Default 0.1 means 90% coverage guarantee.
    method : str
        Nonconformity method:
        - 'simple': 1 - score of predicted class
        - 'aps': Adaptive Prediction Sets (recommended)
        - 'raps': Regularized APS (for many classes)

    Attributes
    ----------
    threshold : float
        Calibrated nonconformity threshold.
    is_calibrated : bool
        Whether the predictor has been calibrated.

    Examples
    --------
    >>> cp = ConformalPredictor(alpha=0.1, method='aps')
    >>> cp.calibrate(cal_scores, cal_predictions)
    >>> pred_sets = cp.predict(test_scores, class_names)
    >>> confidences = cp.get_confidence(pred_sets, n_classes)
    """

    def __init__(self, alpha: float = 0.1, method: str = "aps"):
        if not 0 < alpha < 1:
            raise ValueError(f"alpha must be in (0, 1), got {alpha}")
        if method not in ("simple", "aps", "raps"):
            raise ValueError(f"method must be 'simple', 'aps', or 'raps', got {method}")

        self.alpha = alpha
        self.method = method
        self.threshold: float | None = None
        self.is_calibrated = False

    def calibrate(self, scores: np.ndarray, true_labels: np.ndarray) -> float:
        """
        Calibrate the conformal predictor using a calibration set.

        Parameters
        ----------
        scores : np.ndarray
            Score matrix from calibration set, shape (n_samples, n_classes).
        true_labels : np.ndarray
            Ground-truth class indices for the calibration set.
            These are the CORRECT labels, not model predictions — the
            nonconformity score is computed for the true class of each sample.

        Returns
        -------
        float
            Calibrated threshold.
        """
        nonconformity = compute_nonconformity_scores(scores, true_labels, method=self.method)
        self.threshold = calibrate_threshold(nonconformity, alpha=self.alpha)
        self.is_calibrated = True
        return self.threshold

    def calibrate_cross(
        self,
        scores: np.ndarray,
        true_labels: np.ndarray,
        n_folds: int = 5,
        random_state: int | None = None,
    ) -> float:
        """
        Calibrate using cross-conformal (no held-out data needed).

        Uses K-fold cross-validation to compute nonconformity scores,
        allowing calibration on the same data used for training.

        Parameters
        ----------
        scores : np.ndarray
            Score matrix, shape (n_samples, n_classes).
        true_labels : np.ndarray
            Ground-truth class indices (not model predictions).
        n_folds : int
            Number of cross-validation folds. Default: 5.
        random_state : int or None
            Random seed for reproducible fold splits.  ``None`` (default)
            means the split is non-deterministic.

        Returns
        -------
        float
            Calibrated threshold.
        """
        self.threshold = cross_conformal_calibrate(
            scores,
            true_labels,
            alpha=self.alpha,
            method=self.method,
            n_folds=n_folds,
            random_state=random_state,
        )
        self.is_calibrated = True
        return self.threshold

    def predict(self, scores: np.ndarray, class_names: list[str]) -> list[list[str]]:
        """
        Generate prediction sets.

        Parameters
        ----------
        scores : np.ndarray
            Score matrix, shape (n_samples, n_classes).
        class_names : List[str]
            Names of classes corresponding to score columns.

        Returns
        -------
        List[List[str]]
            Prediction set for each sample.
        """
        if not self.is_calibrated:
            raise ValueError("Predictor not calibrated. Call calibrate() first.")
        return predict_sets(scores, self.threshold, class_names, method=self.method)

    def get_confidence(self, prediction_sets: list[list[str]], n_classes: int) -> np.ndarray:
        """
        Convert prediction sets to confidence scores.

        Smaller prediction sets indicate higher confidence.

        Parameters
        ----------
        prediction_sets : List[List[str]]
            Prediction sets for each sample.
        n_classes : int
            Total number of possible classes.

        Returns
        -------
        np.ndarray
            Confidence scores in [0, 1].
        """
        return set_size_to_confidence(prediction_sets, n_classes)

    def predict_with_confidence(
        self, scores: np.ndarray, class_names: list[str]
    ) -> tuple[np.ndarray, np.ndarray, list[list[str]]]:
        """
        Predict with confidence scores and prediction sets.

        Parameters
        ----------
        scores : np.ndarray
            Score matrix, shape (n_samples, n_classes).
        class_names : List[str]
            Names of classes.

        Returns
        -------
        predictions : np.ndarray
            Point predictions (first element of each set).
        confidences : np.ndarray
            Confidence scores based on set size.
        prediction_sets : List[List[str]]
            Full prediction sets.
        """
        prediction_sets = self.predict(scores, class_names)
        # C5: use argmax for point prediction rather than ps[0].
        # For 'simple' method, predict_sets adds classes in original column
        # order, so ps[0] is the lowest-indexed passing class, NOT the
        # highest-scoring one.  argmax is always the correct point estimate.
        predictions = np.array([class_names[int(np.argmax(scores[i]))] for i in range(len(scores))])
        confidences = self.get_confidence(prediction_sets, len(class_names))
        return predictions, confidences, prediction_sets


def compute_nonconformity_scores(
    scores: np.ndarray, true_labels: np.ndarray, method: str = "aps"
) -> np.ndarray:
    """
    Compute nonconformity scores for conformal prediction.

    The nonconformity score measures how "unusual" a prediction is.
    Higher scores indicate less conformity (more unusual).

    .. important::
        ``true_labels`` must be **ground-truth class indices**, not model
        predictions.  The nonconformity score is computed for the *correct*
        class of each calibration sample — passing model predictions here
        would silently produce wrong scores and an invalid threshold.

    Parameters
    ----------
    scores : np.ndarray
        Score matrix of shape (n_samples, n_classes).
    true_labels : np.ndarray
        Ground-truth class indices (integers) for each sample.
    method : str
        Nonconformity method:
        - 'simple': 1 - score of the true class
        - 'aps': Adaptive Prediction Sets (cumulative probability up to true class)
        - 'raps': Regularized APS (adds penalty for large sets)

    Returns
    -------
    np.ndarray
        Nonconformity scores for each sample.
    """
    # Delegate to the vectorised implementation in core_utils (single source of truth).
    # This function is kept here so ConformalPredictor and module-level callers
    # have a stable import path within this module.
    from .core_utils import compute_nonconformity_scores as _compute

    return _compute(scores, true_labels, method=method)


def calibrate_threshold(calibration_scores: np.ndarray, alpha: float = 0.1) -> float:
    """
    Calibrate the conformal threshold from calibration data.

    The threshold is set such that (1-alpha) fraction of calibration
    samples have nonconformity scores below the threshold.

    .. note::
        Delegates to ``core_utils.calibrate_conformal_threshold``, which is
        the single source of truth for this computation.

    Parameters
    ----------
    calibration_scores : np.ndarray
        Nonconformity scores from calibration set.
    alpha : float
        Miscoverage rate. Default 0.1 means 90% coverage.

    Returns
    -------
    float
        Calibrated threshold (quantile of nonconformity scores).
    """
    from .core_utils import calibrate_conformal_threshold as _calibrate

    return _calibrate(calibration_scores, alpha=alpha)


def predict_sets(
    scores: np.ndarray,
    threshold: float,
    class_names: list[str],
    method: str = "aps",
    calibration_method: str | None = None,
) -> list[list[str]]:
    """
    Generate prediction sets using conformal prediction.

    Returns the set of classes with nonconformity score <= threshold.
    Guaranteed to contain the true class with probability >= (1 - alpha).

    .. note::
        Delegates to ``core_utils.predict_conformal_sets``, which is the
        single source of truth for this computation.

    .. warning::
        ``method`` must match the method used when the ``threshold`` was
        calibrated.  Mixing methods (e.g. calibrating with ``'aps'`` but
        predicting with ``'simple'``) produces sets with no coverage
        guarantee.  Pass ``calibration_method`` to enable an explicit check.

    Parameters
    ----------
    scores : np.ndarray
        Score matrix of shape (n_samples, n_classes).
    threshold : float
        Calibrated conformal threshold.
    class_names : List[str]
        Names of classes corresponding to score columns.
    method : str
        Nonconformity method to use for prediction ('simple', 'aps', 'raps').
    calibration_method : str or None
        The method that was used during calibration.  When provided and
        different from ``method``, a ``ValueError`` is raised immediately
        rather than silently producing invalid sets.

    Returns
    -------
    List[List[str]]
        Prediction set for each sample.

    Raises
    ------
    ValueError
        If ``calibration_method`` is provided and differs from ``method``.
    """
    # C9: guard against method mismatch between calibration and prediction.
    if calibration_method is not None and calibration_method != method:
        raise ValueError(
            f"predict_sets called with method='{method}' but the threshold was "
            f"calibrated with method='{calibration_method}'.  The prediction sets "
            "will have no coverage guarantee.  Use the same method for both steps."
        )
    from .core_utils import predict_conformal_sets as _predict

    return _predict(scores, threshold, class_names, method=method)


def set_size_to_confidence(prediction_sets: list[list[str]], n_classes: int) -> np.ndarray:
    """
    Convert prediction set sizes to confidence scores.

    Smaller prediction sets indicate higher confidence.

    .. note::
        Delegates to ``core_utils.conformal_set_to_confidence``, which is
        the single source of truth for this computation.

    Parameters
    ----------
    prediction_sets : List[List[str]]
        Prediction sets for each sample.
    n_classes : int
        Total number of possible classes.

    Returns
    -------
    np.ndarray
        Confidence scores in [0, 1].
        1 = single class (high confidence)
        0 = all classes (no confidence)
    """
    from .core_utils import conformal_set_to_confidence as _conf

    return _conf(prediction_sets, n_classes)


def cross_conformal_calibrate(
    scores: np.ndarray,
    true_labels: np.ndarray,
    alpha: float = 0.1,
    method: str = "aps",
    n_folds: int = 5,
    random_state: int | None = None,
) -> float:
    """
    Cross-conformal calibration (no held-out data needed).

    Uses K-fold cross-validation to compute nonconformity scores,
    then calibrates threshold on all scores.

    Parameters
    ----------
    scores : np.ndarray
        Score matrix (n_samples, n_classes).
    true_labels : np.ndarray
        Ground-truth class indices (not model predictions).
    alpha : float
        Miscoverage rate.
    method : str
        Nonconformity method.
    n_folds : int
        Number of cross-validation folds.
    random_state : int or None
        Random seed for reproducible fold splits.  ``None`` (default) means
        the split is non-deterministic.  Pass an integer (e.g. ``42``) for
        reproducibility.

    Returns
    -------
    float
        Calibrated threshold.
    """
    n_samples = len(true_labels)
    all_nonconformity = np.zeros(n_samples)

    # C7: random_state is now a parameter rather than a hardcoded 42.
    kf = KFold(n_splits=n_folds, shuffle=True, random_state=random_state)

    for _, val_idx in kf.split(scores):
        val_scores = scores[val_idx]
        val_labels = true_labels[val_idx]
        nonconformity = compute_nonconformity_scores(val_scores, val_labels, method=method)
        all_nonconformity[val_idx] = nonconformity

    return calibrate_threshold(all_nonconformity, alpha=alpha)
