"""
Refactored Cell Typing Package
==============================

A modular package for cell type annotation in single-cell and spatial
transcriptomics data.

Modules
-------
- annotators: Cell type annotation methods (BiomarkerAnnotator, ScTypeAnnotator, etc.)
- conformal: Conformal prediction for uncertainty quantification
- config: Configuration management
- constants: Shared constants, palettes, and defaults
- core_utils: Core utilities (confidence, calibration, consensus, markers, QC)
- io: Data loading and gene mapping
- normalization: Data normalization methods
- plotting: Visualization functions
- qc: Quality control metrics and validation
- consensus: Consensus methods for combining predictions
- celltypist_integration: CellTypist integration
- epithelial_anchored_correction: Epithelial-anchored scVI batch correction (optional,
                                   requires scvi-tools + celltypist)
- workflow: Main workflow orchestration

Quick Start
-----------
>>> from celltype import BiomarkerAnnotator, normalize
>>>
>>> # Normalize data
>>> adata_norm = normalize(adata, method="library_size", log_transform=True)
>>>
>>> # Annotate cells
>>> annotator = BiomarkerAnnotator()
>>> result = annotator.annotate(adata_norm, marker_dict)
>>>
>>> # Access results
>>> print(result.predictions)
>>> print(result.confidences)

For multi-method annotation:
>>> from celltype import MultiMethodAnnotator
>>>
>>> multi = MultiMethodAnnotator(methods=["biomarker", "sctype", "hierarchy"])
>>> results = multi.annotate(adata, marker_dict)

For complete workflow:
>>> from celltype import run_annotation_workflow
>>>
>>> adata, results = run_annotation_workflow(adata, marker_dict=markers)
"""

__version__ = "0.4.0"

# =============================================================================
# CORE IMPORTS - Most commonly used
# =============================================================================


# Annotators
from .annotators import (
    AnnotationResult,
    BiomarkerAnnotator,
    CellTypeAnnotator,  # Base class (abstract)
    HierarchyAnnotator,
    MultiMethodAnnotator,
    OverclusterAnnotator,
    ScTypeAnnotator,
    create_annotator,
)
from .api import annotate_cell_types

# Batch correction (Pillar 0)
from .batch_correction import (
    attach_batch_corrected_clusters,
    batch_correction,
    calculate_shannon_entropy_cluster,
)

# CellTypist integration
from .celltypist_integration import (
    HAS_CELLTYPIST,
    cell_typing_celltypist,
    combine_celltypist_with_consensus,
    compute_voting_clusters,
    diagnose_celltypist_model,
    get_celltypist_predictions,
    list_celltypist_models,
    load_celltypist_model,
    run_celltypist,
)

# Cluster annotation (Pillar 1)
from .cluster_annotation import (
    annotate_clusters_by_markers,
    load_marker_matrix,
    score_marker_genes,
)

# Configuration
from .config import (
    AnnotationMethodConfig,
    ConfidenceConfig,
    PathConfig,
    PlotConfig,
    WorkflowConfig,
    get_default_config,
    get_relaxed_config,
    get_strict_config,
)

# Conformal prediction
from .conformal import (
    ConformalPredictor,
    calibrate_threshold,
    compute_nonconformity_scores,
    predict_sets,
    set_size_to_confidence,
)

# Consensus module
from .consensus import (
    compute_refinement_consensus,
    create_marker_dict_with_validation,
    refine_with_neighborhood,
)

# Constants
from .constants import (
    BREAST_TME_MARKERS,
    CELL_TYPE_HIERARCHY,
    CELL_TYPE_PALETTE,
    DEFAULT_MARKERS,
    XENIUM_TME_MARKERS,
    Colors,
    ColumnNames,
    Defaults,
)

# Core utilities
from .core_utils import (
    analyze_marker_coverage,
    # Threshold
    calculate_optimal_threshold,
    calibrate_confidences,
    calibrate_isotonic,
    # Calibration
    calibrate_minmax,
    calibrate_platt,
    calibrate_quantile,
    # Prediction combination
    combine_primary_with_consensus,
    # Confidence
    compute_entropy_confidence,
    # Feature overlap
    compute_feature_overlap,
    compute_margin_confidence,
    # Markers
    compute_marker_specificity,
    compute_neighborhood_consensus,
    compute_qc_metrics,
    # Spatial variability
    compute_spatial_autocorr,
    # Consensus
    compute_weighted_consensus,
    filter_spatially_variable_markers,
    find_markers_in_data,
    # QC
    perform_qc_filtering,
    save_annotation_statistics,
    summarize_marker_expression,
)

# Ensemble (Pillar 4)
from .ensemble import (
    EnsembleResult,
    build_ensemble,
    combine_celltypist_with_markers,
    combine_predictions,
    combine_scarches_with_markers,
    compute_method_agreement,
    resolve_unknowns,
)

# I/O
from .io import (
    attach_cell_types,
    create_marker_dict,
    gene_symbol_to_ensembl,
    gene_symbol_to_ensembl_mygene,
    load_data,
    load_gene_mapping,
    load_marker_file,
    load_spatial_data,
    load_spatialdata_zarr,
    rename_var_to_ensembl,
    rename_var_to_gene_name,
    save_to_spatialdata,
    update_spatialdata_table,
)

# Normalization
from .normalization import (
    normalize,
    normalize_cell_area,
    normalize_deseq2,
    normalize_library_size,
    normalize_sctransform,
    normalize_tmm,
)

# Plotting
from .plotting import (
    plot_celltype_distribution,
    plot_celltype_spatial,
    plot_confidence_spatial,
    plot_marker_dotplot,
    plot_marker_heatmap,
    save_figure,
)

# QC module
from .qc import (
    AnnotationQCResult,
    MarkerValidationResult,
    add_hierarchical_annotations,
    compute_annotation_qc_metrics,
    flag_low_quality_cells,
    validate_annotations_with_markers,
)

# Smoothing (Pillar 1 post-processing)
from .smoothing import (
    apply_confidence_filter,
    apply_spatial_knn_smoothing,
)

# Workflow module
from .workflow import (
    run_annotation_workflow,
    run_combined_annotation_workflow,
    run_multi_method_annotation,
    run_refinement_pipeline,
)

# ---------------------------------------------------------------------------
# Optional heavy-dependency integrations
# These are imported with try/except so the package loads even when the
# optional dependencies (scarches, scimilarity, nicheformer) are absent.
# ---------------------------------------------------------------------------

try:
    from .epithelial_anchored_correction import (
        # Exposed constants
        EPITHELIAL_LABELS,
        MIN_EPITHELIAL_CELLS_PER_BATCH,
        build_anchor_adata,
        build_corrected_embedding,
        # Post-hoc QC & diagnostics
        check_epithelial_consistency,
        plot_anchor_correction_summary,
        run_anchored_correction_from_merged,
        # Step-level functions
        run_celltypist_pass,
        # Master pipeline
        run_epithelial_anchored_correction,
        summarise_anchor_quality,
        train_anchor_scvi,
        transfer_correction_to_query,
    )

    _HAS_EPITHELIAL_ANCHORED_MODULE = True
except ImportError:
    _HAS_EPITHELIAL_ANCHORED_MODULE = False

try:
    from .scarches import (
        HAS_SCARCHES,
        HAS_SCVI,
        build_scanvi_reference,
        build_scpoli_reference,
        cell_typing_scarches,
        combine_scarches_with_consensus,
        diagnose_scarches,
        get_scarches_predictions,
        run_scarches,
    )

    _HAS_SCARCHES_MODULE = True
except ImportError:
    _HAS_SCARCHES_MODULE = False

try:
    from .scimilarity_integration import (
        HAS_SCIMILARITY,
        cell_typing_scimilarity,
        combine_scimilarity_with_consensus,
        diagnose_scimilarity,
        get_scimilarity_predictions,
        load_scimilarity_model,
        run_scimilarity,
    )

    _HAS_SCIMILARITY_MODULE = True
except ImportError:
    _HAS_SCIMILARITY_MODULE = False

try:
    from .foundation_models import (
        cell_typing_nicheformer,
        get_nicheformer_embeddings,
    )

    _HAS_FOUNDATION_MODELS = True
except ImportError:
    _HAS_FOUNDATION_MODELS = False

# =============================================================================
# PUBLIC API
# =============================================================================

__all__ = [
    "annotate_cell_types",
    # Version
    "__version__",
    # Annotators
    "AnnotationResult",
    "CellTypeAnnotator",
    "BiomarkerAnnotator",
    "ScTypeAnnotator",
    "HierarchyAnnotator",
    "OverclusterAnnotator",
    "MultiMethodAnnotator",
    "create_annotator",
    # Normalization
    "normalize",
    "normalize_library_size",
    "normalize_sctransform",
    "normalize_deseq2",
    "normalize_tmm",
    "normalize_cell_area",
    # Conformal
    "ConformalPredictor",
    "compute_nonconformity_scores",
    "calibrate_threshold",
    "predict_sets",
    "set_size_to_confidence",
    # Constants
    "ColumnNames",
    "Defaults",
    "Colors",
    "CELL_TYPE_PALETTE",
    "CELL_TYPE_HIERARCHY",
    "DEFAULT_MARKERS",
    "XENIUM_TME_MARKERS",
    "BREAST_TME_MARKERS",
    # Core utilities
    "compute_entropy_confidence",
    "compute_margin_confidence",
    "calibrate_minmax",
    "calibrate_quantile",
    "calibrate_platt",
    "calibrate_isotonic",
    "calibrate_confidences",
    "compute_weighted_consensus",
    "compute_neighborhood_consensus",
    "compute_marker_specificity",
    "find_markers_in_data",
    "compute_feature_overlap",
    "combine_primary_with_consensus",
    "compute_spatial_autocorr",
    "filter_spatially_variable_markers",
    "analyze_marker_coverage",
    "summarize_marker_expression",
    "perform_qc_filtering",
    "compute_qc_metrics",
    "save_annotation_statistics",
    "calculate_optimal_threshold",
    # I/O
    "load_data",
    "load_spatial_data",
    "load_spatialdata_zarr",
    "save_to_spatialdata",
    "update_spatialdata_table",
    "gene_symbol_to_ensembl",
    "gene_symbol_to_ensembl_mygene",
    "load_marker_file",
    "create_marker_dict",
    "load_gene_mapping",
    "rename_var_to_ensembl",
    "rename_var_to_gene_name",
    "attach_cell_types",
    # Plotting
    "plot_celltype_distribution",
    "plot_celltype_spatial",
    "plot_confidence_spatial",
    "plot_marker_heatmap",
    "plot_marker_dotplot",
    "save_figure",
    # Config
    "WorkflowConfig",
    "ConfidenceConfig",
    "PathConfig",
    "PlotConfig",
    "AnnotationMethodConfig",
    "get_default_config",
    "get_strict_config",
    "get_relaxed_config",
    # QC module
    "AnnotationQCResult",
    "MarkerValidationResult",
    "compute_annotation_qc_metrics",
    "validate_annotations_with_markers",
    "add_hierarchical_annotations",
    "flag_low_quality_cells",
    # Consensus module
    "compute_refinement_consensus",
    "refine_with_neighborhood",
    "create_marker_dict_with_validation",
    # CellTypist integration
    "HAS_CELLTYPIST",
    "load_celltypist_model",
    "run_celltypist",
    "get_celltypist_predictions",
    "combine_celltypist_with_consensus",
    "list_celltypist_models",
    "diagnose_celltypist_model",
    "compute_voting_clusters",
    "cell_typing_celltypist",
    # Batch correction (Pillar 0)
    "batch_correction",
    "attach_batch_corrected_clusters",
    "calculate_shannon_entropy_cluster",
    # Cluster annotation (Pillar 1)
    "load_marker_matrix",
    "score_marker_genes",
    "annotate_clusters_by_markers",
    # Smoothing (Pillar 1 post-processing)
    "apply_confidence_filter",
    "apply_spatial_knn_smoothing",
    # Ensemble (Pillar 4)
    "EnsembleResult",
    "combine_predictions",
    "combine_celltypist_with_markers",
    "combine_scarches_with_markers",
    "resolve_unknowns",
    "compute_method_agreement",
    "build_ensemble",
    # Workflow module
    "run_annotation_workflow",
    "run_combined_annotation_workflow",
    "run_multi_method_annotation",
    "run_refinement_pipeline",
    # Epithelial-anchored batch correction (optional — requires scvi-tools + celltypist)
    "run_epithelial_anchored_correction",
    "run_anchored_correction_from_merged",
    "run_celltypist_pass",
    "build_anchor_adata",
    "train_anchor_scvi",
    "transfer_correction_to_query",
    "build_corrected_embedding",
    "check_epithelial_consistency",
    "plot_anchor_correction_summary",
    "summarise_anchor_quality",
    "EPITHELIAL_LABELS",
    "MIN_EPITHELIAL_CELLS_PER_BATCH",
    # scArches integration (optional — requires scarches + scvi-tools)
    "build_scanvi_reference",
    "build_scpoli_reference",
    "run_scarches",
    "get_scarches_predictions",
    "combine_scarches_with_consensus",
    "diagnose_scarches",
    "cell_typing_scarches",
    # SCimilarity integration (optional — requires scimilarity)
    "load_scimilarity_model",
    "run_scimilarity",
    "get_scimilarity_predictions",
    "combine_scimilarity_with_consensus",
    "diagnose_scimilarity",
    "cell_typing_scimilarity",
    # Foundation models (optional — requires nicheformer)
    "cell_typing_nicheformer",
    "get_nicheformer_embeddings",
]
