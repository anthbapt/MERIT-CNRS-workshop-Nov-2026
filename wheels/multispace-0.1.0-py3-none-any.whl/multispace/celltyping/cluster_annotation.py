"""
Cluster-Level Annotation (Marker-Based)
========================================

Pillar 1 of the celltype package (Marker annotation).

Functions for scoring marker genes and annotating cell clusters based on
marker gene expression. Supports both positive-only and signed (positive +
negative) marker gene dictionaries.

Key functions
-------------
- load_marker_matrix : Load marker gene definitions from CSV
- score_marker_genes : Score marker genes at the cell level
- annotate_clusters_by_markers : Assign cell types to clusters via marker scores
"""

import os
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns

from .constants import XENIUM_TME_MARKERS

__all__ = [
    "load_marker_matrix",
    "score_marker_genes",
    "annotate_clusters_by_markers",
]


def _parse_marker_entry(entry):
    """
    Normalise a marker dictionary entry to (positive_genes, negative_genes).

    Accepts two formats — old and new are both supported:

    Old format (list) — positive markers only, backwards compatible:
        "T_cell": ["CD3D", "CD3E", "CD8A"]

    New format (dict) — explicit positive and negative markers:
        "T_cell": {"positive": ["CD3D", "CD3E", "CD8A"],
                   "negative": ["EPCAM", "CD68"]}

    Returns
    -------
    positive : list  genes whose high expression supports the cell type
    negative : list  genes whose high expression penalises the cell type
    """
    if isinstance(entry, list):
        return entry, []
    if isinstance(entry, dict):
        positive = entry.get("positive", [])
        negative = entry.get("negative", [])
        if not isinstance(positive, list) or not isinstance(negative, list):
            raise ValueError(
                "Marker entry dict must have 'positive' and 'negative' keys "
                "each mapping to a list of gene symbols."
            )
        return positive, negative
    raise TypeError(
        f"Marker entry must be a list or dict, got {type(entry).__name__}. "
        "Use ['GENE1', 'GENE2'] for positive-only or "
        "{'positive': [...], 'negative': [...]} for signed markers."
    )


def load_marker_matrix(
    csv_path, gene_col=None, positive_value=1, negative_value=-1, key_sanitise=True
):
    """
    Load a marker gene matrix from a CSV file and convert it to the signed
    marker dictionary format used by score_marker_genes() and
    annotate_clusters_by_markers().

    Supported matrix formats
    ------------------------
    Binary (positive only):
        Values in {0, 1}. All 1-entries become positive markers.
        Example: biomarker_cell_type_matrix.csv

    Signed (positive + negative):
        Values in {-1, 0, 1}. 1 = positive, -1 = negative marker.
        Example: disco_marker_matrix_10X.csv

    Format is auto-detected from the presence of -1 values.

    Output format
    -------------
    Binary  → {cell_type: ["GENE1", ...]}
    Signed  → {cell_type: {"positive": [...], "negative": [...]}}

    Parameters
    ----------
    csv_path       : str   path to marker matrix CSV
    gene_col       : str   column with gene symbols; if None, first column
                           used as index
    positive_value : int   value encoding positive marker (default 1)
    negative_value : int   value encoding negative marker (default -1)
    key_sanitise   : bool  replace spaces/special chars with underscores
                           to produce Python-safe dict keys (default True)

    Returns
    -------
    marker_dict : dict  ready to pass to score_marker_genes() or
                        annotate_clusters_by_markers()
    summary_df  : pd.DataFrame  cell_type | n_positive | n_negative |
                                positive_genes | negative_genes

    Examples
    --------
    # Binary matrix
    markers, summary = load_marker_matrix("biomarker_cell_type_matrix.csv")

    # Signed matrix (auto-detected)
    markers, summary = load_marker_matrix("disco_marker_matrix_10X.csv")

    # Pass to scoring functions
    merged_adata = score_marker_genes(
        merged_adata, output_folder=batch_dir, marker_dict=markers)
    merged_adata, annot = annotate_clusters_by_markers(
        merged_adata, output_folder=batch_dir, marker_dict=markers)
    """
    df = pd.read_csv(csv_path, index_col=0 if gene_col is None else gene_col)
    df = df.loc[:, (df != 0).any(axis=0)]  # drop all-zero columns

    has_negative = (df.values == negative_value).any()
    fmt = "signed" if has_negative else "binary"
    print(
        f"  load_marker_matrix: {df.shape[0]} genes x {df.shape[1]} "
        f"cell types | format: {fmt} | path: {Path(csv_path).name}"
    )

    def _sanitise(name):
        return re.sub(r"[^A-Za-z0-9_ ]", "_", name).strip("_")

    marker_dict = {}
    summary_rows = []

    for col in df.columns:
        key = _sanitise(col) if key_sanitise else col
        pos_genes = df.index[df[col] == positive_value].tolist()
        neg_genes = df.index[df[col] == negative_value].tolist() if has_negative else []

        if not pos_genes:
            print(f"  WARNING: '{col}' has no positive markers — skipping")
            continue

        marker_dict[key] = (
            {"positive": pos_genes, "negative": neg_genes} if has_negative else pos_genes
        )
        summary_rows.append(
            {
                "key": key,
                "original_label": col,
                "n_positive": len(pos_genes),
                "n_negative": len(neg_genes),
                "positive_genes": ", ".join(pos_genes[:5])
                + (f" ... (+{len(pos_genes)-5} more)" if len(pos_genes) > 5 else ""),
                "negative_genes": (
                    ", ".join(neg_genes[:5])
                    + (f" ... (+{len(neg_genes)-5} more)" if len(neg_genes) > 5 else "")
                )
                or "—",
            }
        )

    summary_df = pd.DataFrame(summary_rows)
    print(
        f"  Loaded {len(marker_dict)} cell types "
        f"({'with' if has_negative else 'without'} negative markers):"
    )
    for _, row in summary_df.iterrows():
        neg_str = f", {row['n_negative']} neg" if has_negative else ""
        print(f"    {row['key']:<45} {row['n_positive']:>3} pos{neg_str}")

    return marker_dict, summary_df


def _score_signed_markers(adata, cell_type: str, entry, prefix: str, layer: str) -> bool:
    """
    Score a single cell type's signed marker genes into ``adata.obs``.

    Computes ``sc.tl.score_genes`` for positive markers and, when negative
    markers are present, subtracts the negative score to produce a net score.
    The result is stored in ``adata.obs[f"{prefix}{cell_type}"]``.

    Parameters
    ----------
    adata : AnnData
        Data object.  ``adata.X`` must already be set to the desired layer
        by the caller.
    cell_type : str
        Cell type name (used to build column names).
    entry : list or dict
        Marker entry in the format accepted by ``_parse_marker_entry``.
    prefix : str
        Column name prefix for the score (e.g. ``"score_"`` or ``"_mkscore_"``).
    layer : str
        Layer name (used only for logging; the caller is responsible for
        swapping ``adata.X`` before calling this function).

    Returns
    -------
    bool
        ``True`` if scoring succeeded, ``False`` if no valid positive markers
        were found (cell type is skipped).
    """
    pos_genes, neg_genes = _parse_marker_entry(entry)

    valid_pos = [g for g in pos_genes if g in adata.var_names]
    valid_neg = [g for g in neg_genes if g in adata.var_names]

    if not valid_pos:
        return False

    sc.tl.score_genes(adata, valid_pos, score_name=f"_tmp_pos_{cell_type}")

    if valid_neg:
        sc.tl.score_genes(adata, valid_neg, score_name=f"_tmp_neg_{cell_type}")
        adata.obs[f"{prefix}{cell_type}"] = (
            adata.obs[f"_tmp_pos_{cell_type}"] - adata.obs[f"_tmp_neg_{cell_type}"]
        )
        adata.obs.drop(
            columns=[f"_tmp_pos_{cell_type}", f"_tmp_neg_{cell_type}"],
            inplace=True,
        )
    else:
        adata.obs[f"{prefix}{cell_type}"] = adata.obs[f"_tmp_pos_{cell_type}"]
        adata.obs.drop(columns=[f"_tmp_pos_{cell_type}"], inplace=True)

    return True


def score_marker_genes(
    merged_adata, output_folder, marker_dict=None, cluster_key="leiden_corrected", layer="lognorm"
):
    """
    Score canonical marker gene sets per cell (sc.tl.score_genes) and produce
    a cluster x cell-type heatmap for validation.

    Supports both positive-only and signed (positive + negative) marker dicts.
    See _parse_marker_entry() for accepted formats.

    Signed scoring
    --------------
    When negative markers are provided, the final cell-level score is:

        score = positive_score - negative_score

    where each component is a sc.tl.score_genes UCell-style score. Subtracting
    the negative score penalises cells that co-express markers of other cell
    types, sharpening specificity for overlapping populations (e.g. Fibroblast
    vs Malignant which both express ACTA2).

    Parameters
    ----------
    merged_adata  : AnnData  var_names must be gene symbols
    output_folder : str
    marker_dict   : dict  accepts both:
                      positive-only : {cell_type: [gene, ...]}
                      signed        : {cell_type: {"positive": [...],
                                                   "negative": [...]}}
                    defaults to XENIUM_TME_MARKERS
    cluster_key   : str   obs column used to group cells for the heatmap
    layer         : str   expression layer for scoring (default 'lognorm')

    Returns
    -------
    merged_adata : AnnData  with 'score_<CellType>' columns in .obs
                            (signed net score = positive - negative)
    """
    if marker_dict is None:
        marker_dict = XENIUM_TME_MARKERS

    os.makedirs(output_folder, exist_ok=True)

    X_orig = merged_adata.X
    merged_adata.X = merged_adata.layers[layer]

    scored_types = []
    for cell_type, entry in marker_dict.items():
        pos_genes, neg_genes = _parse_marker_entry(entry)

        valid_pos = [g for g in pos_genes if g in merged_adata.var_names]
        valid_neg = [g for g in neg_genes if g in merged_adata.var_names]

        if not valid_pos:
            print(f"  WARNING: no positive markers found for '{cell_type}' " f"— skipping")
            continue

        sc.tl.score_genes(merged_adata, valid_pos, score_name=f"_pos_{cell_type}")

        if valid_neg:
            sc.tl.score_genes(merged_adata, valid_neg, score_name=f"_neg_{cell_type}")
            merged_adata.obs[f"score_{cell_type}"] = (
                merged_adata.obs[f"_pos_{cell_type}"] - merged_adata.obs[f"_neg_{cell_type}"]
            )
            merged_adata.obs.drop(columns=[f"_pos_{cell_type}", f"_neg_{cell_type}"], inplace=True)
            n_neg_str = f", {len(valid_neg)} negative"
        else:
            merged_adata.obs[f"score_{cell_type}"] = merged_adata.obs[f"_pos_{cell_type}"]
            merged_adata.obs.drop(columns=[f"_pos_{cell_type}"], inplace=True)
            n_neg_str = ""

        scored_types.append(cell_type)
        print(f"  scored '{cell_type}': {len(valid_pos)} positive" f"{n_neg_str} markers")

    merged_adata.X = X_orig

    score_cols = [f"score_{ct}" for ct in scored_types]

    if score_cols:
        cluster_means = merged_adata.obs.groupby(cluster_key)[score_cols].mean()
        cluster_means.columns = [c.replace("score_", "") for c in cluster_means.columns]
        g = sns.clustermap(
            cluster_means,
            cmap="RdBu_r",
            center=0,
            figsize=(max(10, len(scored_types) * 0.8), max(8, len(cluster_means) * 0.35)),
            linewidths=0.5,
        )
        g.fig.suptitle("Marker gene scores per cluster (net: pos − neg)", y=1.02)
        plt.savefig(Path(output_folder) / "marker_score_heatmap.png", dpi=150, bbox_inches="tight")
        plt.close()

    return merged_adata


def annotate_clusters_by_markers(
    merged_adata,
    output_folder,
    marker_dict=None,
    cluster_key="leiden_corrected",
    output_col="cell_type_markers",
    min_score=0.0,
    ambiguity_threshold=0.5,
    layer="lognorm",
):
    """
    Assign a cell type label to each Leiden cluster based on marker gene scores,
    then propagate the cluster-level label to every cell in that cluster.

    Supports signed marker dicts (positive + negative) via _parse_marker_entry().
    Signed scoring: net_score = positive_score - negative_score

    Can be used:
      (a) as the primary annotation when no CellTypist model is available
      (b) as a validation layer to cross-check CellTypist predictions
      (c) to resolve 'Unassigned' cells left by apply_confidence_filter()

    Quality gates
    -------------
    min_score          : winner score must be positive (else 'Unresolved')
    ambiguity_threshold: winner/runner_up ratio must exceed this (else 'Ambiguous')

    Saves
    -----
    marker_score_heatmap.png      : cluster x cell-type score matrix
    marker_annotation_umap.png    : UMAP coloured by marker-derived labels
    marker_annotation_summary.csv : cluster -> cell type assignment table

    Parameters
    ----------
    merged_adata        : AnnData  var_names must be gene symbols
    output_folder       : str
    marker_dict         : dict  accepts both formats:
                            positive-only : {cell_type: [gene, ...]}
                            signed        : {cell_type: {"positive": [...],
                                                         "negative": [...]}}
                          defaults to XENIUM_TME_MARKERS
    cluster_key         : str   Leiden obs column to annotate
    output_col          : str   new obs column for marker-derived labels
    min_score           : float minimum winner score (default 0.0)
    ambiguity_threshold : float winner/runner_up ratio threshold (default 0.5)
    layer               : str   expression layer for scoring (default 'lognorm')

    Returns
    -------
    merged_adata  : AnnData  with output_col in .obs
    cluster_annot : pd.DataFrame  cluster -> cell type assignment table
    """
    if marker_dict is None:
        marker_dict = XENIUM_TME_MARKERS

    os.makedirs(output_folder, exist_ok=True)

    # -- 1. Score genes (signed) ----------------------------------------------
    X_orig = merged_adata.X
    merged_adata.X = merged_adata.layers[layer]

    scored_types = []
    for cell_type, entry in marker_dict.items():
        ok = _score_signed_markers(merged_adata, cell_type, entry, prefix="_mkscore_", layer=layer)
        if not ok:
            print(f"  WARNING: no positive markers for '{cell_type}' — skipping")
            continue
        scored_types.append(cell_type)

    merged_adata.X = X_orig

    if not scored_types:
        raise ValueError(
            "No marker genes matched var_names — check that "
            "var_names are gene symbols, not Ensembl IDs."
        )

    score_cols = [f"_mkscore_{ct}" for ct in scored_types]

    # -- 2. Average scores per cluster ----------------------------------------
    cluster_means = merged_adata.obs.groupby(cluster_key)[score_cols].mean()
    cluster_means.columns = scored_types

    # -- 3. Assign label per cluster with quality gates -----------------------
    assignments = {}
    for cluster, row in cluster_means.iterrows():
        sorted_row = row.sort_values(ascending=False)
        winner = sorted_row.index[0]
        w_score = sorted_row.iloc[0]

        if w_score < min_score:
            assignments[cluster] = "Unresolved"
            continue

        if len(sorted_row) > 1:
            runner_up = sorted_row.iloc[1]
            ratio = w_score / runner_up if runner_up > 1e-6 else np.inf
            if ratio < ambiguity_threshold:
                assignments[cluster] = "Ambiguous"
                continue

        assignments[cluster] = winner

    cluster_annot = pd.DataFrame.from_dict(
        assignments, orient="index", columns=["cell_type_markers"]
    )
    cluster_annot.index.name = cluster_key
    cluster_annot["winner_score"] = cluster_means.max(axis=1)
    cluster_annot["runner_up_score"] = cluster_means.apply(
        lambda r: r.nlargest(2).iloc[-1] if len(r) > 1 else np.nan, axis=1
    )
    cluster_annot["ambiguity_ratio"] = (
        cluster_annot["winner_score"] / cluster_annot["runner_up_score"]
    ).replace([np.inf, -np.inf], np.nan)

    # -- 4. Broadcast cluster labels to cells ---------------------------------
    merged_adata.obs[output_col] = (
        merged_adata.obs[cluster_key].map(cluster_annot["cell_type_markers"]).astype(str)
    )

    n_types = merged_adata.obs[output_col].nunique()
    print(
        f"  annotate_clusters_by_markers: {n_types} cell types assigned "
        f"across {cluster_means.shape[0]} clusters"
    )
    for cluster, row in cluster_annot.iterrows():
        flag = "  <<<" if row["cell_type_markers"] in ("Ambiguous", "Unresolved") else ""
        print(
            f"    Cluster {str(cluster):>4} -> "
            f"{row['cell_type_markers']:<35} "
            f"score={row['winner_score']:.3f}  "
            f"ratio={row['ambiguity_ratio']:.2f}{flag}"
        )

    # -- 5. Save outputs ------------------------------------------------------
    display_means = cluster_means.copy()
    display_means.index = [f"{idx} ({assignments[idx]})" for idx in display_means.index]
    g = sns.clustermap(
        display_means,
        cmap="RdBu_r",
        center=0,
        figsize=(max(8, len(scored_types) * 0.7), max(8, len(cluster_means) * 0.35)),
        linewidths=0.3,
    )
    g.fig.suptitle(f"Marker gene scores per cluster ({cluster_key}) [net: pos − neg]", y=1.01)
    plt.savefig(Path(output_folder) / "marker_score_heatmap.png", dpi=150, bbox_inches="tight")
    plt.close()

    n_label_types = merged_adata.obs[output_col].nunique()
    fig, ax = plt.subplots(figsize=(7, 7))
    sc.pl.embedding(
        merged_adata,
        basis="umap_corrected",
        color=output_col,
        ax=ax,
        show=False,
        title=f"Marker annotation ({n_label_types} types, " f"{cluster_key})",
        legend_loc="on data",
        legend_fontsize=6,
        legend_fontoutline=1,
        frameon=False,
    )
    plt.savefig(Path(output_folder) / "marker_annotation_umap.png", dpi=150, bbox_inches="tight")
    plt.close()

    csv_path = Path(output_folder) / "marker_annotation_summary.csv"
    cluster_annot.to_csv(csv_path)
    print(f"  Annotation table saved -> {csv_path}")

    merged_adata.obs.drop(
        columns=[c for c in merged_adata.obs.columns if c.startswith("_mkscore_")], inplace=True
    )

    return merged_adata, cluster_annot
