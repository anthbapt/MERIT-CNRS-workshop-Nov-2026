"""
Core Utilities for Cell Type Annotation
========================================

This module contains shared utility functions used across the cell typing workflow.
Centralizing these functions eliminates code duplication and ensures consistency.

Functions:
----------
- Confidence calculation (entropy-based, margin-based)
- Marker scoring utilities
- Data validation and preprocessing
- Calibration methods
- Conformal prediction utilities

"""

from __future__ import annotations

import logging
import warnings

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import NearestNeighbors

# Local imports
from .constants import (
    ColumnNames,
    Defaults,
    ObsmKeys,
)

# Configure module logger
logger = logging.getLogger(__name__)


# =============================================================================
# CONFIDENCE CALCULATION
# =============================================================================


def compute_entropy_confidence(
    scores: np.ndarray, temperature: float = Defaults.TEMPERATURE, normalize_scores: bool = False
) -> np.ndarray:
    """
    Compute entropy-based confidence from a score matrix.

    Low entropy = high confidence (one dominant class)
    High entropy = low confidence (uniform distribution)

    The confidence measures how "peaked" the score distribution is:
    - If one score is much higher than others -> high confidence
    - If all scores are similar -> low confidence

    Parameters
    ----------
    scores : np.ndarray
        Score matrix of shape (n_samples, n_classes).
        Each row contains scores for all possible cell types.
    temperature : float
        Temperature parameter for softmax (lower = sharper). Default: 0.5
    normalize_scores : bool
        Whether to normalize scores. Default: False
        (normalization loses information about score spread)

    Returns
    -------
    np.ndarray
        Confidence scores in [0, 1] range. Shape: (n_samples,)
        - 1.0 = perfect confidence (all probability on one class)
        - 0.0 = no confidence (uniform distribution)

    Examples
    --------
    >>> # High confidence: one dominant score
    >>> scores = np.array([[0.9, 0.05, 0.05]])
    >>> conf = compute_entropy_confidence(scores, temperature=0.5)
    >>> print(f"High conf: {conf[0]:.3f}")  # Should be > 0.7

    >>> # Low confidence: uniform scores
    >>> scores = np.array([[0.33, 0.33, 0.34]])
    >>> conf = compute_entropy_confidence(scores, temperature=0.5)
    >>> print(f"Low conf: {conf[0]:.3f}")  # Should be < 0.2
    """
    if scores.ndim == 1:
        scores = scores.reshape(1, -1)

    n_samples, n_classes = scores.shape

    if n_classes == 1:
        return np.ones(n_samples)

    # Make a copy to avoid modifying input
    scores = scores.copy().astype(float)

    # Compute mean score (used for margin normalisation below)
    score_mean = scores.mean(axis=1)

    # Handle zero mean case
    score_mean[score_mean == 0] = 1e-10

    # Also compute margin (difference between top 2)
    sorted_scores = np.sort(scores, axis=1)
    margin = sorted_scores[:, -1] - sorted_scores[:, -2]

    # Normalize margin by the mean score (not range!)
    # This way, a small absolute margin with small range still shows low confidence
    normalized_margin = margin / (score_mean + 1e-10)
    # Clip to [0, 1] - margin can't be more than mean in typical cases
    normalized_margin = np.clip(normalized_margin, 0, 1)

    # Compute "peakedness" - how much the max dominates
    max_score = sorted_scores[:, -1]
    total_score = scores.sum(axis=1)
    total_score[total_score == 0] = 1e-10
    max_fraction = max_score / total_score

    # For uniform distribution with n classes, max_fraction = 1/n
    # For perfect confidence, max_fraction = 1
    # Scale to [0, 1]: (max_fraction - 1/n) / (1 - 1/n)
    uniform_fraction = 1.0 / n_classes
    peakedness = (max_fraction - uniform_fraction) / (1 - uniform_fraction + 1e-10)
    peakedness = np.clip(peakedness, 0, 1)

    # Combine metrics:
    # - peakedness: how much probability mass is on the top class (primary)
    # - normalized_margin: how separated the top class is from second (secondary)
    # Weight peakedness more as it better captures true dominance
    confidence = 0.7 * peakedness + 0.3 * normalized_margin

    # Apply temperature scaling
    # Lower temperature = sharper (more extreme) confidence values.
    #
    # NOTE: a plain conf^(1/temperature) power transform does NOT achieve this —
    # for any conf in (0, 1), raising to an exponent > 1 (temperature < 1)
    # always shrinks the value toward 0, and an exponent < 1 (temperature > 1)
    # always inflates it toward 1, regardless of whether conf started above or
    # below 0.5. That uniformly shrinks/inflates every value in the same
    # direction instead of sharpening (pushing high values toward 1 *and* low
    # values toward 0).
    #
    # Use the two-outcome temperature-scaled softmax instead:
    #   conf^(1/T) / (conf^(1/T) + (1-conf)^(1/T))
    # At T=1 this reduces to conf unchanged. For T<1, values above 0.5 are
    # pushed toward 1 and values below 0.5 are pushed toward 0 (sharpens).
    # For T>1, values are pulled toward 0.5 (flattens).
    if temperature != 1.0:
        conf_pow = np.power(confidence, 1.0 / temperature)
        inv_conf_pow = np.power(1.0 - confidence, 1.0 / temperature)
        denom = conf_pow + inv_conf_pow
        denom = np.where(denom == 0, 1e-10, denom)
        confidence = conf_pow / denom

    # Ensure confidence is in [0, 1]
    confidence = np.clip(confidence, 0, 1)

    return confidence


def compute_margin_confidence(scores: np.ndarray) -> np.ndarray:
    """
    Compute margin-based confidence (difference between top two scores).

    Parameters
    ----------
    scores : np.ndarray
        Score matrix of shape (n_samples, n_classes).

    Returns
    -------
    np.ndarray
        Margin values. Shape: (n_samples,)
    """
    if scores.ndim == 1:
        scores = scores.reshape(1, -1)

    if scores.shape[1] < 2:
        return np.ones(scores.shape[0])

    sorted_scores = np.sort(scores, axis=1)
    margin = sorted_scores[:, -1] - sorted_scores[:, -2]

    return margin


def compute_max_probability_confidence(scores: np.ndarray) -> np.ndarray:
    """
    Compute confidence as the maximum probability after softmax.

    Parameters
    ----------
    scores : np.ndarray
        Score matrix of shape (n_samples, n_classes).

    Returns
    -------
    np.ndarray
        Max probability values. Shape: (n_samples,)
    """
    if scores.ndim == 1:
        scores = scores.reshape(1, -1)

    # Softmax
    exp_scores = np.exp(scores - scores.max(axis=1, keepdims=True))
    probs = exp_scores / (exp_scores.sum(axis=1, keepdims=True) + 1e-10)

    return probs.max(axis=1)


# =============================================================================
# CALIBRATION METHODS
# =============================================================================


def calibrate_minmax(
    confidences: np.ndarray, feature_range: tuple[float, float] = (0.0, 1.0)
) -> np.ndarray:
    """
    Min-max normalization of confidence scores.

    Parameters
    ----------
    confidences : np.ndarray
        Raw confidence scores.
    feature_range : Tuple[float, float]
        Desired range for output. Default: (0, 1)

    Returns
    -------
    np.ndarray
        Calibrated confidence scores.
    """
    min_val, max_val = confidences.min(), confidences.max()

    if max_val - min_val < 1e-10:
        # All values are the same
        return np.full_like(confidences, (feature_range[0] + feature_range[1]) / 2)

    scaled = (confidences - min_val) / (max_val - min_val)
    return scaled * (feature_range[1] - feature_range[0]) + feature_range[0]


def calibrate_quantile(confidences: np.ndarray, n_quantiles: int = 100) -> np.ndarray:
    """
    Quantile-based calibration (uniform distribution).

    Parameters
    ----------
    confidences : np.ndarray
        Raw confidence scores.
    n_quantiles : int
        Number of quantiles. Default: 100

    Returns
    -------
    np.ndarray
        Calibrated confidence scores.
    """
    n = len(confidences)
    if n == 1:
        # A single value has no rank context; map to 0.5 (neutral, not 0.0)
        return np.array([0.5], dtype=float)
    ranks = np.argsort(np.argsort(confidences))
    return ranks / (n - 1)


def calibrate_platt(confidences: np.ndarray, labels: np.ndarray) -> np.ndarray:
    """
    Platt scaling (logistic regression calibration).

    Requires ground-truth binary labels.  Use ``calibrate_minmax`` or
    ``calibrate_quantile`` for label-free rank-preserving rescaling.

    Parameters
    ----------
    confidences : np.ndarray
        Raw confidence scores.
    labels : np.ndarray
        Binary labels for calibration (1 = correct prediction, 0 = incorrect).
        Must be provided — label-free calibration is statistically invalid
        (fitting on median-split pseudo-labels derived from the same scores
        being calibrated is circular and produces no true probability
        calibration).

    Returns
    -------
    np.ndarray
        Calibrated confidence scores.

    Raises
    ------
    ValueError
        If ``labels`` is None.
    """
    if labels is None:
        raise ValueError(
            "calibrate_platt requires binary labels (1=correct, 0=incorrect). "
            "Label-free calibration is statistically invalid: fitting on "
            "pseudo-labels derived from the same scores being calibrated is "
            "circular and produces no true probability calibration. "
            "Use calibrate_minmax() or calibrate_quantile() for label-free "
            "rank-preserving rescaling."
        )

    lr = LogisticRegression(solver="lbfgs", max_iter=1000)

    try:
        lr.fit(confidences.reshape(-1, 1), labels)
        calibrated = lr.predict_proba(confidences.reshape(-1, 1))[:, 1]
    except Exception:
        # Fallback to minmax if fitting fails
        calibrated = calibrate_minmax(confidences)

    return calibrated


def calibrate_isotonic(confidences: np.ndarray, labels: np.ndarray) -> np.ndarray:
    """
    Isotonic regression calibration.

    Requires ground-truth binary labels.  Use ``calibrate_minmax`` or
    ``calibrate_quantile`` for label-free rank-preserving rescaling.

    Parameters
    ----------
    confidences : np.ndarray
        Raw confidence scores.
    labels : np.ndarray
        Binary labels for calibration (1 = correct prediction, 0 = incorrect).
        Must be provided — label-free calibration is statistically invalid
        (fitting on median-split pseudo-labels derived from the same scores
        being calibrated is circular and produces no true probability
        calibration).

    Returns
    -------
    np.ndarray
        Calibrated confidence scores.

    Raises
    ------
    ValueError
        If ``labels`` is None.
    """
    if labels is None:
        raise ValueError(
            "calibrate_isotonic requires binary labels (1=correct, 0=incorrect). "
            "Label-free calibration is statistically invalid: fitting on "
            "pseudo-labels derived from the same scores being calibrated is "
            "circular and produces no true probability calibration. "
            "Use calibrate_minmax() or calibrate_quantile() for label-free "
            "rank-preserving rescaling."
        )

    ir = IsotonicRegression(out_of_bounds="clip")

    try:
        ir.fit(confidences, labels)
        calibrated = ir.predict(confidences)
    except Exception:
        calibrated = calibrate_minmax(confidences)

    return calibrated


def calibrate_confidences(
    confidences: dict[str, np.ndarray],
    method: str = "isotonic",
    labels: dict[str, np.ndarray] | None = None,
    verbose: bool = False,
) -> dict[str, np.ndarray]:
    """
    Calibrate confidence scores from multiple annotation methods.

    Parameters
    ----------
    confidences : Dict[str, np.ndarray]
        Dictionary mapping method names to confidence arrays.
    method : str
        Calibration method: 'none', 'minmax', 'platt', 'isotonic', 'quantile'.
        ``'platt'`` and ``'isotonic'`` are supervised methods that require
        ground-truth binary labels (1 = correct prediction, 0 = incorrect).
        When ``labels`` is not provided and a supervised method is requested,
        the function falls back to ``'minmax'`` with a warning.
    labels : Dict[str, np.ndarray], optional
        Ground-truth binary labels per method, required for ``'platt'`` and
        ``'isotonic'``.  Keys must match those in ``confidences``.
    verbose : bool
        Print calibration statistics.

    Returns
    -------
    Dict[str, np.ndarray]
        Dictionary with calibrated confidences.
    """
    if method == "none":
        return confidences

    # Supervised methods require labels — fall back gracefully when absent.
    _supervised = {"platt", "isotonic"}
    if method in _supervised and labels is None:
        warnings.warn(
            f"calibrate_confidences: method='{method}' requires ground-truth labels "
            f"(labels parameter), but none were provided. "
            f"Falling back to 'minmax'. "
            f"Pass labels={{method_name: binary_array}} to use supervised calibration.",
            stacklevel=2,
        )
        method = "minmax"

    calibration_funcs = {
        "minmax": calibrate_minmax,
        "platt": calibrate_platt,
        "isotonic": calibrate_isotonic,
        "quantile": calibrate_quantile,
    }

    if method not in calibration_funcs:
        warnings.warn(f"Unknown calibration method '{method}', using 'minmax'", stacklevel=2)
        method = "minmax"

    calibrate_func = calibration_funcs[method]
    is_supervised = method in _supervised

    calibrated = {}
    for method_name, conf in confidences.items():
        try:
            if is_supervised:
                method_labels = (labels or {}).get(method_name)
                if method_labels is None:
                    warnings.warn(
                        f"calibrate_confidences: no labels for method '{method_name}'; "
                        f"falling back to minmax.",
                        stacklevel=2,
                    )
                    calibrated[method_name] = calibrate_minmax(conf)
                else:
                    calibrated[method_name] = calibrate_func(conf, method_labels)
            else:
                calibrated[method_name] = calibrate_func(conf)

            if verbose:
                logger.info(
                    f"  {method_name}: [{conf.min():.3f}, {conf.max():.3f}] -> "
                    f"[{calibrated[method_name].min():.3f}, {calibrated[method_name].max():.3f}]"
                )
        except Exception as e:
            warnings.warn(f"Calibration failed for {method_name}: {e}. Using minmax.", stacklevel=2)
            calibrated[method_name] = calibrate_minmax(conf)

    return calibrated


# =============================================================================
# MARKER SCORING UTILITIES
# =============================================================================


def score_markers(
    expression_matrix: np.ndarray, marker_indices: list[int], method: str = "mean"
) -> np.ndarray:
    """
    Score cells based on marker gene expression.

    Parameters
    ----------
    expression_matrix : np.ndarray
        Expression matrix of shape (n_cells, n_genes).
    marker_indices : List[int]
        Indices of marker genes in the expression matrix.
    method : str
        Scoring method: 'mean', 'sum', 'median', 'max'.

    Returns
    -------
    np.ndarray
        Scores for each cell. Shape: (n_cells,)
    """
    if not marker_indices:
        return np.zeros(expression_matrix.shape[0])

    # A10: convert sparse to dense before slicing — column indexing on a
    # sparse matrix returns a sparse result, which breaks np.mean/median/max.
    if sparse.issparse(expression_matrix):
        expression_matrix = expression_matrix.toarray()

    marker_expr = expression_matrix[:, marker_indices]

    if method == "mean":
        return np.mean(marker_expr, axis=1)
    elif method == "sum":
        return np.sum(marker_expr, axis=1)
    elif method == "median":
        return np.median(marker_expr, axis=1)
    elif method == "max":
        return np.max(marker_expr, axis=1)
    else:
        raise ValueError(f"Unknown scoring method: {method}")


def compute_marker_specificity(marker_dict: dict[str, list[str]]) -> dict[str, float]:
    """
    Compute specificity weights for markers based on how many cell types they appear in.

    Markers that are unique to one cell type get higher weights.

    Parameters
    ----------
    marker_dict : Dict[str, List[str]]
        Dictionary mapping cell types to marker genes.

    Returns
    -------
    Dict[str, float]
        Dictionary mapping marker genes to specificity weights.
    """
    # Count how many cell types each marker appears in
    marker_counts = {}
    for markers in marker_dict.values():
        for marker in markers:
            marker_counts[marker] = marker_counts.get(marker, 0) + 1

    # Convert to specificity (inverse of count)
    specificity = {marker: 1.0 / count for marker, count in marker_counts.items()}

    return specificity


def find_markers_in_data(
    markers: list[str], var_names: pd.Index, gene_symbol_col: pd.Series | None = None
) -> tuple[list[str], list[str]]:
    """
    Find which markers are present in the data.

    Parameters
    ----------
    markers : List[str]
        List of marker gene names to look for.
    var_names : pd.Index
        Variable names from AnnData.
    gene_symbol_col : pd.Series, optional
        Gene symbol column from adata.var for alternative lookup.

    Returns
    -------
    Tuple[List[str], List[str]]
        (found_markers, missing_markers)
    """
    found = []
    missing = []

    var_names_set = set(var_names)
    gene_symbol_map = {}

    if gene_symbol_col is not None:
        # Warn on duplicate gene symbols — dict(zip(...)) silently keeps the
        # last mapping, which can cause markers to resolve to the wrong var_name.
        dup_symbols = gene_symbol_col[gene_symbol_col.duplicated()].unique().tolist()
        if dup_symbols:
            warnings.warn(
                f"find_markers_in_data: {len(dup_symbols)} duplicate gene symbol(s) "
                f"in gene_symbol_col — last mapping wins for: {dup_symbols[:10]}"
                + (" ..." if len(dup_symbols) > 10 else ""),
                stacklevel=2,
            )
        gene_symbol_map = dict(zip(gene_symbol_col, var_names))

    for marker in markers:
        if marker in var_names_set:
            found.append(marker)
        elif marker in gene_symbol_map:
            found.append(gene_symbol_map[marker])
        else:
            missing.append(marker)

    return found, missing


# =============================================================================
# DATA VALIDATION
# =============================================================================


def validate_adata(
    adata,
    required_obs_cols: list[str] | None = None,
    required_obsm_keys: list[str] | None = None,
    check_normalized: bool = False,
) -> list[str]:
    """
    Validate AnnData object for required columns and keys.

    Parameters
    ----------
    adata : AnnData
        Annotated data object.
    required_obs_cols : List[str], optional
        Required columns in adata.obs.
    required_obsm_keys : List[str], optional
        Required keys in adata.obsm.
    check_normalized : bool
        Check if data appears to be normalized.

    Returns
    -------
    List[str]
        List of validation warnings/errors.
    """
    issues = []

    # Check obs columns
    if required_obs_cols:
        missing_cols = [col for col in required_obs_cols if col not in adata.obs.columns]
        if missing_cols:
            issues.append(f"Missing obs columns: {missing_cols}")

    # Check obsm keys
    if required_obsm_keys:
        missing_keys = [key for key in required_obsm_keys if key not in adata.obsm]
        if missing_keys:
            issues.append(f"Missing obsm keys: {missing_keys}")

    # Check for empty data
    if adata.n_obs == 0:
        issues.append("AnnData has no cells (n_obs = 0)")
    if adata.n_vars == 0:
        issues.append("AnnData has no genes (n_vars = 0)")

    # Check normalization
    if check_normalized:
        # A11: avoid loading the full matrix into memory.
        # Sample up to 500 cells × 200 genes to check for integer values.
        X = adata.X
        n_sample_cells = min(adata.n_obs, 500)
        n_sample_genes = min(adata.n_vars, 200)
        rng = np.random.default_rng(seed=0)
        cell_idx = rng.choice(adata.n_obs, size=n_sample_cells, replace=False)
        gene_idx = rng.choice(adata.n_vars, size=n_sample_genes, replace=False)
        X_sample = X[np.ix_(cell_idx, gene_idx)]
        if sparse.issparse(X_sample):
            X_sample = X_sample.toarray()

        # Check if values are likely raw counts (integers)
        if np.allclose(X_sample, X_sample.astype(int)):
            issues.append("Data appears to be raw counts (not normalized) — sampled check")

        # Check for negative values (shouldn't happen in expression data)
        if (X_sample < 0).any():
            issues.append("Data contains negative values")

    return issues


def check_duplicate_columns(df: pd.DataFrame) -> list[str]:
    """
    Check for duplicate columns in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to check.

    Returns
    -------
    List[str]
        List of duplicate column names.
    """
    return df.columns[df.columns.duplicated()].tolist()


def check_missing_values(df: pd.DataFrame, threshold: float = 0.2) -> dict[str, float]:
    """
    Check for columns with high missing value rates.

    Parameters
    ----------
    df : pd.DataFrame
        DataFrame to check.
    threshold : float
        Fraction threshold for flagging columns. Default: 0.2 (20%)

    Returns
    -------
    Dict[str, float]
        Dictionary mapping column names to missing fractions (only for columns above threshold).
    """
    missing_pct = df.isnull().sum() / len(df)
    return {col: pct for col, pct in missing_pct.items() if pct > threshold}


# =============================================================================
# CONSENSUS COMPUTATION
# =============================================================================


def compute_weighted_consensus(
    predictions: dict[str, np.ndarray],
    confidences: dict[str, np.ndarray],
    cell_types: list[str],
    min_agreement: float = 0.0,
    method_weights: dict[str, float] | None = None,
    unknown_label: str = "Unknown",
) -> tuple[np.ndarray, np.ndarray]:
    """
    Compute weighted consensus from multiple prediction methods.

    Parameters
    ----------
    predictions : Dict[str, np.ndarray]
        Dictionary mapping method names to prediction arrays (cell type indices).
    confidences : Dict[str, np.ndarray]
        Dictionary mapping method names to confidence arrays.
    cell_types : List[str]
        List of possible cell type names.
    min_agreement : float
        Minimum weighted agreement (normalised vote share of the winner) for a
        cell to keep its consensus label; cells below it get ``unknown_label``.
        Default 0.0 (no threshold; callers such as
        ``compute_refinement_consensus`` apply their own threshold).
    method_weights : Dict[str, float], optional
        Weights for each method. Default: equal weights (1.0 for all).
    unknown_label : str
        Label for cells that cannot be resolved: no method cast a positive
        vote (all confidences 0, or every prediction outside ``cell_types``),
        or two or more cell types tie for the top vote. Default "Unknown".

    Notes
    -----
    Before this guard, ``np.argmax`` on an all-zero vote row returned index 0,
    so unresolved cells silently received ``cell_types[0]`` (the alphabetically
    first type when ``cell_types`` is sorted, e.g. "B cell") with confidence 0.
    Exact ties were likewise broken alphabetically.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        (consensus_predictions, consensus_confidences)
    """
    methods = list(predictions.keys())
    if not methods:
        raise ValueError("compute_weighted_consensus needs at least one method.")
    n_cells = len(predictions[methods[0]])
    cell_types = list(cell_types)
    n_types = len(cell_types)

    if n_types == 0:
        # Nothing to vote for: every cell is unresolved.
        return np.full(n_cells, unknown_label, dtype=object), np.zeros(n_cells)

    # Default method weights
    if method_weights is None:
        method_weights = dict.fromkeys(methods, 1.0)

    # Build a lookup from cell type name → integer index (O(1) per lookup)
    ct_index = {ct: i for i, ct in enumerate(cell_types)}

    # Build weighted vote matrix — vectorised per method (A4)
    vote_matrix = np.zeros((n_cells, n_types))

    for method in methods:
        preds = predictions[method]
        confs = np.asarray(confidences[method], dtype=float)
        # Negative or non-finite confidences must not cancel other methods' votes.
        confs = np.where(np.isfinite(confs), np.clip(confs, 0.0, None), 0.0)
        weight = method_weights.get(method, 1.0)

        # Convert string predictions to integer indices in one pass
        if isinstance(preds[0], str):
            idx_array = np.array([ct_index.get(p, -1) for p in preds], dtype=int)
        else:
            idx_array = np.asarray(preds, dtype=int)

        # Keep only valid indices (unknown cell types map to -1 and are skipped)
        valid = idx_array >= 0
        rows = np.where(valid)[0]
        cols = idx_array[valid]
        np.add.at(vote_matrix, (rows, cols), confs[valid] * weight)

    # Normalize votes
    raw_sums = vote_matrix.sum(axis=1)
    vote_sums = raw_sums.copy()
    vote_sums[vote_sums == 0] = 1  # Avoid division by zero
    vote_matrix_norm = vote_matrix / vote_sums[:, None]

    # Get consensus
    consensus_idx = np.argmax(vote_matrix_norm, axis=1)
    consensus_conf = np.max(vote_matrix_norm, axis=1)

    # Convert indices to cell type names (object dtype so unknown_label is
    # never truncated by a fixed-width string dtype).
    consensus_preds = np.array([cell_types[i] for i in consensus_idx], dtype=object)

    # Guard 1: no positive vote at all -> argmax returned index 0 by default.
    no_vote = raw_sums <= 0
    # Guard 2: exact tie for the top vote -> argmax broke it by list order.
    n_at_max = np.isclose(vote_matrix_norm, consensus_conf[:, None], rtol=0.0, atol=1e-12).sum(axis=1)
    tie = (~no_vote) & (n_at_max > 1)
    # Guard 3: optional agreement threshold (documented, previously unused).
    weak = (~no_vote) & (consensus_conf < min_agreement)

    consensus_preds[no_vote | tie | weak] = unknown_label
    consensus_conf[no_vote] = 0.0

    n_no_vote, n_tie, n_weak = int(no_vote.sum()), int(tie.sum()), int((weak & ~tie).sum())
    if n_no_vote or n_tie or n_weak:
        logger.info(
            f"Weighted consensus: {n_no_vote} cells with no vote, {n_tie} tied, "
            f"{n_weak} below min_agreement={min_agreement} -> '{unknown_label}'"
        )

    return consensus_preds, consensus_conf


# compute_majority_vote was removed (A3): it was a near-duplicate of
# compute_weighted_consensus with method_weights=None.
# Replace any call site with: compute_weighted_consensus(..., method_weights=None)


# =============================================================================
# CONFORMAL PREDICTION
# =============================================================================


def compute_nonconformity_scores(
    scores: np.ndarray, true_labels: np.ndarray, method: str = "aps"
) -> np.ndarray:
    """
    Compute nonconformity scores for conformal prediction.

    .. important::
        ``true_labels`` must be **ground-truth class indices**, not model
        predictions.  The nonconformity score is computed for the *correct*
        class of each calibration sample.

    Parameters
    ----------
    scores : np.ndarray
        Score matrix of shape (n_samples, n_classes).
    true_labels : np.ndarray
        Ground-truth class indices (integers) for each calibration sample.
    method : str
        Nonconformity method: 'simple', 'aps', 'raps'.

    Returns
    -------
    np.ndarray
        Nonconformity scores.
    """
    n_samples, n_classes = scores.shape
    true_labels = np.asarray(true_labels, dtype=int)

    if method == "simple":
        # Vectorised: 1 - score of the true class for each sample
        nonconformity = 1.0 - scores[np.arange(n_samples), true_labels]

    elif method in ["aps", "raps"]:
        # Sort scores descending for all samples at once
        sorted_indices = np.argsort(-scores, axis=1)  # (n, k)
        sorted_scores = scores[np.arange(n_samples)[:, None], sorted_indices]
        row_sums = sorted_scores.sum(axis=1, keepdims=True)
        probs = sorted_scores / (row_sums + 1e-10)  # (n, k)
        cumprobs = np.cumsum(probs, axis=1)  # (n, k)

        # Position of the true class in the sorted order for each sample
        pred_pos = (sorted_indices == true_labels[:, None]).argmax(axis=1)  # (n,)

        nonconformity = cumprobs[np.arange(n_samples), pred_pos]

        if method == "raps":
            lambda_reg = 0.01
            k_reg = 5
            penalty = np.where(pred_pos >= k_reg, lambda_reg * (pred_pos - k_reg + 1), 0.0)
            nonconformity = nonconformity + penalty
    else:
        raise ValueError(f"Unknown nonconformity method: {method}")

    return nonconformity


def calibrate_conformal_threshold(calibration_scores: np.ndarray, alpha: float = 0.1) -> float:
    """
    Calibrate conformal threshold from calibration data.

    Parameters
    ----------
    calibration_scores : np.ndarray
        Nonconformity scores from calibration set.
    alpha : float
        Miscoverage rate. Default 0.1 = 90% coverage.

    Returns
    -------
    float
        Calibrated threshold.
    """
    n = len(calibration_scores)
    q = np.ceil((n + 1) * (1 - alpha)) / n
    q = min(q, 1.0)
    return np.quantile(calibration_scores, q)


def predict_conformal_sets(
    scores: np.ndarray, threshold: float, class_names: list[str], method: str = "aps"
) -> list[list[str]]:
    """
    Generate prediction sets using conformal prediction.

    Parameters
    ----------
    scores : np.ndarray
        Score matrix of shape (n_samples, n_classes).
    threshold : float
        Calibrated conformal threshold.
    class_names : List[str]
        Names of classes.
    method : str
        Nonconformity method.

    Returns
    -------
    List[List[str]]
        Prediction set for each sample.
    """
    n_samples, n_classes = scores.shape
    prediction_sets = []

    for i in range(n_samples):
        pred_set = []

        if method == "simple":
            for j in range(n_classes):
                if scores[i, j] >= (1 - threshold):
                    pred_set.append(class_names[j])

        elif method in ["aps", "raps"]:
            sorted_indices = np.argsort(-scores[i])
            sorted_scores = scores[i, sorted_indices]
            probs = sorted_scores / (sorted_scores.sum() + 1e-10)

            cumsum = 0
            for j, idx in enumerate(sorted_indices):
                cumsum += probs[j]
                pred_set.append(class_names[idx])

                penalty = 0
                if method == "raps" and j >= 5:
                    penalty = 0.01 * (j - 5 + 1)

                if cumsum + penalty > threshold:
                    break

        if not pred_set:
            best_idx = np.argmax(scores[i])
            pred_set = [class_names[best_idx]]

        prediction_sets.append(pred_set)

    return prediction_sets


def conformal_set_to_confidence(prediction_sets: list[list[str]], n_classes: int) -> np.ndarray:
    """
    Convert prediction set sizes to confidence scores.

    Parameters
    ----------
    prediction_sets : List[List[str]]
        Prediction sets for each sample.
    n_classes : int
        Total number of possible classes.

    Returns
    -------
    np.ndarray
        Confidence scores in [0, 1].
    """
    confidences = np.zeros(len(prediction_sets))

    for i, pred_set in enumerate(prediction_sets):
        set_size = len(pred_set)
        if set_size == 0:
            confidences[i] = 0.0
        elif n_classes > 1:
            confidences[i] = 1 - (set_size - 1) / (n_classes - 1)
        else:
            confidences[i] = 1.0

    return confidences


# =============================================================================
# FEATURE OVERLAP UTILITIES
# =============================================================================


def compute_feature_overlap(
    model_features: set,
    panel_features: set,
) -> dict:
    """
    Compute overlap statistics between a model's feature set and a panel.

    Used by ``diagnose_celltypist_model``, ``cell_typing_celltypist``,
    ``diagnose_scarches``, and ``diagnose_scimilarity`` to avoid duplicated
    overlap arithmetic.

    Parameters
    ----------
    model_features : set
        Feature names from the model (e.g. CellTypist model.features).
    panel_features : set
        Feature names (var_names) from the AnnData being annotated.

    Returns
    -------
    dict with keys:
        overlap        : set   — genes present in both
        n_overlap      : int
        n_panel        : int
        n_model        : int
        panel_coverage : float — overlap / panel  (KEY metric, %)
        model_coverage : float — overlap / model  (expected low for targeted panels, %)
    """
    overlap = model_features & panel_features
    n_panel = max(len(panel_features), 1)
    n_model = max(len(model_features), 1)
    return {
        "overlap": overlap,
        "n_overlap": len(overlap),
        "n_panel": len(panel_features),
        "n_model": len(model_features),
        "panel_coverage": 100.0 * len(overlap) / n_panel,
        "model_coverage": 100.0 * len(overlap) / n_model,
    }


# =============================================================================
# PREDICTION COMBINATION UTILITIES
# =============================================================================


def combine_primary_with_consensus(
    primary_predictions: np.ndarray,
    primary_confidences: np.ndarray,
    primary_threshold: float,
    consensus_predictions: np.ndarray,
    consensus_confidences: np.ndarray,
    consensus_threshold: float = 0.5,
    unknown_label: str = "Unknown",
    source_label: str = "primary",
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Combine primary method predictions with consensus refinement.

    Shared implementation used by CellTypist, scArches, and SCimilarity
    combination functions.  All three follow the same 3-branch decision logic:

    1. Primary confidence >= ``primary_threshold``
       → keep primary prediction
    2. Primary confidence < threshold AND consensus confidence >= ``consensus_threshold``
       → use consensus prediction
    3. Both below their respective thresholds
       → mark as ``unknown_label``

    Parameters
    ----------
    primary_predictions : np.ndarray
        Cell type predictions from the primary method.
    primary_confidences : np.ndarray
        Confidence scores from the primary method [0, 1].
    primary_threshold : float
        Minimum primary confidence to accept a prediction directly.
    consensus_predictions : np.ndarray
        Consensus cell type predictions.
    consensus_confidences : np.ndarray
        Consensus confidence scores [0, 1].
    consensus_threshold : float
        Minimum consensus confidence to use a consensus prediction.
        Default 0.5.
    unknown_label : str
        Label assigned when both methods are below their thresholds.
        Default ``"Unknown"``.
    source_label : str
        Label used in the ``source`` array for high-confidence primary cells.
        Default ``"primary"``; callers pass ``"celltypist"``, ``"scarches"``,
        ``"scimilarity"``, etc.

    Returns
    -------
    refined_predictions : np.ndarray
        Final cell type predictions.
    refined_confidences : np.ndarray
        Final confidence scores.
    source : np.ndarray
        Per-cell source label: ``source_label``, ``"consensus"``, or
        ``"unknown"``.
    """
    needs_refinement = primary_confidences < primary_threshold
    consensus_ok = consensus_confidences >= consensus_threshold

    # Vectorised three-branch logic using np.where
    source = np.where(
        ~needs_refinement,
        source_label,
        np.where(consensus_ok, "consensus", "unknown"),
    )

    refined_predictions = np.where(
        ~needs_refinement,
        primary_predictions,
        np.where(consensus_ok, consensus_predictions, unknown_label),
    )

    # For "unknown" cells keep the higher of the two confidence scores
    # (best available signal rather than discarding both).
    refined_confidences = np.where(
        ~needs_refinement,
        primary_confidences,
        np.where(
            consensus_ok,
            consensus_confidences,
            np.maximum(primary_confidences, consensus_confidences),
        ),
    )

    n_primary = int((source == source_label).sum())
    n_consensus = int((source == "consensus").sum())
    n_unknown = int((source == "unknown").sum())

    logger.info(
        f"combine_primary_with_consensus [{source_label}]: "
        f"{n_primary} primary, {n_consensus} consensus, {n_unknown} unknown"
    )

    return refined_predictions, refined_confidences, source


# =============================================================================
# NEIGHBORHOOD UTILITIES
# =============================================================================


def compute_neighborhood_consensus(
    adata, cell_type_col: str, n_neighbors: int = Defaults.N_NEIGHBORS, use_rep: str = ObsmKeys.PCA
) -> tuple[np.ndarray, np.ndarray]:
    """
    Compute neighborhood consensus for cell type assignments.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type assignments.
    cell_type_col : str
        Column containing cell type annotations.
    n_neighbors : int
        Number of neighbors to consider.
    use_rep : str
        Representation to use for neighbor computation.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        (consensus_types, consensus_fractions)
    """
    if use_rep not in adata.obsm:
        raise ValueError(f"Representation '{use_rep}' not found in adata.obsm")

    X = adata.obsm[use_rep]
    cell_types = adata.obs[cell_type_col].values

    # Fit nearest neighbors
    nn = NearestNeighbors(n_neighbors=n_neighbors + 1)  # +1 to exclude self
    nn.fit(X)
    _, indices = nn.kneighbors(X)

    # Exclude self (first neighbor): shape (n_cells, n_neighbors)
    neighbor_indices = indices[:, 1:]

    # Vectorised majority vote (A9):
    # 1. Encode cell type strings as integers
    unique_types, encoded = np.unique(cell_types, return_inverse=True)
    n_types_unique = len(unique_types)

    # 2. Gather neighbour labels: (n_cells, n_neighbors)
    neighbor_labels = encoded[neighbor_indices]

    # 3. Count votes per type for each cell using a 2-D bincount
    #    np.apply_along_axis with bincount is cleaner than a loop
    n_cells = len(cell_types)
    vote_counts = np.apply_along_axis(
        lambda row: np.bincount(row, minlength=n_types_unique),
        axis=1,
        arr=neighbor_labels,
    )  # shape (n_cells, n_types_unique)

    # 4. Consensus = argmax of vote counts; fraction = max_count / n_neighbors
    consensus_encoded = vote_counts.argmax(axis=1)
    consensus_types = unique_types[consensus_encoded]
    consensus_fracs = vote_counts[np.arange(n_cells), consensus_encoded] / n_neighbors

    return consensus_types, consensus_fracs


def refine_with_neighborhood(
    adata,
    cell_type_col: str,
    confidence_col: str,
    confidence_threshold: float,
    consensus_threshold: float = Defaults.NEIGHBORHOOD_CONSENSUS,
    n_neighbors: int = Defaults.N_NEIGHBORS,
    output_col: str | None = None,
):
    """
    Refine low-confidence cell type assignments using neighborhood consensus.

    Parameters
    ----------
    adata : AnnData
        Annotated data.
    cell_type_col : str
        Column with cell type assignments.
    confidence_col : str
        Column with confidence scores.
    confidence_threshold : float
        Cells below this confidence are candidates for refinement.
    consensus_threshold : float
        Minimum neighbor agreement for reassignment.
    n_neighbors : int
        Number of neighbors.
    output_col : str, optional
        Output column name. If None, modifies cell_type_col in place.

    Returns
    -------
    int
        Number of cells refined.
    """
    if output_col is None:
        output_col = cell_type_col

    # Get low confidence cells
    low_conf_mask = adata.obs[confidence_col] < confidence_threshold

    if not low_conf_mask.any():
        logger.info("No low-confidence cells to refine")
        return 0

    # Compute neighborhood consensus
    consensus_types, consensus_fracs = compute_neighborhood_consensus(
        adata, cell_type_col, n_neighbors
    )

    # Copy original assignments
    refined = adata.obs[cell_type_col].values.copy()

    # Vectorised refinement (A8): build a boolean mask for all three conditions
    # at once and apply a single array assignment instead of a Python loop.
    refine_mask = (
        np.asarray(low_conf_mask)
        & (consensus_fracs >= consensus_threshold)
        & (refined != consensus_types)
    )
    refined[refine_mask] = consensus_types[refine_mask]
    n_refined = int(refine_mask.sum())

    adata.obs[output_col] = refined

    logger.info(f"Refined {n_refined} cells using neighborhood consensus")

    return n_refined


# =============================================================================
# THRESHOLD CALCULATION
# =============================================================================


def calculate_optimal_threshold(
    scores: np.ndarray,
    percentile: int = 50,
    method: str = "percentile",
) -> float:
    """
    Calculate optimal threshold for confidence scores.

    .. note::
        This is a standalone diagnostic utility. It is **not** called by
        ``run_refinement_pipeline`` — use the ``consensus_threshold`` and
        ``biomarker_threshold`` parameters of that function instead.

    Parameters
    ----------
    scores : np.ndarray
        Confidence or score values.
    percentile : int
        Percentile to use for threshold. Default: 50 (median)
    method : str
        Method: 'percentile', 'otsu', 'mean_std'.

    Returns
    -------
    float
        Calculated threshold.
    """
    scores = scores[~np.isnan(scores)]

    if len(scores) == 0:
        return 0.5

    if method == "percentile":
        return np.percentile(scores, percentile)

    elif method == "mean_std":
        return np.mean(scores) - np.std(scores)

    elif method == "otsu":
        # Otsu's method for bimodal distribution
        hist, bin_edges = np.histogram(scores, bins=50)
        bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2

        total = hist.sum()
        current_max = 0
        threshold = bin_centers[0]

        sum_total = np.sum(bin_centers * hist)
        sum_bg = 0
        weight_bg = 0

        for _i, (count, center) in enumerate(zip(hist, bin_centers)):
            weight_bg += count
            if weight_bg == 0:
                continue

            weight_fg = total - weight_bg
            if weight_fg == 0:
                break

            sum_bg += count * center
            mean_bg = sum_bg / weight_bg
            mean_fg = (sum_total - sum_bg) / weight_fg

            variance_between = weight_bg * weight_fg * (mean_bg - mean_fg) ** 2

            if variance_between > current_max:
                current_max = variance_between
                threshold = center

        return threshold

    else:
        raise ValueError(f"Unknown threshold method: {method}")


# =============================================================================
# EXPRESSION UTILITIES
# =============================================================================


def get_expression_matrix(adata, use_raw: bool = False, as_dense: bool = True) -> np.ndarray:
    """
    Get expression matrix from AnnData.

    Parameters
    ----------
    adata : AnnData
        Annotated data.
    use_raw : bool
        Use raw counts if available.
    as_dense : bool
        Convert sparse to dense.

    Returns
    -------
    np.ndarray
        Expression matrix.
    """
    X = adata.raw.X if use_raw and adata.raw is not None else adata.X

    if as_dense and sparse.issparse(X):
        X = X.toarray()

    return X


def zscore_normalize(X: np.ndarray, axis: int = 0) -> np.ndarray:
    """
    Z-score normalize expression matrix.

    Parameters
    ----------
    X : np.ndarray
        Expression matrix.
    axis : int
        Axis along which to normalize. 0 = per gene, 1 = per cell.

    Returns
    -------
    np.ndarray
        Z-score normalized matrix.
    """
    mean = X.mean(axis=axis, keepdims=True)
    std = X.std(axis=axis, keepdims=True)
    std[std == 0] = 1  # Avoid division by zero
    return (X - mean) / std


# =============================================================================
# MARKER ANALYSIS
# =============================================================================


def analyze_marker_coverage(adata, marker_dict: dict[str, list[str]]) -> pd.DataFrame:
    """
    Analyze marker gene coverage in data.

    Parameters
    ----------
    adata : AnnData
        Annotated data.
    marker_dict : dict
        Marker dictionary mapping cell types to gene lists.

    Returns
    -------
    pd.DataFrame
        Coverage statistics per cell type with columns:
        - cell_type: Cell type name
        - total_markers: Total markers defined
        - found: Number of markers found in data
        - missing: Number of missing markers
        - coverage: Fraction of markers found
        - missing_genes: List of missing gene names
    """
    results = []

    for cell_type, markers in marker_dict.items():
        found, missing = find_markers_in_data(markers, adata.var_names)

        results.append(
            {
                "cell_type": cell_type,
                "total_markers": len(markers),
                "found": len(found),
                "missing": len(missing),
                "coverage": len(found) / len(markers) if markers else 0,
                "missing_genes": ", ".join(missing[:5]) + ("..." if len(missing) > 5 else ""),
            }
        )

    return pd.DataFrame(results)


def summarize_marker_expression(
    adata, marker_dict: dict[str, list[str]], cell_type_key: str = None
) -> pd.DataFrame:
    """
    Summarize marker expression by cell type.

    Parameters
    ----------
    adata : AnnData
        Annotated data.
    marker_dict : dict
        Marker dictionary.
    cell_type_key : str, optional
        Column name for cell types.

    Returns
    -------
    pd.DataFrame
        Summary statistics including mean expression and fold change.
    """
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE

    X = get_expression_matrix(adata, as_dense=True)
    results = []

    for ct, markers in marker_dict.items():
        found, _ = find_markers_in_data(markers, adata.var_names)
        if not found:
            continue

        marker_idx = [adata.var_names.get_loc(m) for m in found]
        ct_mask = adata.obs[cell_type_key] == ct

        if ct_mask.sum() == 0:
            continue

        # Mean expression in this cell type
        ct_expr = X[ct_mask][:, marker_idx].mean()

        # Mean expression in other cell types
        other_expr = X[~ct_mask][:, marker_idx].mean() if (~ct_mask).sum() > 0 else 0

        results.append(
            {
                "cell_type": ct,
                "n_cells": ct_mask.sum(),
                "n_markers": len(found),
                "mean_expr_in_type": ct_expr,
                "mean_expr_in_others": other_expr,
                "fold_change": ct_expr / (other_expr + 1e-10),
            }
        )

    return pd.DataFrame(results)


# =============================================================================
# QUALITY CONTROL
# =============================================================================


def perform_qc_filtering(
    adata,
    min_counts: int = 50,
    min_genes: int = 10,
    max_pct_mito: float = 20.0,
):
    """
    Perform QC filtering and return a filtered copy.

    .. note::
        Always returns a new AnnData object.  The ``inplace`` parameter was
        removed because the mitochondrial filter requires creating a new
        object (boolean indexing returns a view/copy), making true in-place
        modification impossible without a full reassignment that the caller
        cannot observe.  Assign the return value::

            adata = perform_qc_filtering(adata)

    Parameters
    ----------
    adata : AnnData
        Input data.
    min_counts : int
        Minimum total counts per cell. Default: 50.
    min_genes : int
        Minimum genes detected per cell. Default: 10.
    max_pct_mito : float
        Maximum percentage mitochondrial genes. Default: 20.0.

    Returns
    -------
    AnnData
        Filtered copy of the input data.
    """
    import scanpy as sc

    adata_work = adata.copy()

    # Calculate QC metrics
    adata_work.var["mt"] = adata_work.var_names.str.startswith("MT-")
    sc.pp.calculate_qc_metrics(adata_work, qc_vars=["mt"], inplace=True)

    n_before = adata_work.n_obs

    sc.pp.filter_cells(adata_work, min_counts=min_counts)
    sc.pp.filter_cells(adata_work, min_genes=min_genes)

    if "pct_counts_mt" in adata_work.obs.columns:
        adata_work = adata_work[adata_work.obs["pct_counts_mt"] < max_pct_mito].copy()

    n_after = adata_work.n_obs
    logger.info(f"QC filtering: {n_before} -> {n_after} cells ({n_before - n_after} removed)")

    return adata_work


def compute_qc_metrics(adata) -> pd.DataFrame:
    """
    Compute QC metrics for cells.

    Parameters
    ----------
    adata : AnnData
        Input data.

    Returns
    -------
    pd.DataFrame
        QC metrics per cell.
    """
    import scanpy as sc

    # A12: avoid copying the full expression matrix just to add a var column.
    # Add "mt" to a shallow copy of var only; calculate_qc_metrics writes
    # results into obs (not X), so we can work on a view.
    if "mt" not in adata.var.columns:
        adata.var["mt"] = adata.var_names.str.startswith("MT-")
    sc.pp.calculate_qc_metrics(adata, qc_vars=["mt"], inplace=True)

    return adata.obs[["n_genes_by_counts", "total_counts", "pct_counts_mt"]].copy()


def save_annotation_statistics(
    adata, output_path: str, confidence_key: str = None, cell_type_key: str = None
) -> None:
    """
    Save annotation statistics to file.

    Parameters
    ----------
    adata : AnnData
        Annotated data.
    output_path : str
        Output file path.
    confidence_key : str, optional
        Column name for confidence.
    cell_type_key : str, optional
        Column name for cell types.
    """
    from pathlib import Path

    if confidence_key is None:
        confidence_key = ColumnNames.CONFIDENCE
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE

    output_path = Path(output_path)

    # Overall statistics
    conf = adata.obs[confidence_key]

    stats = {
        "n_cells": len(conf),
        "mean_confidence": conf.mean(),
        "median_confidence": conf.median(),
        "std_confidence": conf.std(),
        "min_confidence": conf.min(),
        "max_confidence": conf.max(),
        # A13: use Defaults.CONFIDENCE_THRESHOLD so this stat is consistent
        # with the threshold used elsewhere in the pipeline.
        "pct_low_confidence": (conf < Defaults.CONFIDENCE_THRESHOLD).mean() * 100,
    }

    # Per cell type
    if cell_type_key in adata.obs.columns:
        ct_stats = adata.obs.groupby(cell_type_key)[confidence_key].agg(
            ["mean", "median", "std", "count"]
        )
        ct_stats.to_csv(output_path.with_suffix(".celltype_stats.csv"))

    # Save overall stats
    pd.Series(stats).to_csv(output_path)


# =============================================================================
# SPATIAL VARIABILITY FILTERING
# =============================================================================


def compute_spatial_autocorr(
    adata,
    genes: list[str],
    n_neighbors: int = 6,
    use_squidpy: bool = True,
) -> pd.Series:
    """
    Compute Moran's I spatial autocorrelation for a list of genes.

    Moran's I ranges from -1 (perfect dispersion) to +1 (perfect clustering),
    with ~0 indicating random / uniform expression. Genes with high Moran's I
    are expressed in spatially coherent patches and are informative markers.

    Parameters
    ----------
    adata : AnnData
        Must contain spatial coordinates in ``adata.obsm['spatial']``.
    genes : list of str
        Genes to evaluate. Genes absent from ``adata.var_names`` are skipped.
    n_neighbors : int
        Number of spatial neighbours used to build the weight matrix.
        Default: 6 (hex-grid neighbourhood typical of Xenium).
    use_squidpy : bool
        Try squidpy first (faster for large datasets). Falls back to a
        pure-numpy implementation when squidpy is not installed.

    Returns
    -------
    pd.Series
        Moran's I value indexed by gene name, for genes present in the data.

    Examples
    --------
    >>> scores = compute_spatial_autocorr(adata, ["CD3D", "KRT18", "ACTB"])
    >>> scores.sort_values(ascending=False)
    """
    if "spatial" not in adata.obsm:
        raise ValueError(
            "No spatial coordinates found in adata.obsm['spatial']. "
            "Spatial autocorrelation requires spatial coordinates."
        )

    # Keep only genes that exist in the data
    present = [g for g in genes if g in adata.var_names]
    if not present:
        logger.warning("compute_spatial_autocorr: no requested genes found in adata.var_names")
        return pd.Series(dtype=float)

    # ── squidpy path ────────────────────────────────────────────────────────
    if use_squidpy:
        try:
            import squidpy as sq

            adata_tmp = adata.copy()
            sq.gr.spatial_neighbors(adata_tmp, n_neighs=n_neighbors, coord_type="generic")
            sq.gr.spatial_autocorr(adata_tmp, genes=present, mode="moran", show_progress_bar=False)
            mi_df = adata_tmp.uns["moranI"]
            return mi_df["I"].reindex(present).fillna(0.0)
        except ImportError:
            logger.debug("squidpy not available – falling back to numpy Moran's I")
        except Exception as e:
            logger.debug(f"squidpy spatial_autocorr failed ({e}) – falling back to numpy")

    # ── Pure-numpy fallback ──────────────────────────────────────────────────
    coords = np.array(adata.obsm["spatial"])
    n = len(coords)

    # Build binary KNN weight matrix (excluding self)
    nn = NearestNeighbors(n_neighbors=n_neighbors + 1, algorithm="ball_tree")
    nn.fit(coords)
    _, indices = nn.kneighbors(coords)

    # Binary (unweighted) KNN weight matrix W — global normalisation (n/W_sum)
    # is applied in the Moran's I formula below, which is the standard approach.
    rows, cols = [], []
    for i, nbrs in enumerate(indices[:, 1:]):  # skip self (index 0)
        for j in nbrs:
            rows.append(i)
            cols.append(j)
    W = sparse.csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n), dtype=float)
    W_sum = W.sum()

    results: dict[str, float] = {}
    for gene in present:
        x = adata[:, gene].X
        x = x.toarray().ravel() if sparse.issparse(x) else np.asarray(x).ravel()

        x_dev = x - x.mean()
        denom = float(np.dot(x_dev, x_dev))
        if denom == 0.0:
            results[gene] = 0.0
            continue

        # W @ x_dev  (sparse matrix × dense vector)
        Wx = W.dot(x_dev)
        numer = float(np.dot(x_dev, Wx))
        results[gene] = (n / W_sum) * (numer / denom)

    return pd.Series(results)


def _parse_marker_entry(entry):
    """
    Normalise a marker dictionary entry to (positive_genes, negative_genes).

    Accepts two formats — both are supported transparently throughout the
    celltype package:

    Old format (list) — positive markers only, backwards compatible:
        "T_cell": ["CD3D", "CD3E", "CD8A"]

    New format (dict) — explicit positive and negative markers:
        "T_cell": {"positive": ["CD3D", "CD3E", "CD8A"],
                   "negative": ["EPCAM", "CD68"]}

    Returns
    -------
    positive : list  genes whose high expression supports the cell type
    negative : list  genes whose high expression penalises the cell type
    """
    if isinstance(entry, list):
        return entry, []
    if isinstance(entry, dict):
        positive = entry.get("positive", [])
        negative = entry.get("negative", [])
        if not isinstance(positive, list) or not isinstance(negative, list):
            raise ValueError(
                "Marker entry dict must have 'positive' and 'negative' keys "
                "each mapping to a list of gene symbols."
            )
        return positive, negative
    raise TypeError(
        f"Marker entry must be a list or dict, got {type(entry).__name__}. "
        "Use ['GENE1', 'GENE2'] for positive-only or "
        "{'positive': [...], 'negative': [...]} for signed markers."
    )


def filter_spatially_variable_markers(
    adata,
    marker_dict: dict[str, list[str]],
    min_morans_i: float = 0.025,
    n_neighbors: int = 6,
    use_squidpy: bool = True,
    min_markers_per_type: int = 3,
    verbose: bool = True,
    threshold_mode: str = "zscore",
    n_std: float = 0.25,
    top_pct: float = 25.0,
) -> tuple[dict[str, list[str]], pd.DataFrame]:
    """
    Remove spatially uniform markers before annotation.

    Genes with low Moran's I (expressed ubiquitously or randomly throughout
    the tissue) are uninformative for spatial cell-type assignment and can
    actively mislead scoring by inflating scores for the wrong cell types.

    Only genes actually present in ``adata.var_names`` are evaluated.
    Cell types that retain at least ``min_markers_per_type`` spatially-variable
    markers keep only those filtered markers (non-spatial genes are always
    dropped).  Cell types whose retained marker count falls below
    ``min_markers_per_type`` are excluded from the returned dictionary entirely.

    The effective cut-off is determined by ``threshold_mode``:

    * ``"zscore"`` *(default)* — keeps genes with Moran's I above
      ``mean + n_std × std`` of all evaluated genes in this core, with
      ``min_morans_i`` as a hard floor.  Adapts to each core's overall
      spatial structure: a lymphoid-rich core and a fibrotic core will
      use different effective thresholds automatically.
    * ``"percentile"`` — keeps the top ``top_pct``% of genes by Moran's I,
      again with ``min_morans_i`` as a floor.  Simple and always
      data-relative, but always retains the same fraction regardless of
      how many genes are genuinely spatial.
    * ``"fixed"`` — original behaviour: keeps every gene with
      Moran's I ≥ ``min_morans_i``.  Consistent across cores but blind to
      per-core baseline differences.

    Parameters
    ----------
    adata : AnnData
        Spatial data with ``adata.obsm['spatial']``.
    marker_dict : dict
        Mapping of cell type → marker gene list.
    min_morans_i : float
        Hard floor on the effective threshold regardless of ``threshold_mode``.
        Genes below this value are always removed.  Default: 0.025.
    n_neighbors : int
        Spatial neighbourhood size for Moran's I computation. Default: 6.
    use_squidpy : bool
        Prefer squidpy for autocorrelation if available. Default: True.
    min_markers_per_type : int
        Minimum number of spatially-variable markers a cell type must retain
        to remain in the returned dictionary. Cell types with fewer than this
        many markers after filtering are excluded entirely.  The threshold
        matches the point at which ``sc.tl.score_genes`` background noise
        dominates and scType specificity-weighting becomes unreliable.
        Default: 3.
    verbose : bool
        Print a summary of kept / removed markers. Default: True.
    threshold_mode : str
        Strategy for computing the effective Moran's I cut-off.
        One of ``"zscore"`` (default), ``"percentile"``, or ``"fixed"``.
    n_std : float
        Number of standard deviations above the mean used in
        ``threshold_mode="zscore"``. Default: 0.25.
    top_pct : float
        Percentage of top-ranked genes to retain in
        ``threshold_mode="percentile"`` (e.g. 25 keeps the top 25%).
        Default: 25.0.

    Returns
    -------
    filtered_dict : dict
        Marker dictionary containing only spatially variable markers.
    report : pd.DataFrame
        Per-gene report with columns: gene, morans_i, effective_threshold,
        kept, cell_types.

    Examples
    --------
    >>> # Adaptive z-score mode (recommended for multi-core TMA workflows)
    >>> filtered_dict, report = filter_spatially_variable_markers(
    ...     adata, marker_dict, threshold_mode="zscore", n_std=0.25
    ... )

    >>> # Fixed threshold (original behaviour)
    >>> filtered_dict, report = filter_spatially_variable_markers(
    ...     adata, marker_dict, threshold_mode="fixed", min_morans_i=0.1
    ... )
    """
    _VALID_MODES = {"zscore", "percentile", "fixed"}
    if threshold_mode not in _VALID_MODES:
        raise ValueError(f"threshold_mode must be one of {_VALID_MODES!r}, got {threshold_mode!r}.")

    if "spatial" not in adata.obsm:
        logger.warning(
            "filter_spatially_variable_markers: no spatial coordinates found – "
            "returning original marker_dict unchanged."
        )
        empty_report = pd.DataFrame(
            columns=["gene", "morans_i", "effective_threshold", "kept", "cell_types"]
        )
        return marker_dict, empty_report

    # Collect every unique marker (positive + negative) that is actually in the data.
    # _parse_marker_entry handles both the plain-list and signed-dict formats.
    all_markers_in_data = list(
        {
            m
            for entry in marker_dict.values()
            for genes in _parse_marker_entry(entry)  # returns (pos_list, neg_list)
            for m in genes
            if m in adata.var_names
        }
    )

    logger.info(
        f"filter_spatially_variable_markers: computing Moran's I for "
        f"{len(all_markers_in_data)} genes …"
    )

    morans_i = compute_spatial_autocorr(
        adata, all_markers_in_data, n_neighbors=n_neighbors, use_squidpy=use_squidpy
    )

    # ── Compute the effective threshold for this core ──────────────────────
    evaluated_values = morans_i.values  # only genes actually in the panel

    if threshold_mode == "zscore":
        mu = float(np.mean(evaluated_values))
        sigma = float(np.std(evaluated_values))
        adaptive_cutoff = mu + n_std * sigma
        effective_threshold = max(min_morans_i, adaptive_cutoff)
        logger.info(
            f"  threshold_mode=zscore: mean={mu:.4f}, std={sigma:.4f}, "
            f"adaptive={adaptive_cutoff:.4f}, floor={min_morans_i} "
            f"→ effective threshold={effective_threshold:.4f}"
        )

    elif threshold_mode == "percentile":
        pct_cutoff = float(np.percentile(evaluated_values, 100.0 - top_pct))
        effective_threshold = max(min_morans_i, pct_cutoff)
        logger.info(
            f"  threshold_mode=percentile: top {top_pct}% cut-off={pct_cutoff:.4f}, "
            f"floor={min_morans_i} → effective threshold={effective_threshold:.4f}"
        )

    else:  # "fixed"
        effective_threshold = min_morans_i
        logger.info(f"  threshold_mode=fixed: effective threshold={effective_threshold:.4f}")

    # Genes that pass the effective threshold
    passed_set = set(morans_i[morans_i >= effective_threshold].index.tolist())

    # Build per-gene → cell types map for the report (covers positive + negative)
    gene_to_types: dict[str, list[str]] = {}
    for ct, entry in marker_dict.items():
        pos_genes, neg_genes = _parse_marker_entry(entry)
        for m in pos_genes + neg_genes:
            gene_to_types.setdefault(m, []).append(ct)

    # Build filtered dictionary, excluding types that lack sufficient spatial signal.
    # A cell type is kept only when it retains at least min_markers_per_type *positive*
    # markers that (a) are present in the Xenium panel AND (b) passed the Moran's I
    # threshold.  Negative markers are also filtered but do not count toward the
    # minimum.  Genes absent from the panel are silently dropped.
    # The output format mirrors the input: plain list if the entry was a plain list,
    # signed dict if the entry was a signed dict.
    panel_genes = set(adata.var_names)
    filtered_dict: dict = {}
    excluded_types: list[str] = []

    for ct, entry in marker_dict.items():
        pos_genes, neg_genes = _parse_marker_entry(entry)
        kept_pos = [m for m in pos_genes if m in passed_set and m in panel_genes]
        kept_neg = [m for m in neg_genes if m in passed_set and m in panel_genes]
        if len(kept_pos) < min_markers_per_type:
            excluded_types.append(ct)
        else:
            # Preserve the original format so downstream code receives the same type
            if isinstance(entry, dict):
                filtered_dict[ct] = {"positive": kept_pos, "negative": kept_neg}
            else:
                filtered_dict[ct] = kept_pos

    # Build report DataFrame (includes effective_threshold column for traceability)
    report_rows = []
    for gene in sorted(gene_to_types.keys()):
        mi = morans_i.get(gene, float("nan"))
        in_data = gene in morans_i.index
        kept = (not in_data) or (gene in passed_set)
        report_rows.append(
            {
                "gene": gene,
                "morans_i": round(mi, 4) if not np.isnan(mi) else float("nan"),
                "effective_threshold": round(effective_threshold, 4),
                "in_xenium_panel": in_data,
                "kept": kept,
                "cell_types": ", ".join(gene_to_types[gene]),
            }
        )
    report = pd.DataFrame(report_rows)

    # Summary log
    n_total = len(all_markers_in_data)
    n_kept = len(passed_set)
    n_removed = n_total - n_kept

    if verbose:
        logger.info(
            f"\n{'='*55}\n"
            f"Spatial variability filter  "
            f"(mode={threshold_mode}, threshold={effective_threshold:.4f})\n"
            f"{'='*55}\n"
            f"  Genes evaluated : {n_total}\n"
            f"  Kept            : {n_kept}  ({100*n_kept/max(n_total,1):.1f}%)\n"
            f"  Removed         : {n_removed}  ({100*n_removed/max(n_total,1):.1f}%)\n"
            f"  Excluded types  : {excluded_types if excluded_types else 'none'}\n"
            f"    (< {min_markers_per_type} spatially-variable markers — dropped from annotation)\n"
            f"{'='*55}"
        )
        if n_removed > 0:
            removed_genes = report[~report["kept"] & report["in_xenium_panel"]]["gene"].tolist()
            logger.info(f"  Removed genes   : {removed_genes}")

    return filtered_dict, report
