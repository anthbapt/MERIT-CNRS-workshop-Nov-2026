"""
Consensus Methods for Cell Type Annotation
==========================================

This module provides functions for combining predictions from multiple
annotation methods and refining predictions using neighborhood information.

Functions
---------
- compute_refinement_consensus: Weighted consensus from multiple methods
- refine_with_neighborhood: Refine low-confidence predictions using neighbors
- create_marker_dict_with_validation: Create marker dict with gene validation
"""

from __future__ import annotations

import logging

import numpy as np
import pandas as pd
import scanpy as sc

from .constants import (
    CELL_TYPE_PALETTE,
    ColumnNames,
    Defaults,
)
from .core_utils import (
    calibrate_confidences,
    compute_neighborhood_consensus,
    compute_weighted_consensus,
    find_markers_in_data,
)

logger = logging.getLogger(__name__)


__all__ = [
    "compute_refinement_consensus",
    "refine_with_neighborhood",
    "create_marker_dict_with_validation",
]


def compute_refinement_consensus(
    predictions: dict[str, np.ndarray],
    confidences: dict[str, np.ndarray],
    consensus_threshold: float = 0.5,
    unknown_label: str = "Unknown",
    calibration_method: str = "minmax",
) -> tuple[np.ndarray, np.ndarray, pd.DataFrame]:
    """
    Compute weighted consensus from multiple annotation methods.

    Parameters
    ----------
    predictions : dict
        Dictionary mapping method names to prediction arrays.
    confidences : dict
        Dictionary mapping method names to confidence arrays.
    consensus_threshold : float
        Minimum confidence for consensus to be accepted.
    unknown_label : str
        Label for low-confidence consensus.
    calibration_method : str
        Method to calibrate confidence scores before combining.
        Supported: ``'minmax'`` (default), ``'quantile'``, ``'none'``.
        ``'isotonic'`` and ``'platt'`` require ground-truth labels and are
        not available here; passing either will fall back to ``'minmax'``
        with a warning.

    Returns
    -------
    consensus_predictions : np.ndarray
        Consensus cell type for each cell.
    consensus_confidences : np.ndarray
        Consensus confidence for each cell.
    agreement_df : pd.DataFrame
        Agreement statistics between methods.

    Examples
    --------
    >>> preds = {"biomarker": pred1, "sctype": pred2}
    >>> confs = {"biomarker": conf1, "sctype": conf2}
    >>> consensus, conf, agreement = compute_refinement_consensus(preds, confs)
    """
    logger.info(f"Computing consensus from {len(predictions)} methods")

    # CS1: calibration_method was previously accepted but never applied.
    # 'isotonic' and 'platt' require ground-truth labels which are not
    # available here; guard against them and fall back to 'minmax'.
    _label_required = {"isotonic", "platt"}
    if calibration_method in _label_required:
        logger.warning(
            f"calibration_method='{calibration_method}' requires ground-truth labels "
            "which are not available in compute_refinement_consensus. "
            "Falling back to 'minmax'."
        )
        calibration_method = "minmax"

    if calibration_method != "none":
        confidences = calibrate_confidences(confidences, method=calibration_method)

    # Get all unique cell types
    all_cell_types = set()
    for preds in predictions.values():
        all_cell_types.update(np.unique(preds))
    cell_types = sorted(
        [ct for ct in all_cell_types if ct and str(ct).lower() not in ["unknown", "nan", ""]]
    )

    # Use core_utils function
    consensus_preds, consensus_conf = compute_weighted_consensus(
        predictions=predictions, confidences=confidences, cell_types=cell_types
    )

    # Apply threshold
    low_conf_mask = consensus_conf < consensus_threshold
    consensus_preds[low_conf_mask] = unknown_label

    # Compute agreement statistics
    agreement_data = []
    methods = list(predictions.keys())
    for i, m1 in enumerate(methods):
        for m2 in methods[i + 1 :]:
            agreement = (predictions[m1] == predictions[m2]).mean()
            agreement_data.append({"method1": m1, "method2": m2, "agreement": agreement})
    agreement_df = pd.DataFrame(agreement_data)

    n_unknown = (consensus_preds == unknown_label).sum()
    n_total = len(consensus_preds)
    logger.info(f"Consensus: {n_total - n_unknown} confident, {n_unknown} unknown")

    return consensus_preds, consensus_conf, agreement_df


def refine_with_neighborhood(
    adata: sc.AnnData,
    cell_type_key: str = None,
    confidence_key: str = None,
    coord_key: str = "X_umap",
    n_neighbors: int = 10,
    confidence_threshold: float = 0.5,
    neighborhood_consensus: float = None,
    inplace: bool = False,
) -> sc.AnnData:
    """
    Refine low-confidence predictions using neighborhood consensus.

    For cells with confidence below ``confidence_threshold``, the cell type
    is re-evaluated based on the majority vote of its neighbors.  The new
    label is only accepted when at least ``neighborhood_consensus`` fraction
    of the neighbors agree; otherwise the original label is kept.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type predictions.
    cell_type_key : str, optional
        Column name for cell type predictions.
    confidence_key : str, optional
        Column name for confidence scores.
    coord_key : str
        Key for coordinates in obsm.
    n_neighbors : int
        Number of neighbors to consider.
    confidence_threshold : float
        Cells whose confidence is below this value are candidates for
        neighborhood-based reassignment.  Default: 0.5.
    neighborhood_consensus : float, optional
        Minimum fraction of neighbors that must agree on a cell type before
        the reassignment is accepted.  If ``None``, uses
        ``Defaults.NEIGHBORHOOD_CONSENSUS`` (0.7).
    inplace : bool
        Modify adata in place.

    Returns
    -------
    AnnData or None
        Modified copy of ``adata`` when ``inplace=False`` (default).
        ``None`` when ``inplace=True`` — the original object is modified
        in place and nothing is returned.

    Examples
    --------
    >>> adata = refine_with_neighborhood(adata, confidence_threshold=0.5,
    ...                                  neighborhood_consensus=0.7)
    >>> print(adata.obs["cell_type_refined"].value_counts())
    """
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE
    if confidence_key is None:
        confidence_key = ColumnNames.CONFIDENCE
    if neighborhood_consensus is None:
        neighborhood_consensus = Defaults.NEIGHBORHOOD_CONSENSUS

    if not inplace:
        adata = adata.copy()

    # Get current predictions and confidences
    predictions = np.array(adata.obs[cell_type_key].values, dtype=object)

    if confidence_key in adata.obs.columns:
        confidences = adata.obs[confidence_key].values.copy()
    else:
        logger.warning(f"{confidence_key} not found, skipping refinement")
        # Honour the inplace contract: return None when inplace=True, the
        # (possibly copied) adata when inplace=False.
        return None if inplace else adata

    # Get coordinates
    if coord_key not in adata.obsm:
        logger.warning(f"{coord_key} not found, skipping refinement")
        return None if inplace else adata

    # Use core_utils function - it takes adata and column name
    use_rep = coord_key if coord_key in adata.obsm else "X_pca"

    refined_preds, refined_conf = compute_neighborhood_consensus(
        adata, cell_type_col=cell_type_key, n_neighbors=n_neighbors, use_rep=use_rep
    )

    # Apply confidence threshold - only refine low-confidence cells
    low_conf_mask = confidences < confidence_threshold
    final_preds = predictions.copy()
    final_conf = confidences.copy()

    # For low-confidence cells, accept the neighborhood label only when
    # the neighbor agreement (refined_conf) meets neighborhood_consensus.
    strong_agreement = refined_conf >= neighborhood_consensus
    apply_mask = low_conf_mask & strong_agreement
    final_preds[apply_mask] = refined_preds[apply_mask]
    final_conf[apply_mask] = refined_conf[apply_mask]

    # Store results
    adata.obs[f"{cell_type_key}_refined"] = final_preds
    adata.obs[f"{confidence_key}_refined"] = final_conf

    # Track changes
    n_changed = (predictions != final_preds).sum()
    logger.info(f"Neighborhood refinement changed {n_changed} cells")

    if inplace:
        return None
    return adata


def create_marker_dict_with_validation(
    biomarker_df: pd.DataFrame,
    adata: sc.AnnData,
    palette: dict[str, str] | None = None,
    min_markers: int = 1,
) -> tuple[dict[str, list[str]], list[str], list[tuple[str, set]], dict[str, list[str]]]:
    """
    Create marker dictionary with validation of available genes.

    Positive markers (values > 0) are collected into ``marker_dict``.
    Negative markers (values < 0) — genes that should be *down-regulated* for
    a given cell type — are collected into ``negative_marker_dict``.  Both
    dicts contain only genes that are actually present in ``adata.var_names``.
    ``negative_marker_dict`` can be passed directly to
    :class:`~celltype.annotators.ScTypeAnnotator` as ``negative_markers`` so
    that down-regulated genes subtract from that cell type's score.

    Parameters
    ----------
    biomarker_df : DataFrame
        Matrix of biomarkers (genes × cell types).  Positive values indicate
        up-regulated markers; negative values indicate down-regulated markers.
    adata : AnnData
        Annotated data object to check gene availability.
    palette : dict, optional
        Color palette for cell types.
    min_markers : int
        Minimum *positive* markers required per cell type to be included in
        ``marker_dict``.  No minimum is applied to negative markers.

    Returns
    -------
    marker_dict : dict
        Cell type → positive marker genes (only genes present in adata).
    complete_cell_types : list
        Cell types with all positive markers present in adata.
    missing_markers : list
        List of (cell_type, missing_genes) tuples for positive markers.
    negative_marker_dict : dict
        Cell type → negative marker genes (only genes present in adata).
        Only cell types that have at least one negative marker in the panel
        are included.  Pass this to ``ScTypeAnnotator(negative_markers=...)``
        or to ``run_refinement_pipeline(sctype_negative_markers=...)``.

    Examples
    --------
    >>> marker_dict, complete, missing, neg_dict = create_marker_dict_with_validation(
    ...     biomarker_df, adata
    ... )
    >>> print(f"{len(complete)} cell types with complete markers")
    >>> # Pass negative markers into the scType scorer:
    >>> from celltype import ScTypeAnnotator
    >>> annotator = ScTypeAnnotator(negative_markers=neg_dict)
    """
    if palette is None:
        palette = CELL_TYPE_PALETTE

    marker_dict = {}
    negative_marker_dict = {}
    missing_markers = []
    complete_cell_types = []

    # Get gene symbol column if available
    gene_symbols = adata.var.get(ColumnNames.GENE_SYMBOL, None)

    for cell_type in biomarker_df.columns:
        # ── Positive markers (up-regulated, value > 0) ──────────────────────
        pos_markers = biomarker_df[biomarker_df[cell_type] > 0].index.tolist()
        found, missing = find_markers_in_data(pos_markers, adata.var_names, gene_symbols)

        if missing:
            missing_markers.append((cell_type, set(missing)))
            logger.debug(f"{cell_type}: {len(missing)} missing positive markers")
        else:
            complete_cell_types.append(cell_type)

        if len(found) >= min_markers:
            marker_dict[cell_type] = found

        # ── Negative markers (down-regulated, value < 0) ────────────────────
        neg_markers = biomarker_df[biomarker_df[cell_type] < 0].index.tolist()
        if neg_markers:
            neg_found, neg_missing = find_markers_in_data(
                neg_markers, adata.var_names, gene_symbols
            )
            if neg_missing:
                logger.debug(
                    f"{cell_type}: {len(neg_missing)} negative marker(s) not in panel — "
                    f"{neg_missing}"
                )
            if neg_found:
                negative_marker_dict[cell_type] = neg_found

    n_neg_types = len(negative_marker_dict)
    logger.info(f"{len(complete_cell_types)} cell types with complete marker sets")
    logger.info(f"{len(missing_markers)} cell types with missing markers")
    if n_neg_types:
        logger.info(
            f"{n_neg_types} cell type(s) have negative markers in the panel: "
            + ", ".join(f"{ct}: {len(m)}" for ct, m in negative_marker_dict.items())
        )
    else:
        logger.info("No negative markers found in biomarker matrix (all values >= 0)")

    return marker_dict, complete_cell_types, missing_markers, negative_marker_dict
