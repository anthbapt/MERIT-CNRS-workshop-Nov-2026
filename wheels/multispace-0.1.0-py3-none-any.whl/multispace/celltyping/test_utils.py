"""
Testing Utilities for Cell Type Annotation
==========================================

This module provides utilities for testing the cell typing workflow:
- Synthetic data generation with known ground truth
- Test fixtures and helpers
- Validation utilities

The synthetic data generator creates realistic single-cell expression data
with known cell type labels, allowing validation of annotation accuracy.

"""

from __future__ import annotations

import logging

import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc

from .constants import (
    DEFAULT_MARKERS,
    ColumnNames,
)

logger = logging.getLogger(__name__)


# =============================================================================
# SYNTHETIC DATA GENERATION
# =============================================================================


def generate_synthetic_adata(
    n_cells: int = 1000,
    n_genes: int = 500,
    cell_types: list[str] | None = None,
    cell_type_fractions: dict[str, float] | None = None,
    marker_dict: dict[str, list[str]] | None = None,
    marker_fold_change: float = 8.0,
    noise_level: float = 0.5,
    dropout_rate: float = 0.3,
    random_seed: int = 42,
    add_umap: bool = True,
    add_pca: bool = True,
) -> tuple[ad.AnnData, np.ndarray]:
    """
    Generate synthetic single-cell expression data with known cell types.

    Creates realistic expression data where marker genes are upregulated
    in their corresponding cell types, allowing validation of annotation
    methods.

    Parameters
    ----------
    n_cells : int
        Number of cells to generate. Default: 1000
    n_genes : int
        Total number of genes. Default: 500
    cell_types : List[str], optional
        List of cell types to include. Default: common immune/stromal types.
    cell_type_fractions : Dict[str, float], optional
        Fraction of cells for each type. Default: equal fractions.
    marker_dict : Dict[str, List[str]], optional
        Marker genes for each cell type. Default: uses DEFAULT_MARKERS.
    marker_fold_change : float
        Fold change for marker genes in their cell type. Default: 3.0
    noise_level : float
        Standard deviation of expression noise. Default: 0.5
    dropout_rate : float
        Fraction of zero values (dropout). Default: 0.3
    random_seed : int
        Random seed for reproducibility. Default: 42
    add_umap : bool
        Compute and add UMAP coordinates. Default: True
    add_pca : bool
        Compute and add PCA. Default: True

    Returns
    -------
    Tuple[AnnData, np.ndarray]
        (adata, true_labels) where true_labels contains the ground truth
        cell type for each cell.

    Examples
    --------
    >>> adata, true_labels = generate_synthetic_adata(n_cells=1000)
    >>> print(f"Generated {adata.n_obs} cells with {adata.n_vars} genes")
    >>> print(f"Cell types: {np.unique(true_labels)}")

    >>> # Custom cell types
    >>> adata, labels = generate_synthetic_adata(
    ...     cell_types=["T_cell", "B_cell", "Macrophage"],
    ...     cell_type_fractions={"T_cell": 0.5, "B_cell": 0.3, "Macrophage": 0.2}
    ... )
    """
    np.random.seed(random_seed)

    # Default cell types
    if cell_types is None:
        cell_types = [
            "T_cell",
            "B_cell",
            "Macrophage",
            "Fibroblast",
            "Endothelial",
            "NK_cell",
        ]

    # Default marker dictionary
    if marker_dict is None:
        marker_dict = {
            "T_cell": ["CD3D", "CD3E", "CD2", "CD4", "CD8A"],
            "B_cell": ["CD19", "CD79A", "MS4A1", "CD27"],
            "Macrophage": ["CD14", "CD68", "CD163", "CSF1R"],
            "Fibroblast": ["COL1A1", "COL1A2", "FAP", "PDGFRA"],
            "Endothelial": ["PECAM1", "VWF", "CDH5", "ERG"],
            "NK_cell": ["NCAM1", "NKG7", "GNLY", "KLRD1"],
            "Monocyte": ["CD14", "FCGR3A", "S100A8", "S100A9"],
            "Dendritic_cell": ["CD1C", "CLEC9A", "FCER1A"],
            "Mast_cell": ["KIT", "TPSAB1", "CPA3"],
            "malignant cell": ["EPCAM", "KRT8", "KRT18", "KRT19"],
        }

    # Filter marker_dict to only include requested cell types
    marker_dict = {ct: markers for ct, markers in marker_dict.items() if ct in cell_types}

    # Default equal fractions
    if cell_type_fractions is None:
        cell_type_fractions = {ct: 1.0 / len(cell_types) for ct in cell_types}

    # Normalize fractions
    total = sum(cell_type_fractions.values())
    cell_type_fractions = {ct: f / total for ct, f in cell_type_fractions.items()}

    # Generate cell type assignments
    true_labels = []
    for ct, frac in cell_type_fractions.items():
        n_ct = int(n_cells * frac)
        true_labels.extend([ct] * n_ct)

    # Adjust for rounding
    while len(true_labels) < n_cells:
        true_labels.append(cell_types[0])
    true_labels = np.array(true_labels[:n_cells])

    # Shuffle
    shuffle_idx = np.random.permutation(n_cells)
    true_labels = true_labels[shuffle_idx]

    # Collect all marker genes
    all_markers = set()
    for markers in marker_dict.values():
        all_markers.update(markers)
    all_markers = sorted(all_markers)

    # Generate gene names
    n_markers = len(all_markers)
    n_other = n_genes - n_markers

    if n_other < 0:
        logger.warning(f"n_genes ({n_genes}) < n_markers ({n_markers}), using only markers")
        n_other = 0
        n_genes = n_markers

    other_genes = [f"Gene_{i}" for i in range(n_other)]
    gene_names = all_markers + other_genes

    # Generate base expression matrix
    # Log-normal distribution for realistic expression
    base_expr = np.random.lognormal(mean=1.0, sigma=1.0, size=(n_cells, n_genes))

    # Add cell type-specific marker expression
    marker_to_idx = {m: i for i, m in enumerate(gene_names)}

    for ct in cell_types:
        ct_mask = true_labels == ct
        ct_markers = marker_dict.get(ct, [])

        for marker in ct_markers:
            if marker in marker_to_idx:
                idx = marker_to_idx[marker]
                # Upregulate marker in this cell type
                base_expr[ct_mask, idx] *= marker_fold_change
                # Add some noise
                base_expr[ct_mask, idx] += np.random.normal(0, noise_level, ct_mask.sum())

    # Add general noise
    base_expr += np.random.normal(0, noise_level, base_expr.shape)
    base_expr = np.maximum(base_expr, 0)  # No negative expression

    # Apply dropout
    dropout_mask = np.random.random(base_expr.shape) < dropout_rate
    base_expr[dropout_mask] = 0

    # Create AnnData
    adata = ad.AnnData(
        X=base_expr.astype(np.float32),
        obs=pd.DataFrame(index=[f"Cell_{i}" for i in range(n_cells)]),
        var=pd.DataFrame(index=gene_names),
    )

    # Add gene symbol column
    adata.var[ColumnNames.GENE_SYMBOL] = gene_names

    # Store true labels (but not in obs to simulate real scenario)
    adata.uns["true_labels"] = true_labels
    adata.uns["marker_dict"] = marker_dict
    adata.uns["cell_types"] = cell_types

    # Normalize
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)

    # Add PCA (only if we have enough cells/genes)
    if add_pca:
        n_pcs = min(50, n_cells - 1, n_genes - 1)
        if n_pcs >= 1:
            sc.pp.pca(adata, n_comps=n_pcs)

    # Add UMAP (only if we have enough cells and PCA was computed)
    if add_umap and add_pca and n_cells > 2 and "X_pca" in adata.obsm:
        sc.pp.neighbors(adata, n_neighbors=min(15, n_cells - 1))
        sc.tl.umap(adata)

    logger.info(
        f"Generated synthetic data: {n_cells} cells, {n_genes} genes, "
        f"{len(cell_types)} cell types"
    )

    return adata, true_labels


def generate_marker_dict_subset(
    cell_types: list[str], markers_per_type: int = 4, include_shared: bool = True
) -> dict[str, list[str]]:
    """
    Generate a marker dictionary for specified cell types.

    Parameters
    ----------
    cell_types : List[str]
        Cell types to include.
    markers_per_type : int
        Number of markers per cell type.
    include_shared : bool
        Include some shared markers between related types.

    Returns
    -------
    Dict[str, List[str]]
        Marker dictionary.
    """
    marker_dict = {}

    for ct in cell_types:
        if ct in DEFAULT_MARKERS:
            markers = DEFAULT_MARKERS[ct][:markers_per_type]
        else:
            # Generate placeholder markers
            markers = [f"{ct}_marker_{i}" for i in range(markers_per_type)]

        marker_dict[ct] = markers

    return marker_dict


# =============================================================================
# TEST FIXTURES
# =============================================================================


def create_test_adata_simple(n_cells: int = 100, n_genes: int = 50) -> ad.AnnData:
    """
    Create a simple test AnnData without cell type structure.

    Useful for testing basic functionality.
    """
    np.random.seed(42)

    X = np.random.lognormal(0, 1, (n_cells, n_genes))

    adata = ad.AnnData(
        X=X.astype(np.float32),
        obs=pd.DataFrame(index=[f"Cell_{i}" for i in range(n_cells)]),
        var=pd.DataFrame(index=[f"Gene_{i}" for i in range(n_genes)]),
    )

    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)

    return adata


def create_test_score_matrix(
    n_cells: int = 100, n_types: int = 5, dominant_type: bool = True
) -> tuple[np.ndarray, np.ndarray]:
    """
    Create a test score matrix for confidence calculation testing.

    Parameters
    ----------
    n_cells : int
        Number of cells.
    n_types : int
        Number of cell types.
    dominant_type : bool
        If True, each cell has one dominant type (high confidence).
        If False, scores are more uniform (low confidence).

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        (score_matrix, expected_predictions)
    """
    np.random.seed(42)

    if dominant_type:
        # Each cell has one dominant type
        scores = np.random.uniform(0.1, 0.3, (n_cells, n_types))
        predictions = np.random.randint(0, n_types, n_cells)
        for i, pred in enumerate(predictions):
            scores[i, pred] = np.random.uniform(0.7, 1.0)
    else:
        # More uniform scores
        scores = np.random.uniform(0.3, 0.6, (n_cells, n_types))
        predictions = np.argmax(scores, axis=1)

    return scores, predictions


# =============================================================================
# VALIDATION UTILITIES
# =============================================================================


def compute_annotation_accuracy(
    predictions: np.ndarray, true_labels: np.ndarray, normalize: bool = True
) -> float:
    """
    Compute annotation accuracy.

    Parameters
    ----------
    predictions : np.ndarray
        Predicted cell types.
    true_labels : np.ndarray
        Ground truth cell types.
    normalize : bool
        Return fraction (True) or count (False).

    Returns
    -------
    float
        Accuracy score.
    """
    correct = (predictions == true_labels).sum()
    if normalize:
        return correct / len(true_labels)
    return correct


def compute_per_type_accuracy(predictions: np.ndarray, true_labels: np.ndarray) -> dict[str, float]:
    """
    Compute accuracy for each cell type.

    Parameters
    ----------
    predictions : np.ndarray
        Predicted cell types.
    true_labels : np.ndarray
        Ground truth cell types.

    Returns
    -------
    Dict[str, float]
        Accuracy per cell type.
    """
    accuracies = {}

    for ct in np.unique(true_labels):
        mask = true_labels == ct
        if mask.sum() > 0:
            accuracies[ct] = (predictions[mask] == ct).mean()

    return accuracies


def compute_confusion_matrix(
    predictions: np.ndarray, true_labels: np.ndarray, labels: list[str] | None = None
) -> pd.DataFrame:
    """
    Compute confusion matrix.

    Parameters
    ----------
    predictions : np.ndarray
        Predicted cell types.
    true_labels : np.ndarray
        Ground truth cell types.
    labels : List[str], optional
        Order of labels.

    Returns
    -------
    pd.DataFrame
        Confusion matrix.
    """
    if labels is None:
        labels = sorted(set(true_labels) | set(predictions))

    n_labels = len(labels)
    label_to_idx = {label: i for i, label in enumerate(labels)}

    matrix = np.zeros((n_labels, n_labels), dtype=int)

    for pred, true in zip(predictions, true_labels):
        if pred in label_to_idx and true in label_to_idx:
            matrix[label_to_idx[true], label_to_idx[pred]] += 1

    return pd.DataFrame(matrix, index=labels, columns=labels)


def validate_annotation_result(
    result, expected_n_cells: int, expected_types: list[str] | None = None
) -> list[str]:
    """
    Validate an AnnotationResult object.

    Parameters
    ----------
    result : AnnotationResult
        Result to validate.
    expected_n_cells : int
        Expected number of cells.
    expected_types : List[str], optional
        Expected cell types.

    Returns
    -------
    List[str]
        List of validation issues (empty if valid).
    """
    issues = []

    # Check predictions
    if len(result.predictions) != expected_n_cells:
        issues.append(
            f"Predictions length mismatch: {len(result.predictions)} != {expected_n_cells}"
        )

    # Check confidences
    if len(result.confidences) != expected_n_cells:
        issues.append(
            f"Confidences length mismatch: {len(result.confidences)} != {expected_n_cells}"
        )

    # Check confidence range
    if result.confidences.min() < 0 or result.confidences.max() > 1:
        issues.append(
            f"Confidences out of range: [{result.confidences.min():.3f}, {result.confidences.max():.3f}]"
        )

    # Check scores
    if len(result.scores) != expected_n_cells:
        issues.append(f"Scores length mismatch: {len(result.scores)} != {expected_n_cells}")

    # Check expected types
    if expected_types is not None:
        missing = set(expected_types) - set(result.predictions)
        if missing:
            issues.append(f"Missing expected types: {missing}")

    return issues


# =============================================================================
# BENCHMARK UTILITIES
# =============================================================================


def benchmark_annotator(
    annotator,
    adata: ad.AnnData,
    marker_dict: dict[str, list[str]],
    true_labels: np.ndarray,
    n_runs: int = 3,
) -> dict[str, float]:
    """
    Benchmark an annotator's performance.

    Parameters
    ----------
    annotator : CellTypeAnnotator
        Annotator to benchmark.
    adata : AnnData
        Test data.
    marker_dict : Dict[str, List[str]]
        Marker dictionary.
    true_labels : np.ndarray
        Ground truth labels.
    n_runs : int
        Number of runs for timing.

    Returns
    -------
    Dict[str, float]
        Benchmark results including accuracy and timing.
    """
    import time

    # Accuracy
    result = annotator.annotate(adata.copy(), marker_dict, store_in_adata=False)
    accuracy = compute_annotation_accuracy(result.predictions, true_labels)
    per_type_acc = compute_per_type_accuracy(result.predictions, true_labels)

    # Timing
    times = []
    for _ in range(n_runs):
        start = time.time()
        annotator.annotate(adata.copy(), marker_dict, store_in_adata=False)
        times.append(time.time() - start)

    return {
        "accuracy": accuracy,
        "per_type_accuracy": per_type_acc,
        "mean_confidence": result.confidences.mean(),
        "median_confidence": np.median(result.confidences),
        "mean_time": np.mean(times),
        "std_time": np.std(times),
        "n_cells": len(true_labels),
        "n_types": len(np.unique(true_labels)),
    }


# =============================================================================
# ASSERTION HELPERS
# =============================================================================


def assert_valid_adata(adata: ad.AnnData) -> None:
    """Assert that AnnData is valid for annotation."""
    assert adata.n_obs > 0, "AnnData has no cells"
    assert adata.n_vars > 0, "AnnData has no genes"
    assert not np.isnan(adata.X).any(), "AnnData contains NaN values"
    assert not np.isinf(adata.X).any(), "AnnData contains Inf values"


def assert_valid_result(result, n_cells: int) -> None:
    """Assert that AnnotationResult is valid."""
    assert len(result.predictions) == n_cells, "Predictions length mismatch"
    assert len(result.confidences) == n_cells, "Confidences length mismatch"
    assert result.confidences.min() >= 0, "Negative confidence"
    assert result.confidences.max() <= 1, "Confidence > 1"
    assert len(result.scores) == n_cells, "Scores length mismatch"


def assert_reasonable_accuracy(
    predictions: np.ndarray, true_labels: np.ndarray, min_accuracy: float = 0.5
) -> None:
    """Assert that accuracy is above a minimum threshold."""
    accuracy = compute_annotation_accuracy(predictions, true_labels)
    assert accuracy >= min_accuracy, f"Accuracy {accuracy:.2%} < {min_accuracy:.2%}"
