"""Module 4 — cell typing, wired into the SpatialData contract.

Runs the marker-based multi-method workflow of this package
(:func:`multispace.celltyping.workflow.run_annotation_workflow`) on the active
table and writes the result back as contract columns:

=====================  ==========================================
``cell_type``          consensus label
``cell_type_confidence`` consensus confidence (0–1)
``cell_type_coarse``   hierarchical coarse label (when available)
``cell_type_fine``     hierarchical fine label (when available)
=====================  ==========================================

The table's ``X`` is left untouched (raw counts); normalisation happens on a
copy. Run it on a protein table with ``table=...`` and ``key_added=...`` to
keep RNA and protein calls side by side (multimodal fusion: see README ToDo).
"""
from __future__ import annotations

import logging
from pathlib import Path

from .._sdata import get_table, record_step
from ..constants import Keys, Obs

logger = logging.getLogger(__name__)

__all__ = ["annotate_cell_types"]


def annotate_cell_types(
    sdata,
    *,
    markers: dict[str, list[str]] | str | Path | None = None,
    methods: list[str] | None = None,
    table: str = Keys.TABLE,
    normalization: str = "library_size",
    add_hierarchy: bool = True,
    key_added: str = Obs.CELL_TYPE,
    output_dir: str | Path | None = None,
    verbose: bool = False,
):
    """Annotate cells of ``sdata.tables[table]`` and store contract columns.

    Parameters
    ----------
    markers
        ``{cell_type: [marker genes]}``, or a marker file readable by
        :func:`multispace.celltyping.io.load_marker_file` (CSV / JSON / YAML).
        ``None`` uses the package's default (breast-cancer, METABRIC) markers.
    methods
        Subset of ``["biomarker", "sctype", "hierarchy", ...]``; default from
        the workflow.
    key_added
        Base name of the output columns (``cell_type`` → ``cell_type``,
        ``cell_type_confidence``, ...).
    """
    from .io import load_marker_file
    from .workflow import run_annotation_workflow

    adata = get_table(sdata, table)
    if isinstance(markers, (str, Path)):
        markers = load_marker_file(markers)
    if markers is None:
        logger.warning("No markers given: using the default METABRIC breast-cancer marker set.")
    if Obs.COUNTS_LAYER not in adata.layers:
        adata.layers[Obs.COUNTS_LAYER] = adata.X.copy()

    annotated, results = run_annotation_workflow(
        adata, marker_dict=markers, methods=methods, normalize_data=normalization not in (None, "none"),
        normalization_method=normalization or "library_size", compute_qc=True,
        add_hierarchy=add_hierarchy, output_dir=output_dir, verbose=verbose,
    )
    mapping = {
        "cell_type": key_added,
        "confidence": f"{key_added}_confidence",
        "cell_type_coarse": f"{key_added}_coarse",
        "cell_type_fine": f"{key_added}_fine",
    }
    written = []
    for src, dst in mapping.items():
        if src in annotated.obs:
            adata.obs[dst] = annotated.obs[src].reindex(adata.obs_names).to_numpy()
            written.append(dst)
    if key_added in adata.obs:
        adata.obs[key_added] = adata.obs[key_added].astype("category")
    counts = adata.obs[key_added].value_counts().to_dict() if key_added in adata.obs else {}
    record_step(sdata, "cell_typing", {"table": table, "methods": methods, "normalization": normalization,
                                       "n_marker_types": len(markers) if markers else "default"},
                columns=written, counts=counts)
    return sdata
