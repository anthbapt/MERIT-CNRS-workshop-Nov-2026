"""
CellTypist Integration
======================

This module provides integration with CellTypist for cell type annotation,
including model loading, prediction extraction, and combining with other methods.

Functions
---------
- load_celltypist_model         : Load a CellTypist model
- run_celltypist                : Run CellTypist annotation (core annotator)
- get_celltypist_predictions    : Extract predictions from annotated data
- combine_celltypist_with_consensus : Combine CellTypist with consensus refinement
- list_celltypist_models        : List available pre-built models
- diagnose_celltypist_model     : Inspect model/panel feature overlap before running
- compute_voting_clusters       : Compute high-res Leiden partition for majority voting
- cell_typing_celltypist        : Full pipeline step (orchestrates the functions above)

Design hierarchy
----------------
cell_typing_celltypist()          ← pipeline orchestrator
    ├── compute_voting_clusters() ← prep: dedicated Leiden partition
    ├── run_celltypist()          ← core: single place celltypist.annotate() is called
    └── plots + cleanup           ← post: diagnostics, state restoration
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import scanpy as sc

# ---------------------------------------------------------------------------
# Optional dependency
# ---------------------------------------------------------------------------
try:
    import celltypist

    HAS_CELLTYPIST = True
except ImportError:
    HAS_CELLTYPIST = False

# ---------------------------------------------------------------------------
# FIX 21: Relative imports moved to module level with a graceful fallback.
# Previously `from .io import ...` appeared inside function bodies, which
# (a) re-executes the import on every call, (b) raises a confusing
# ImportError deep inside a function rather than at module load time, and
# (c) breaks when the module is imported outside the package context
# (e.g. in tests or notebooks).  We guard with try/except so the module
# still loads in standalone contexts; functions that need these helpers
# will raise a clear RuntimeError if the package context is missing.
# ---------------------------------------------------------------------------
try:
    from .io import (
        load_gene_mapping,
        rename_var_to_ensembl,
        rename_var_to_gene_name,
    )

    _HAS_IO = True
except ImportError:
    _HAS_IO = False
    load_gene_mapping = rename_var_to_ensembl = rename_var_to_gene_name = None  # type: ignore[assignment]

from .constants import ColumnNames
from .core_utils import combine_primary_with_consensus, compute_feature_overlap

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Layer key constant — single definition used throughout this module.
# Change here if the layer name changes elsewhere in the pipeline.
# ---------------------------------------------------------------------------
LOGNORM_LAYER: str = "lognorm"

__all__ = [
    "HAS_CELLTYPIST",
    "LOGNORM_LAYER",
    "load_celltypist_model",
    "run_celltypist",
    "get_celltypist_predictions",
    "combine_celltypist_with_consensus",
    "list_celltypist_models",
    "diagnose_celltypist_model",
    "compute_voting_clusters",
    "cell_typing_celltypist",
]


# ---------------------------------------------------------------------------
# 1. load_celltypist_model
# ---------------------------------------------------------------------------


def load_celltypist_model(model_path: str) -> Any:
    """
    Load a CellTypist model from file.

    Parameters
    ----------
    model_path : str
        Path to the CellTypist model file (.pkl).

    Returns
    -------
    celltypist.Model
        Loaded CellTypist model.

    Raises
    ------
    ImportError
        If celltypist is not installed.
    FileNotFoundError
        If model file doesn't exist.

    Examples
    --------
    >>> model = load_celltypist_model("Immune_All_Low.pkl")
    >>> print(model.cell_types)
    """
    if not HAS_CELLTYPIST:
        raise ImportError(
            "celltypist is required for this function. " "Install with: pip install celltypist"
        )
    logger.info(f"Loading CellTypist model from {model_path}")
    return celltypist.models.Model.load(model_path)


# ---------------------------------------------------------------------------
# 2. run_celltypist  (core annotator — single place celltypist.annotate() lives)
# ---------------------------------------------------------------------------


def run_celltypist(
    adata: sc.AnnData,
    model: Any = None,
    model_path: str = None,
    majority_voting: bool = True,
    mode: str = "best match",
    over_clustering: str | None = None,
    min_prop: float = 0.1,
    inplace: bool = True,
) -> sc.AnnData | None:
    """
    Run CellTypist annotation on data.

    This is the single place in the module where ``celltypist.annotate()``
    is called.  ``cell_typing_celltypist`` delegates to this function rather
    than reimplementing the call.

    Parameters
    ----------
    adata : AnnData
        Data to annotate.  Should contain log-normalised counts in ``.X``.
    model : celltypist.Model, optional
        Pre-loaded CellTypist model.
    model_path : str, optional
        Path to model file (used when *model* is not provided).
    majority_voting : bool
        Whether to use majority voting for over-clustering. Default True.
    mode : str
        Prediction mode: ``"best match"`` or ``"prob match"``.
    over_clustering : str or None
        Key in ``adata.obs`` containing a pre-computed clustering to use for
        majority voting.  When ``None``, CellTypist computes its own internal
        clustering.  Pass ``"leiden_voting"`` when calling from
        ``cell_typing_celltypist`` so the dedicated voting partition is used.
    min_prop : float
        Minimum proportion of cells in a cluster required for a cell type
        label to be assigned during majority voting. Default 0.1.
    inplace : bool
        If ``True`` (default), write predictions directly into *adata* and
        return ``None``.  If ``False``, return an annotated copy.

    Returns
    -------
    AnnData or None
        Annotated AnnData if ``inplace=False``, else ``None``.

    Raises
    ------
    ImportError
        If celltypist is not installed.
    ValueError
        If neither *model* nor *model_path* is provided.

    Examples
    --------
    >>> run_celltypist(adata, model_path="Immune_All_Low.pkl", inplace=True)
    >>> print(adata.obs["predicted_labels"].value_counts())
    """
    if not HAS_CELLTYPIST:
        raise ImportError(
            "celltypist is required for this function. " "Install with: pip install celltypist"
        )

    # FIX 1: Work on a copy only when inplace=False; never rebind the local
    # `adata` variable when inplace=True (the old code did
    # `adata = predictions.to_adata()` which silently discarded the caller's
    # object and made inplace=True a no-op).
    adata_work = adata if inplace else adata.copy()

    if model is None:
        if model_path is None:
            raise ValueError("Either model or model_path must be provided.")
        model = load_celltypist_model(model_path)

    logger.info("Running CellTypist annotation")

    # FIX 2: Forward over_clustering so callers can supply a pre-computed
    # partition (e.g. "leiden_voting" from compute_voting_clusters).
    annotate_kwargs: dict = {
        "model": model,
        "majority_voting": majority_voting,
        "mode": mode,
        "min_prop": min_prop,
    }
    if over_clustering is not None:
        annotate_kwargs["over_clustering"] = over_clustering

    predictions = celltypist.annotate(adata_work, **annotate_kwargs)

    # FIX 3: Transfer results column-by-column into adata_work instead of
    # reassigning the variable.  predictions.to_adata() returns a *new*
    # AnnData; copying its obs columns preserves the original object identity
    # so that inplace=True actually modifies the caller's object.
    # NOTE: assign the Series directly (no .values) so pandas aligns on the
    # shared obs_names index.  Using .values would do positional assignment
    # and silently misalign predictions if CellTypist internally reorders
    # cells before returning pred_adata.
    pred_adata = predictions.to_adata()
    for col in [
        ColumnNames.CELLTYPIST_PREDICTION,
        "over_clustering",
        ColumnNames.CELLTYPIST_MAJORITY,
        ColumnNames.CONF_SCORE,
    ]:
        if col in pred_adata.obs.columns:
            adata_work.obs[col] = pred_adata.obs[col]

    n_types = adata_work.obs[ColumnNames.CELLTYPIST_PREDICTION].nunique()
    logger.info(f"CellTypist identified {n_types} cell types (raw per-cell)")

    return None if inplace else adata_work


# ---------------------------------------------------------------------------
# 3. get_celltypist_predictions
# ---------------------------------------------------------------------------


def get_celltypist_predictions(
    adata: sc.AnnData,
    confidence_threshold: float = 0.9,
    prefer_majority_voting: bool = False,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Extract CellTypist predictions and identify cells needing refinement.

    Parameters
    ----------
    adata : AnnData
        Data with CellTypist predictions in ``.obs``.
    confidence_threshold : float
        Cells whose confidence score is below this value are flagged as
        needing refinement. Default 0.9.
    prefer_majority_voting : bool
        If ``True`` and ``majority_voting`` is present in ``.obs``, return
        the smoothed majority-voting labels instead of the raw
        ``predicted_labels``.  Default ``False`` (return raw labels).

    Returns
    -------
    predictions : np.ndarray
        CellTypist cell type predictions.
    confidences : np.ndarray
        CellTypist confidence scores.
    needs_refinement : np.ndarray
        Boolean mask; ``True`` for cells whose confidence < threshold.

    Raises
    ------
    ValueError
        If no CellTypist prediction column is found in ``adata.obs``.

    Examples
    --------
    >>> preds, confs, needs_refine = get_celltypist_predictions(adata)
    >>> print(f"{needs_refine.sum()} cells need refinement")
    """
    # FIX 4: Honour prefer_majority_voting so callers can explicitly request
    # the smoothed labels when majority voting was used.
    if prefer_majority_voting and ColumnNames.CELLTYPIST_MAJORITY in adata.obs.columns:
        label_key = ColumnNames.CELLTYPIST_MAJORITY
    else:
        # Fall back through CellTypist-specific column names only.
        # "celltypist_cell_type" is kept for backwards compatibility with
        # older pipeline outputs.
        label_key = None
        for key in [ColumnNames.CELLTYPIST_PREDICTION, "celltypist_cell_type"]:
            if key in adata.obs.columns:
                label_key = key
                break

    if label_key is None:
        raise ValueError(
            "No CellTypist predictions found in adata.obs. "
            "Expected one of: 'predicted_labels', 'majority_voting', "
            "'celltypist_cell_type'."
        )

    predictions = adata.obs[label_key].values

    # FIX 5: Search only CellTypist-specific confidence columns to avoid
    # accidentally picking up a generic 'confidence' column written by
    # another annotation method (e.g. ColumnNames.CONFIDENCE in constants.py).
    conf_key = None
    for key in [ColumnNames.CONF_SCORE, "celltypist_confidence"]:
        if key in adata.obs.columns:
            conf_key = key
            break

    if conf_key is None:
        # FIX 6: Default to 0.0 (conservative — treat as low confidence)
        # rather than 0.5, which sits exactly on the boundary of most
        # thresholds and causes non-deterministic behaviour.
        logger.warning(
            "No CellTypist confidence column found ('conf_score', "
            "'celltypist_confidence'). Defaulting all confidences to 0.0 "
            "(all cells will be flagged as needing refinement)."
        )
        confidences = np.zeros(len(predictions))
    else:
        confidences = adata.obs[conf_key].values.astype(float)

    needs_refinement = confidences < confidence_threshold

    logger.info(
        f"CellTypist [{label_key}]: {(~needs_refinement).sum()} high-confidence, "
        f"{needs_refinement.sum()} need refinement "
        f"(threshold={confidence_threshold})"
    )

    return predictions, confidences, needs_refinement


# ---------------------------------------------------------------------------
# 4. combine_celltypist_with_consensus
# ---------------------------------------------------------------------------


def combine_celltypist_with_consensus(
    celltypist_predictions: np.ndarray,
    celltypist_confidences: np.ndarray,
    celltypist_threshold: float,
    consensus_predictions: np.ndarray,
    consensus_confidences: np.ndarray,
    consensus_threshold: float = 0.5,
    unknown_label: str = "Unknown",
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Combine CellTypist predictions with consensus refinement.

    Decision logic (applied per cell):

    1. CellTypist confidence >= ``celltypist_threshold``
       → keep CellTypist prediction
    2. CellTypist confidence < threshold AND
       consensus confidence >= ``consensus_threshold``
       → use consensus prediction
    3. Both below their respective thresholds
       → mark as ``unknown_label``

    Parameters
    ----------
    celltypist_predictions : np.ndarray
        Raw CellTypist cell type predictions.
    celltypist_confidences : np.ndarray
        CellTypist confidence scores in [0, 1].
    celltypist_threshold : float
        Minimum CellTypist confidence to accept a prediction directly.
        (Previously this was derived externally as ``needs_refinement`` and
        passed in as a boolean array — now computed internally for
        consistency.)
    consensus_predictions : np.ndarray
        Consensus cell type predictions.
    consensus_confidences : np.ndarray
        Consensus confidence scores in [0, 1].
    consensus_threshold : float
        Minimum consensus confidence to use a consensus prediction.
        Default 0.5.
    unknown_label : str
        Label assigned when both methods are below their thresholds.
        Default ``"Unknown"``.

    Returns
    -------
    refined_predictions : np.ndarray
        Final cell type predictions.
    refined_confidences : np.ndarray
        Final confidence scores.
    source : np.ndarray
        Per-cell source label: ``"celltypist"``, ``"consensus"``, or
        ``"unknown"``.

    Examples
    --------
    >>> refined, conf, source = combine_celltypist_with_consensus(
    ...     ct_preds, ct_conf, celltypist_threshold=0.9,
    ...     consensus_preds, consensus_conf,
    ... )
    >>> print(pd.Series(source).value_counts().to_dict())
    """
    # Delegate to the shared vectorised helper in core_utils.
    # The three-branch logic (primary → consensus → unknown) is identical
    # across CellTypist, scArches, and SCimilarity; keeping it in one place
    # ensures any future changes propagate everywhere automatically.
    return combine_primary_with_consensus(
        primary_predictions=celltypist_predictions,
        primary_confidences=celltypist_confidences,
        primary_threshold=celltypist_threshold,
        consensus_predictions=consensus_predictions,
        consensus_confidences=consensus_confidences,
        consensus_threshold=consensus_threshold,
        unknown_label=unknown_label,
        source_label="celltypist",
    )


# ---------------------------------------------------------------------------
# 5. list_celltypist_models
# ---------------------------------------------------------------------------


def list_celltypist_models(print_output: bool = True) -> str:
    """
    Return (and optionally print) all available pre-built CellTypist models.

    Recommended breast TME options:
      - Immune_All_High.pkl      : 32 immune subtypes, pan-tissue
      - Immune_All_Low.pkl       : 20 broad immune types
      - Human_Breast_Cancer.pkl  : breast-specific TME labels (if available)

    Download with::

        celltypist.models.download_models(model='Immune_All_High.pkl')

    Parameters
    ----------
    print_output : bool
        If ``True`` (default), also print the description to stdout.

    Returns
    -------
    str
        Model description string (can be used programmatically or in tests).

    Raises
    ------
    ImportError
        If celltypist is not installed.
    """
    if not HAS_CELLTYPIST:
        raise ImportError(
            "celltypist is required for this function. " "Install with: pip install celltypist"
        )

    # FIX 9: Return the description string so the function is usable
    # programmatically (e.g. in tests or notebooks that capture output).
    # FIX 10: Wrap in try/except — models_description() is an internal API
    # that has changed across CellTypist versions.
    try:
        description = str(celltypist.models.models_description())
    except AttributeError:
        try:
            # Fallback for older / newer CellTypist versions
            all_models = celltypist.models.get_all_models()
            description = "\n".join(all_models) if all_models else "No models found."
        except Exception as exc:
            description = (
                f"Could not retrieve model list ({exc}). "
                "Visit https://www.celltypist.org/models for the full list."
            )

    if print_output:
        print("Available CellTypist models:")
        print(description)

    return description


# ---------------------------------------------------------------------------
# 6. diagnose_celltypist_model
# ---------------------------------------------------------------------------


def diagnose_celltypist_model(
    model_path: str,
    merged_adata: sc.AnnData,
    output_folder: str | None = None,
    gene_list_path: str | None = None,
) -> Any:
    """
    Inspect a CellTypist model BEFORE running annotation.

    Checks overlap between the model's feature set and the panel genes in two
    ways: first using ``var_names`` as-is, then (if *gene_list_path* is
    provided) using Ensembl-remapped ``var_names``.  Auto-detects the model's
    ID format (Ensembl IDs vs gene symbols) and gives an explicit
    recommendation for how to call ``cell_typing_celltypist()``.

    Two overlap metrics
    -------------------
    **panel_coverage** = overlap / panel_features  ← KEY metric
        Proportion of YOUR panel genes that the model knows about.
        High (>90 %) means CellTypist sees essentially all your data.
        Low (<50 %) means a gene ID mismatch or wrong organism.

    **model_coverage** = overlap / model_features  ← expected low
        How much of the model's whole-transcriptome feature space your panel
        covers.  Always low (~15 %) for targeted panels — CellTypist
        zero-imputes the missing features (documented behaviour).

    Parameters
    ----------
    model_path : str
        Path to trained CellTypist ``.pkl`` model.
    merged_adata : AnnData
        AnnData whose ``var_names`` are checked against the model.
    output_folder : str or None
        Directory to save the diagnostic text report.  When ``None``
        (default) no file is written — useful for quick interactive checks.
    gene_list_path : str or None
        Path to the 10X Xenium gene list CSV (``gene_name``, ``gene_id``
        columns).  When provided, the diagnostic additionally checks overlap
        after remapping ``var_names`` to Ensembl IDs.  Pass ``None``
        (default) to skip this check.

    Returns
    -------
    celltypist.Model
        The loaded model (so the caller can reuse it without loading twice).
    """
    if not HAS_CELLTYPIST:
        raise ImportError(
            "celltypist is required for this function. " "Install with: pip install celltypist"
        )

    # FIX 11: output_folder is now optional — no directory is created or
    # written unless the caller explicitly provides a path.
    if output_folder is not None:
        os.makedirs(output_folder, exist_ok=True)

    model = load_celltypist_model(model_path)
    cell_types = sorted(model.cell_types)
    model_features = set(model.features)

    # Auto-detect model feature format (Ensembl IDs vs gene symbols)
    sample_features = list(model.features)[:20]
    n_ensembl_like = sum(1 for f in sample_features if str(f).startswith("ENSG"))
    model_id_format = "Ensembl IDs" if n_ensembl_like > 10 else "gene symbols"

    # FIX 12: Use shared compute_feature_overlap() helper instead of
    # duplicating the overlap arithmetic that also lives in cell_typing_celltypist.
    panel_raw = set(merged_adata.var_names)
    stats_raw = compute_feature_overlap(model_features, panel_raw)

    # Ensembl-remapped overlap (only when gene_list_path is provided)
    stats_ens = None
    cov_ens_panel = None
    if gene_list_path is not None:
        # Uses module-level load_gene_mapping (FIX 21)
        if not _HAS_IO:
            raise RuntimeError(
                "diagnose_celltypist_model: gene_list_path was provided but the "
                "package IO helpers (load_gene_mapping) could not be imported. "
                "Ensure this module is used within the pipeline package context."
            )
        name_to_ensembl, _ = load_gene_mapping(gene_list_path)
        panel_ensembl = {name_to_ensembl.get(g, g) for g in merged_adata.var_names}
        stats_ens = compute_feature_overlap(model_features, panel_ensembl)
        cov_ens_panel = stats_ens["panel_coverage"]

    sep = "=" * 60
    lines = [
        sep,
        f"CellTypist model diagnostic: {Path(model_path).name}",
        sep,
        f"  Number of cell types : {len(cell_types)}",
        "  Cell types           :",
        *[f"    - {ct}" for ct in cell_types],
        f"  Model features       : {stats_raw['n_model']}",
        f"  Model ID format      : {model_id_format}  "
        f"(detected from first {len(sample_features)} features)",
        "",
        "  --- Overlap with raw var_names (as-is) ---",
        f"  Panel features       : {stats_raw['n_panel']}",
        f"  Overlap (genes)      : {stats_raw['n_overlap']}",
        f"  Panel coverage       : {stats_raw['panel_coverage']:.1f}%  [KEY metric]",
        f"  Model coverage       : {stats_raw['model_coverage']:.1f}%  "
        "[expected low for targeted panels]",
    ]

    if stats_ens is not None:
        lines += [
            "",
            "  --- Overlap after Ensembl remapping (gene_list_path provided) ---",
            f"  Overlap (genes)      : {stats_ens['n_overlap']}",
            f"  Panel coverage       : {stats_ens['panel_coverage']:.1f}%  [KEY metric]",
        ]

    # Recommendation
    # FIX 13: When raw and Ensembl coverages are equal (tie), we prefer
    # gene_list_path=None (raw var_names) because it avoids the remapping
    # step and its associated failure modes.  This tie-breaking is explicit.
    best_raw = stats_raw["panel_coverage"]
    best_ens = cov_ens_panel if cov_ens_panel is not None else -1.0

    lines.append("")
    if best_raw >= 50 and best_raw >= best_ens:
        # Tie (best_raw == best_ens) also falls here — prefer no remapping.
        lines += [
            "  RECOMMENDATION: use gene_list_path=None in cell_typing_celltypist()",
            f"    The model ({model_id_format}) matches your var_names as-is "
            f"({best_raw:.1f}% panel coverage).",
        ]
    elif best_ens >= 50 and best_ens > best_raw:
        lines += [
            "  RECOMMENDATION: provide gene_list_path in cell_typing_celltypist()",
            f"    The model ({model_id_format}) matches after Ensembl remapping "
            f"({best_ens:.1f}% panel coverage).",
        ]
    else:
        lines += [
            "  !! ALERT: panel coverage <50% in all configurations.",
            f"    Raw var_names: {best_raw:.1f}%"
            + (f"  |  After Ensembl remap: {best_ens:.1f}%" if cov_ens_panel is not None else ""),
            "    Possible causes:",
            "      - Gene ID mismatch between panel and model",
            "      - Wrong organism (model trained on different species)",
        ]
        if gene_list_path is None:
            lines.append("      - Try providing gene_list_path to also check Ensembl remapping")

    if len(cell_types) <= 3:
        lines.append(
            "  !! ALERT: model has <= 3 cell types — consider a richer "
            "pre-trained model (run list_celltypist_models() for options)"
        )
    lines.append(sep)

    report_text = "\n".join(lines)
    print(report_text)

    # FIX 14: Only write the report file when output_folder is provided.
    if output_folder is not None:
        report_path = Path(output_folder) / "celltypist_model_diagnostic.txt"
        with open(report_path, "w") as f:
            f.write(f"Model: {model_path}\n")
            f.write(f"Model ID format: {model_id_format}\n")
            f.write(f"Cell types ({len(cell_types)}):\n")
            for ct in cell_types:
                f.write(f"  {ct}\n")
            f.write(f"\nModel features        : {stats_raw['n_model']}\n")
            f.write("\n--- Raw var_names ---\n")
            f.write(f"Panel features        : {stats_raw['n_panel']}\n")
            f.write(f"Overlap (genes)       : {stats_raw['n_overlap']}\n")
            f.write(f"Panel coverage        : {stats_raw['panel_coverage']:.1f}%\n")
            f.write(f"Model coverage        : {stats_raw['model_coverage']:.1f}%\n")
            if stats_ens is not None:
                f.write("\n--- After Ensembl remapping ---\n")
                f.write(f"Overlap (genes)       : {stats_ens['n_overlap']}\n")
                f.write(f"Panel coverage        : {stats_ens['panel_coverage']:.1f}%\n")
            rec = "None" if (best_raw >= 50 and best_raw >= best_ens) else repr(gene_list_path)
            f.write(f"\nRecommendation: gene_list_path={rec}\n")
        print(f"  Report saved -> {report_path}")

    return model


# ---------------------------------------------------------------------------
# 7. compute_voting_clusters
# ---------------------------------------------------------------------------


def compute_voting_clusters(
    merged_adata: sc.AnnData,
    resolution: float = 2.5,
    rep_key: str | None = None,
    neighbors_key: str | None = None,
) -> tuple[sc.AnnData, int]:
    """
    Compute a dedicated high-resolution Leiden partition for CellTypist
    majority voting — independent of the ``leiden_corrected`` used for
    batch QC.

    Why a separate partition?
    -------------------------
    ``leiden_corrected`` (resolution ≈ 1) yields ~10–25 coarse clusters.
    Majority voting over these swamps rare populations that are minorities
    within mixed clusters.  A finer partition (resolution 2–4) preserves
    these populations.

    Parameters
    ----------
    merged_adata : AnnData
        Output of ``batch_correction()``.
    resolution : float
        Leiden resolution.  Default ``2.5`` (matches
        ``Defaults.OVERCLUSTER_RESOLUTION`` in ``constants.py``).
    rep_key : str or None
        ``obsm`` key for the embedding; inferred from
        ``uns['corrected_rep']`` if ``None``.
    neighbors_key : str or None
        Existing neighbour graph to reuse; builds a new one if ``None``.

    Returns
    -------
    merged_adata : AnnData
        With ``'leiden_voting'`` added to ``.obs``.
    n_clusters : int
        Number of voting clusters produced.
    """
    # FIX 15: Default resolution aligned with Defaults.OVERCLUSTER_RESOLUTION
    # in constants.py (was 3.0, now 2.5).

    if rep_key is None:
        rep_key = merged_adata.uns.get("corrected_rep", "X_pca_harmony")

    if neighbors_key is None:
        # FIX 16: Standardise parameter spelling to match scanpy's API
        # (American: neighbors_key, not neighbours_key).
        # Back up uns["neighbors"] — scanpy ≤ 1.8 overwrites it even when
        # key_added is set, corrupting the corrected graph and causing the
        # UMAP to collapse to a degenerate vertical line.
        # TODO: remove this workaround once minimum supported scanpy >= 1.9,
        # where the bug (github.com/scverse/scanpy/issues/XXXX) was fixed.
        _neighbors_backup = merged_adata.uns.pop("neighbors", None)
        sc.pp.neighbors(
            merged_adata,
            use_rep=rep_key,
            key_added="neighbors_voting",
        )
        merged_adata.uns.pop("neighbors", None)
        if _neighbors_backup is not None:
            merged_adata.uns["neighbors"] = _neighbors_backup
        neighbors_key = "neighbors_voting"

    sc.tl.leiden(
        merged_adata,
        key_added="leiden_voting",
        neighbors_key=neighbors_key,
        resolution=resolution,
    )

    n_clusters = merged_adata.obs["leiden_voting"].nunique()
    print(
        f"  compute_voting_clusters: {n_clusters} clusters at resolution "
        f"{resolution} (key: 'leiden_voting')"
    )
    return merged_adata, n_clusters


# ---------------------------------------------------------------------------
# 8. cell_typing_celltypist  (pipeline orchestrator)
# ---------------------------------------------------------------------------


def cell_typing_celltypist(
    merged_adata: sc.AnnData,
    model_path: str,
    output_folder: str,
    gene_list_path: str | None = None,
    majority_voting: bool = True,
    voting_resolution: float = 2.5,
    min_prop: float = 0.1,
    layer: str = LOGNORM_LAYER,
    plot_confidence_threshold: float = 0.5,
) -> sc.AnnData:
    """
    Run CellTypist on ``merged_adata`` using the joint lognorm layer.

    This function is the pipeline orchestrator.  It delegates the actual
    annotation to ``run_celltypist()`` (the single place
    ``celltypist.annotate()`` is called) and wraps it with:

    - A dedicated high-resolution Leiden partition for majority voting
      (``compute_voting_clusters``).
    - Optional gene symbol → Ensembl ID remapping (round-trip, transparent
      to downstream code).
    - Feature overlap reporting via the shared ``compute_feature_overlap``
      helper.
    - Exception-safe state restoration: ``.X`` and ``var_names`` are always
      restored even if annotation fails.
    - Diagnostic plots saved to *output_folder*.

    Why majority_voting=False for tumour-dominated data?
    ----------------------------------------------------
    In breast cancer TMAs, malignant cells dominate every Leiden cluster
    regardless of resolution.  Majority voting collapses all 29 model cell
    types to 2 (malignant cell, fibroblast).  Setting
    ``majority_voting=False`` retains raw per-cell ``predicted_labels`` and
    delegates smoothing to ``apply_confidence_filter()`` +
    ``apply_spatial_knn_smoothing()``.

    Gene name → Ensembl ID round-trip (optional)
    ---------------------------------------------
    Only performed when *gene_list_path* is provided.  Use this when the
    CellTypist model was trained on Ensembl IDs while your AnnData uses gene
    symbols as ``var_names`` (common for 10X Xenium panels).

    Adds to merged_adata.obs
    ------------------------
    predicted_labels : per-cell raw CellTypist prediction
    majority_voting  : cluster-smoothed prediction (only if majority_voting=True)
    over_clustering  : voting cluster used (only if majority_voting=True)
    conf_score       : per-cell confidence score [0, 1]
    leiden_voting    : high-res Leiden partition

    Parameters
    ----------
    merged_adata : AnnData
        Output of ``batch_correction()``.
    model_path : str
        Path to trained CellTypist ``.pkl`` model.
    output_folder : str
        Directory for diagnostic plots and reports.
    gene_list_path : str or None
        Path to a 10X Xenium gene list CSV containing ``gene_name`` and
        ``gene_id`` columns, used to remap ``var_names`` from gene symbols
        to Ensembl IDs before running CellTypist.  Set to ``None`` (default)
        when the model features already match your ``var_names``.
    majority_voting : bool
        Smooth predictions over voting clusters.  Set ``False`` for
        tumour-dominated datasets.  Default ``True``.
    voting_resolution : float
        Leiden resolution for voting clusters.  Default ``2.5``.
    min_prop : float
        Minimum winning-type proportion for a cluster label during majority
        voting.  Default ``0.1``.
    layer : str
        Expression layer used as CellTypist input.  Default
        ``LOGNORM_LAYER`` (``"lognorm"``).  Change by updating the module-
        level constant or passing a different value here.
    plot_confidence_threshold : float
        Threshold line drawn on the confidence score histogram plot ONLY.
        Default ``0.5``.  This does NOT control which cells are filtered
        downstream — that is governed by the ``confidence_threshold``
        parameter of ``get_celltypist_predictions()`` (default 0.9).
        Rename makes the scope explicit and prevents the plot from
        misleading users into thinking 0.5 is the active filter.

    Returns
    -------
    AnnData
        ``merged_adata`` with cell type columns added to ``.obs``.
    """
    if not HAS_CELLTYPIST:
        raise ImportError(
            "celltypist is required for this function. " "Install with: pip install celltypist"
        )

    os.makedirs(output_folder, exist_ok=True)

    # -- 1. Load Ensembl mapping (only when gene_list_path is provided) -------
    do_ensembl_remap = gene_list_path is not None
    if do_ensembl_remap:
        # Uses module-level imports (FIX 21)
        if not _HAS_IO:
            raise RuntimeError(
                "cell_typing_celltypist: gene_list_path was provided but the "
                "package IO helpers (load_gene_mapping, rename_var_to_ensembl, "
                "rename_var_to_gene_name) could not be imported. "
                "Ensure this module is used within the pipeline package context."
            )
        print("Loading gene name -> Ensembl ID mapping...")
        name_to_ensembl, _ = load_gene_mapping(gene_list_path)
    else:
        print(
            "gene_list_path not provided — skipping Ensembl remapping "
            "(var_names passed to CellTypist as-is)."
        )

    # -- 2. Compute high-resolution voting clusters ---------------------------
    print(f"Computing voting clusters (resolution={voting_resolution})...")
    merged_adata, n_voting = compute_voting_clusters(merged_adata, resolution=voting_resolution)

    # -- 3. Swap .X to lognorm layer and optionally remap var_names -----------
    # FIX 17: Wrap the entire annotate block in try/finally so that .X and
    # var_names are ALWAYS restored even if celltypist.annotate() raises.
    # Previously an exception left merged_adata in a broken state (wrong .X,
    # Ensembl var_names) with no way to recover.
    X_orig = merged_adata.X
    original_var_names = None

    try:
        merged_adata.X = merged_adata.layers[layer]

        if do_ensembl_remap:
            print("Renaming var_names to Ensembl IDs for CellTypist...")
            merged_adata, original_var_names = rename_var_to_ensembl(merged_adata, name_to_ensembl)

        # -- 4. Load model and report feature overlap -------------------------
        # FIX 18: Use load_celltypist_model() (canonical loader) and the
        # shared compute_feature_overlap() helper instead of duplicating
        # the overlap arithmetic.
        print("Loading CellTypist model...")
        model = load_celltypist_model(model_path)
        stats = compute_feature_overlap(set(model.features), set(merged_adata.var_names))
        n_types = len(model.cell_types)

        print(f"  Model cell types : {n_types} -> {sorted(model.cell_types)}")
        print(f"  Overlap (genes)  : {stats['n_overlap']}")
        print(f"  Panel coverage   : {stats['panel_coverage']:.1f}%  [KEY metric]")
        print(
            f"  Model coverage   : {stats['model_coverage']:.1f}%  "
            "[expected low for targeted panels]"
        )

        if stats["panel_coverage"] == 0 and do_ensembl_remap:
            raise ValueError(
                "cell_typing_celltypist: 0 features overlap with the model after "
                "Ensembl remapping.  This means the model uses gene symbols, not "
                "Ensembl IDs.\n"
                "Fix: call cell_typing_celltypist() with gene_list_path=None.\n"
                "Tip: run diagnose_celltypist_model() first — it checks both "
                "formats and tells you which setting to use."
            )
        elif stats["panel_coverage"] < 50:
            print(
                "  WARNING: panel coverage <50% — "
                + (
                    "likely gene ID mismatch; try providing gene_list_path "
                    "for Ensembl remapping."
                    if not do_ensembl_remap
                    else "likely gene ID mismatch despite remapping; " "check gene_list_path."
                )
            )
        if n_types <= 3:
            print(
                f"  WARNING: model has only {n_types} cell types — consider a "
                "richer model (run list_celltypist_models() for options)"
            )

        # -- 5. Annotate via run_celltypist() ---------------------------------
        # FIX 19: Delegate to run_celltypist() — the single place where
        # celltypist.annotate() is called — instead of reimplementing it.
        print(
            f"Running CellTypist (majority_voting={majority_voting}, "
            f"voting clusters={n_voting}, min_prop={min_prop})..."
        )
        run_celltypist(
            merged_adata,
            model=model,
            majority_voting=majority_voting,
            over_clustering="leiden_voting",
            min_prop=min_prop,
            inplace=True,
        )

    finally:
        # -- 6. Always restore var_names and .X -------------------------------
        # IMPORTANT: restore .X FIRST, before any potential rebinding of
        # merged_adata.  If rename_var_to_gene_name returns a new object
        # (copy), we must set .X on that new object — so we do the rename
        # first, then set .X on whatever object we end up with.
        if do_ensembl_remap and original_var_names is not None:
            print("Restoring var_names to gene symbols...")
            restored = rename_var_to_gene_name(merged_adata, original_var_names)
            # rename_var_to_gene_name should mutate in place and return the
            # same object.  If it returns a copy, we accept it but warn so
            # the caller knows the returned object differs from their input.
            if restored is not merged_adata:
                logger.warning(
                    "rename_var_to_gene_name returned a new object (copy). "
                    "The caller's original merged_adata reference will have "
                    "Ensembl var_names; use the return value of "
                    "cell_typing_celltypist() instead."
                )
            merged_adata = restored
        merged_adata.X = X_orig

    # -- 7. Report results ----------------------------------------------------
    n_raw = merged_adata.obs[ColumnNames.CELLTYPIST_PREDICTION].nunique()
    has_mv = majority_voting and ColumnNames.CELLTYPIST_MAJORITY in merged_adata.obs.columns

    print(f"  Raw per-cell predictions : {n_raw} cell types")
    if has_mv:
        n_smoothed = merged_adata.obs[ColumnNames.CELLTYPIST_MAJORITY].nunique()
        print(f"  After majority voting    : {n_smoothed} cell types")
        if n_smoothed < n_raw * 0.5:
            print(
                f"  NOTE: majority voting collapsed {n_raw} -> {n_smoothed} types. "
                "Consider majority_voting=False + apply_confidence_filter() + "
                "apply_spatial_knn_smoothing()."
            )
    else:
        n_smoothed = None
        print(
            "  majority_voting=False: using raw per-cell predicted_labels. "
            "Run apply_confidence_filter() and apply_spatial_knn_smoothing() "
            "after this step."
        )

    # -- 8. Diagnostic plots --------------------------------------------------
    n_panels = 4 if has_mv else 3
    panel_size = 6
    fig, axs = plt.subplots(
        1,
        n_panels,
        figsize=(panel_size * n_panels, panel_size),
        gridspec_kw={"wspace": 0.4},
    )

    sc.pl.embedding(
        merged_adata,
        basis="umap_corrected",
        color=ColumnNames.CELLTYPIST_PREDICTION,
        ax=axs[0],
        show=False,
        title=f"Raw predictions ({n_raw} types)",
        legend_loc="on data",
        legend_fontsize=5,
        legend_fontoutline=1,
        frameon=False,
    )
    if has_mv:
        sc.pl.embedding(
            merged_adata,
            basis="umap_corrected",
            color=ColumnNames.CELLTYPIST_MAJORITY,
            ax=axs[1],
            show=False,
            title=f"Majority voting ({n_smoothed} types)",
            legend_loc="on data",
            legend_fontsize=6,
            legend_fontoutline=1,
            frameon=False,
        )
        conf_ax = axs[2]
        cluster_ax = axs[3]
    else:
        conf_ax = axs[1]
        cluster_ax = axs[2]

    sc.pl.embedding(
        merged_adata,
        basis="umap_corrected",
        color=ColumnNames.CONF_SCORE,
        ax=conf_ax,
        show=False,
        color_map="viridis",
        vmin=0,
        vmax=1,
        title="Confidence score",
        frameon=False,
    )
    sc.pl.embedding(
        merged_adata,
        basis="umap_corrected",
        color="leiden_voting",
        ax=cluster_ax,
        show=False,
        title=f"Voting clusters (res={voting_resolution}, n={n_voting})",
        legend_loc="on data",
        legend_fontsize=5,
        legend_fontoutline=1,
        frameon=False,
    )
    plt.savefig(
        Path(output_folder) / "celltypist_umap.png",
        dpi=150,
        bbox_inches="tight",
    )
    plt.close()

    if ColumnNames.CONF_SCORE in merged_adata.obs.columns:
        fig, ax = plt.subplots(figsize=(8, 4))
        merged_adata.obs[ColumnNames.CONF_SCORE].hist(
            bins=50, ax=ax, color="steelblue", edgecolor="white"
        )
        ax.set_xlabel("Confidence score")
        ax.set_ylabel("Cell count")
        ax.set_title("CellTypist confidence score distribution")
        # FIX 20: Use plot_confidence_threshold (renamed from confidence_threshold)
        # to make clear this line is diagnostic only and does not control
        # actual cell filtering (which is done in get_celltypist_predictions).
        ax.axvline(
            plot_confidence_threshold,
            color="red",
            linestyle="--",
            label=f"plot threshold = {plot_confidence_threshold} (diagnostic only)",
        )
        ax.legend()
        plt.tight_layout()
        plt.savefig(Path(output_folder) / "celltypist_conf_score_dist.png", dpi=150)
        plt.close()

    composition_col = (
        ColumnNames.CELLTYPIST_MAJORITY if has_mv else ColumnNames.CELLTYPIST_PREDICTION
    )
    composition_title = (
        "Cell type composition (majority voting)"
        if has_mv
        else "Cell type composition (raw per-cell predictions)"
    )
    ct_counts = merged_adata.obs[composition_col].value_counts().sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(8, max(4, len(ct_counts) * 0.4)))
    ct_counts.plot(kind="barh", ax=ax, color="steelblue", edgecolor="white")
    ax.set_xlabel("Cell count")
    ax.set_title(composition_title)
    plt.tight_layout()
    plt.savefig(Path(output_folder) / "celltypist_composition.png", dpi=150)
    plt.close()

    return merged_adata
