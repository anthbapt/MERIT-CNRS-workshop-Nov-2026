"""
Post-Processing and Label Smoothing (Marker Annotation — Pillar 1)
===================================================================

Functions for filtering and smoothing cell type predictions after annotation.
Particularly useful for refining low-confidence CellTypist predictions.

Key functions
-------------
- apply_confidence_filter : Mask low-confidence cells as 'Unassigned'
- apply_spatial_knn_smoothing : Smooth labels via k-NN consensus
"""

import numpy as np
import pandas as pd
import scipy.sparse as sp

__all__ = [
    "apply_confidence_filter",
    "apply_spatial_knn_smoothing",
]


def apply_confidence_filter(
    merged_adata,
    label_col="predicted_labels",
    conf_col="conf_score",
    conf_threshold=0.5,
    output_col="cell_type_final",
):
    """
    Primary annotation step when majority_voting=False.

    Masks low-confidence cells as 'Unassigned' rather than collapsing them
    into the dominant cell type. Follow with apply_spatial_knn_smoothing().

    Parameters
    ----------
    merged_adata   : AnnData  output of cell_typing_celltypist()
    label_col      : str      raw per-cell prediction column
    conf_col       : str      confidence score column
    conf_threshold : float    cells below this -> 'Unassigned' (default 0.5)
    output_col     : str      new obs column for final labels

    Returns
    -------
    merged_adata : AnnData  with output_col in .obs
    """
    labels = merged_adata.obs[label_col].copy()
    conf = merged_adata.obs[conf_col]

    # CellTypist returns predicted_labels as pandas Categorical — assigning
    # 'Unassigned' raises TypeError unless converted to object dtype first.
    if hasattr(labels, "cat"):
        labels = labels.astype(str)

    labels[conf < conf_threshold] = "Unassigned"
    merged_adata.obs[output_col] = labels

    counts = labels.value_counts()
    print(f"  Cell type distribution after confidence filter " f"(threshold={conf_threshold}):")
    for ct, n in counts.items():
        pct = 100 * n / len(labels)
        print(f"    {ct:<45} {n:>6}  ({pct:.1f}%)")

    return merged_adata


def apply_spatial_knn_smoothing(
    merged_adata,
    label_col="cell_type_final",
    output_col="cell_type_smoothed",
    neighbours_key="neighbours_corrected",
    k=15,
):
    """
    Smooth cell type labels by k-nearest-neighbour consensus in the
    corrected embedding space.

    Unlike majority voting over Leiden clusters, this operates at the
    single-cell level — each cell adopts the plurality label among its k
    nearest neighbours. Preserves rare spatially coherent populations.
    Unassigned cells are reassigned if neighbours reach consensus.

    Parameters
    ----------
    merged_adata   : AnnData
    label_col      : str      input label column (from apply_confidence_filter)
    output_col     : str      new smoothed label column
    neighbours_key : str      pre-computed neighbour graph key
    k              : int      number of neighbours to consider (default 15)

    Returns
    -------
    merged_adata : AnnData  with output_col in .obs
    """
    conn = merged_adata.obsp[neighbours_key + "_connectivities"]
    labels_arr = merged_adata.obs[label_col].values
    n_cells = conn.shape[0]

    # Encode labels as integers for fast bincount-based majority vote.
    # "Unassigned" cells are excluded from the vote but can still receive
    # a new label from their neighbours.
    unique_labels, encoded = np.unique(labels_arr, return_inverse=True)
    unassigned_int = np.where(unique_labels == "Unassigned")[0]
    unassigned_int = int(unassigned_int[0]) if len(unassigned_int) else -1
    n_labels = len(unique_labels)

    smoothed_encoded = encoded.copy()

    # Convert to CSR for efficient row slicing
    if not sp.isspmatrix_csr(conn):
        conn = conn.tocsr()

    for i in range(n_cells):
        start, end = conn.indptr[i], conn.indptr[i + 1]
        if start == end:
            continue
        neighbour_idx = conn.indices[start:end]
        weights = conn.data[start:end]

        # Select top-k neighbours by weight
        if len(neighbour_idx) > k:
            top_k_pos = np.argpartition(weights, -k)[-k:]
            neighbour_idx = neighbour_idx[top_k_pos]

        neighbour_enc = encoded[neighbour_idx]

        # Exclude "Unassigned" neighbours from the vote
        if unassigned_int >= 0:
            neighbour_enc = neighbour_enc[neighbour_enc != unassigned_int]

        if len(neighbour_enc) == 0:
            continue

        # Majority vote via bincount
        vote_counts = np.bincount(neighbour_enc, minlength=n_labels)
        smoothed_encoded[i] = int(np.argmax(vote_counts))

    smoothed = unique_labels[smoothed_encoded]
    merged_adata.obs[output_col] = smoothed
    n_types = pd.Series(smoothed).nunique()
    print(f"  KNN smoothing: {n_types} cell types after smoothing " f"(k={k}, input: {label_col})")

    return merged_adata
