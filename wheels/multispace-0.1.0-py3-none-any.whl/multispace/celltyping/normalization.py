"""
Normalization Methods for Single-Cell and Spatial Transcriptomics
=================================================================

This module provides various normalization methods for single-cell and
spatial transcriptomics data, including:

- Library size normalization (standard total count)
- scTransform (Pearson residuals)
- DESeq2-style size factor normalization
- TMM (Trimmed Mean of M-values)
- Cell area normalization (spatial-specific)

All methods work with AnnData objects and can be applied in-place or
return a normalized copy.

Example
-------
>>> from multispace.celltyping.normalization import normalize
>>> adata_norm = normalize(adata, method="library_size", target_sum=1e4)

>>> # Or use specific methods directly
>>> from multispace.celltyping.normalization import normalize_deseq2
>>> normalize_deseq2(adata, inplace=True)
"""

from __future__ import annotations

import warnings

import anndata as ad
import numpy as np
import scanpy as sc
from scipy import sparse

from .constants import ColumnNames

__all__ = [
    "normalize",
    "normalize_library_size",
    "normalize_sctransform",
    "normalize_deseq2",
    "normalize_tmm",
    "normalize_cell_area",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_dense(X) -> np.ndarray:
    """Return a dense float64 copy of X regardless of whether it is sparse."""
    if sparse.issparse(X):
        return X.toarray().astype(np.float64)
    return np.array(X, dtype=np.float64)


def _sanitise_uns_value(v):
    """
    Recursively convert a value to something safely serialisable to HDF5/JSON.
    Numpy scalars/arrays are converted to plain Python types; anything else
    that is not a basic type is cast to str so that h5ad saving never fails.
    """
    if isinstance(v, (bool, int, float, str, type(None))):
        return v
    if isinstance(v, np.generic):  # numpy scalar
        return v.item()
    if isinstance(v, np.ndarray):
        return v.tolist()
    if isinstance(v, dict):
        return {k: _sanitise_uns_value(val) for k, val in v.items()}
    if isinstance(v, (list, tuple)):
        return [_sanitise_uns_value(i) for i in v]
    return str(v)  # fallback: stringify


# ---------------------------------------------------------------------------
# 1. Unified dispatcher
# ---------------------------------------------------------------------------


def normalize(
    adata: ad.AnnData,
    method: str = "library_size",
    target_sum: float = 1e4,
    log_transform: bool = False,
    inplace: bool = True,
    **kwargs,
) -> ad.AnnData | None:
    """
    Unified normalization function for single-cell/spatial data.

    Parameters
    ----------
    adata : AnnData
        Annotated data matrix with cells x genes.
    method : str
        Normalization method:
        - 'library_size': Standard total count normalization (default)
        - 'sctransform': Pearson residuals (regularized negative binomial)
        - 'deseq2': DESeq2-style size factor normalization
        - 'tmm': Trimmed Mean of M-values (edgeR-style)
        - 'cell_area': Normalize by cell volume/area (spatial-specific)
        - 'none': No normalization
    target_sum : float
        Target sum for library_size normalization. Default: 1e4.
    log_transform : bool
        Whether to apply log1p transformation after normalization.
        Ignored when method='sctransform' (Pearson residuals are already
        variance-stabilised and must not be log-transformed) or
        method='none'.
    inplace : bool
        Whether to modify adata in place or return a copy.
    **kwargs
        Additional parameters forwarded to the specific normalization
        function. Values must be serialisable (plain Python / numpy
        scalars); non-serialisable objects are cast to str before being
        stored in adata.uns.

    Returns
    -------
    AnnData or None
        Returns normalized AnnData if inplace=False, else None.

    Examples
    --------
    >>> # Library size normalization with log transform
    >>> adata_norm = normalize(adata, method="library_size", log_transform=True, inplace=False)

    >>> # DESeq2 normalization in place
    >>> normalize(adata, method="deseq2", inplace=True)
    """
    adata_work = adata if inplace else adata.copy()

    # FIX 1: Store raw counts before any modification.
    # Assigning an AnnData directly triggers scanpy's Raw.__init__, which
    # correctly converts it to a Raw object.  Using .copy() here would store
    # a full AnnData in .raw, which is the wrong type and breaks
    # adata.raw.to_adata() in some scanpy versions.
    if adata_work.raw is None:
        adata_work.raw = adata_work

    # Apply normalization
    normalizers = {
        "library_size": lambda: normalize_library_size(adata_work, target_sum=target_sum),
        "sctransform": lambda: normalize_sctransform(adata_work, **kwargs),
        "deseq2": lambda: normalize_deseq2(adata_work),
        "tmm": lambda: normalize_tmm(adata_work, **kwargs),
        "cell_area": lambda: normalize_cell_area(adata_work, **kwargs),
        "none": lambda: None,
    }

    if method not in normalizers:
        valid = ", ".join(normalizers.keys())
        raise ValueError(f"Unknown normalization method: {method}. Choose from: {valid}")

    normalizers[method]()

    # FIX 2: Skip log transform for 'none' (no normalisation was applied,
    # so log-transforming raw counts may be intentional but should be an
    # explicit separate step) and for 'sctransform' (Pearson residuals are
    # already variance-stabilised; log1p would distort them).
    if log_transform and method not in ("sctransform", "none"):
        sc.pp.log1p(adata_work)

    # FIX 3: Sanitise kwargs before storing in uns so that h5ad saving
    # never fails due to non-serialisable objects (arrays, callables, etc.).
    # FIX 4: Only store target_sum when it is actually used.
    uns_entry: dict = {
        "method": method,
        "log_transformed": log_transform and method not in ("sctransform", "none"),
    }
    if method == "library_size":
        uns_entry["target_sum"] = float(target_sum)
    uns_entry.update({k: _sanitise_uns_value(v) for k, v in kwargs.items()})
    adata_work.uns["normalization"] = uns_entry

    return None if inplace else adata_work


# ---------------------------------------------------------------------------
# 2. Library size normalization
# ---------------------------------------------------------------------------


def normalize_library_size(
    adata: ad.AnnData, target_sum: float = 1e4, inplace: bool = True
) -> ad.AnnData | None:
    """
    Library size (total count) normalization.

    Scales each cell so that total counts equal target_sum.

    Parameters
    ----------
    adata : AnnData
        Annotated data matrix.
    target_sum : float
        Target sum for each cell. Default: 1e4.
    inplace : bool
        Modify in place or return copy.

    Returns
    -------
    AnnData or None
    """
    adata_work = adata if inplace else adata.copy()

    # FIX 5: Guard against double-normalisation.
    # After library-size normalisation the per-cell sum equals target_sum.
    # If the data have already been normalised the median cell sum will be
    # close to target_sum rather than to raw count magnitudes.  We use a
    # heuristic: if the median per-cell sum is within 5 % of target_sum,
    # warn the user rather than silently re-normalising.
    cell_sums = np.asarray(_to_dense(adata_work.X)).sum(axis=1)
    median_sum = float(np.median(cell_sums))
    if abs(median_sum - target_sum) / target_sum < 0.05:
        warnings.warn(
            f"Median cell sum ({median_sum:.1f}) is already close to target_sum "
            f"({target_sum:.1f}). The data may have been normalised previously. "
            "Proceeding, but check for double-normalisation.",
            UserWarning,
            stacklevel=2,
        )

    sc.pp.normalize_total(adata_work, target_sum=target_sum, inplace=True)
    return None if inplace else adata_work


# ---------------------------------------------------------------------------
# 3. scTransform (Pearson residuals)
# ---------------------------------------------------------------------------


def normalize_sctransform(
    adata: ad.AnnData,
    theta: float = 100.0,  # FIX 6: float, not int — θ is a continuous parameter
    clip: float | None = None,
    inplace: bool = True,
) -> ad.AnnData | None:
    """
    scTransform normalization using Pearson residuals.

    Implements the variance-stabilizing transformation from
    Hafemeister & Satija (2019).

    Parameters
    ----------
    adata : AnnData
        Annotated data matrix with raw counts.
    theta : float
        Overdispersion parameter for the negative binomial model.
        Must be positive. Default: 100.0.  Note: this is a continuous
        parameter; integer values are a special case.
    clip : float, optional
        Clip residuals to [-clip, clip].  Default: None, which delegates
        to scanpy's internal default (sqrt(n_cells / 30) as of scanpy
        ≥ 1.9; verify against your installed version).
    inplace : bool
        Modify in place or return copy.

    Returns
    -------
    AnnData or None

    Notes
    -----
    The output is Pearson residuals, which are variance-stabilised but
    are NOT log-transformed.  Do not apply log1p to the output of this
    function — it would distort the residuals.  The `log_transform`
    flag in the `normalize()` dispatcher is therefore ignored for this
    method.
    """
    # FIX 7: validate theta is positive float
    theta = float(theta)
    if theta <= 0:
        raise ValueError(f"theta must be positive, got {theta}")

    adata_work = adata if inplace else adata.copy()
    sc.experimental.pp.normalize_pearson_residuals(adata_work, theta=theta, clip=clip, inplace=True)
    return None if inplace else adata_work


# ---------------------------------------------------------------------------
# 4. DESeq2-style size factor normalization
# ---------------------------------------------------------------------------


def normalize_deseq2(adata: ad.AnnData, inplace: bool = True) -> ad.AnnData | None:
    """
    DESeq2-style size factor normalization.

    Computes size factors using the median-of-ratios method from
    Anders & Huber (2010).

    Parameters
    ----------
    adata : AnnData
        Annotated data matrix with raw counts.
    inplace : bool
        Modify in place or return copy.

    Returns
    -------
    AnnData or None

    Notes
    -----
    Size factors are stored in adata.obs['size_factors_deseq2'].
    Cells with all-zero counts receive size factor NaN and a warning
    is raised; they are left as-is in the output matrix.
    """
    adata_work = adata if inplace else adata.copy()

    counts = _to_dense(adata_work.X)  # cells × genes, float64

    # FIX 8: Vectorised geometric mean per gene (log-mean approach).
    # Equivalent to gmean(x[x > 0]) but operates on the full matrix at
    # once — orders of magnitude faster than a Python loop over genes.
    with np.errstate(divide="ignore", invalid="ignore"):
        log_counts = np.where(counts > 0, np.log(counts), np.nan)
    gene_geom_means = np.exp(np.nanmean(log_counts, axis=0))  # shape: (n_genes,)

    # Genes whose geometric mean is 0 (all-zero gene) are excluded from
    # the ratio computation — same as the original DESeq2 paper.
    valid_genes = gene_geom_means > 0

    # FIX 9: Vectorised size factor computation.
    # Divide each cell's counts by the gene geometric means (only valid
    # genes), then take the median ratio per cell.
    ratios = counts[:, valid_genes] / gene_geom_means[np.newaxis, valid_genes]
    # Mask zeros: a zero count gives ratio=0 which should not enter the
    # median (DESeq2 excludes zero counts from the median calculation).
    ratios_masked = np.where(ratios > 0, ratios, np.nan)
    size_factors = np.nanmedian(ratios_masked, axis=1)  # shape: (n_cells,)

    # FIX 10: Warn explicitly about all-zero cells instead of silently
    # assigning size_factor = 1.0, which would produce misleading output.
    zero_cells = np.isnan(size_factors)
    if zero_cells.any():
        n_zero = int(zero_cells.sum())
        warnings.warn(
            f"{n_zero} cell(s) have all-zero counts or no valid gene ratios. "
            "Their size factors are set to NaN and their rows are left "
            "unchanged in the output matrix. Consider filtering these cells "
            "before normalization.",
            UserWarning,
            stacklevel=2,
        )
        # Leave those cells unchanged (divide by 1 effectively)
        size_factors = np.where(zero_cells, 1.0, size_factors)

    # Normalise: divide each cell's counts by its size factor
    adata_work.X = counts / size_factors[:, np.newaxis]
    adata_work.obs[ColumnNames.SIZE_FACTORS_DESEQ2] = size_factors

    return None if inplace else adata_work


# ---------------------------------------------------------------------------
# 5. TMM normalization
# ---------------------------------------------------------------------------


def normalize_tmm(
    adata: ad.AnnData,
    ref_sample: int | None = None,
    M_trim: float = 0.3,
    A_trim: float = 0.05,
    inplace: bool = True,
) -> ad.AnnData | None:
    """
    TMM (Trimmed Mean of M-values) normalization.

    Implements the TMM method from Robinson & Oshlack (2010), used in edgeR.

    Parameters
    ----------
    adata : AnnData
        Annotated data matrix with raw counts.
    ref_sample : int, optional
        Index of reference sample. Default: sample with 75th-percentile
        library size (edgeR default).
    M_trim : float
        Fraction to trim from both tails of M-values (log fold changes).
        Default: 0.3.
    A_trim : float
        Fraction to trim from the lower tail of A-values (average
        expression). Default: 0.05.
    inplace : bool
        Modify in place or return copy.

    Returns
    -------
    AnnData or None

    Notes
    -----
    TMM factors are stored in adata.obs['tmm_factors'].

    The output matrix is effective counts per million (CPM) scaled by
    TMM factors, i.e. counts / (lib_size * tmm_factor).  This matches
    the cpm(y, normalized.lib.sizes=TRUE) output from edgeR.  If you
    need raw counts with TMM offsets for a GLM (as edgeR uses internally),
    keep the original counts and use tmm_factors as log-offsets.
    """
    adata_work = adata if inplace else adata.copy()

    # FIX 11: Compute lib_sizes from the ORIGINAL counts (before any
    # pseudocount) so that library sizes reflect the true sequencing depth.
    counts_orig = _to_dense(adata_work.X)  # cells × genes, float64
    lib_sizes = counts_orig.sum(axis=1)  # shape: (n_cells,)

    # FIX 12: Use pseudocount ONLY for M/A computation — never write it
    # back to the output matrix.
    counts_ps = counts_orig + 1  # pseudocount copy, local only

    # Select reference sample: 75th-percentile library size (edgeR default)
    if ref_sample is None:
        ref_sample = int(np.argsort(lib_sizes)[int(len(lib_sizes) * 0.75)])

    ref_counts = counts_ps[ref_sample, :]
    ref_libsize = lib_sizes[ref_sample]
    tmm_factors = np.ones(counts_orig.shape[0])

    for i in range(counts_orig.shape[0]):
        if i == ref_sample:
            continue

        samp_counts = counts_ps[i, :]
        samp_libsize = lib_sizes[i]

        # Compute M (log2 fold-change) and A (average log2 expression)
        with np.errstate(divide="ignore", invalid="ignore"):
            M = np.log2(samp_counts / samp_libsize) - np.log2(ref_counts / ref_libsize)
            A = 0.5 * (np.log2(samp_counts / samp_libsize) + np.log2(ref_counts / ref_libsize))

        # Keep only genes with valid, finite M and A
        mask = (
            (counts_orig[i, :] > 0)
            & (counts_orig[ref_sample, :] > 0)
            & np.isfinite(M)
            & np.isfinite(A)
        )
        M_valid = M[mask]
        A_valid = A[mask]

        if len(M_valid) == 0:
            continue

        # Trim M symmetrically (both tails) and A from the lower tail only
        # FIX 13: A-values should only be trimmed from the lower tail
        # (low-expression genes), not symmetrically, per Robinson & Oshlack.
        M_keep = _trim_indices_symmetric(M_valid, M_trim)
        A_keep = _trim_indices_lower(A_valid, A_trim)
        keep_idx = np.intersect1d(M_keep, A_keep)

        if len(keep_idx) == 0:
            warnings.warn(
                f"TMM: no genes remain after trimming for sample {i}. " "TMM factor set to 1.0.",
                UserWarning,
                stacklevel=2,
            )
            continue

        # Precision weights: w_g = 1/Var(M_g) ≈ (N_r-K_rg)/(N_r*K_rg) + (N_i-K_ig)/(N_i*K_ig)
        # (Robinson & Oshlack 2010, equation 4)
        K_i = counts_ps[i, :][mask][keep_idx]
        K_r = ref_counts[mask][keep_idx]
        weights = (ref_libsize - K_r) / (ref_libsize * K_r) + (samp_libsize - K_i) / (
            samp_libsize * K_i
        )

        # FIX 14: Exclude degenerate weights (≤ 0) rather than replacing
        # with a tiny constant, which would give those genes undue influence.
        valid_w = weights > 0
        if not valid_w.any():
            continue
        weights = weights[valid_w]
        M_trimmed = M_valid[keep_idx][valid_w]

        # FIX 15: Use weights directly (not 1/weights).
        # Higher weight = lower variance = more reliable M-value.
        tmm_factors[i] = 2 ** np.average(M_trimmed, weights=weights)

    # FIX 16: Normalise using the ORIGINAL lib_sizes (not pseudocount-inflated)
    adata_work.X = counts_orig / (lib_sizes[:, np.newaxis] * tmm_factors[:, np.newaxis])
    adata_work.obs[ColumnNames.TMM_FACTORS] = tmm_factors

    return None if inplace else adata_work


# ---------------------------------------------------------------------------
# 6. Cell area normalization
# ---------------------------------------------------------------------------


def normalize_cell_area(
    adata: ad.AnnData,
    area_key: str = ColumnNames.CELL_AREA,
    scale_factor_clip: tuple[float, float] = (0.1, 10.0),
    inplace: bool = True,
) -> ad.AnnData | None:
    """
    Normalize by cell area (spatial-specific).

    Scales counts by cell area to account for cell size differences in
    spatial data.

    Parameters
    ----------
    adata : AnnData
        Annotated data matrix.
    area_key : str
        Column name in adata.obs containing cell areas. Default: "cell_area".
    scale_factor_clip : tuple of (float, float)
        (min, max) bounds applied to the computed scale factors before
        normalisation.  Prevents extreme inflation/deflation caused by
        segmentation artefacts (e.g. near-zero area cells).
        Default: (0.1, 10.0).
    inplace : bool
        Modify in place or return copy.

    Returns
    -------
    AnnData or None

    Notes
    -----
    Scale factors are stored in adata.obs['area_scale_factors'].
    """
    adata_work = adata if inplace else adata.copy()

    if area_key not in adata_work.obs.columns:
        raise ValueError(f"Cell area column '{area_key}' not found in adata.obs")

    areas = adata_work.obs[area_key].values.astype(float)

    # Handle invalid areas — replace with median before computing scale factors
    invalid_mask = areas <= 0
    if invalid_mask.any():
        # FIX 17: Compute median once, from valid areas only
        median_area = float(np.median(areas[~invalid_mask]))
        warnings.warn(
            f"{int(invalid_mask.sum())} cell(s) have zero or negative area. "
            f"Replacing with median area ({median_area:.4f}).",
            UserWarning,
            stacklevel=2,
        )
        areas = areas.copy()
        areas[invalid_mask] = median_area
    else:
        median_area = float(np.median(areas))

    # Scale factors: ratio of median area to each cell's area
    scale_factors = median_area / areas

    # FIX 18: Clip scale factors to prevent extreme values from segmentation
    # artefacts (e.g. a near-zero area cell would otherwise get a scale
    # factor of thousands, massively inflating its counts).
    lo, hi = scale_factor_clip
    n_clipped = int(((scale_factors < lo) | (scale_factors > hi)).sum())
    if n_clipped > 0:
        warnings.warn(
            f"{n_clipped} scale factor(s) were clipped to [{lo}, {hi}]. "
            "Consider inspecting cells with extreme areas.",
            UserWarning,
            stacklevel=2,
        )
    scale_factors = np.clip(scale_factors, lo, hi)

    # FIX 19: Preserve sparse format when the input is sparse.
    # Multiplying a sparse matrix by a diagonal scale is memory-efficient
    # and avoids materialising a dense copy for large datasets.
    if sparse.issparse(adata_work.X):
        # scipy sparse: multiply each row i by scale_factors[i]
        diag = sparse.diags(scale_factors, format="csr")
        adata_work.X = diag.dot(adata_work.X)
    else:
        counts = np.array(adata_work.X, dtype=np.float64)
        adata_work.X = counts * scale_factors[:, np.newaxis]

    adata_work.obs["area_scale_factors"] = scale_factors

    return None if inplace else adata_work


# ---------------------------------------------------------------------------
# 7. Trimming helpers
# ---------------------------------------------------------------------------


def _trim_indices_symmetric(values: np.ndarray, trim_fraction: float) -> np.ndarray:
    """
    Return indices of values after trimming both tails symmetrically.

    Used for M-values (log fold-changes) in TMM normalization.

    Parameters
    ----------
    values : np.ndarray
        1-D array of values to trim.
    trim_fraction : float
        Fraction to remove from each tail (0 ≤ trim_fraction < 0.5).

    Returns
    -------
    np.ndarray
        Indices of the retained values in the original array.
        Returns an empty array if trimming removes all values, and
        emits a UserWarning in that case.
    """
    n = len(values)
    n_trim = int(n * trim_fraction)
    sorted_idx = np.argsort(values)
    kept = sorted_idx[n_trim : n - n_trim] if n - 2 * n_trim > 0 else np.array([], dtype=int)
    # FIX 20: Warn when trimming leaves nothing
    if len(kept) == 0:
        warnings.warn(
            f"_trim_indices_symmetric: all {n} values were trimmed "
            f"(trim_fraction={trim_fraction}, n={n}). "
            "Returning empty index array.",
            UserWarning,
            stacklevel=2,
        )
    return kept


def _trim_indices_lower(values: np.ndarray, trim_fraction: float) -> np.ndarray:
    """
    Return indices of values after trimming the lower tail only.

    Used for A-values (average expression) in TMM normalization.
    Per Robinson & Oshlack (2010), only low-expression genes are removed
    from the A-value axis — the upper tail is retained.

    Parameters
    ----------
    values : np.ndarray
        1-D array of values to trim.
    trim_fraction : float
        Fraction to remove from the lower tail only (0 ≤ trim_fraction < 1).

    Returns
    -------
    np.ndarray
        Indices of the retained values in the original array.
        Returns an empty array (with warning) if trimming removes all values.
    """
    n = len(values)
    n_trim = int(n * trim_fraction)
    sorted_idx = np.argsort(values)
    # FIX 21: Trim lower tail only (not upper)
    kept = sorted_idx[n_trim:] if n - n_trim > 0 else np.array([], dtype=int)
    if len(kept) == 0:
        warnings.warn(
            f"_trim_indices_lower: all {n} values were trimmed "
            f"(trim_fraction={trim_fraction}, n={n}). "
            "Returning empty index array.",
            UserWarning,
            stacklevel=2,
        )
    return kept
