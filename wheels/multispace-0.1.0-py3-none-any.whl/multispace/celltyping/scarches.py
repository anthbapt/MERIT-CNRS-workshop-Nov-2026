"""
scArches Integration (Auto-annotation — Pillar 2)
=================================================

scArches (single-cell Architectural Surgery) enables query-to-reference
mapping for automated cell type annotation via **model surgery**: a
pre-trained reference model is extended with new batch embeddings and
fine-tuned on the query data, keeping the reference weights mostly frozen.
Label transfer is then performed by the model's built-in classifier.

How scArches differs from CellTypist
-------------------------------------
CellTypist trains a logistic-regression classifier on a reference atlas and
applies it directly to query cells in gene-expression space.  The query data
must share the same gene space as the reference, and no integration of batch
effects is performed.

scArches works differently:

1. A **reference model** (scANVI or scPoli) is trained on a labelled atlas.
   The model learns a low-dimensional *latent space* that is both
   batch-corrected and cell-type-aware.

2. **Model surgery** (``load_query_data``) extends the reference model with
   new batch/condition embeddings for the query dataset while freezing the
   encoder weights that encode biological variation.

3. The extended model is **fine-tuned** on the query data (typically
   50–100 epochs) so that query cells are projected into the same latent
   space as the reference.

4. **Label transfer** is performed in latent space:
   - scANVI: the built-in softmax classifier (``model.predict()``) assigns
     the most probable reference label to each query cell; soft probabilities
     are obtained via ``model.predict_proba()``.
   - scPoli: a prototype-based nearest-neighbour classifier
     (``model.classify()``) returns predicted labels and a scaled uncertainty
     score [0, 1] (0 = certain, 1 = maximally uncertain).

Two supported backends
-----------------------
``backend="scanvi"``  (default)
    Uses scVI → scANVI pipeline.  Requires raw counts in ``adata.X``.
    Returns per-cell soft probabilities → confidence = max(softmax).
    Best when a pre-trained scANVI reference model is available on disk.

``backend="scpoli"``
    Uses scPoli prototype learning.  Accepts normalised or raw counts.
    Returns per-cell uncertainty scores (distance to nearest prototype,
    scaled to [0, 1]).  Best when building a reference from scratch or
    when the reference atlas is provided as an AnnData with cell-type labels.

Public API
----------
- build_scanvi_reference        : train scVI + scANVI on a labelled reference
- build_scpoli_reference        : train scPoli on a labelled reference
- run_scarches                  : map query data to a saved reference model
- get_scarches_predictions      : extract (predictions, confidences, needs_refinement)
- combine_scarches_with_consensus : mirror of celltypist combine function
- diagnose_scarches             : pre-flight gene overlap / obs column check
- cell_typing_scarches          : high-level entry point (mirrors cell_typing_celltypist)
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Literal

import numpy as np
import scanpy as sc

from .core_utils import combine_primary_with_consensus, compute_feature_overlap

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional dependency guards
# ---------------------------------------------------------------------------

try:
    import scarches as sca

    HAS_SCARCHES = True
except ImportError:
    HAS_SCARCHES = False

try:
    import scvi  # noqa: F401  -- availability check only; module itself not referenced

    HAS_SCVI = True
except ImportError:
    HAS_SCVI = False

__all__ = [
    "HAS_SCARCHES",
    "HAS_SCVI",
    "build_scanvi_reference",
    "build_scpoli_reference",
    "run_scarches",
    "get_scarches_predictions",
    "combine_scarches_with_consensus",
    "diagnose_scarches",
    "cell_typing_scarches",
]

# ---------------------------------------------------------------------------
# Reference model builders
# ---------------------------------------------------------------------------


def build_scanvi_reference(
    reference_adata: sc.AnnData,
    cell_type_key: str,
    batch_key: str,
    save_path: str,
    unlabeled_category: str = "Unknown",
    n_layers: int = 2,
    scvi_epochs: int = 400,
    scanvi_epochs: int = 20,
    use_gpu: bool = True,
) -> Any:
    """
    Train a scVI → scANVI reference model on a fully labelled atlas.

    This is the *reference-building* step.  Run it once on your atlas and
    save the model; downstream query mapping loads it from ``save_path``.

    scVI is trained first as an unsupervised VAE for batch correction, then
    converted to scANVI which adds a semi-supervised classifier head.

    Parameters
    ----------
    reference_adata : AnnData
        Labelled reference atlas.  ``adata.X`` must contain **raw counts**.
    cell_type_key : str
        ``obs`` column with ground-truth cell type labels.
    batch_key : str
        ``obs`` column with batch / study identifiers.
    save_path : str
        Directory where the trained scANVI model will be saved.
    unlabeled_category : str
        Placeholder label for unlabelled cells (default ``"Unknown"``).
    n_layers : int
        Number of hidden layers in the encoder/decoder (default 2).
    scvi_epochs : int
        Training epochs for the scVI pre-training step (default 400).
    scanvi_epochs : int
        Fine-tuning epochs for the scANVI classifier head (default 20).
    use_gpu : bool
        Use GPU if available (default True).

    Returns
    -------
    scanvae : scvi.model.SCANVI
        Trained scANVI model (also saved to ``save_path``).

    Examples
    --------
    >>> scanvae = build_scanvi_reference(
    ...     atlas_adata, cell_type_key="cell_type",
    ...     batch_key="study", save_path="ref_model/"
    ... )
    """
    _require_scarches()

    logger.info("Setting up scVI on reference data...")
    sca.models.SCVI.setup_anndata(
        reference_adata,
        batch_key=batch_key,
        labels_key=cell_type_key,
    )

    vae = sca.models.SCVI(
        reference_adata,
        n_layers=n_layers,
        encode_covariates=True,
        deeply_inject_covariates=False,
        use_layer_norm="both",
        use_batch_norm="none",
    )
    logger.info(f"Training scVI for {scvi_epochs} epochs...")
    vae.train(max_epochs=scvi_epochs, use_gpu=use_gpu)

    logger.info("Converting scVI → scANVI and fine-tuning classifier...")
    scanvae = sca.models.SCANVI.from_scvi_model(vae, unlabeled_category=unlabeled_category)
    scanvae.train(max_epochs=scanvi_epochs, use_gpu=use_gpu)

    os.makedirs(save_path, exist_ok=True)
    scanvae.save(save_path, overwrite=True)
    logger.info(f"scANVI reference model saved to {save_path}")

    return scanvae


def build_scpoli_reference(
    reference_adata: sc.AnnData,
    cell_type_key: str,
    condition_key: str,
    save_path: str,
    embedding_dims: int = 5,
    recon_loss: str = "nb",
    n_epochs: int = 50,
    pretraining_epochs: int = 40,
    eta: float = 5.0,
    use_gpu: bool = True,
) -> Any:
    """
    Train a scPoli reference model on a fully labelled atlas.

    scPoli learns both a batch-corrected latent space and *prototype*
    embeddings — one prototype per cell type — that serve as anchors for
    label transfer.  No separate classifier head is needed.

    Parameters
    ----------
    reference_adata : AnnData
        Labelled reference atlas.  Accepts normalised counts (log1p or raw).
    cell_type_key : str
        ``obs`` column with ground-truth cell type labels.
    condition_key : str
        ``obs`` column with batch / study identifiers.
    save_path : str
        Directory where the trained scPoli model will be saved.
    embedding_dims : int
        Dimensionality of the condition embedding (default 5).
    recon_loss : str
        Reconstruction loss: ``"nb"`` (negative binomial, default) or
        ``"mse"`` / ``"zinb"``.
    n_epochs : int
        Total training epochs (default 50).
    pretraining_epochs : int
        Unsupervised pre-training epochs before prototype loss is applied
        (default 40; recommended ~80% of ``n_epochs``).
    eta : float
        Weight of the prototype loss (default 5.0).
    use_gpu : bool
        Use GPU if available (default True).

    Returns
    -------
    scpoli_model : scarches.models.scpoli.scPoli
        Trained scPoli model (also saved to ``save_path``).

    Examples
    --------
    >>> scpoli_model = build_scpoli_reference(
    ...     atlas_adata, cell_type_key="cell_type",
    ...     condition_key="study", save_path="ref_scpoli/"
    ... )
    """
    _require_scarches()
    from scarches.models.scpoli import scPoli

    logger.info("Training scPoli reference model...")
    scpoli_model = scPoli(
        adata=reference_adata,
        condition_keys=condition_key,
        cell_type_keys=cell_type_key,
        embedding_dims=embedding_dims,
        recon_loss=recon_loss,
    )

    early_stopping_kwargs = {
        "early_stopping_metric": "val_prototype_loss",
        "mode": "min",
        "threshold": 0,
        "patience": 20,
        "reduce_lr": True,
        "lr_patience": 13,
        "lr_factor": 0.1,
    }

    scpoli_model.train(
        n_epochs=n_epochs,
        pretraining_epochs=pretraining_epochs,
        early_stopping_kwargs=early_stopping_kwargs,
        eta=eta,
    )

    os.makedirs(save_path, exist_ok=True)
    scpoli_model.save(save_path, overwrite=True)
    logger.info(f"scPoli reference model saved to {save_path}")

    return scpoli_model


# ---------------------------------------------------------------------------
# Core query-mapping function
# ---------------------------------------------------------------------------


def run_scarches(
    adata: sc.AnnData,
    reference_model_path: str,
    batch_key: str,
    cell_type_key: str = "cell_type",
    backend: Literal["scanvi", "scpoli"] = "scanvi",
    unlabeled_category: str = "Unknown",
    surgery_epochs: int = 100,
    surgery_lr_decay: float = 0.0,
    scpoli_eta: float = 10.0,
    scpoli_pretraining_ratio: float = 0.8,
    use_gpu: bool = True,
    layer: str | None = None,
    inplace: bool = False,
) -> sc.AnnData:
    """
    Map query data to a pre-trained reference model and transfer labels.

    This is the main entry point for scArches-based annotation.  It performs
    model surgery (extending the reference model with query batch embeddings),
    fine-tunes on the query, and writes predictions into ``adata.obs``.

    Parameters
    ----------
    adata : AnnData
        Query dataset to annotate.
        - scANVI backend: ``adata.X`` must contain **raw counts** (or set
          ``layer`` to point to a raw-count layer).
        - scPoli backend: accepts log-normalised counts.
    reference_model_path : str
        Path to the saved reference model directory (output of
        ``build_scanvi_reference`` or ``build_scpoli_reference``).
    batch_key : str
        ``obs`` column identifying batches/samples in the query data.
        Must be present in ``adata.obs``.
    cell_type_key : str
        ``obs`` column name used for cell type labels.  For unlabelled query
        data, this column will be created and filled with ``unlabeled_category``
        before surgery (required by scANVI).
    backend : {"scanvi", "scpoli"}
        Which scArches model to use (default ``"scanvi"``).
    unlabeled_category : str
        Placeholder label for query cells (default ``"Unknown"``).
    surgery_epochs : int
        Fine-tuning epochs on the query data (default 100).
    surgery_lr_decay : float
        Weight decay during surgery; 0.0 disables L2 regularisation
        (recommended for scANVI surgery, default 0.0).
    scpoli_eta : float
        Prototype loss weight during scPoli surgery (default 10.0).
    scpoli_pretraining_ratio : float
        Fraction of ``surgery_epochs`` used for unsupervised pre-training
        in scPoli surgery (default 0.8).
    use_gpu : bool
        Use GPU if available (default True).
    layer : str or None
        If set, swap ``adata.X`` with ``adata.layers[layer]`` before running
        scANVI (useful when raw counts are stored in a layer).
    inplace : bool
        If True, modify ``adata`` in place; otherwise work on a copy.

    Returns
    -------
    AnnData
        Query data with the following columns added to ``.obs``:

        For scANVI backend:
          - ``scarches_predicted_labels``  : argmax of softmax classifier
          - ``scarches_conf_score``        : max softmax probability [0, 1]
          - ``scarches_latent_rep``        : stored in ``.obsm["X_scarches_latent"]``

        For scPoli backend:
          - ``scarches_predicted_labels``  : nearest-prototype label
          - ``scarches_conf_score``        : 1 − scaled_uncertainty [0, 1]
          - ``scarches_uncertainty``       : raw scaled uncertainty [0, 1]
          - ``scarches_latent_rep``        : stored in ``.obsm["X_scarches_latent"]``

    Raises
    ------
    ImportError
        If scarches / scvi-tools is not installed.
    ValueError
        If ``batch_key`` is missing from ``adata.obs``.

    Examples
    --------
    >>> adata = run_scarches(
    ...     query_adata,
    ...     reference_model_path="ref_model/",
    ...     batch_key="sample_id",
    ...     backend="scanvi",
    ... )
    >>> print(adata.obs["scarches_predicted_labels"].value_counts())
    """
    _require_scarches()

    if batch_key not in adata.obs.columns:
        raise ValueError(
            f"batch_key '{batch_key}' not found in adata.obs. "
            f"Available columns: {list(adata.obs.columns)}"
        )

    if not inplace:
        adata = adata.copy()

    # Optionally swap .X to a raw-count layer (scANVI requires raw counts)
    X_orig = None
    if layer is not None:
        logger.info(f"Swapping adata.X to layer '{layer}' for scArches input")
        X_orig = adata.X.copy()
        adata.X = adata.layers[layer]

    try:
        if backend == "scanvi":
            adata = _run_scanvi_surgery(
                adata=adata,
                reference_model_path=reference_model_path,
                batch_key=batch_key,
                cell_type_key=cell_type_key,
                unlabeled_category=unlabeled_category,
                surgery_epochs=surgery_epochs,
                surgery_lr_decay=surgery_lr_decay,
                use_gpu=use_gpu,
            )
        elif backend == "scpoli":
            adata = _run_scpoli_surgery(
                adata=adata,
                reference_model_path=reference_model_path,
                batch_key=batch_key,
                cell_type_key=cell_type_key,
                unlabeled_category=unlabeled_category,
                surgery_epochs=surgery_epochs,
                eta=scpoli_eta,
                pretraining_ratio=scpoli_pretraining_ratio,
            )
        else:
            raise ValueError(f"Unknown backend '{backend}'. Choose 'scanvi' or 'scpoli'.")
    finally:
        # Always restore .X even if surgery fails
        if X_orig is not None:
            adata.X = X_orig

    return adata


# ---------------------------------------------------------------------------
# Backend-specific surgery helpers (private)
# ---------------------------------------------------------------------------


def _run_scanvi_surgery(
    adata: sc.AnnData,
    reference_model_path: str,
    batch_key: str,
    cell_type_key: str,
    unlabeled_category: str,
    surgery_epochs: int,
    surgery_lr_decay: float,
    use_gpu: bool,
) -> sc.AnnData:
    """Internal: perform scANVI model surgery and label transfer."""

    # scANVI requires a cell_type_key column; fill with unlabeled_category
    # if absent or if we want fully unsupervised surgery
    if cell_type_key not in adata.obs.columns:
        logger.info(
            f"'{cell_type_key}' not in obs — creating column filled with "
            f"'{unlabeled_category}' for scANVI surgery"
        )
        adata.obs[cell_type_key] = unlabeled_category
    else:
        # Preserve original labels; mark all as unlabeled for surgery
        adata.obs[f"_orig_{cell_type_key}"] = adata.obs[cell_type_key].copy()
        adata.obs[cell_type_key] = unlabeled_category

    logger.info("Loading scANVI reference model and performing surgery...")
    model = sca.models.SCANVI.load_query_data(
        adata,
        reference_model_path,
        freeze_dropout=True,
        use_gpu=use_gpu,
    )
    # All query cells are unlabeled — surgery is fully unsupervised
    model._unlabeled_indices = np.arange(adata.n_obs)
    model._labeled_indices = []

    logger.info(
        f"Fine-tuning scANVI on query data for {surgery_epochs} epochs "
        f"(weight_decay={surgery_lr_decay})..."
    )
    model.train(
        max_epochs=surgery_epochs,
        plan_kwargs={"weight_decay": surgery_lr_decay},
        check_val_every_n_epoch=10,
        use_gpu=use_gpu,
    )

    # --- Label transfer via built-in softmax classifier ---
    logger.info("Transferring labels via scANVI classifier...")
    predictions = np.array(model.predict())  # argmax labels
    soft_probs = model.predict_proba()  # (n_cells, n_types) softmax

    confidences = soft_probs.max(axis=1)  # max softmax = confidence

    adata.obs["scarches_predicted_labels"] = predictions
    adata.obs["scarches_conf_score"] = confidences

    # Store latent representation
    latent = model.get_latent_representation()
    adata.obsm["X_scarches_latent"] = latent

    n_types = len(np.unique(predictions))
    logger.info(
        f"scANVI label transfer complete: {n_types} cell types identified. "
        f"Mean confidence: {confidences.mean():.3f}"
    )
    return adata


def _run_scpoli_surgery(
    adata: sc.AnnData,
    reference_model_path: str,
    batch_key: str,
    cell_type_key: str,
    unlabeled_category: str,
    surgery_epochs: int,
    eta: float,
    pretraining_ratio: float,
) -> sc.AnnData:
    """Internal: perform scPoli model surgery and prototype-based label transfer."""
    from scarches.models.scpoli import scPoli

    # scPoli needs a cell_type_key column; fill with unlabeled_category
    if cell_type_key not in adata.obs.columns:
        logger.info(
            f"'{cell_type_key}' not in obs — creating column filled with "
            f"'{unlabeled_category}' for scPoli surgery"
        )
        adata.obs[cell_type_key] = unlabeled_category

    logger.info("Loading scPoli reference model and performing surgery...")
    scpoli_query = scPoli.load_query_data(
        adata=adata,
        reference_model=reference_model_path,
        labeled_indices=[],  # fully unsupervised surgery
    )

    pretraining_epochs = int(surgery_epochs * pretraining_ratio)
    logger.info(
        f"Fine-tuning scPoli on query data for {surgery_epochs} epochs "
        f"(pretraining={pretraining_epochs}, eta={eta})..."
    )
    scpoli_query.train(
        n_epochs=surgery_epochs,
        pretraining_epochs=pretraining_epochs,
        eta=eta,
    )

    # --- Label transfer via prototype classifier ---
    logger.info("Transferring labels via scPoli prototype classifier...")
    results_dict = scpoli_query.classify(adata, scale_uncertainties=True)

    predictions = np.array(results_dict[cell_type_key]["preds"])
    uncertainties = np.array(results_dict[cell_type_key]["uncert"])

    # Convert uncertainty → confidence: certain = high confidence
    # uncertainty=0 → conf=1.0 (cell sits on prototype)
    # uncertainty=1 → conf=0.0 (maximally far from any prototype)
    confidences = 1.0 - uncertainties

    adata.obs["scarches_predicted_labels"] = predictions
    adata.obs["scarches_conf_score"] = confidences
    adata.obs["scarches_uncertainty"] = uncertainties

    # Store latent representation
    scpoli_query.model.eval()
    latent = scpoli_query.get_latent(adata, mean=True)
    adata.obsm["X_scarches_latent"] = latent

    n_types = len(np.unique(predictions))
    logger.info(
        f"scPoli label transfer complete: {n_types} cell types identified. "
        f"Mean confidence: {confidences.mean():.3f}"
    )
    return adata


# ---------------------------------------------------------------------------
# Prediction extraction (mirrors get_celltypist_predictions)
# ---------------------------------------------------------------------------


def get_scarches_predictions(
    adata: sc.AnnData,
    confidence_threshold: float = 0.7,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Extract scArches predictions and flag low-confidence cells.

    Mirrors ``get_celltypist_predictions`` so both can be used
    interchangeably in the consensus pipeline.

    Parameters
    ----------
    adata : AnnData
        Data annotated by ``run_scarches``.
    confidence_threshold : float
        Cells with ``scarches_conf_score < threshold`` are flagged as
        needing refinement (default 0.7).

        Note: scArches confidence scores are typically lower than CellTypist
        scores because they reflect distance in latent space (scPoli) or
        softmax entropy over many classes (scANVI).  A threshold of 0.7 is
        a reasonable starting point; inspect the distribution with
        ``diagnose_scarches`` first.

    Returns
    -------
    predictions : np.ndarray
        Per-cell predicted cell type labels.
    confidences : np.ndarray
        Per-cell confidence scores in [0, 1].
    needs_refinement : np.ndarray
        Boolean mask; True where confidence < threshold.

    Raises
    ------
    ValueError
        If no scArches predictions are found in ``adata.obs``.

    Examples
    --------
    >>> preds, confs, needs_refine = get_scarches_predictions(adata)
    >>> print(f"{needs_refine.sum()} cells need refinement")
    """
    if "scarches_predicted_labels" not in adata.obs.columns:
        raise ValueError("No scArches predictions found in adata.obs. " "Run run_scarches() first.")

    predictions = adata.obs["scarches_predicted_labels"].values
    confidences = adata.obs["scarches_conf_score"].values
    needs_refinement = confidences < confidence_threshold

    logger.info(
        f"scArches: {(~needs_refinement).sum()} high-confidence "
        f"(>= {confidence_threshold}), "
        f"{needs_refinement.sum()} need refinement"
    )
    return predictions, confidences, needs_refinement


# ---------------------------------------------------------------------------
# Consensus combination (mirrors combine_celltypist_with_consensus)
# ---------------------------------------------------------------------------


def combine_scarches_with_consensus(
    scarches_predictions: np.ndarray,
    scarches_confidences: np.ndarray,
    needs_refinement: np.ndarray,
    consensus_predictions: np.ndarray,
    consensus_confidences: np.ndarray,
    consensus_threshold: float = 0.5,
    unknown_label: str = "Unknown",
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Combine scArches predictions with consensus refinement.

    Decision logic (identical structure to ``combine_celltypist_with_consensus``):

    - scArches conf >= threshold  →  keep scArches label
    - scArches conf < threshold AND consensus conf >= threshold  →  use consensus
    - Both low confidence  →  mark as ``unknown_label``

    Parameters
    ----------
    scarches_predictions : np.ndarray
        scArches cell type predictions.
    scarches_confidences : np.ndarray
        scArches confidence scores [0, 1].
    needs_refinement : np.ndarray
        Boolean mask from ``get_scarches_predictions``.
    consensus_predictions : np.ndarray
        Consensus cell type predictions.
    consensus_confidences : np.ndarray
        Consensus confidence scores [0, 1].
    consensus_threshold : float
        Minimum confidence to accept a consensus prediction (default 0.5).
    unknown_label : str
        Label assigned when both methods are low-confidence (default ``"Unknown"``).

    Returns
    -------
    refined_predictions : np.ndarray
        Final cell type labels.
    refined_confidences : np.ndarray
        Final confidence scores.
    source : np.ndarray
        Per-cell source string: ``"scarches"``, ``"consensus"``, or ``"unknown"``.

    Examples
    --------
    >>> refined, conf, source = combine_scarches_with_consensus(
    ...     sc_preds, sc_conf, needs_refine,
    ...     consensus_preds, consensus_conf
    ... )
    """
    # needs_refinement is a boolean mask: True = low-confidence primary cell.
    # Convert to a threshold-based call for the shared helper by deriving the
    # effective threshold from the mask itself.  We pass the raw confidences
    # and a threshold of +inf so that cells flagged as needing refinement
    # (needs_refinement=True) are always treated as below-threshold.
    # A cleaner approach: invert the mask to get "high-confidence" cells and
    # use np.where directly via the shared helper with a sentinel threshold.
    #
    # Implementation: set primary_threshold = 0 and pre-zero the confidences
    # of cells that need refinement so they fall below the threshold.
    # Simpler: delegate directly using the boolean mask as a confidence proxy.
    primary_conf_proxy = np.where(needs_refinement, 0.0, 1.0)
    return combine_primary_with_consensus(
        primary_predictions=scarches_predictions,
        primary_confidences=primary_conf_proxy,
        primary_threshold=0.5,  # proxy: 1.0 = keep, 0.0 = refine
        consensus_predictions=consensus_predictions,
        consensus_confidences=consensus_confidences,
        consensus_threshold=consensus_threshold,
        unknown_label=unknown_label,
        source_label="scarches",
    )


# ---------------------------------------------------------------------------
# Diagnostics (mirrors diagnose_celltypist_model)
# ---------------------------------------------------------------------------


def diagnose_scarches(
    adata: sc.AnnData,
    reference_model_path: str,
    batch_key: str,
    output_folder: str,
    backend: Literal["scanvi", "scpoli"] = "scanvi",
) -> None:
    """
    Pre-flight checks before running scArches surgery.

    Verifies:
    1. Gene overlap between query ``var_names`` and the reference model's
       feature set (panel coverage — the KEY metric).
    2. Presence of ``batch_key`` in ``adata.obs``.
    3. Number of reference cell types.

    Unlike CellTypist (which zero-imputes missing genes), scArches requires
    the query gene set to be a **subset** of the reference gene set.  Missing
    genes are zero-padded internally, but a low panel coverage (<80%) will
    degrade label transfer quality significantly.

    Parameters
    ----------
    adata : AnnData
        Query dataset.
    reference_model_path : str
        Path to the saved reference model directory.
    batch_key : str
        ``obs`` column for batch identifiers.
    output_folder : str
        Directory to save the diagnostic text report.
    backend : {"scanvi", "scpoli"}
        Which backend model to inspect (default ``"scanvi"``).

    Returns
    -------
    None
        Prints a diagnostic report and saves it to ``output_folder``.

    Examples
    --------
    >>> diagnose_scarches(query_adata, "ref_model/", "sample_id", "diagnostics/")
    """
    _require_scarches()
    os.makedirs(output_folder, exist_ok=True)

    sep = "=" * 60
    lines: list[str] = []

    def _log(msg: str = "") -> None:
        print(msg)
        lines.append(msg)

    _log(sep)
    _log(f"scArches diagnostic  [{backend.upper()} backend]")
    _log(f"Reference model path : {reference_model_path}")
    _log(sep)

    # --- 1. batch_key check -------------------------------------------------
    if batch_key in adata.obs.columns:
        n_batches = adata.obs[batch_key].nunique()
        _log(f"  batch_key '{batch_key}' : OK  ({n_batches} unique values)")
    else:
        _log(f"  !! batch_key '{batch_key}' NOT FOUND in adata.obs")
        _log(f"     Available columns: {list(adata.obs.columns)}")

    # --- 2. Gene overlap check ----------------------------------------------
    query_genes = set(adata.var_names)
    ref_genes: set[str] = set()
    n_cell_types = 0

    try:
        if backend == "scanvi":
            model = sca.models.SCANVI.load(reference_model_path)
            # scVI/scANVI stores the training var_names in the registry
            ref_genes = set(model.adata.var_names)
            n_cell_types = len(model.cell_type_mapping)
        elif backend == "scpoli":
            from scarches.models.scpoli import scPoli

            model = scPoli.load_query_data(
                adata=adata,
                reference_model=reference_model_path,
                labeled_indices=[],
            )
            ref_genes = set(model.adata.var_names)
            # scPoli stores cell types in the label encoder
            n_cell_types = len(model.cell_type_encoder)
    except Exception as exc:
        _log(f"  !! Could not load reference model to inspect genes: {exc}")
        _log("     Skipping gene overlap check.")
        ref_genes = set()

    if ref_genes:
        stats = compute_feature_overlap(ref_genes, query_genes)
        panel_coverage = stats["panel_coverage"]
        ref_coverage = stats["model_coverage"]
        query_only = query_genes - ref_genes
        ref_only = ref_genes - query_genes

        _log()
        _log(f"  Query genes          : {stats['n_panel']}")
        _log(f"  Reference genes      : {stats['n_model']}")
        _log(f"  Overlap (genes)      : {stats['n_overlap']}")
        _log(f"  Panel coverage       : {panel_coverage:.1f}%  [KEY metric]")
        _log(f"  Reference coverage   : {ref_coverage:.1f}%")
        _log(f"  Query-only genes     : {len(query_only)}  (will be ignored by model)")
        _log(f"  Reference-only genes : {len(ref_only)}  (zero-padded in query)")
        _log()

        if panel_coverage >= 80:
            _log("  ✓ Panel coverage >= 80% — gene overlap is sufficient.")
        elif panel_coverage >= 50:
            _log(f"  ~ Panel coverage {panel_coverage:.1f}% — moderate overlap.")
            _log("    Label transfer may be degraded. Check gene naming conventions.")
        else:
            _log(f"  !! Panel coverage {panel_coverage:.1f}% — LOW overlap.")
            _log("    Possible causes:")
            _log("      - Gene symbol vs Ensembl ID mismatch")
            _log("      - Reference trained on different organism")
            _log("      - Targeted panel vs whole-transcriptome reference")
            _log("    Tip: rename adata.var_names to match the reference before surgery.")

    # --- 3. Cell type count -------------------------------------------------
    if n_cell_types > 0:
        _log(f"  Reference cell types : {n_cell_types}")
        if n_cell_types <= 3:
            _log(f"  !! Only {n_cell_types} cell types — consider a richer reference atlas.")
    _log(sep)

    # Save report
    report_path = Path(output_folder) / "scarches_diagnostic.txt"
    with open(report_path, "w") as f:
        f.write("\n".join(lines))
    print(f"  Report saved -> {report_path}")


# ---------------------------------------------------------------------------
# High-level entry point (mirrors cell_typing_celltypist)
# ---------------------------------------------------------------------------


def cell_typing_scarches(
    merged_adata: sc.AnnData,
    reference_model_path: str,
    batch_key: str,
    output_folder: str,
    cell_type_key: str = "cell_type",
    backend: Literal["scanvi", "scpoli"] = "scanvi",
    confidence_threshold: float = 0.7,
    unlabeled_category: str = "Unknown",
    surgery_epochs: int = 100,
    surgery_lr_decay: float = 0.0,
    scpoli_eta: float = 10.0,
    use_gpu: bool = True,
    layer: str | None = None,
) -> sc.AnnData:
    """
    Run scArches annotation on ``merged_adata`` — high-level entry point.

    Mirrors ``cell_typing_celltypist`` in structure and output columns so
    both functions can be used interchangeably in the same pipeline.

    Workflow
    --------
    1. Pre-flight diagnostics (gene overlap, batch_key check).
    2. Model surgery: extend reference model with query batch embeddings.
    3. Fine-tune on query data.
    4. Label transfer in latent space.
    5. Write predictions to ``adata.obs``.
    6. Generate diagnostic plots (UMAP, confidence distribution, composition).

    Key difference from CellTypist
    --------------------------------
    CellTypist classifies cells directly in gene-expression space using a
    logistic regression model trained on the reference.  scArches first
    *integrates* the query into the reference latent space (correcting batch
    effects), then classifies in that shared latent space.  This makes
    scArches more robust to batch effects but requires a compatible reference
    model and raw counts (scANVI) or normalised counts (scPoli).

    Adds to ``merged_adata.obs``
    ----------------------------
    scarches_predicted_labels : per-cell predicted cell type
    scarches_conf_score       : confidence score [0, 1]
    scarches_uncertainty      : raw uncertainty (scPoli only)

    Adds to ``merged_adata.obsm``
    -----------------------------
    X_scarches_latent : low-dimensional latent representation

    Parameters
    ----------
    merged_adata : AnnData
        Output of batch correction / preprocessing.
    reference_model_path : str
        Path to the saved reference model directory.
    batch_key : str
        ``obs`` column for batch / sample identifiers.
    output_folder : str
        Directory for diagnostic plots and reports.
    cell_type_key : str
        ``obs`` column name for cell type labels (default ``"cell_type"``).
    backend : {"scanvi", "scpoli"}
        scArches model backend (default ``"scanvi"``).
    confidence_threshold : float
        Cells below this confidence are flagged as low-confidence
        (default 0.7; lower than CellTypist's 0.9 because scArches scores
        are calibrated differently).
    unlabeled_category : str
        Placeholder label for query cells during surgery (default ``"Unknown"``).
    surgery_epochs : int
        Fine-tuning epochs on the query (default 100).
    surgery_lr_decay : float
        Weight decay for scANVI surgery (default 0.0).
    scpoli_eta : float
        Prototype loss weight for scPoli surgery (default 10.0).
    use_gpu : bool
        Use GPU if available (default True).
    layer : str or None
        Layer containing raw counts for scANVI (e.g. ``"counts"``).
        Set to None if ``adata.X`` already contains the correct data.

    Returns
    -------
    merged_adata : AnnData
        Annotated query data.

    Examples
    --------
    >>> merged_adata = cell_typing_scarches(
    ...     merged_adata,
    ...     reference_model_path="ref_model/",
    ...     batch_key="sample_id",
    ...     output_folder="results/scarches/",
    ...     backend="scanvi",
    ... )
    """
    _require_scarches()

    import matplotlib.pyplot as plt

    os.makedirs(output_folder, exist_ok=True)

    # -- 1. Pre-flight diagnostics -------------------------------------------
    print(f"Running scArches diagnostics [{backend.upper()} backend]...")
    diagnose_scarches(
        merged_adata,
        reference_model_path=reference_model_path,
        batch_key=batch_key,
        output_folder=output_folder,
        backend=backend,
    )

    # -- 2. Surgery + label transfer -----------------------------------------
    print(
        f"Running scArches surgery and label transfer "
        f"({surgery_epochs} epochs, backend={backend})..."
    )
    merged_adata = run_scarches(
        adata=merged_adata,
        reference_model_path=reference_model_path,
        batch_key=batch_key,
        cell_type_key=cell_type_key,
        backend=backend,
        unlabeled_category=unlabeled_category,
        surgery_epochs=surgery_epochs,
        surgery_lr_decay=surgery_lr_decay,
        scpoli_eta=scpoli_eta,
        use_gpu=use_gpu,
        layer=layer,
        inplace=True,
    )

    # -- 3. Summary statistics -----------------------------------------------
    predictions = merged_adata.obs["scarches_predicted_labels"]
    confidences = merged_adata.obs["scarches_conf_score"]
    n_types = predictions.nunique()
    n_low_conf = (confidences < confidence_threshold).sum()

    print(f"  Cell types identified    : {n_types}")
    print(f"  Mean confidence score    : {confidences.mean():.3f}")
    print(f"  Low-confidence cells     : {n_low_conf} " f"(< {confidence_threshold})")

    # -- 4. Diagnostic plots -------------------------------------------------
    umap_key = _find_umap_key(merged_adata)

    if umap_key is not None:
        # Panel 1: predicted labels
        # Panel 2: confidence score
        # Panel 3: uncertainty (scPoli only) or latent UMAP
        has_uncertainty = "scarches_uncertainty" in merged_adata.obs.columns
        n_panels = 3 if has_uncertainty else 2
        fig, axs = plt.subplots(1, n_panels, figsize=(6 * n_panels, 6), gridspec_kw={"wspace": 0.4})

        sc.pl.embedding(
            merged_adata,
            basis=umap_key,
            color="scarches_predicted_labels",
            ax=axs[0],
            show=False,
            title=f"scArches predictions ({n_types} types)",
            legend_loc="on data",
            legend_fontsize=5,
            legend_fontoutline=1,
            frameon=False,
        )
        sc.pl.embedding(
            merged_adata,
            basis=umap_key,
            color="scarches_conf_score",
            ax=axs[1],
            show=False,
            color_map="viridis",
            vmin=0,
            vmax=1,
            title="Confidence score",
            frameon=False,
        )
        if has_uncertainty:
            sc.pl.embedding(
                merged_adata,
                basis=umap_key,
                color="scarches_uncertainty",
                ax=axs[2],
                show=False,
                color_map="magma",
                vmin=0,
                vmax=1,
                title="Uncertainty (scPoli)",
                frameon=False,
            )

        plt.savefig(Path(output_folder) / "scarches_umap.png", dpi=150, bbox_inches="tight")
        plt.close()
    else:
        print(
            "  No UMAP embedding found in obsm — skipping UMAP plots. "
            "Run sc.tl.umap() first if you want UMAP diagnostics."
        )

    # Confidence score distribution
    fig, ax = plt.subplots(figsize=(8, 4))
    confidences.hist(bins=50, ax=ax, color="steelblue", edgecolor="white")
    ax.axvline(
        confidence_threshold,
        color="red",
        linestyle="--",
        label=f"threshold = {confidence_threshold}",
    )
    ax.set_xlabel("Confidence score")
    ax.set_ylabel("Cell count")
    ax.set_title(f"scArches confidence score distribution [{backend}]")
    ax.legend()
    plt.tight_layout()
    plt.savefig(Path(output_folder) / "scarches_conf_score_dist.png", dpi=150)
    plt.close()

    # Cell type composition bar chart
    ct_counts = predictions.value_counts().sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(8, max(4, len(ct_counts) * 0.4)))
    ct_counts.plot(kind="barh", ax=ax, color="steelblue", edgecolor="white")
    ax.set_xlabel("Cell count")
    ax.set_title(f"Cell type composition (scArches {backend})")
    plt.tight_layout()
    plt.savefig(Path(output_folder) / "scarches_composition.png", dpi=150)
    plt.close()

    return merged_adata


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def _require_scarches() -> None:
    """Raise ImportError if scarches is not installed."""
    if not HAS_SCARCHES:
        raise ImportError(
            "scarches is required for this module. " "Install with: pip install scarches"
        )


def _find_umap_key(adata: sc.AnnData) -> str | None:
    """Return the first UMAP key found in obsm, preferring corrected variants."""
    for key in ["umap_corrected", "X_umap_corrected", "X_umap"]:
        if key in adata.obsm:
            return key
    # Fallback: any key containing 'umap'
    for key in adata.obsm:
        if "umap" in key.lower():
            return key
    return None
