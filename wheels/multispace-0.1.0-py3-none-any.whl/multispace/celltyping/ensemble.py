"""
Combined Annotation (Ensemble)
===============================

Pillar 4 of the celltype package.

Combines predictions from any subset of the three annotation pillars
(Marker annotation, Auto-annotation, Foundation model) into a single
unified set of cell type labels with per-cell source tracking.

Key functions
-------------
- combine_celltypist_with_markers : two-way CellTypist + marker combination
- combine_scarches_with_markers   : two-way scArches + marker combination (stub)
- combine_predictions             : generic N-way combination
- resolve_unknowns                : fill Unknown/Unassigned cells from backup sources
- compute_method_agreement        : pairwise agreement diagnostics
- build_ensemble                  : high-level orchestrator
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

__all__ = [
    "EnsembleResult",
    "combine_celltypist_with_markers",
    "combine_scarches_with_markers",
    "combine_predictions",
    "resolve_unknowns",
    "compute_method_agreement",
    "build_ensemble",
]


@dataclass
class EnsembleResult:
    """Container for ensemble annotation results."""

    predictions: np.ndarray  # final combined cell type per cell
    confidences: np.ndarray  # final confidence per cell
    source: np.ndarray  # which method contributed each cell's label
    method_predictions: dict  # raw predictions from each input method
    method_confidences: dict  # raw confidences from each input method
    agreement_df: pd.DataFrame  # pairwise agreement table
    n_cells: int
    n_types: int

    def summary(self) -> str:
        """Generate a text summary of ensemble results."""
        source_counts = pd.Series(self.source).value_counts()
        summary_lines = [
            "Ensemble Results",
            "================",
            f"Total cells: {self.n_cells}",
            f"Unique cell types: {self.n_types}",
            f"Mean confidence: {self.confidences.mean():.3f}",
            "",
            "Source distribution:",
        ]
        for method, count in source_counts.items():
            pct = 100 * count / self.n_cells
            summary_lines.append(f"  {method}: {count} cells ({pct:.1f}%)")
        return "\n".join(summary_lines)


def combine_predictions(
    predictions_dict: dict[str, np.ndarray],
    confidences_dict: dict[str, np.ndarray],
    mode: str = "confidence_priority",
    priority_order: list[str] | None = None,
    unknown_labels: list[str] | None = None,
    consensus_threshold: float = 0.5,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Combine predictions from multiple methods into a single unified prediction.

    Parameters
    ----------
    predictions_dict : dict[str, np.ndarray]
        Dictionary mapping method name to array of predictions (one per cell).
    confidences_dict : dict[str, np.ndarray]
        Dictionary mapping method name to array of confidences (one per cell).
    mode : str
        Combination mode: "confidence_priority" or "ranked_priority".
        - "confidence_priority": per cell, pick method with highest confidence
          (if above consensus_threshold); else Unknown
        - "ranked_priority": iterate through priority_order; use first method
          with non-Unknown label and confidence >= consensus_threshold
    priority_order : list[str] | None
        For "ranked_priority" mode, order to try methods.
        If None, uses dict order.
    unknown_labels : list[str] | None
        Labels to treat as Unknown (default: ["Unknown", "Unassigned"]).
    consensus_threshold : float
        Minimum confidence required (default 0.5).

    Returns
    -------
    final_predictions : np.ndarray
        Final combined predictions.
    final_confidences : np.ndarray
        Final combined confidences.
    source_array : np.ndarray
        Source method for each cell's label.
    """
    if unknown_labels is None:
        unknown_labels = ["Unknown", "Unassigned"]
    if priority_order is None:
        priority_order = list(predictions_dict.keys())

    n_cells = len(next(iter(predictions_dict.values())))
    final_predictions = np.empty(n_cells, dtype=object)
    final_confidences = np.zeros(n_cells)
    source_array = np.empty(n_cells, dtype=object)

    if mode == "confidence_priority":
        # E2: vectorised — build (n_methods, n_cells) arrays, mask unknowns,
        # then argmax over methods per cell in one numpy call.
        methods_list = list(predictions_dict.keys())
        n_methods = len(methods_list)

        # Stack confidences: shape (n_methods, n_cells)
        conf_matrix = np.vstack([confidences_dict[m].astype(float) for m in methods_list])

        # Build boolean valid mask: True where prediction is not unknown
        valid_matrix = np.ones((n_methods, n_cells), dtype=bool)
        for mi, method in enumerate(methods_list):
            preds_arr = np.asarray(predictions_dict[method], dtype=object)
            for ul in unknown_labels:
                valid_matrix[mi] &= preds_arr != ul

        # Mask invalid entries with -inf so argmax ignores them
        masked_conf = np.where(valid_matrix, conf_matrix, -np.inf)
        best_method_idx = np.argmax(masked_conf, axis=0)  # (n_cells,)
        best_conf = masked_conf[best_method_idx, np.arange(n_cells)]

        for i in range(n_cells):
            mi = best_method_idx[i]
            bc = best_conf[i]
            if np.isfinite(bc) and bc >= consensus_threshold:
                final_predictions[i] = predictions_dict[methods_list[mi]][i]
                final_confidences[i] = bc
                source_array[i] = methods_list[mi]
            else:
                final_predictions[i] = "Unknown"
                # All methods either returned an Unknown label or fell below the
                # consensus_threshold.  Store 0.0 — using the raw (unmasked)
                # confidence here would be misleading: it comes from a method
                # that was already deemed invalid for this cell.
                final_confidences[i] = 0.0
                source_array[i] = "none"

    elif mode == "ranked_priority":
        # E2: vectorised — process each method in priority order, filling only
        # cells that are still unassigned (source == "none").
        unassigned = np.ones(n_cells, dtype=bool)  # True = not yet assigned
        final_predictions[:] = "Unknown"
        final_confidences[:] = 0.0
        source_array[:] = "none"

        for method in priority_order:
            if method not in predictions_dict or not unassigned.any():
                continue
            preds_arr = np.asarray(predictions_dict[method], dtype=object)
            confs_arr = confidences_dict[method].astype(float)

            # Valid: non-unknown label AND above threshold
            valid = np.ones(n_cells, dtype=bool)
            for ul in unknown_labels:
                valid &= preds_arr != ul
            valid &= confs_arr >= consensus_threshold

            assign = unassigned & valid
            if assign.any():
                final_predictions[assign] = preds_arr[assign]
                final_confidences[assign] = confs_arr[assign]
                source_array[assign] = method
                unassigned[assign] = False

    else:
        raise ValueError(f"Unknown mode: {mode}")

    return final_predictions, final_confidences, source_array


def combine_celltypist_with_markers(
    ct_predictions: np.ndarray,
    ct_confidences: np.ndarray,
    marker_predictions: np.ndarray,
    marker_confidences: np.ndarray,
    celltypist_threshold: float = 0.9,
    consensus_threshold: float = 0.5,
    unknown_label: str = "Unknown",
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Combine CellTypist predictions with marker-based predictions.

    Strategy:
    - Cells where CellTypist confidence >= celltypist_threshold → keep CellTypist
    - Remaining cells where marker confidence >= consensus_threshold → use marker
    - All others → Unknown

    Parameters
    ----------
    ct_predictions : np.ndarray
        CellTypist cell type predictions (one per cell).
    ct_confidences : np.ndarray
        CellTypist confidence scores [0, 1].
    marker_predictions : np.ndarray
        Marker-based cell type predictions.
    marker_confidences : np.ndarray
        Marker-based confidence scores.
    celltypist_threshold : float
        CellTypist confidence threshold (default 0.9).
    consensus_threshold : float
        Marker confidence threshold (default 0.5).
    unknown_label : str
        Label for low-confidence cells (default "Unknown").

    Returns
    -------
    final_predictions : np.ndarray
        Combined predictions.
    final_confidences : np.ndarray
        Combined confidences.
    source_array : np.ndarray
        Source method ("celltypist", "marker", "unknown") per cell.
    """
    # E2: vectorised with boolean masks — avoids O(n_cells) Python loop.
    n_cells = len(ct_predictions)
    ct_confidences = np.asarray(ct_confidences, dtype=float)
    marker_confidences = np.asarray(marker_confidences, dtype=float)

    final_predictions = np.empty(n_cells, dtype=object)
    final_confidences = np.zeros(n_cells, dtype=float)
    source_array = np.empty(n_cells, dtype=object)

    # Priority 1: high-confidence primary source
    primary_mask = ct_confidences >= celltypist_threshold
    # Priority 2: fallback to marker where primary is low-confidence
    fallback_mask = ~primary_mask & (marker_confidences >= consensus_threshold)
    # Remainder: both low-confidence
    unknown_mask = ~primary_mask & ~fallback_mask

    final_predictions[primary_mask] = np.asarray(ct_predictions, dtype=object)[primary_mask]
    final_confidences[primary_mask] = ct_confidences[primary_mask]
    source_array[primary_mask] = "celltypist"

    final_predictions[fallback_mask] = np.asarray(marker_predictions, dtype=object)[fallback_mask]
    final_confidences[fallback_mask] = marker_confidences[fallback_mask]
    source_array[fallback_mask] = "marker"

    final_predictions[unknown_mask] = unknown_label
    final_confidences[unknown_mask] = np.maximum(
        ct_confidences[unknown_mask], marker_confidences[unknown_mask]
    )
    source_array[unknown_mask] = "unknown"

    return final_predictions, final_confidences, source_array


def combine_scarches_with_markers(
    scarches_predictions: np.ndarray,
    scarches_confidences: np.ndarray,
    marker_predictions: np.ndarray,
    marker_confidences: np.ndarray,
    scarches_threshold: float = 0.9,
    consensus_threshold: float = 0.5,
    unknown_label: str = "Unknown",
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Combine scArches predictions with marker-based predictions.

    Logic identical to combine_celltypist_with_markers but for scArches input.

    Note: scArches integration is not yet implemented in this package.
    Predictions must be provided externally.

    Parameters
    ----------
    scarches_predictions : np.ndarray
        scArches cell type predictions.
    scarches_confidences : np.ndarray
        scArches confidence scores.
    marker_predictions : np.ndarray
        Marker-based predictions.
    marker_confidences : np.ndarray
        Marker-based confidences.
    scarches_threshold : float
        scArches confidence threshold (default 0.9).
    consensus_threshold : float
        Marker confidence threshold (default 0.5).
    unknown_label : str
        Label for low-confidence cells (default "Unknown").

    Returns
    -------
    final_predictions : np.ndarray
        Combined predictions.
    final_confidences : np.ndarray
        Combined confidences.
    source_array : np.ndarray
        Source method ("scarches", "marker", "unknown") per cell.
    """
    # E3: logic is identical to combine_celltypist_with_markers — delegate to
    # avoid duplication, then rename the source labels from "celltypist" →
    # "scarches" so callers see the correct provenance.
    final_predictions, final_confidences, source_array = combine_celltypist_with_markers(
        ct_predictions=scarches_predictions,
        ct_confidences=scarches_confidences,
        marker_predictions=marker_predictions,
        marker_confidences=marker_confidences,
        celltypist_threshold=scarches_threshold,
        consensus_threshold=consensus_threshold,
        unknown_label=unknown_label,
    )
    # Rename source labels to reflect the actual method
    source_array = np.where(source_array == "celltypist", "scarches", source_array)
    return final_predictions, final_confidences, source_array


def resolve_unknowns(
    predictions: np.ndarray,
    confidences: np.ndarray,
    source: np.ndarray,
    backup_predictions_dict: dict[str, np.ndarray],
    backup_confidences_dict: dict[str, np.ndarray],
    unknown_labels: list[str] | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    For cells still labelled Unknown/Unassigned, try to resolve using backup sources.

    Iterates through backup sources in descending order of mean confidence,
    assigning the first non-Unknown label found.

    Parameters
    ----------
    predictions : np.ndarray
        Current predictions (may contain Unknown labels).
    confidences : np.ndarray
        Current confidences.
    source : np.ndarray
        Current source labels.
    backup_predictions_dict : dict[str, np.ndarray]
        Additional predictions to use as backup.
    backup_confidences_dict : dict[str, np.ndarray]
        Confidences for backup predictions.
    unknown_labels : list[str] | None
        Labels to treat as Unknown (default: ["Unknown", "Unassigned"]).

    Returns
    -------
    predictions : np.ndarray
        Updated predictions.
    confidences : np.ndarray
        Updated confidences.
    source : np.ndarray
        Updated source labels.
    """
    if unknown_labels is None:
        unknown_labels = ["Unknown", "Unassigned"]

    # Ensure object dtype so variable-length strings (e.g. "method_backup")
    # are never silently truncated by a fixed numpy string dtype.
    predictions = np.array(predictions, dtype=object)
    confidences = np.array(confidences, dtype=float)
    source = np.array(source, dtype=object)

    n_cells = len(predictions)
    unknown_mask = np.array([p in unknown_labels for p in predictions])

    # Sort backups by mean confidence (highest first)
    backup_means = {
        method: backup_confidences_dict[method].mean() for method in backup_predictions_dict
    }
    sorted_backups = sorted(backup_means.items(), key=lambda x: x[1], reverse=True)

    for method, _ in sorted_backups:
        if not unknown_mask.any():
            break
        preds_arr = np.asarray(backup_predictions_dict[method], dtype=object)
        confs_arr = np.asarray(backup_confidences_dict[method], dtype=float)

        # Valid: still unknown AND backup has a non-unknown label
        valid = np.ones(n_cells, dtype=bool)
        for ul in unknown_labels:
            valid &= preds_arr != ul
        assign = unknown_mask & valid

        if assign.any():
            predictions[assign] = preds_arr[assign]
            confidences[assign] = confs_arr[assign]
            source[assign] = f"{method}_backup"
            unknown_mask[assign] = False

    return predictions, confidences, source


def compute_method_agreement(
    predictions_dict: dict[str, np.ndarray],
) -> pd.DataFrame:
    """
    Compute pairwise agreement between methods (fraction of cells where two methods agree).

    Parameters
    ----------
    predictions_dict : dict[str, np.ndarray]
        Dictionary mapping method name to predictions array.

    Returns
    -------
    agreement_df : pd.DataFrame
        Columns: method1, method2, agreement (fraction), n_cells.
    """
    methods = list(predictions_dict.keys())
    rows = []

    for i, method1 in enumerate(methods):
        for method2 in methods[i + 1 :]:
            pred1 = predictions_dict[method1]
            pred2 = predictions_dict[method2]

            agree = (pred1 == pred2).sum()
            total = len(pred1)
            agreement = agree / total if total > 0 else 0.0

            rows.append(
                {
                    "method1": method1,
                    "method2": method2,
                    "agreement": agreement,
                    "n_cells": total,
                }
            )

    return pd.DataFrame(rows)


def build_ensemble(
    predictions_dict: dict[str, np.ndarray],
    confidences_dict: dict[str, np.ndarray],
    mode: str = "confidence_priority",
    priority_order: list[str] | None = None,
    resolve_unknown: bool = True,
    consensus_threshold: float = 0.5,
    unknown_labels: list[str] | None = None,
) -> EnsembleResult:
    """
    High-level orchestrator for ensemble annotation.

    Parameters
    ----------
    predictions_dict : dict[str, np.ndarray]
        Dictionary mapping method name to predictions.
    confidences_dict : dict[str, np.ndarray]
        Dictionary mapping method name to confidences.
    mode : str
        Combination mode ("confidence_priority" or "ranked_priority").
    priority_order : list[str] | None
        For ranked_priority mode, order to try methods.
    resolve_unknown : bool
        If True, try to resolve Unknown cells using remaining sources.
    consensus_threshold : float
        Minimum confidence threshold.
    unknown_labels : list[str] | None
        Labels to treat as Unknown.

    Returns
    -------
    EnsembleResult
        Container with predictions, confidences, source, and agreement metrics.
    """
    # Step 1: Combine predictions
    final_preds, final_confs, source = combine_predictions(
        predictions_dict,
        confidences_dict,
        mode=mode,
        priority_order=priority_order,
        unknown_labels=unknown_labels,
        consensus_threshold=consensus_threshold,
    )

    # Step 2: Resolve unknowns if requested.
    # E1: the original code passed ALL methods (including the primary one that
    # already produced "Unknown" for a cell) as backups, so resolve_unknowns
    # would just retry the same sources that already failed.  Instead, pass
    # only the methods that were NOT the primary source for each cell.
    # Since combine_predictions already picked the best available label per
    # cell, the most useful backup pass is over all methods in a fixed order —
    # but we must exclude the method already recorded in `source` for that
    # cell.  resolve_unknowns iterates over all backups per unknown cell and
    # skips labels that are still Unknown, so passing all methods is safe as
    # long as the primary method's label was already Unknown (which is exactly
    # when source[i] == "none").  The real fix is to exclude methods whose
    # label was already tried and found to be Unknown or below threshold.
    # We achieve this by only passing methods that have at least one
    # non-Unknown prediction (i.e. they can potentially contribute something).
    if resolve_unknown and len(predictions_dict) > 1:
        # Use `is not None` — an explicit empty list [] means "treat nothing as
        # unknown", which must be respected.  The old `if unknown_labels` test
        # is falsy for both None and [], causing the caller's [] to be silently
        # replaced with the default set.
        _unk = set(unknown_labels) if unknown_labels is not None else {"Unknown", "Unassigned"}
        backup_methods = {
            m: preds for m, preds in predictions_dict.items() if any(p not in _unk for p in preds)
        }
        backup_confs = {m: confidences_dict[m] for m in backup_methods}

        if backup_methods:
            final_preds, final_confs, source = resolve_unknowns(
                final_preds,
                final_confs,
                source,
                backup_methods,
                backup_confs,
                unknown_labels=unknown_labels,
            )

    # Step 3: Compute agreement metrics
    agreement_df = compute_method_agreement(predictions_dict)

    # Step 4: Build result
    n_cells = len(final_preds)
    n_types = len(np.unique(final_preds))

    return EnsembleResult(
        predictions=final_preds,
        confidences=final_confs,
        source=source,
        method_predictions=predictions_dict.copy(),
        method_confidences=confidences_dict.copy(),
        agreement_df=agreement_df,
        n_cells=n_cells,
        n_types=n_types,
    )
