"""
Epithelial-Anchored Batch Correction
=====================================

Pillar 0b of the celltype package — an alternative to Harmony / plain scVI
for breast cancer TMA cohorts where epithelial cells are the most stable
biological anchor across batches.

Strategy
--------
1. Run a lightweight CellTypist pass to identify high-confidence epithelial
   cells across all batches.
2. Train an scVI model exclusively on the epithelial anchor population.
3. Transfer the learned correction to all remaining cells via scVI reference
   mapping (load_query_data / scArches-style).
4. Merge anchor + query latent representations into a single cohort-wide
   corrected embedding stored in ``adata.obsm["X_scVI_anchored"]``.

Why epithelial anchoring?
--------------------------
In a breast cancer TMA cohort with 100+ cores, Cancer_Epithelial cells are
ubiquitous and biologically similar across patients (same tissue of origin).
Training scVI on this "anchor" population first ensures the latent space is
calibrated against a biologically consistent reference, then immune/stromal
cells are mapped into that space via reference transfer.  This prevents
immune-rich cores (with few epithelial cells) from dominating the scVI
objective and distorting the embedding.

METABRIC-specific adaptations
-------------------------------
- batch_key         : "metabric_ID" (METABRIC TMA core identifier)
- CellTypist model  : wu_model_celltype_major.pkl (Wu et al. breast TME)
- EPITHELIAL_LABELS : Wu model class names (Cancer_Epithelial, Normal_Epithelial …)
- n_hvgs            : capped at n_vars — Xenium panels have only ~230 genes,
                      so HVG selection is skipped when n_hvgs ≥ n_vars
- neighbors_key     : "neighbours_corrected" — matches the key expected by
                      downstream steps (KNN smoothing, Leiden, annotation)
- model persistence : train_anchor_scvi() accepts load_dir to reload a saved
                      model instead of retraining (LOAD_PRECOMPUTED-like flag)
- dispersion        : "gene" by default (safer for small panels with many batches)

Requirements
-------------
scvi-tools >= 1.0, celltypist, scanpy, anndata, numpy, pandas

Functions
---------
- run_celltypist_pass               : Step 1 — lightweight CellTypist anchor pass
- build_anchor_adata                : Step 2 — prepare epithelial anchor AnnData
- train_anchor_scvi                 : Step 3 — train (or reload) scVI on anchor
- transfer_correction_to_query      : Step 4 — map all cells into corrected space
- build_corrected_embedding         : Step 5 — KNN graph + UMAP on anchored latent
- run_epithelial_anchored_correction: Master pipeline (calls steps 1–5)
- run_anchored_correction_from_merged: Thin wrapper called from step0_load_data()
- check_epithelial_consistency      : Post-hoc QC — anchor labels vs final labels
- plot_anchor_correction_summary    : Diagnostic UMAP coloured by anchor role
- summarise_anchor_quality          : Per-batch epithelial cell count summary

Integration with celltype_merged_full_workflow.py
--------------------------------------------------
Set ``BATCH_CORRECTION_METHOD = "epithelial_anchored"`` in the workflow CONFIG.
step0_load_data() will then call::

    from multispace.celltyping.epithelial_anchored_correction import (
        run_anchored_correction_from_merged,
        check_epithelial_consistency,
    )
    merged_adata = run_anchored_correction_from_merged(
        merged_adata,
        celltypist_model_path=MODEL_PATH,
        batch_key=BATCH_ID,
        save_model_dir=EPITHELIAL_ANCHORED_SAVE_DIR,
        load_model_dir=EPITHELIAL_ANCHORED_SAVE_DIR if LOAD_PRECOMPUTED else None,
        n_hvgs=N_TOP_GENES,
        n_latent=SCVI_N_LATENT,
        output_dir=OUTPUT_DIR,
    )
"""

from __future__ import annotations

import gc
import logging
import os
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp
import scvi

logger = logging.getLogger(__name__)

__all__ = [
    # Public API
    "run_epithelial_anchored_correction",
    "run_anchored_correction_from_merged",
    "check_epithelial_consistency",
    # Step-level functions (for advanced / custom pipelines)
    "run_celltypist_pass",
    "build_anchor_adata",
    "train_anchor_scvi",
    "transfer_correction_to_query",
    "build_corrected_embedding",
    # Diagnostic utilities
    "plot_anchor_correction_summary",
    "summarise_anchor_quality",
    # Constants exposed for downstream override
    "EPITHELIAL_LABELS",
    "MIN_EPITHELIAL_CELLS_PER_BATCH",
    "SCVI_N_LATENT",
    "SCVI_N_LAYERS",
    "SCVI_N_HIDDEN",
    "SCVI_MAX_EPOCHS_ANCHOR",
    "SCVI_MAX_EPOCHS_QUERY",
    "SCVI_EARLY_STOPPING",
    "SCVI_HVG_FLAVOR",
    "DEFAULT_MODEL_PATH",
    "DEFAULT_BATCH_KEY",
]


# ---------------------------------------------------------------------------
# Constants — METABRIC / Wu model specific
# ---------------------------------------------------------------------------

# Cell types considered "epithelial anchors" — covers all epithelial labels
# produced by wu_model_celltype_major.pkl (Wu et al. breast TME atlas).
# Both cancer and normal epithelium are used as anchors because they share
# the same tissue-of-origin biology and are present in every core.
EPITHELIAL_LABELS: tuple[str, ...] = (
    # Wu model (major) labels
    "Cancer_Epithelial",
    "Normal_Epithelial",
    # Generic fallbacks — covers other breast-specific CellTypist models
    "Luminal epithelial cell",
    "Basal epithelial cell",
    "Luminal progenitor",
    "Basal progenitor",
    "Epithelial cell",
    "Luminal",
    "Basal",
    "HER2+",
    "Cancer epithelial",
    "Epithelial",
)

# Minimum number of epithelial cells a batch must contribute to be included
# in anchor training.  Batches below this threshold are still corrected by
# reference transfer but do not influence the learned latent geometry.
# Raised to 50 for large gene panels (5 000 genes): with too few cells per
# batch the per-gene expression estimates become unreliable.  Analysis of the
# 121-core METABRIC cohort shows only 3 extra cores are excluded at threshold
# 50 vs 30 (all are very small cores with < 50 total cells), so anchor
# coverage is essentially unchanged.
MIN_EPITHELIAL_CELLS_PER_BATCH: int = 50

# scVI model hyperparameters — tuned for large breast cancer TMA cohorts
# with a 5 000-gene targeted panel (METABRIC Xenium v2).
#
# Scaling rationale vs the original 230-gene version:
#
#   n_latent  30   (was 20) — 5 000 genes carry substantially more biological
#                              signal; 30 latent dims accommodate the richer
#                              input while remaining conservative enough to
#                              avoid overfitting the anchor-only training set.
#
#   n_layers   3   (was 2)  — deeper encoder/decoder needed to compress a
#                              5 000-dim input into 30 latent dims.
#
#   n_hidden 256   (was 128)— standard recommendation for 1 000–10 000 gene
#                              panels; doubling hidden width prevents the first
#                              encoder layer from becoming an information
#                              bottleneck when processing 5 000 genes.
#
#   max_epochs_anchor 400   (was 200) — larger input + ~96 000 anchor cells
#                              need more gradient steps to converge.  Early
#                              stopping (patience=15) caps actual runtime.
#
#   max_epochs_query  200   (was 100) — query fine-tuning similarly benefits
#                              from more epochs when the anchor latent space
#                              is richer (30 dims, 5 000-gene encoder).
SCVI_N_LATENT: int = 30
SCVI_N_LAYERS: int = 3
SCVI_N_HIDDEN: int = 256
SCVI_MAX_EPOCHS_ANCHOR: int = 400
SCVI_MAX_EPOCHS_QUERY: int = 250
SCVI_EARLY_STOPPING: bool = True

# HVG selection flavor for scVI anchor preparation.
# "seurat"    — dispersion-based; robust for targeted panels and epithelial
#               subsets where many genes have near-zero variance.  Requires
#               log-normalised counts.
# "seurat_v3" — LOESS-based; preferred for full-transcriptomics data but
#               prone to "near singularities" failures on targeted panels
#               (e.g. METABRIC Xenium 5 000-gene).  Not recommended here.
SCVI_HVG_FLAVOR: str = "seurat"

# Default paths for METABRIC workflow
DEFAULT_MODEL_PATH = "data/wu_et_al/wu_model_celltype_major.pkl"
DEFAULT_BATCH_KEY = "metabric_ID"


# ---------------------------------------------------------------------------
# GPU / accelerator helpers
# ---------------------------------------------------------------------------


def _get_accelerator() -> tuple[str, int]:
    """
    Auto-detect the best available accelerator for scVI / PyTorch Lightning.

    Returns
    -------
    (accelerator, devices) tuple ready to be passed to ``model.train()``.

    Priority
    --------
    1. CUDA (NVIDIA / AMD ROCm)
    2. CPU  (fallback — see note below)

    MPS (Apple Silicon GPU) is deliberately EXCLUDED from auto-detection.
    PyTorch's MPS backend does not implement deterministic kernels for
    several ops scVI's VAE training relies on, so even with a fixed seed,
    training on MPS produces small run-to-run numerical differences.  This
    was traced (empirically, by diffing two full pipeline reruns on
    MB-GU-1173 and cohort-wide) to real downstream instability: 6-38% of
    cells near cell-type decision boundaries were relabeled between two
    otherwise-identical runs, because the biomarker / hierarchy / sctype
    annotators all score against a Leiden clustering built on this
    embedding, and cluster boundaries shift when the embedding shifts.
    CellTypist, which doesn't depend on the corrected embedding at all,
    was 100% reproducible in the same comparison — confirming the scVI/MPS
    step as the source. CPU has full deterministic-algorithm coverage in
    PyTorch (see ``_set_deterministic_mode`` below), so it's preferred here
    over MPS whenever no CUDA GPU is available, at the cost of slower
    training.
    """
    import torch

    if torch.cuda.is_available():
        logger.info("  Accelerator: CUDA (GPU)")
        return "cuda", 1
    if torch.backends.mps.is_available():
        logger.info(
            "  Accelerator: CPU (MPS available but skipped — MPS lacks "
            "deterministic-kernel coverage for scVI training; see "
            "_get_accelerator docstring)"
        )
    else:
        logger.info("  Accelerator: CPU")
    return "cpu", 1


def _set_deterministic_mode(seed: int = 42) -> None:
    """
    Force fully reproducible scVI / PyTorch training.

    A fixed seed alone (``scvi.settings.seed``) is NOT sufficient for
    bit-reproducible training — it fixes what random numbers get drawn, but
    not the exact floating-point outcome of the GPU/CPU kernels those draws
    feed into. ``torch.use_deterministic_algorithms(True)`` closes that gap
    by forcing PyTorch to use deterministic kernel implementations
    everywhere, and to raise ``RuntimeError`` for any op that has no
    deterministic implementation on the selected accelerator — which is
    exactly why MPS is excluded in ``_get_accelerator`` above: several ops
    used by scVI's encoder/decoder would fail loudly under this flag on
    MPS. On CPU, coverage is complete, so this combination
    (CPU accelerator + this function) gives genuinely repeatable training,
    not just "probably similar" training.

    Call once per process, before the first ``model.train()`` call
    (``run_epithelial_anchored_correction`` does this automatically).

    Parameters
    ----------
    seed : int
        Seed forwarded to ``scvi.settings.seed``, which seeds Python's
        ``random``, ``numpy``, and ``torch`` together (scvi-tools' documented
        mechanism for this) — should match ``config.yaml``'s
        ``data.random_seed`` so the rest of the pipeline (which already uses
        that value) stays consistent.
    """
    import torch

    # Needed if CUDA is ever used downstream on a different machine —
    # required by torch.use_deterministic_algorithms(True) for a handful of
    # CUDA linear-algebra kernels (cuBLAS). Harmless / unused on CPU or MPS.
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

    scvi.settings.seed = seed
    torch.use_deterministic_algorithms(True)

    logger.info(
        f"  Determinism: scvi.settings.seed={seed}, " f"torch.use_deterministic_algorithms(True)"
    )


# ---------------------------------------------------------------------------
# Step 1 — Lightweight CellTypist pass to identify epithelial anchors
# ---------------------------------------------------------------------------


def run_celltypist_pass(
    adata: ad.AnnData,
    model_path: str = DEFAULT_MODEL_PATH,
    batch_key: str = DEFAULT_BATCH_KEY,
    confidence_threshold: float = 0.5,
    majority_voting: bool = False,
) -> ad.AnnData:
    """
    Run CellTypist on the full cohort and flag high-confidence epithelial cells.

    This is a lightweight pass used purely for anchor selection — it does NOT
    replace the full CellTypist annotation in Step 2 of the main workflow.
    Results are stored in:
        adata.obs["celltypist_label_anchor"]          — consolidated label:
                                                         all epithelial cells → "Epithelial",
                                                         low-confidence → "Low confidence",
                                                         others → original CellTypist label
        adata.obs["celltypist_label_anchor_detailed"] — original per-cell CellTypist label
                                                         before consolidation (preserves
                                                         Cancer_Epithelial / Normal_Epithelial split)
        adata.obs["celltypist_conf_anchor"]           — max softmax probability
        adata.obs["is_epithelial"]                    — boolean anchor flag

    Parameters
    ----------
    adata
        Full cohort AnnData.  Raw counts must be in adata.layers["counts"]
        or adata.X.
    model_path
        Path to a CellTypist .pkl model file.
        Default: wu_model_celltype_major.pkl
    batch_key
        Column in adata.obs identifying TMA cores / batches.
        Default: "metabric_ID"
    confidence_threshold
        Cells with max softmax probability below this value are labelled
        "Low confidence" and excluded from anchor selection.
        0.5 is a permissive default — tighten to 0.7+ for cleaner anchors.
    majority_voting
        Whether to apply CellTypist majority voting.  False is faster and
        preferred here since we only need a coarse epithelial / non-epithelial
        split, not fine-grained subtypes.
    """
    try:
        import celltypist
        from celltypist import models as ct_models
    except ImportError as e:
        raise ImportError("celltypist is required: pip install celltypist") from e

    logger.info("─── Step 1: CellTypist anchor pass ───")

    # Work on a lightweight copy for normalisation (keep original layers intact)
    adata_ct = adata.copy()

    # Use raw counts if available
    if "counts" in adata_ct.layers:
        adata_ct.X = adata_ct.layers["counts"].copy()

    sc.pp.normalize_total(adata_ct, target_sum=1e4)
    sc.pp.log1p(adata_ct)

    model = ct_models.Model.load(model_path)

    predictions = celltypist.annotate(
        adata_ct,
        model=model,
        majority_voting=majority_voting,
    )

    # CellTypist returns a Predictions object where both attributes are DataFrames:
    #   predictions.predicted_labels  — DataFrame with a "predicted_labels" column
    #   predictions.majority_voting   — DataFrame with "majority_voting" and
    #                                   "over_clustering" columns
    # We must select the specific column (Series), otherwise .values is 2D and
    # pandas raises ValueError: 2 when assigning to obs.
    if majority_voting:
        labels = predictions.majority_voting["majority_voting"]
    else:
        labels = predictions.predicted_labels["predicted_labels"]

    # CellTypist returns a Categorical Series; convert to plain str so that
    # "Low confidence" can be assigned without first registering it as a category.
    adata.obs["celltypist_label_anchor"] = labels.values.astype(str)
    adata.obs["celltypist_conf_anchor"] = predictions.probability_matrix.max(axis=1).values

    # Mark low-confidence calls
    low_conf_mask = adata.obs["celltypist_conf_anchor"] < confidence_threshold
    adata.obs.loc[low_conf_mask, "celltypist_label_anchor"] = "Low confidence"

    # Flag epithelial anchor cells
    adata.obs["is_epithelial"] = adata.obs["celltypist_label_anchor"].isin(EPITHELIAL_LABELS)

    # Preserve the original per-cell CellTypist label for downstream diagnostics
    # (e.g. Cancer_Epithelial vs Normal_Epithelial breakdown within the anchor).
    adata.obs["celltypist_label_anchor_detailed"] = adata.obs["celltypist_label_anchor"].copy()

    # Collapse ALL epithelial subtypes (Cancer_Epithelial, Normal_Epithelial,
    # Luminal epithelial cell, etc.) to the single unified "Epithelial" label.
    # This matches the marker matrix which defines a single "Epithelial" class.
    adata.obs.loc[adata.obs["is_epithelial"], "celltypist_label_anchor"] = "Epithelial"

    n_epi = adata.obs["is_epithelial"].sum()
    n_total = adata.n_obs
    logger.info(
        f"  Epithelial anchors identified: {n_epi:,} / {n_total:,} "
        f"({100 * n_epi / n_total:.1f}%)"
    )

    # Per-batch summary
    batch_epi = adata.obs.groupby(batch_key)["is_epithelial"].sum()
    n_zero = (batch_epi == 0).sum()
    n_low = (batch_epi.between(1, MIN_EPITHELIAL_CELLS_PER_BATCH - 1)).sum()
    logger.info(
        f"  Batches with 0 epithelial cells: {n_zero} | "
        f"below threshold ({MIN_EPITHELIAL_CELLS_PER_BATCH}): {n_low}"
    )

    del adata_ct
    gc.collect()

    return adata


# ---------------------------------------------------------------------------
# Step 2 — Build the epithelial anchor AnnData
# ---------------------------------------------------------------------------


def build_anchor_adata(
    adata: ad.AnnData,
    batch_key: str = DEFAULT_BATCH_KEY,
    min_cells_per_batch: int = MIN_EPITHELIAL_CELLS_PER_BATCH,
    n_hvgs: int = 2000,
) -> tuple[ad.AnnData, list[str], np.ndarray]:
    """
    Subset to epithelial cells and prepare them for scVI training.

    METABRIC note on HVGs
    ─────────────────────
    Xenium panels contain ~230 genes.  If n_hvgs ≥ n_vars, HVG selection is
    skipped and all genes are used (adata.var["highly_variable"] = True).
    This avoids a scanpy error and is biologically correct — all genes in a
    targeted panel are pre-selected for relevance.

    Parameters
    ----------
    adata
        Full cohort AnnData after :func:`run_celltypist_pass`.
    batch_key
        Column in adata.obs identifying batches.
    min_cells_per_batch
        Minimum epithelial cell count per batch to include in anchor training.
    n_hvgs
        Number of highly variable genes for scVI.
        Automatically capped at n_vars — 1 for small Xenium panels.

    Returns
    -------
    (adata_anchor, excluded_batches, anchor_pos)
        adata_anchor     — prepared anchor AnnData
        excluded_batches — list of batch IDs below the min-cells threshold
        anchor_pos       — integer positions in the FULL adata of anchor cells
    """
    logger.info("─── Step 2: Building epithelial anchor ───")

    if "is_epithelial" not in adata.obs.columns:
        raise ValueError("Column 'is_epithelial' not found.  Run run_celltypist_pass() first.")

    # Record integer positions of ALL epithelial cells in the full adata BEFORE
    # any subsetting.  We use positional indexing (np.where on a boolean mask)
    # rather than obs_names.isin() because Xenium barcodes (e.g. "cell_1") are
    # NOT unique across the 121 cores — isin() would match every cell and
    # produce a shape-mismatch error when writing back to X_combined.
    epi_pos_in_full = np.where(adata.obs["is_epithelial"].values)[0]  # shape (n_epi,)

    adata_epi = adata[adata.obs["is_epithelial"]].copy()

    # Per-batch epithelial cell counts
    batch_counts = adata_epi.obs[batch_key].value_counts()
    included = batch_counts[batch_counts >= min_cells_per_batch].index.tolist()
    excluded = batch_counts[batch_counts < min_cells_per_batch].index.tolist()

    if excluded:
        logger.warning(
            f"  {len(excluded)} batch(es) excluded from anchor training "
            f"(< {min_cells_per_batch} epithelial cells): "
            + str(excluded[:5])
            + (" …" if len(excluded) > 5 else "")
        )

    adata_anchor = adata_epi[adata_epi.obs[batch_key].isin(included)].copy()

    # Compute integer positions of anchor cells in the FULL adata.
    # Strategy: epi_pos_in_full maps epithelial-subset positions → full-adata
    # positions.  We then select only those epithelial cells that belong to
    # included batches (same boolean mask used to build adata_anchor).
    included_epi_mask = adata_epi.obs[batch_key].isin(included).values  # (n_epi,) bool
    anchor_pos = epi_pos_in_full[included_epi_mask]  # integer positions in full adata

    logger.info(
        f"  Anchor: {adata_anchor.n_obs:,} epithelial cells "
        f"from {len(included)} / {len(batch_counts)} batches"
    )

    # Use raw counts for scVI
    if "counts" in adata_anchor.layers:
        adata_anchor.X = adata_anchor.layers["counts"].copy()
    else:
        logger.warning("  'counts' layer not found — assuming adata.X contains raw counts.")

    # ── HVG selection ────────────────────────────────────────────────────────
    # For Xenium (~230 genes) or when n_hvgs ≥ n_vars: skip selection entirely.
    if n_hvgs >= adata_anchor.n_vars:
        logger.info(
            f"  n_hvgs ({n_hvgs}) ≥ n_vars ({adata_anchor.n_vars}) — "
            f"using all {adata_anchor.n_vars} panel genes (no HVG filtering)."
        )
        adata_anchor.var["highly_variable"] = True
    else:
        # Use SCVI_HVG_FLAVOR (default "seurat", dispersion-based).
        # "seurat_v3" (LOESS-based) is unreliable for targeted panels and
        # epithelial-only subsets: genes with near-zero variance across most
        # batches cause "near singularities" errors in the LOESS fit.
        # "seurat" requires log-normalised counts, so we normalise a copy.
        min_cells = max(3, int(0.005 * adata_anchor.n_obs))  # ≥0.5% of cells
        sc.pp.filter_genes(adata_anchor, min_cells=min_cells)
        n_hvgs_eff = min(n_hvgs, adata_anchor.n_vars - 1)
        logger.info(
            f"  Genes after min-cells filter (min_cells={min_cells}): "
            f"{adata_anchor.n_vars} → selecting {n_hvgs_eff} HVGs "
            f"(flavor='{SCVI_HVG_FLAVOR}')"
        )

        if n_hvgs_eff >= adata_anchor.n_vars:
            logger.info("  n_hvgs_eff ≥ n_vars after filtering — using all remaining genes.")
            adata_anchor.var["highly_variable"] = True
        elif SCVI_HVG_FLAVOR == "seurat_v3":
            # seurat_v3 operates directly on raw counts
            sc.pp.highly_variable_genes(
                adata_anchor,
                n_top_genes=n_hvgs_eff,
                flavor="seurat_v3",
                batch_key=batch_key,
                subset=True,
            )
            logger.info(f"  HVGs selected (seurat_v3): {adata_anchor.n_vars}")
        else:
            # "seurat" (dispersion) — requires log-normalised counts;
            # compute on a lightweight copy so raw counts in adata_anchor are preserved.
            adata_anchor_norm = adata_anchor.copy()
            sc.pp.normalize_total(adata_anchor_norm, target_sum=1e4)
            sc.pp.log1p(adata_anchor_norm)
            sc.pp.highly_variable_genes(
                adata_anchor_norm,
                n_top_genes=n_hvgs_eff,
                flavor="seurat",
                batch_key=batch_key,
            )
            adata_anchor.var["highly_variable"] = adata_anchor_norm.var["highly_variable"]
            adata_anchor = adata_anchor[:, adata_anchor.var["highly_variable"]].copy()
            del adata_anchor_norm
            logger.info(f"  HVGs selected (seurat): {adata_anchor.n_vars}")

    return adata_anchor, excluded, anchor_pos


# ---------------------------------------------------------------------------
# Step 3 — Train scVI on the anchor population
# ---------------------------------------------------------------------------


def train_anchor_scvi(
    adata_anchor: ad.AnnData,
    batch_key: str = DEFAULT_BATCH_KEY,
    n_latent: int = SCVI_N_LATENT,
    n_layers: int = SCVI_N_LAYERS,
    n_hidden: int = SCVI_N_HIDDEN,
    max_epochs: int = SCVI_MAX_EPOCHS_ANCHOR,
    early_stopping: bool = SCVI_EARLY_STOPPING,
    save_dir: str | None = None,
    load_dir: str | None = None,
    accelerator: str | None = None,
    devices: int = 1,
) -> scvi.model.SCVI:
    """
    Train an scVI model on the epithelial anchor population, or reload
    a previously saved model (LOAD_PRECOMPUTED equivalent).

    Parameters
    ----------
    adata_anchor
        Prepared anchor AnnData from :func:`build_anchor_adata`.
    batch_key
        Column in adata.obs identifying batches.
    n_latent, n_layers, n_hidden
        scVI architecture hyperparameters.
        n_latent=30 is appropriate for 5 000-gene targeted panels.
    max_epochs
        Maximum training epochs.
    early_stopping
        Whether to use early stopping on validation ELBO.
    save_dir
        If provided, save the trained model to this directory.
    load_dir
        If provided, reload a previously saved model from this directory
        instead of training from scratch.  Useful with LOAD_PRECOMPUTED=True.
    accelerator
        Accelerator type ("cuda", "mps", "cpu").  None → auto-detect.
    devices
        Number of devices.

    Returns
    -------
    Trained (or reloaded) scVI model.
    """
    logger.info("─── Step 3: scVI anchor model ───")

    # Auto-detect GPU if caller did not specify an accelerator
    if accelerator is None:
        accelerator, devices = _get_accelerator()

    scvi.model.SCVI.setup_anndata(adata_anchor, batch_key=batch_key)

    if load_dir is not None and Path(load_dir).exists():
        logger.info(f"  Loading saved model from {load_dir}")
        model = scvi.model.SCVI.load(load_dir, adata=adata_anchor)
    else:
        model = scvi.model.SCVI(
            adata_anchor,
            n_latent=n_latent,
            n_layers=n_layers,
            n_hidden=n_hidden,
            gene_likelihood="nb",  # negative binomial — appropriate for Xenium counts
            dispersion="gene",  # "gene" is safer than "gene-batch" for small panels
            # (gene-batch adds batch×gene parameters which can
            # overfit when some batches have few anchor cells)
        )

        logger.info(f"  Model: {model}")

        model.train(
            max_epochs=max_epochs,
            early_stopping=early_stopping,
            early_stopping_patience=15,
            plan_kwargs={"lr": 1e-3},
            accelerator=accelerator,
            devices=devices,
        )

        if save_dir is not None:
            Path(save_dir).mkdir(parents=True, exist_ok=True)
            model.save(save_dir, overwrite=True)
            logger.info(f"  Model saved → {save_dir}")

    # Store anchor latent representation
    adata_anchor.obsm["X_scVI_anchor"] = model.get_latent_representation()
    logger.info(f"  Anchor latent shape: {adata_anchor.obsm['X_scVI_anchor'].shape}")

    return model


# ---------------------------------------------------------------------------
# Step 4 — Transfer correction to non-epithelial (query) cells
# ---------------------------------------------------------------------------


def transfer_correction_to_query(
    adata: ad.AnnData,
    adata_anchor: ad.AnnData,
    anchor_model: scvi.model.SCVI,
    anchor_pos: np.ndarray,
    batch_key: str = DEFAULT_BATCH_KEY,
    max_epochs: int = SCVI_MAX_EPOCHS_QUERY,
    accelerator: str | None = None,
    devices: int = 1,
) -> ad.AnnData:
    """
    Map all non-anchor cells into the epithelial-defined latent space using
    scVI reference mapping (scArches-style).

    The final corrected embedding ``X_scVI_anchored`` is written to
    ``adata.obsm`` for ALL cells (anchor + query merged).

    Parameters
    ----------
    adata
        Full cohort AnnData (all cell types).
    adata_anchor
        Epithelial anchor AnnData used for training (must share the gene set
        that was selected during :func:`build_anchor_adata`).
    anchor_model
        Trained scVI model from :func:`train_anchor_scvi`.
    anchor_pos
        Integer positions (in ``adata``) of the anchor cells, as returned by
        :func:`build_anchor_adata`.  Used for positional indexing into
        ``X_combined`` so that the correct rows are filled even when
        ``obs_names`` are non-unique across Xenium cores.
    batch_key
        Column in adata.obs identifying batches.
    max_epochs
        Maximum epochs for query mapping fine-tuning.
    accelerator
        Accelerator type ("cuda", "mps", "cpu").  None → auto-detect.
    devices
        Number of devices.
    """
    logger.info("─── Step 4: Transferring correction to query cells ───")

    if accelerator is None:
        accelerator, devices = _get_accelerator()

    anchor_genes = adata_anchor.var_names.tolist()
    non_epi_mask = ~adata.obs["is_epithelial"]

    logger.info(f"  Query cells (non-epithelial): {non_epi_mask.sum():,}")

    # ── 4a. Prepare query AnnData (subset to anchor gene set) ───────────────
    adata_query = adata[non_epi_mask, anchor_genes].copy()

    if "counts" in adata_query.layers:
        adata_query.X = adata_query.layers["counts"].copy()

    # ── 4b. scArches-style reference mapping ────────────────────────────────
    # prepare_query_anndata aligns the query to the anchor model's gene space
    # and adds any missing scVI metadata.
    # load_query_data freezes the encoder weights and only fine-tunes the
    # batch-specific parameters, preserving the anchor latent geometry.
    scvi.model.SCVI.prepare_query_anndata(adata_query, anchor_model)

    query_model = scvi.model.SCVI.load_query_data(
        adata_query,
        anchor_model,
        freeze_dropout=True,
    )

    query_model.train(
        max_epochs=max_epochs,
        early_stopping=True,
        early_stopping_patience=10,
        plan_kwargs={"weight_decay": 0.0},  # scArches recommendation
        accelerator=accelerator,
        devices=devices,
    )

    query_latent = query_model.get_latent_representation(adata_query)
    logger.info(f"  Query latent shape: {query_latent.shape}")

    # ── 4c. Merge anchor + query into the full adata ─────────────────────────
    n_cells = adata.n_obs
    n_latent = adata_anchor.obsm["X_scVI_anchor"].shape[1]
    X_combined = np.zeros((n_cells, n_latent), dtype=np.float32)

    # Use pre-computed integer positions (anchor_pos) rather than obs_names
    # matching.  Xenium barcodes (e.g. "cell_1") repeat across all 121 cores,
    # so obs_names.isin() would match every cell in the full adata and produce
    # a shape-mismatch error.  anchor_pos is guaranteed to have exactly
    # adata_anchor.n_obs entries in the same row order as adata_anchor.
    query_idx = np.where(non_epi_mask)[0]

    assert len(anchor_pos) == adata_anchor.n_obs, (
        f"anchor_pos length ({len(anchor_pos)}) != adata_anchor.n_obs "
        f"({adata_anchor.n_obs}). This is a bug in build_anchor_adata."
    )

    X_combined[anchor_pos] = adata_anchor.obsm["X_scVI_anchor"]
    X_combined[query_idx] = query_latent

    adata.obsm["X_scVI_anchored"] = X_combined

    # ── 4d. Tag each cell with its role in the correction ────────────────────
    # Build a boolean mask for "is in anchor" using positional indexing.
    in_anchor_mask = np.zeros(n_cells, dtype=bool)
    in_anchor_mask[anchor_pos] = True
    in_anchor = pd.Series(in_anchor_mask, index=adata.obs_names)

    is_epi = adata.obs["is_epithelial"]  # pandas Series (bool)

    adata.obs["anchor_role"] = "query"
    adata.obs.loc[in_anchor & is_epi, "anchor_role"] = "anchor"
    adata.obs.loc[is_epi & ~in_anchor, "anchor_role"] = "epi_transfer"

    logger.info("  anchor_role counts:\n" + adata.obs["anchor_role"].value_counts().to_string())

    del adata_query, query_model
    gc.collect()

    return adata


# ---------------------------------------------------------------------------
# Step 5 — Build neighborhood graph & UMAP on corrected embedding
# ---------------------------------------------------------------------------


def build_corrected_embedding(
    adata: ad.AnnData,
    use_rep: str = "X_scVI_anchored",
    n_neighbors: int = 15,
    umap_min_dist: float = 0.3,
    random_state: int = 42,
    neighbors_key_added: str = "neighbours_corrected",
) -> ad.AnnData:
    """
    Compute neighbors and UMAP on the anchored latent space.

    METABRIC compatibility note
    ───────────────────────────
    The downstream workflow (apply_spatial_knn_smoothing, Leiden clustering,
    annotate_clusters_by_markers) all reference the ``neighbours_corrected``
    key.  Setting ``neighbors_key_added="neighbours_corrected"`` ensures full
    compatibility without any changes to downstream code.

    Parameters
    ----------
    adata
        Full cohort AnnData with ``obsm["X_scVI_anchored"]``.
    use_rep
        Key in obsm to use as input for the neighbor graph.
    n_neighbors
        Number of neighbors for the kNN graph.
    umap_min_dist
        UMAP min_dist parameter.
    random_state
        Random seed for reproducibility.
    neighbors_key_added
        Key under which to store the neighbor graph in adata.uns / adata.obsp.
        Default "neighbours_corrected" matches the rest of the METABRIC workflow.
    """
    logger.info("─── Step 5: Neighborhood graph + UMAP ───")

    sc.pp.neighbors(
        adata,
        use_rep=use_rep,
        n_neighbors=n_neighbors,
        random_state=random_state,
        key_added=neighbors_key_added,
    )

    sc.tl.umap(
        adata,
        min_dist=umap_min_dist,
        random_state=random_state,
        neighbors_key=neighbors_key_added,
    )

    # Store under a named key to avoid collision with other UMAPs
    adata.obsm["X_umap_anchored"] = adata.obsm["X_umap"].copy()

    # The celltype package (cell_typing_celltypist, batch_correction plots)
    # hardcodes basis="umap_corrected" / "X_umap_corrected" in several places
    # and does NOT fall back gracefully when the key is absent.
    # Store an alias so all downstream celltype-package functions find it
    # without any changes to that package.
    adata.obsm["X_umap_corrected"] = adata.obsm["X_umap"].copy()

    logger.info(
        f"  Neighbors stored as '{neighbors_key_added}'; "
        f"UMAP stored as 'X_umap_anchored' and 'X_umap_corrected' (alias for celltype package)."
    )
    return adata


# ---------------------------------------------------------------------------
# Master pipeline function
# ---------------------------------------------------------------------------


def run_epithelial_anchored_correction(
    adata: ad.AnnData,
    celltypist_model_path: str = DEFAULT_MODEL_PATH,
    batch_key: str = DEFAULT_BATCH_KEY,
    confidence_threshold: float = 0.5,
    min_cells_per_batch: int = MIN_EPITHELIAL_CELLS_PER_BATCH,
    n_hvgs: int = 2000,  # automatically capped at n_vars for Xenium panels
    n_latent: int = SCVI_N_LATENT,
    n_layers: int = SCVI_N_LAYERS,
    n_hidden: int = SCVI_N_HIDDEN,
    max_epochs_anchor: int = SCVI_MAX_EPOCHS_ANCHOR,
    max_epochs_query: int = SCVI_MAX_EPOCHS_QUERY,
    save_model_dir: str | None = None,
    load_model_dir: str | None = None,
    neighbors_key_added: str = "neighbours_corrected",
    compute_umap: bool = True,
    n_neighbors: int = 15,
    accelerator: (
        str | None
    ) = None,  # None → auto-detect (CUDA > CPU; MPS excluded, see _get_accelerator)
    seed: int = 42,
) -> ad.AnnData:
    """
    Full epithelial-anchored batch correction pipeline for METABRIC TMA data.

    Integrates with ``celltype_merged_full_workflow.py`` as an alternative to
    Harmony.  Set ``BATCH_CORRECTION_METHOD = "epithelial_anchored"`` in the
    workflow config to use this pipeline in Step 0.

    Parameters
    ----------
    adata
        Full cohort AnnData.  Must have:
          • raw counts in ``layers["counts"]`` (or ``X``)
          • batch labels in ``obs[batch_key]``
          • gene symbols in ``var_names``
    celltypist_model_path
        Path to CellTypist model (.pkl).  Default: wu_model_celltype_major.pkl
    batch_key
        Column in adata.obs identifying TMA cores.  Default: "metabric_ID"
    confidence_threshold
        CellTypist confidence threshold for epithelial anchor selection.
    min_cells_per_batch
        Minimum epithelial cells per batch required for anchor training.
    n_hvgs
        Number of HVGs for scVI.  Automatically capped at n_vars for
        small Xenium panels — set to 0 or a large number to use all genes.
    n_latent, n_layers, n_hidden
        scVI architecture.  n_latent=30 recommended for 5 000-gene panels.
    max_epochs_anchor
        Max training epochs for the anchor scVI model.
    max_epochs_query
        Max epochs for query reference mapping fine-tuning.
    save_model_dir
        Optional directory to save the trained anchor scVI model.
        Use together with load_model_dir for LOAD_PRECOMPUTED-style caching.
    load_model_dir
        If provided AND the directory exists, reload the saved model instead
        of retraining.  Equivalent to LOAD_PRECOMPUTED for this step.
    neighbors_key_added
        Key for the computed neighbor graph.  Default "neighbours_corrected"
        is required for compatibility with the METABRIC downstream workflow.
    compute_umap
        Whether to compute UMAP on the corrected embedding.
    n_neighbors
        Number of neighbors for the kNN graph.
    accelerator
        Accelerator type ("cuda", "mps", "cpu").  None → auto-detect
        (CUDA > CPU; MPS is never auto-selected — see ``_get_accelerator``).
        Passing ``"mps"`` explicitly still works but disables the
        determinism guarantee below.
    seed
        Seed for ``_set_deterministic_mode`` — should match
        ``config.yaml``'s ``data.random_seed``. Combined with a CPU/CUDA
        accelerator and ``torch.use_deterministic_algorithms(True)``, this
        makes the scVI training step (and everything downstream of it —
        Leiden clustering, biomarker/hierarchy/sctype annotation) fully
        reproducible across reruns.

    Returns
    -------
    adata with:
        ``obs["celltypist_label_anchor"]``  — cell type labels (anchor pass)
        ``obs["celltypist_conf_anchor"]``   — confidence scores (anchor pass)
        ``obs["is_epithelial"]``            — epithelial anchor flag
        ``obs["anchor_role"]``              — "anchor" / "epi_transfer" / "query"
        ``obsm["X_scVI_anchored"]``         — corrected latent (n_cells × n_latent)
        ``obsm["X_umap_anchored"]``         — UMAP of corrected embedding (if compute_umap)
        ``uns[neighbors_key_added]``        — neighbor graph metadata
        ``obsp[neighbors_key_added + "_connectivities"]``
        ``obsp[neighbors_key_added + "_distances"]``
    """
    logger.info("═══ Epithelial-Anchored Batch Correction (METABRIC) ═══")
    logger.info(f"  Cohort   : {adata.n_obs:,} cells × {adata.n_vars:,} genes")
    logger.info(f"  Batches  : {adata.obs[batch_key].nunique()} (key: '{batch_key}')")
    logger.info(f"  Model    : {celltypist_model_path}")

    # Must run BEFORE any model.train() call below (Steps 3-4) so that both
    # scVI training passes are seeded and use deterministic kernels.
    _set_deterministic_mode(seed)

    # 1. CellTypist anchor annotation
    adata = run_celltypist_pass(
        adata,
        model_path=celltypist_model_path,
        batch_key=batch_key,
        confidence_threshold=confidence_threshold,
        majority_voting=False,  # faster; we only need epithelial / non-epithelial split
    )

    # 2. Build anchor subset
    adata_anchor, excluded_batches, anchor_pos = build_anchor_adata(
        adata,
        batch_key=batch_key,
        min_cells_per_batch=min_cells_per_batch,
        n_hvgs=n_hvgs,
    )

    # Resolve accelerator once here so both training steps use the same device
    _accel, _devices = _get_accelerator() if accelerator is None else (accelerator, 1)

    # 3. Train (or reload) scVI on anchor
    anchor_model = train_anchor_scvi(
        adata_anchor,
        batch_key=batch_key,
        n_latent=n_latent,
        n_layers=n_layers,
        n_hidden=n_hidden,
        max_epochs=max_epochs_anchor,
        save_dir=save_model_dir,
        load_dir=load_model_dir,
        accelerator=_accel,
        devices=_devices,
    )

    # 4. Transfer correction to all cells
    adata = transfer_correction_to_query(
        adata,
        adata_anchor=adata_anchor,
        anchor_model=anchor_model,
        anchor_pos=anchor_pos,
        batch_key=batch_key,
        max_epochs=max_epochs_query,
        accelerator=_accel,
        devices=_devices,
    )

    # 5. Neighborhood graph + UMAP
    if compute_umap:
        adata = build_corrected_embedding(
            adata,
            n_neighbors=n_neighbors,
            neighbors_key_added=neighbors_key_added,
        )

    # ── Create lognorm layer ─────────────────────────────────────────────────
    # The entire downstream celltyping stack (CellTypist, cluster_annotation,
    # scimilarity) reads merged_adata.layers["lognorm"] as its expression input.
    # The old batch_correction.py created this layer during preprocessing;
    # the scVI pipeline skips that step, so we create it here from "counts".
    # We also set uns["corrected_expr_layer"] so any code that calls
    #   merged_adata.uns.get("corrected_expr_layer", "lognorm")
    # gets the right answer without hard-coding the layer name.
    if "lognorm" not in adata.layers:
        logger.info("  Creating layers['lognorm'] from layers['counts'] …")
        if "counts" in adata.layers:
            raw = adata.layers["counts"]
            # Work on a dense or sparse copy — do NOT modify the counts layer
            lognorm = raw.copy().astype(np.float32)
            if sp.issparse(lognorm):
                # Normalise each row to sum to 1e4, then log1p in-place.
                # .multiply() returns COO; AnnData requires CSR or CSC → .tocsr()
                row_sums = np.asarray(lognorm.sum(axis=1)).ravel()
                row_sums[row_sums == 0] = 1.0  # avoid div-by-zero
                scale = 1e4 / row_sums
                lognorm = lognorm.multiply(scale[:, None]).tocsr()
                lognorm.data = np.log1p(lognorm.data)
            else:
                row_sums = lognorm.sum(axis=1, keepdims=True)
                row_sums[row_sums == 0] = 1.0
                lognorm = np.log1p(lognorm / row_sums * 1e4)
            adata.layers["lognorm"] = lognorm
            logger.info(
                f"  layers['lognorm'] created  " f"(shape: {adata.layers['lognorm'].shape})"
            )
        else:
            # Fallback: log-normalise whatever is in .X (already normalised
            # by scVI preprocessing — just log1p it and store)
            logger.warning(
                "  'counts' layer not found — creating layers['lognorm'] "
                "from .X via log1p (counts may already be normalised)."
            )
            adata.layers["lognorm"] = np.log1p(
                np.asarray(adata.X.todense() if sp.issparse(adata.X) else adata.X, dtype=np.float32)
            )
    else:
        logger.info("  layers['lognorm'] already present — skipping creation.")

    adata.uns["corrected_expr_layer"] = "lognorm"

    # ── Register corrected_rep so every downstream function that calls
    # merged_adata.uns.get("corrected_rep", "X_pca_harmony") picks up the
    # right embedding.  This is read by:
    #   • compute_voting_clusters()  → leiden_voting (always called in step 2)
    #   • OverclusterAnnotator       → high-res Leiden for overcluster method
    #   • Any other celltype-module function that infers the corrected embedding
    # Without this key, all of them fall back to "X_pca_harmony" which does
    # not exist in an anchored-corrected AnnData → immediate crash in step 2.
    adata.uns["corrected_rep"] = "X_scVI_anchored"
    adata.uns["corrected_expr_layer"] = "lognorm"  # re-affirm
    adata.uns["batch_correction_method"] = "epithelial_anchored"
    logger.info(
        "  uns keys set: corrected_rep='X_scVI_anchored', "
        "corrected_expr_layer='lognorm', batch_correction_method='epithelial_anchored'"
    )

    logger.info("═══ Pipeline complete ═══")
    logger.info(
        f"  Corrected embedding : obsm['X_scVI_anchored'] " f"{adata.obsm['X_scVI_anchored'].shape}"
    )
    if compute_umap:
        logger.info(f"  Neighbor graph      : uns['{neighbors_key_added}']")

    return adata


# ---------------------------------------------------------------------------
# Convenience wrapper — called from celltype_merged_full_workflow step0
# ---------------------------------------------------------------------------


def run_anchored_correction_from_merged(
    merged_adata: ad.AnnData,
    celltypist_model_path: str = DEFAULT_MODEL_PATH,
    batch_key: str = DEFAULT_BATCH_KEY,
    save_model_dir: str | None = None,
    load_model_dir: str | None = None,
    n_hvgs: int = 3000,
    n_latent: int = SCVI_N_LATENT,
    n_layers: int = SCVI_N_LAYERS,
    n_hidden: int = SCVI_N_HIDDEN,
    min_cells_per_batch: int = MIN_EPITHELIAL_CELLS_PER_BATCH,
    max_epochs_anchor: int = SCVI_MAX_EPOCHS_ANCHOR,
    max_epochs_query: int = SCVI_MAX_EPOCHS_QUERY,
    n_neighbors: int = 15,
    output_dir: str = "merged_full_results",
    seed: int = 42,
) -> ad.AnnData:
    """
    Thin wrapper called from ``step0_load_data()`` in
    ``celltype_merged_full_workflow.py`` when
    ``BATCH_CORRECTION_METHOD == "epithelial_anchored"``.

    The input ``merged_adata`` is expected to be the result of concatenating
    all per-core tables (with ``layers["counts"]`` preserved) but WITHOUT any
    prior batch correction embedding — this function replaces Harmony entirely.

    Parameters
    ----------
    merged_adata
        Concatenated cohort AnnData with raw counts in ``layers["counts"]``.
    celltypist_model_path
        Path to CellTypist model (.pkl).
    batch_key
        obs column identifying TMA cores.
    save_model_dir
        Directory to save the trained anchor scVI model.
    load_model_dir
        If provided and exists, reload saved model instead of retraining.
    n_hvgs
        Number of HVGs passed to scVI.  Defaults to 3 000, appropriate for a
        5 000-gene panel; automatically capped at n_vars.
    n_latent
        scVI latent dimensions.  Default 30 for 5 000-gene panels.
    n_layers
        Number of encoder/decoder layers.  Default 3 for 5 000-gene panels.
    n_hidden
        Hidden-layer width.  Default 256 for 5 000-gene panels.
    min_cells_per_batch
        Minimum epithelial cells a core must contribute to participate in
        anchor training.  Default 50 for 5 000-gene panels.
    max_epochs_anchor
        Max training epochs for the anchor model.
    max_epochs_query
        Max epochs for query reference mapping fine-tuning.
    n_neighbors
        Number of neighbors for the kNN graph.
    output_dir
        Directory for diagnostic outputs (anchor_quality_summary.csv).
    seed
        Forwarded to ``run_epithelial_anchored_correction``'s
        ``_set_deterministic_mode`` call — should match ``config.yaml``'s
        ``data.random_seed``.

    Returns
    -------
    merged_adata with all anchored-correction outputs added.
    """
    os.makedirs(output_dir, exist_ok=True)

    merged_adata = run_epithelial_anchored_correction(
        merged_adata,
        celltypist_model_path=celltypist_model_path,
        batch_key=batch_key,
        confidence_threshold=0.5,
        min_cells_per_batch=min_cells_per_batch,
        seed=seed,
        n_hvgs=n_hvgs,
        n_latent=n_latent,
        n_layers=n_layers,
        n_hidden=n_hidden,
        max_epochs_anchor=max_epochs_anchor,
        max_epochs_query=max_epochs_query,
        save_model_dir=save_model_dir,
        load_model_dir=load_model_dir,
        neighbors_key_added="neighbours_corrected",  # downstream compatibility
        compute_umap=True,
        n_neighbors=n_neighbors,
    )

    # Diagnostics
    summary = summarise_anchor_quality(merged_adata, batch_key=batch_key)
    summary_path = f"{output_dir}/anchor_quality_summary.csv"
    summary.to_csv(summary_path)
    logger.info(f"  Anchor quality summary saved → {summary_path}")

    return merged_adata


# ---------------------------------------------------------------------------
# Diagnostic utilities
# ---------------------------------------------------------------------------


def plot_anchor_correction_summary(
    adata: ad.AnnData,
    batch_key: str = DEFAULT_BATCH_KEY,
    color_keys: list[str] = None,
    save_path: str | None = None,
) -> None:
    """
    Quick diagnostic UMAP plot coloured by batch, CellTypist label, and
    anchor role.

    Switches the default obsm["X_umap"] to the anchored UMAP so that
    standard ``sc.pl.umap()`` calls work without modification.
    """
    import matplotlib.pyplot as plt  # noqa: F401 — ensures matplotlib backend is ready

    if "X_umap_anchored" not in adata.obsm:
        raise ValueError("Run build_corrected_embedding() first.")

    adata.obsm["X_umap"] = adata.obsm["X_umap_anchored"]

    if color_keys is None:
        color_keys = ["celltypist_label_anchor", batch_key, "anchor_role"]

    sc.pl.umap(
        adata,
        color=color_keys,
        ncols=len(color_keys),
        show=save_path is None,
        save=save_path,
        frameon=False,
        wspace=0.4,
    )


def summarise_anchor_quality(
    adata: ad.AnnData,
    batch_key: str = DEFAULT_BATCH_KEY,
) -> pd.DataFrame:
    """
    Return a per-batch summary DataFrame showing:
      • total cells
      • epithelial cells
      • epithelial fraction
      • dominant anchor role (anchor / epi_transfer / query)

    Useful for identifying cores with very few epithelial cells that may be
    corrected primarily by reference transfer rather than anchor learning.
    """
    df = adata.obs[[batch_key, "is_epithelial", "anchor_role"]].copy()

    summary = (
        df.groupby(batch_key)
        .agg(
            total_cells=("is_epithelial", "count"),
            epi_cells=("is_epithelial", "sum"),
        )
        .assign(epi_fraction=lambda x: x["epi_cells"] / x["total_cells"])
    )

    role = (
        df.groupby(batch_key)["anchor_role"]
        .agg(lambda x: x.value_counts().index[0])
        .rename("dominant_role")
    )

    summary = summary.join(role).sort_values("epi_fraction", ascending=False)
    return summary


# ---------------------------------------------------------------------------
# Post-hoc QC — compare anchor labels vs final cell typing
# ---------------------------------------------------------------------------


def check_epithelial_consistency(
    adata: ad.AnnData,
    anchor_label_col: str = "celltypist_label_anchor",
    final_label_col: str = "cell_type",
    batch_key: str = DEFAULT_BATCH_KEY,
    output_dir: str | None = None,
    epithelial_final_labels: tuple[str, ...] = ("Epithelial",),
) -> pd.DataFrame:
    """
    Compare Step-1 epithelial anchor labels against Step-4 final cell typing.

    This is a post-hoc QC step.  After the full workflow completes (CellTypist
    anchor pass → scVI correction → final cell typing), we check whether cells
    labelled as "Epithelial" in the anchor pass are also classified as
    "Epithelial" in the final annotation (and vice-versa).

    A 2×2 confusion-matrix decomposition is produced per batch and overall:

        TP  — anchor=epithelial  AND final=epithelial  (consistent)
        FP  — anchor=epithelial  AND final=non-epithelial (anchor over-called)
        FN  — anchor=non-epithelial AND final=epithelial  (anchor missed)
        TN  — anchor=non-epithelial AND final=non-epithelial (consistent non-epi)

    Parameters
    ----------
    adata
        Merged AnnData after the complete workflow.  Must contain both
        ``anchor_label_col`` (set in Step 1) and ``final_label_col`` (set in
        Step 4 cell typing).
    anchor_label_col
        obs column produced by :func:`run_celltypist_pass`.
        Default "celltypist_label_anchor".
    final_label_col
        obs column produced by the final cell typing step.
        Default "cell_type".
    batch_key
        obs column identifying TMA cores / batches.
    output_dir
        If provided, saves two CSVs:
          ``{output_dir}/epithelial_consistency_per_batch.csv``
          ``{output_dir}/epithelial_consistency_overall.csv``
    epithelial_final_labels
        Which values in ``final_label_col`` count as "epithelial".
        Default ("Epithelial",) — matches the unified marker matrix label.

    Returns
    -------
    pd.DataFrame
        Per-batch summary with columns:
        ``n_cells, TP, FP, FN, TN, precision, recall, f1, jaccard``
    """
    missing = [
        c for c in [anchor_label_col, final_label_col, batch_key] if c not in adata.obs.columns
    ]
    if missing:
        raise KeyError(
            f"check_epithelial_consistency: missing obs columns: {missing}.  "
            f"Ensure the workflow has completed Steps 1 and 4 before calling."
        )

    obs = adata.obs[[batch_key, anchor_label_col, final_label_col]].copy()

    # Boolean masks
    obs["anchor_epi"] = obs[anchor_label_col] == "Epithelial"
    obs["final_epi"] = obs[final_label_col].isin(epithelial_final_labels)

    def _confusion(df: pd.DataFrame) -> dict:
        tp = int((df["anchor_epi"] & df["final_epi"]).sum())
        fp = int((df["anchor_epi"] & ~df["final_epi"]).sum())
        fn = int((~df["anchor_epi"] & df["final_epi"]).sum())
        tn = int((~df["anchor_epi"] & ~df["final_epi"]).sum())
        precision = tp / (tp + fp) if (tp + fp) > 0 else float("nan")
        recall = tp / (tp + fn) if (tp + fn) > 0 else float("nan")
        f1 = (
            2 * precision * recall / (precision + recall)
            if (precision + recall) > 0
            else float("nan")
        )
        jaccard = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else float("nan")
        return {
            "n_cells": len(df),
            "TP": tp,
            "FP": fp,
            "FN": fn,
            "TN": tn,
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1": round(f1, 4),
            "jaccard": round(jaccard, 4),
        }

    # Per-batch summary
    rows = []
    for batch_id, grp in obs.groupby(batch_key):
        row = {"batch": batch_id}
        row.update(_confusion(grp))
        rows.append(row)
    per_batch = pd.DataFrame(rows).set_index("batch")
    per_batch = per_batch.sort_values("f1", ascending=False)

    # Overall summary
    overall = pd.DataFrame([{"batch": "OVERALL"}]).set_index("batch")
    overall_vals = _confusion(obs)
    for k, v in overall_vals.items():
        overall[k] = v

    logger.info(
        f"  Epithelial consistency (overall): "
        f"TP={overall_vals['TP']:,}  FP={overall_vals['FP']:,}  "
        f"FN={overall_vals['FN']:,}  TN={overall_vals['TN']:,}  "
        f"F1={overall_vals['f1']:.3f}  Recall={overall_vals['recall']:.3f}  "
        f"Precision={overall_vals['precision']:.3f}"
    )

    if output_dir is not None:
        os.makedirs(output_dir, exist_ok=True)
        pb_path = f"{output_dir}/epithelial_consistency_per_batch.csv"
        ov_path = f"{output_dir}/epithelial_consistency_overall.csv"
        per_batch.to_csv(pb_path)
        overall.to_csv(ov_path)
        logger.info(f"  Consistency reports saved → {pb_path}, {ov_path}")

    return per_batch
