"""
Quality Control and Validation for Cell Type Annotations
=========================================================

This module provides QC metrics and validation functions for evaluating
cell type annotation quality.

Classes
-------
- AnnotationQCResult: Dataclass for QC metrics
- MarkerValidationResult: Dataclass for marker validation results

Functions
---------
- compute_annotation_qc_metrics: Compute QC metrics for annotations
- validate_annotations_with_markers: Validate annotations using marker expression
- validate_cell_type_hierarchy: Check hierarchy consistency
- add_hierarchical_annotations: Add coarse/fine annotations
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse
from sklearn.metrics import silhouette_score

from .constants import (
    CELL_TYPE_HIERARCHY,
    ColumnNames,
)
from .core_utils import (
    compute_marker_specificity,
    find_markers_in_data,
)

logger = logging.getLogger(__name__)


__all__ = [
    "AnnotationQCResult",
    "MarkerValidationResult",
    "compute_annotation_qc_metrics",
    "validate_annotations_with_markers",
    "validate_cell_type_hierarchy",
    "add_hierarchical_annotations",
    "flag_low_quality_cells",
]


@dataclass
class AnnotationQCResult:
    """
    Results from annotation quality control analysis.

    Attributes
    ----------
    n_cells : int
        Total number of cells.
    n_cell_types : int
        Number of unique cell types.
    mean_confidence : float
        Mean confidence score.
    median_confidence : float
        Median confidence score.
    low_confidence_fraction : float
        Fraction of cells with low confidence.
    silhouette_score : float, optional
        Silhouette score if embedding available.
    cell_type_distribution : pd.Series
        Cell counts per type.
    confidence_by_type : pd.DataFrame
        Confidence statistics per type.
    """

    n_cells: int
    n_cell_types: int
    mean_confidence: float
    median_confidence: float
    low_confidence_fraction: float
    silhouette_score: float | None
    cell_type_distribution: pd.Series
    confidence_by_type: pd.DataFrame

    def summary(self) -> str:
        """Return summary string."""
        return (
            f"AnnotationQC: {self.n_cells} cells, {self.n_cell_types} types, "
            f"mean_conf={self.mean_confidence:.3f}, "
            f"low_conf={100*self.low_confidence_fraction:.1f}%"
        )

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "n_cells": self.n_cells,
            "n_cell_types": self.n_cell_types,
            "mean_confidence": self.mean_confidence,
            "median_confidence": self.median_confidence,
            "low_confidence_fraction": self.low_confidence_fraction,
            "silhouette_score": self.silhouette_score,
        }


@dataclass
class MarkerValidationResult:
    """
    Results from marker-based validation.

    Attributes
    ----------
    cell_type : str
        Cell type being validated.
    n_cells : int
        Number of cells of this type.
    markers_found : List[str]
        Markers present in data.
    markers_missing : List[str]
        Markers not found in data.
    mean_marker_expression : float
        Mean expression of markers.
    marker_specificity : float
        Specificity score in [-1, 1].  Positive values indicate higher
        expression in this cell type than in all others; negative values
        indicate the markers are actually more expressed elsewhere.
        Computed as ``(ct_expr - other_expr) / (ct_expr + other_expr + ε)``.
    """

    cell_type: str
    n_cells: int
    markers_found: list[str]
    markers_missing: list[str]
    mean_marker_expression: float
    marker_specificity: float

    def is_valid(self, min_expression: float = 0.5, min_specificity: float = 0.3) -> bool:
        """Check if validation passes thresholds."""
        return (
            self.mean_marker_expression >= min_expression
            and self.marker_specificity >= min_specificity
        )


def compute_annotation_qc_metrics(
    adata: sc.AnnData,
    cell_type_key: str = None,
    confidence_key: str = None,
    embedding_key: str = "X_umap",
    low_confidence_threshold: float = 0.5,
) -> AnnotationQCResult:
    """
    Compute quality control metrics for cell type annotations.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type predictions.
    cell_type_key : str, optional
        Column name for cell types. Default: ColumnNames.CELL_TYPE
    confidence_key : str, optional
        Column name for confidence. Default: ColumnNames.CONFIDENCE
    embedding_key : str
        Key for embedding in obsm (for silhouette score).
    low_confidence_threshold : float
        Threshold for low confidence cells.

    Returns
    -------
    AnnotationQCResult
        QC metrics.

    Examples
    --------
    >>> qc = compute_annotation_qc_metrics(adata)
    >>> print(qc.summary())
    """
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE
    if confidence_key is None:
        confidence_key = ColumnNames.CONFIDENCE

    cell_types = adata.obs[cell_type_key]

    if confidence_key in adata.obs.columns:
        confidences = adata.obs[confidence_key].values
    else:
        confidences = np.ones(len(cell_types))

    # Basic metrics
    n_cells = len(cell_types)
    n_cell_types = cell_types.nunique()
    mean_conf = float(confidences.mean())
    median_conf = float(np.median(confidences))
    low_conf_frac = float((confidences < low_confidence_threshold).mean())

    # Cell type distribution
    ct_distribution = cell_types.value_counts()

    # Confidence by cell type
    if confidence_key in adata.obs.columns:
        conf_by_type = (
            adata.obs.groupby(cell_type_key)[confidence_key]
            .agg(["mean", "median", "std", "count"])
            .reset_index()
        )
    else:
        conf_by_type = pd.DataFrame()

    # Silhouette score (if embedding available)
    sil_score = None
    if embedding_key in adata.obsm and n_cell_types > 1:
        try:
            valid_mask = ~cell_types.isin(["unknown", "Unknown", ""])
            if valid_mask.sum() > 100:
                sil_score = silhouette_score(
                    adata.obsm[embedding_key][valid_mask],
                    cell_types[valid_mask],
                    sample_size=min(5000, valid_mask.sum()),
                )
        except Exception as e:
            logger.warning(f"Could not compute silhouette score: {e}")

    return AnnotationQCResult(
        n_cells=n_cells,
        n_cell_types=n_cell_types,
        mean_confidence=mean_conf,
        median_confidence=median_conf,
        low_confidence_fraction=low_conf_frac,
        silhouette_score=sil_score,
        cell_type_distribution=ct_distribution,
        confidence_by_type=conf_by_type,
    )


def validate_annotations_with_markers(
    adata: sc.AnnData, marker_dict: dict[str, list[str]], cell_type_key: str = None
) -> list[MarkerValidationResult]:
    """
    Validate cell type annotations using marker expression.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type predictions.
    marker_dict : dict
        Dictionary mapping cell types to marker genes.
    cell_type_key : str, optional
        Column name for cell types.

    Returns
    -------
    List[MarkerValidationResult]
        Validation results for each cell type.

    Examples
    --------
    >>> results = validate_annotations_with_markers(adata, marker_dict)
    >>> for r in results:
    ...     print(f"{r.cell_type}: valid={r.is_valid()}")
    """
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE

    # Q1: compute_marker_specificity returns per-marker specificity weights
    # (inverse of how many cell types share each marker).  The original code
    # called this but discarded the return value — a dead call.  We capture
    # the result here so it is available for the per-type loop below.
    # NOTE: mean_marker_expression is kept as a plain (unweighted) mean over
    # all (cell × marker) pairs to preserve the existing public API semantics.
    # The specificity weights are used only to compute marker_specificity.
    specificity_scores = compute_marker_specificity(marker_dict)

    results = []
    cell_types = adata.obs[cell_type_key]

    # Q2: use scipy.sparse.issparse() — the canonical check — instead of
    # hasattr(X, "toarray"), which would also match non-sparse objects that
    # happen to have that method (e.g. some custom array wrappers).
    X = adata.X.toarray() if scipy.sparse.issparse(adata.X) else np.asarray(adata.X)

    for ct, markers in marker_dict.items():
        ct_mask = cell_types == ct
        n_cells = ct_mask.sum()

        if n_cells == 0:
            continue

        # Find markers in data
        found, missing = find_markers_in_data(markers, adata.var_names)

        if not found:
            results.append(
                MarkerValidationResult(
                    cell_type=ct,
                    n_cells=int(n_cells),  # Q9: cast numpy.int64 → int
                    markers_found=[],
                    markers_missing=missing,
                    mean_marker_expression=0.0,
                    marker_specificity=0.0,
                )
            )
            continue

        # Get marker indices
        marker_idx = [adata.var_names.get_loc(m) for m in found]

        # Mean expression in this cell type (unweighted, preserving original semantics)
        ct_expr = float(X[ct_mask][:, marker_idx].mean())

        # Specificity: weighted by per-marker uniqueness; range [-1, 1].
        # Markers shared across many cell types contribute less to the score.
        weights = np.array([specificity_scores.get(m, 1.0) for m in found])
        weights = weights / (weights.sum() + 1e-10)
        ct_expr_w = float(np.average(X[ct_mask][:, marker_idx].mean(axis=0), weights=weights))
        other_expr_w = (
            float(np.average(X[~ct_mask][:, marker_idx].mean(axis=0), weights=weights))
            if (~ct_mask).sum() > 0
            else 0.0
        )
        spec = (ct_expr_w - other_expr_w) / (ct_expr_w + other_expr_w + 1e-10)

        results.append(
            MarkerValidationResult(
                cell_type=ct,
                # Q9: cast numpy.int64 → int to avoid JSON serialisation crash
                n_cells=int(n_cells),
                markers_found=found,
                markers_missing=missing,
                mean_marker_expression=float(ct_expr),
                marker_specificity=float(spec),
            )
        )

    return results


def validate_cell_type_hierarchy(
    adata: sc.AnnData, hierarchy: dict[str, tuple[str, str]] = None, cell_type_key: str = None
) -> pd.DataFrame:
    """
    Validate that cell type annotations are consistent with hierarchy.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type predictions.
    hierarchy : dict, optional
        Hierarchy mapping child -> (parent, grandparent).
    cell_type_key : str, optional
        Column name for cell types.

    Returns
    -------
    pd.DataFrame
        Validation results with hierarchy levels.
    """
    if hierarchy is None:
        hierarchy = CELL_TYPE_HIERARCHY
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE

    cell_types = adata.obs[cell_type_key]

    results = []
    for ct in cell_types.unique():
        if ct in hierarchy:
            # Q8: guard against malformed hierarchy entries that are not
            # exactly 2-tuples; unpack safely and fall back to None.
            entry = hierarchy[ct]
            if isinstance(entry, (tuple, list)) and len(entry) >= 2:
                parent, grandparent = entry[0], entry[1]
            elif isinstance(entry, (tuple, list)) and len(entry) == 1:
                parent, grandparent = entry[0], None
            else:
                parent, grandparent = str(entry), None
                logger.warning(
                    f"Unexpected hierarchy entry for '{ct}': {entry!r}. "
                    "Expected a 2-tuple (parent, grandparent)."
                )
            level = "fine"
        elif ct in {p for p, _ in hierarchy.values()}:
            parent = ct
            grandparent = None
            level = "coarse"
        else:
            parent = None
            grandparent = None
            level = "unknown"

        n_cells = (cell_types == ct).sum()
        results.append(
            {
                "cell_type": ct,
                "parent": parent,
                "grandparent": grandparent,
                "level": level,
                "n_cells": n_cells,
            }
        )

    return pd.DataFrame(results)


def add_hierarchical_annotations(
    adata: sc.AnnData,
    hierarchy: dict[str, tuple[str, str]] = None,
    cell_type_key: str = None,
    inplace: bool = False,
) -> sc.AnnData:
    """
    Add coarse and fine-grained cell type annotations based on hierarchy.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type predictions.
    hierarchy : dict, optional
        Hierarchy mapping child -> (parent, grandparent).
    cell_type_key : str, optional
        Column name for cell types.
    inplace : bool
        Modify adata in place.

    Returns
    -------
    AnnData or None
        Modified copy of ``adata`` when ``inplace=False`` (default).
        ``None`` when ``inplace=True`` — the original object is modified
        in place and nothing is returned.
    """
    if hierarchy is None:
        hierarchy = CELL_TYPE_HIERARCHY
    if cell_type_key is None:
        cell_type_key = ColumnNames.CELL_TYPE

    if not inplace:
        adata = adata.copy()

    cell_types = adata.obs[cell_type_key]

    coarse = []
    fine = []

    for ct in cell_types:
        if ct in hierarchy:
            parent, _ = hierarchy[ct]
            coarse.append(parent)
            fine.append(ct)
        else:
            coarse.append(ct)
            fine.append(ct)

    adata.obs[f"{cell_type_key}_coarse"] = coarse
    adata.obs[f"{cell_type_key}_fine"] = fine

    if inplace:
        return None
    return adata


def flag_low_quality_cells(
    adata: sc.AnnData,
    confidence_key: str = None,
    confidence_threshold: float = 0.5,
    min_genes: int = 200,
    max_mito_fraction: float = 0.2,
    flag_column: str = "low_quality",
    inplace: bool = False,
) -> sc.AnnData:
    """
    Flag low-quality cells based on confidence and QC metrics.

    Parameters
    ----------
    adata : AnnData
        Annotated data with cell type predictions.
    confidence_key : str, optional
        Column name for confidence scores.
    confidence_threshold : float
        Minimum confidence to be considered high quality.
    min_genes : int
        Minimum number of genes expressed.
    max_mito_fraction : float
        Maximum mitochondrial gene fraction.
    flag_column : str
        Name of column to store flag.
    inplace : bool
        Modify adata in place.

    Returns
    -------
    AnnData or None
        Modified copy of ``adata`` when ``inplace=False`` (default).
        ``None`` when ``inplace=True`` — the original object is modified
        in place and nothing is returned.

    Examples
    --------
    >>> adata = flag_low_quality_cells(adata, confidence_threshold=0.5)
    >>> print(f"{adata.obs['low_quality'].sum()} low quality cells")
    """
    if confidence_key is None:
        confidence_key = ColumnNames.CONFIDENCE

    if not inplace:
        adata = adata.copy()

    # Initialize flag as False
    low_quality = np.zeros(adata.n_obs, dtype=bool)

    # Flag low confidence cells
    if confidence_key in adata.obs.columns:
        low_quality |= adata.obs[confidence_key].values < confidence_threshold

    # Flag cells with few genes
    if "n_genes" in adata.obs.columns:
        low_quality |= adata.obs["n_genes"].values < min_genes
    elif "n_genes_by_counts" in adata.obs.columns:
        low_quality |= adata.obs["n_genes_by_counts"].values < min_genes

    # Flag high mitochondrial fraction.
    # Q6: the two common column names use different units:
    #   - "pct_counts_mt"  (scanpy default): percentage, range 0–100
    #   - "percent_mito"   (Seurat / manual): fraction, range 0–1
    # max_mito_fraction is always a fraction (0–1); multiply by 100 only for
    # the percentage-scale column.
    if "pct_counts_mt" in adata.obs.columns:
        low_quality |= adata.obs["pct_counts_mt"].values > max_mito_fraction * 100
    elif "percent_mito" in adata.obs.columns:
        low_quality |= adata.obs["percent_mito"].values > max_mito_fraction

    adata.obs[flag_column] = low_quality

    n_flagged = low_quality.sum()
    logger.info(f"Flagged {n_flagged} ({100*n_flagged/adata.n_obs:.1f}%) low quality cells")

    if inplace:
        return None
    return adata
