"""Module 1 — data import.

Builds the multispace SpatialData object from vendor output and adds extra
image modalities (H&E, IF / spatial proteomics) to it.

* Spatial transcriptomics is read with ``spatialdata-io`` so element names
  follow the reader defaults (see :mod:`multispace.constants`).
* CosMx per-FOV output is stitched into one mosaic, the layout the
  resegmentation step works on.
* Extra images are added in their **own** coordinate system (named after the
  element). They join ``global`` only once registration has computed their
  transform, so an unregistered H&E is never silently drawn in the wrong place.
"""
from __future__ import annotations

import logging
from collections.abc import Sequence
from pathlib import Path

import numpy as np

from .._sdata import record_step, require
from ..constants import Attrs, Keys, Platform

logger = logging.getLogger(__name__)

__all__ = ["read_st", "read_xenium", "read_cosmx", "read_merscope", "add_image", "read_image_array"]


# ── spatial transcriptomics ──────────────────────────────────────────────────
def read_xenium(path: str | Path, **kwargs):
    """Read a Xenium (or Atera) output folder with ``spatialdata_io.xenium``."""
    sdio = require("spatialdata_io", "io")
    sdata = sdio.xenium(str(path), **kwargs)
    _check_morphology(sdata)
    return sdata


def read_cosmx(path: str | Path, *, dataset_id: str | None = None, stitch: bool = True,
               stitched_path: str | Path | None = None, **kwargs):
    """Read CosMx output with ``spatialdata_io.cosmx``.

    With ``stitch=True`` (default) the per-FOV images and points are merged into
    a single ``morphology_focus`` mosaic and one ``transcripts`` element, using
    the stitching code from the original resegmentation workflow.
    """
    sdio = require("spatialdata_io", "io")
    sdata = sdio.cosmx(str(path), dataset_id=dataset_id, **kwargs)
    if not stitch:
        return sdata
    return stitch_cosmx(sdata, output_zarr_path=stitched_path)


def stitch_cosmx(sdata, output_zarr_path: str | Path | None = None):
    """Stitch per-FOV CosMx elements and rename them to the contract names."""
    from ..segmentation._legacy.reseg_tools import stitch_cosmx_core

    stitched = stitch_cosmx_core(sdata, output_zarr_path=None)
    import spatialdata as sd

    images = {Keys.MORPHOLOGY: stitched.images["Stitched"]}
    points = {Keys.TRANSCRIPTS: stitched.points["points"]} if "points" in stitched.points else {}
    tables = dict(stitched.tables)
    out = sd.SpatialData(images=images, points=points, tables=tables)
    if output_zarr_path is not None:
        out.write(str(output_zarr_path), overwrite=True)
        out = sd.read_zarr(str(output_zarr_path))
    return out


def read_merscope(path: str | Path, **kwargs):
    """Read MERSCOPE / MERFISH output (import only; resegmentation not yet adapted)."""
    sdio = require("spatialdata_io", "io")
    return sdio.merscope(str(path), **kwargs)


_READERS = {
    Platform.XENIUM: read_xenium,
    Platform.ATERA: read_xenium,
    Platform.COSMX: read_cosmx,
    Platform.MERFISH: read_merscope,
}


#: CosMx camera pixel size (µm / px) used when the stitched frame is in pixels.
COSMX_UM_PER_PX = 0.12028


def read_st(path: str | Path, platform: str, *, um_per_unit: float | None = None, **kwargs):
    """Read spatial transcriptomics output for ``platform`` and tag the object.

    Parameters
    ----------
    path
        Vendor output folder, or an existing ``.zarr`` (read as-is).
    platform
        One of :class:`multispace.constants.Platform`.
    um_per_unit
        Microns per ``global`` unit. Derived from the transcripts transform when
        omitted (Xenium / MERSCOPE); CosMx defaults to 0.12028 µm/px.
    """
    platform = platform.lower()
    if platform not in _READERS:
        raise ValueError(f"Unknown platform '{platform}'. Choose from {sorted(_READERS)}.")
    path = Path(path)
    if path.suffix == ".zarr":
        import spatialdata as sd

        sdata = sd.read_zarr(str(path))
        if platform == Platform.COSMX and Keys.MORPHOLOGY not in sdata.images and any(
                k.endswith("_image") and k.split("_image")[0].isdigit() for k in sdata.images):
            # per-FOV zarr (e.g. from splitting_cosmx_updated.py): stitch it
            logger.info("Per-FOV CosMx zarr detected; stitching FOVs into '%s'.", Keys.MORPHOLOGY)
            sdata = stitch_cosmx(sdata)
    else:
        sdata = _READERS[platform](path, **kwargs)
    meta = sdata.attrs.setdefault(Attrs.ROOT, {})
    meta[Attrs.PLATFORM] = platform
    if um_per_unit is None:
        um_per_unit = meta.get("um_per_unit")
    if um_per_unit is None:
        um_per_unit = COSMX_UM_PER_PX if platform == Platform.COSMX else _derive_um_per_unit(sdata)
    if um_per_unit is not None:
        meta["um_per_unit"] = float(um_per_unit)
    record_step(sdata, "import", {"path": str(path), "platform": platform, "um_per_unit": um_per_unit, **kwargs})
    return sdata


def _derive_um_per_unit(sdata) -> float | None:
    """Points are stored in microns by the readers; their scale into ``global``
    therefore gives global units per micron."""
    if Keys.TRANSCRIPTS not in sdata.points:
        return None
    from spatialdata.transformations import get_transformation

    try:
        m = get_transformation(sdata.points[Keys.TRANSCRIPTS], to_coordinate_system=Keys.COORDINATE_SYSTEM)
        m = np.asarray(m.to_affine_matrix(input_axes=("x", "y"), output_axes=("x", "y")))
        sx = float(np.hypot(m[0, 0], m[1, 0]))
        return 1.0 / sx if sx > 0 else None
    except Exception:  # pragma: no cover - unusual layouts
        return None


def _check_morphology(sdata) -> None:
    if Keys.MORPHOLOGY not in sdata.images and sdata.images:
        first = next(iter(sdata.images))
        logger.warning("No '%s' image; registration will use '%s' as the ST reference unless told otherwise.",
                       Keys.MORPHOLOGY, first)


# ── extra image modalities ───────────────────────────────────────────────────
def read_image_array(path: str | Path, *, series: int = 0, level: int = 0) -> tuple[np.ndarray, list[str] | None]:
    """Read a TIFF / OME-TIFF (or any skimage-readable image) as ``(c, y, x)``.

    Returns the array and channel names when the OME metadata has them.
    RGB(A) images (``y, x, 3|4``) are moved to channel-first.
    """
    path = Path(path)
    names: list[str] | None = None
    if path.suffix.lower() in {".tif", ".tiff", ".btf"} or path.name.lower().endswith(".ome.tif"):
        import tifffile

        with tifffile.TiffFile(str(path)) as tif:
            s = tif.series[series]
            arr = s.levels[level].asarray() if level else s.asarray()
            axes = s.axes
            if tif.ome_metadata:
                names = _ome_channel_names(tif.ome_metadata)
        arr = _to_cyx(arr, axes)
    else:
        from skimage import io as skio

        arr = _to_cyx(skio.imread(str(path)), None)
    if names is not None and len(names) != arr.shape[0]:
        names = None
    return arr, names


def _to_cyx(arr: np.ndarray, axes: str | None) -> np.ndarray:
    arr = np.asarray(arr)
    if axes:
        axes = axes.upper().replace("S", "C")
        keep = [a for a in axes if a in "CYX"]
        # drop singleton T / Z / other axes
        for i, a in reversed(list(enumerate(axes))):
            if a not in "CYX":
                if arr.shape[i] != 1:
                    raise ValueError(f"Image has a non-singleton '{a}' axis; pass a 2-D (optionally multichannel) image.")
                arr = arr.take(0, axis=i)
        if "C" not in keep:
            arr = arr[np.newaxis]
            keep = ["C", *keep]
        order = [keep.index(a) for a in "CYX"]
        return np.transpose(arr, order)
    if arr.ndim == 2:
        return arr[np.newaxis]
    if arr.ndim == 3 and arr.shape[-1] in (3, 4) and arr.shape[0] not in (3, 4):
        return np.moveaxis(arr[..., :3], -1, 0)
    if arr.ndim == 3:
        return arr
    raise ValueError(f"Unsupported image shape {arr.shape}")


def _ome_channel_names(xml: str) -> list[str] | None:
    import re

    names = re.findall(r'<Channel[^>]*?Name="([^"]*)"', xml)
    return names or None


def add_image(sdata, image: str | Path | np.ndarray, name: str, *, modality: str = "generic",
              channel_names: Sequence[str] | None = None, scale_factors: Sequence[int] | None = (2, 2, 2, 2),
              chunks: int = 1024, overwrite: bool = False):
    """Add an H&E / IF / proteomics image to ``sdata.images[name]``.

    The image gets an Identity transform into a coordinate system named
    ``name`` only; :func:`multispace.registration.register_image` later adds the
    transform into ``global``.

    Parameters
    ----------
    image
        Path to a TIFF / OME-TIFF (Akoya ``.qptiff`` works through tifffile) or a
        ``(c, y, x)`` / ``(y, x, 3)`` array.
    modality
        ``"he"``, ``"if"``, ``"proteomics"``, ``"metabolomics"`` or ``"generic"``;
        stored in the provenance and used to pick registration defaults.
    """
    if name in sdata.images and not overwrite:
        raise ValueError(f"sdata.images['{name}'] exists; pass overwrite=True to replace it.")
    from spatialdata.models import Image2DModel
    from spatialdata.transformations import Identity

    if isinstance(image, (str, Path)):
        arr, names = read_image_array(image)
        source = str(image)
    else:
        arr, names, source = _to_cyx(image, None), None, "array"
    names = list(channel_names) if channel_names is not None else names
    if names is None:
        names = ["R", "G", "B"] if modality == "he" and arr.shape[0] == 3 else [f"ch{i}" for i in range(arr.shape[0])]
    # Multiscale only when the image is big enough for the requested pyramid.
    sf = None
    if scale_factors:
        sf, size = [], min(arr.shape[1:])
        for f in scale_factors:
            if size // f < 256:
                break
            size //= f
            sf.append(f)
        sf = sf or None
    element = Image2DModel.parse(arr, dims=("c", "y", "x"), c_coords=names,
                                 transformations={name: Identity()}, scale_factors=sf,
                                 chunks=(1, chunks, chunks) if chunks else None)
    sdata.images[name] = element
    images_meta = sdata.attrs.setdefault(Attrs.ROOT, {}).setdefault("images", {})
    images_meta[name] = {"modality": modality, "source": source, "shape": list(arr.shape)}
    record_step(sdata, f"add_image:{name}", {"modality": modality, "source": source})
    return sdata
