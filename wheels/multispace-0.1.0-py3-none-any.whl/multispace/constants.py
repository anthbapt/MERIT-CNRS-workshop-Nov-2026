"""The multispace data contract.

Every pipeline step reads from and writes to ONE :class:`spatialdata.SpatialData`
object. This module is the single place where the names of its elements and of
the per-cell annotation columns are defined, so that the steps agree with each
other without knowing about each other.

Element names follow the ``spatialdata-io`` reader defaults (Xenium naming),
so scverse tutorials and tools work on a multispace object unchanged.

Rules
-----
* All elements live in the ``global`` coordinate system. Spatial
  transcriptomics (ST) is the reference frame: the ST morphology image has an
  Identity transform into ``global`` and every other image (H&E, IF, ...)
  reaches ``global`` through the transform computed by registration.
* ``tables["table"]`` is always the *active* cell x feature table that
  downstream steps use. When resegmentation replaces it, the previous one is
  kept as ``tables["table_original"]``.
* Steps add columns to ``table.obs``; they never rename or drop columns that
  another step wrote.
* Provenance (which step ran, with what parameters) is recorded in
  ``sdata.attrs["multispace"]``.
"""
from __future__ import annotations

__all__ = ["Keys", "Obs", "Attrs", "Platform"]


class Platform:
    """Supported spatial transcriptomics platforms."""

    XENIUM = "xenium"
    COSMX = "cosmx"
    ATERA = "atera"  # whole-slide Xenium-like data, seam-stitched segmentation
    MERFISH = "merfish"  # import only for now (see README ToDo)

    ALL = (XENIUM, COSMX, ATERA, MERFISH)


class Keys:
    """Names of SpatialData elements."""

    #: Coordinate system shared by every element.
    COORDINATE_SYSTEM = "global"

    # ── images ───────────────────────────────────────────────────────────
    #: ST morphology image (DAPI / membrane stains); the registration reference.
    MORPHOLOGY = "morphology_focus"
    #: Default element name for an imported H&E image.
    HE = "he"
    #: Default element name for an imported IF / spatial proteomics image.
    IF = "if"

    # ── points ───────────────────────────────────────────────────────────
    TRANSCRIPTS = "transcripts"

    # ── shapes / labels ──────────────────────────────────────────────────
    CELL_BOUNDARIES = "cell_boundaries"
    NUCLEUS_BOUNDARIES = "nucleus_boundaries"
    CELL_LABELS = "cell_labels"
    #: Output of resegmentation.
    CELL_BOUNDARIES_RESEG = "cell_boundaries_reseg"
    CELL_LABELS_RESEG = "cell_labels_reseg"
    #: Tissue region polygons from annotation (tumour, stroma, ...).
    REGIONS = "regions"

    # ── tables ───────────────────────────────────────────────────────────
    TABLE = "table"
    TABLE_ORIGINAL = "table_original"


class Obs:
    """Names of per-cell columns in ``tables['table'].obs``."""

    #: spatialdata region / instance keys (set by the readers; do not reuse
    #: ``region`` for tissue regions — spatialdata owns that column).
    REGION_KEY = "region"
    INSTANCE_KEY = "cell_id"

    # module 4 — cell typing
    CELL_TYPE = "cell_type"
    CELL_TYPE_CONFIDENCE = "cell_type_confidence"
    CELL_TYPE_COARSE = "cell_type_coarse"
    CELL_TYPE_FINE = "cell_type_fine"

    # module 5 — tissue region annotation
    TISSUE_REGION = "tissue_region"
    DIST_TO_REGION_BORDER = "tissue_region_border_distance"

    # module 6 — copy number variation
    CNV_SCORE = "cnv_score"
    CNV_CLUSTER = "cnv_cluster"

    #: obsm key for cell centroids in ``global`` coordinates.
    SPATIAL = "spatial"
    #: layer holding raw counts.
    COUNTS_LAYER = "counts"


class Attrs:
    """Keys inside ``sdata.attrs['multispace']``."""

    ROOT = "multispace"
    VERSION = "version"
    PLATFORM = "platform"
    STEPS = "steps"
    REGISTRATION = "registration"
