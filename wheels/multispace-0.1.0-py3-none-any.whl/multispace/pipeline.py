"""End-to-end orchestration in the order of ``docs/pipeline_workflow.png``.

    import (1) → images (1) → registration (3) → segmentation (2)
      → cell_typing (4) → annotation (5) → cnv (6) → analysis (7) → plots (8)

Every step takes the one SpatialData object and returns it. With
``project.checkpoint: true`` the object lives in ``<output_dir>/<name>.zarr``
and is updated on disk after each step, so a run can stop and ``resume``
from the last finished step.
"""
from __future__ import annotations

import logging
import time
from collections.abc import Callable, Sequence
from pathlib import Path

import numpy as np
import pandas as pd

from ._sdata import get_meta, summary
from .config import load_config

logger = logging.getLogger(__name__)

__all__ = ["Pipeline", "STEPS", "run_pipeline"]

#: Pipeline steps in execution order (figure order: registration before resegmentation).
STEPS = ("import", "images", "registration", "segmentation", "cell_typing", "annotation", "cnv", "analysis", "plots")
_DONE_KEY = "pipeline_done"


class Pipeline:
    """Run the multispace workflow from a config file or dict.

    Examples
    --------
    >>> pipe = Pipeline("config.yaml")
    >>> sdata = pipe.run()                         # everything enabled, resuming finished steps
    >>> sdata = pipe.run(steps=["cell_typing"], resume=False)   # re-run one step
    """

    def __init__(self, config, sdata=None):
        self.cfg = load_config(config)
        self.sdata = sdata
        proj = self.cfg["project"]
        self.out = Path(proj["output_dir"])
        self.zarr_path = self.out / f"{proj['name']}.zarr"
        self._steps: dict[str, Callable] = {s: getattr(self, f"_step_{s}") for s in STEPS}

    # ── public ───────────────────────────────────────────────────────────
    def enabled_steps(self) -> list[str]:
        c = self.cfg
        on = {
            "import": True,
            "images": bool(c["images"]),
            "registration": bool(c["registration"]),
            "segmentation": c["segmentation"]["enabled"],
            "cell_typing": c["cell_typing"]["enabled"],
            "annotation": c["annotation"]["enabled"],
            "cnv": c["cnv"]["enabled"],
            "analysis": c["analysis"]["enabled"],
            "plots": c["plots"]["enabled"],
        }
        return [s for s in STEPS if on[s]]

    def run(self, steps: Sequence[str] | None = None, *, resume: bool = True):
        """Run ``steps`` (default: all enabled) and return the SpatialData.

        ``resume=True`` reloads ``<name>.zarr`` when it exists and skips steps
        it records as done; ``resume=False`` re-runs the requested steps.
        """
        self.out.mkdir(parents=True, exist_ok=True)
        todo = list(steps) if steps is not None else self.enabled_steps()
        bad = set(todo) - set(STEPS)
        if bad:
            raise ValueError(f"Unknown steps {sorted(bad)}; choose from {STEPS}")
        todo = [s for s in STEPS if s in todo]  # always in pipeline order

        if self.sdata is None and self.zarr_path.exists() and (resume or "import" not in todo):
            import spatialdata as sd

            logger.info("Loading %s", self.zarr_path)
            self.sdata = sd.read_zarr(str(self.zarr_path))
        done = set(get_meta(self.sdata).get(_DONE_KEY, [])) if self.sdata is not None else set()

        for step in todo:
            if resume and step in done:
                logger.info("✓ %s (done earlier, skipped)", step)
                continue
            if self.sdata is None and step != "import":
                raise RuntimeError(f"Step '{step}' needs data: run 'import' first.")
            t0 = time.time()
            logger.info("▶ %s", step)
            before = _snapshot(self.sdata) if self.sdata is not None else {}
            self.sdata = self._steps[step]() or self.sdata
            meta = get_meta(self.sdata)
            meta[_DONE_KEY] = [s for s in meta.get(_DONE_KEY, []) if s != step] + [step]
            self._checkpoint(before, first=(step == "import"))
            logger.info("✓ %s (%.1fs)", step, time.time() - t0)
        logger.info("Final object:\n%s", summary(self.sdata))
        return self.sdata

    # ── persistence ──────────────────────────────────────────────────────
    def _checkpoint(self, before: dict, first: bool = False) -> None:
        if not self.cfg["project"]["checkpoint"]:
            return
        import spatialdata as sd

        sdata = self.sdata
        if first or not sdata.is_backed() or Path(str(sdata.path)).resolve() != self.zarr_path.resolve():
            sdata.write(str(self.zarr_path), overwrite=True)
            self.sdata = sd.read_zarr(str(self.zarr_path))
            return
        after = _snapshot(sdata)
        on_disk = {name for _, name in _disk_elements(sdata)}
        for name, ident in after.items():
            kind, ename = name
            changed = before.get(name) != ident or kind == "tables"  # tables are edited in place
            if changed:
                if ename in on_disk:
                    # spatialdata refuses to overwrite inside its own store: delete, then write.
                    # Safe because the replaced element is in memory (or backed by another store).
                    sdata.delete_element_from_disk(ename)
                sdata.write_element(ename)
            elif kind in ("images", "labels", "shapes", "points"):
                sdata.write_transformations(ename)  # e.g. registration only changes transforms
        for _, ename in set(before) - set(after):
            if ename in on_disk:
                sdata.delete_element_from_disk(ename)
        sdata.write_attrs()

    def _workdir(self, step: str) -> Path:
        p = self.out / step
        p.mkdir(parents=True, exist_ok=True)
        return p

    # ── steps ────────────────────────────────────────────────────────────
    def _step_import(self):
        from .io import read_st

        inp = self.cfg["input"]
        sdata = read_st(inp["path"], inp["platform"], um_per_unit=inp.get("um_per_unit"),
                        **(inp.get("reader_kwargs") or {}))
        if self.sdata is not None:  # explicit re-import: keep nothing from the old object
            logger.info("Re-importing: previous results in %s will be replaced.", self.zarr_path)
        return sdata

    def _step_images(self):
        from .io import add_image

        for img in self.cfg["images"]:
            add_image(self.sdata, img["path"], img["name"], modality=img.get("modality", "generic"),
                      channel_names=img.get("channel_names"), overwrite=True)
        return self.sdata

    def _step_registration(self):
        from .registration import register_image

        for reg in self.cfg["registration"]:
            kw = {k: v for k, v in reg.items() if k not in ("moving", "landmarks")}
            if reg.get("landmarks") is not None:
                kw["landmarks"] = _read_landmarks(reg["landmarks"])
                kw.setdefault("method", "landmarks")
            res = register_image(self.sdata, reg["moving"], **kw)
            logger.info("  %s → %s: %s", reg["moving"], res.fixed, res.details.get("quality", {}))
        return self.sdata

    def _step_segmentation(self):
        from .constants import Platform
        from .segmentation import resegment, resegment_atera

        seg = self.cfg["segmentation"]
        platform = self.cfg["input"]["platform"]
        if platform == Platform.ATERA:
            return resegment_atera(self.sdata, config_path=seg["atera_config"], phases=seg.get("atera_phases", "all"))
        if not self.zarr_path.exists():  # the legacy code reads from disk
            self.sdata.write(str(self.zarr_path), overwrite=True)
        return resegment(
            self.sdata, zarr_path=self.zarr_path, platform=platform, workdir=self._workdir("resegmentation"),
            channel_names=seg.get("channel_names"), channels_to_use=seg.get("channels_to_use"),
            factor_rescale=seg["factor_rescale"], cellpose=seg.get("cellpose"), proseg=seg.get("proseg", False),
            gene_list_path=seg.get("gene_list_path"), cell_filter=seg.get("cell_filter"),
            preprocess=seg.get("preprocess"), orientation=seg.get("orientation", "check"),
            device=seg.get("device", "auto"))

    def _step_cell_typing(self):
        from .celltyping import annotate_cell_types

        ct = self.cfg["cell_typing"]
        return annotate_cell_types(self.sdata, markers=ct.get("markers"), methods=ct.get("methods"),
                                   normalization=ct.get("normalization", "library_size"),
                                   output_dir=self._workdir("cell_typing"))

    def _step_annotation(self):
        from .annotation import add_regions, assign_regions, read_regions

        ann = self.cfg["annotation"]
        regions = read_regions(ann["regions"], label_field=ann.get("label_field"))
        add_regions(self.sdata, regions, drawn_on=ann.get("drawn_on"))
        return assign_regions(self.sdata, distance_to=ann.get("distance_to"))

    def _step_cnv(self):
        from .cnv import infer_cnv

        c = self.cfg["cnv"]
        return infer_cnv(self.sdata, output_dir=self._workdir("cnv"), reference_key=c["reference_key"],
                         reference_categories=c.get("reference_categories"),
                         **(c.get("params") or {}))

    def _step_analysis(self):
        from .analysis import run_spatial_analysis

        a = self.cfg["analysis"]
        run_spatial_analysis(self.sdata, results_dir=self._workdir("analysis"), sections=a["sections"],
                             groupby=a.get("groupby"), grid_size_um=a.get("grid_size_um"), params=a.get("params"))
        return self.sdata

    def _step_plots(self):
        from .plotting import save_overview

        saved = save_overview(self.sdata, self._workdir("figures"), dpi=self.cfg["plots"].get("dpi", 150))
        logger.info("  %d figures in %s", len(saved), self.out / "figures")
        return self.sdata


def run_pipeline(config, steps: Sequence[str] | None = None, resume: bool = True):
    """Functional shortcut for ``Pipeline(config).run(steps, resume=resume)``."""
    return Pipeline(config).run(steps, resume=resume)


def _snapshot(sdata) -> dict:
    """{(kind, name): identity} of every element, to detect what a step replaced."""
    snap = {}
    for kind in ("images", "labels", "points", "shapes", "tables"):
        for name, el in getattr(sdata, kind).items():
            snap[(kind, name)] = id(el)
    return snap


def _disk_elements(sdata) -> list[tuple[str, str]]:
    """(kind, name) of elements present in the backing zarr."""
    out = []
    for path in sdata.elements_paths_on_disk():
        kind, _, name = path.partition("/")
        out.append((kind, name))
    return out


def _read_landmarks(path_or_array):
    """CSV with fixed_x, fixed_y, moving_x, moving_y (full-resolution pixels)."""
    if not isinstance(path_or_array, (str, Path)):
        a = np.asarray(path_or_array, float)
        return a[:, :2], a[:, 2:4]
    df = pd.read_csv(path_or_array)
    need = ["fixed_x", "fixed_y", "moving_x", "moving_y"]
    missing = [c for c in need if c not in df]
    if missing:
        raise ValueError(f"Landmark file {path_or_array} lacks columns {missing}")
    return df[["fixed_x", "fixed_y"]].to_numpy(float), df[["moving_x", "moving_y"]].to_numpy(float)
