"""multispace — multimodal spatial omics on one SpatialData object.

Pipeline (see ``docs/pipeline_workflow.png``)::

    1 import → 3 registration → 2 resegmentation
      → 4 cell typing · 5 tissue regions · 6 CNV → 7 spatial analysis → 8 plots

Each module exposes one SpatialData-in / SpatialData-out function and the
names they share are defined in :mod:`multispace.constants`. Submodules are
imported lazily so a missing optional dependency only affects its own step.
"""
from __future__ import annotations

import importlib

__version__ = "0.1.0"

from .constants import Attrs, Keys, Obs, Platform  # noqa: E402  (light, always available)

_LAZY = {
    # steps
    "read_st": ("io", "read_st"),
    "add_image": ("io", "add_image"),
    "register_image": ("registration", "register_image"),
    "resegment": ("segmentation", "resegment"),
    "annotate_cell_types": ("celltyping", "annotate_cell_types"),
    "add_regions": ("annotation", "add_regions"),
    "assign_regions": ("annotation", "assign_regions"),
    "infer_cnv": ("cnv", "infer_cnv"),
    "run_spatial_analysis": ("analysis", "run_spatial_analysis"),
    "save_overview": ("plotting", "save_overview"),
    # orchestration
    "Pipeline": ("pipeline", "Pipeline"),
    "run_pipeline": ("pipeline", "run_pipeline"),
    "load_config": ("config", "load_config"),
}
_SUBMODULES = {"io", "registration", "segmentation", "celltyping", "annotation", "cnv", "analysis",
               "plotting", "pipeline", "config", "constants"}

__all__ = ["Keys", "Obs", "Attrs", "Platform", *_LAZY, *_SUBMODULES]


def __getattr__(name):
    if name in _LAZY:
        mod, attr = _LAZY[name]
        return getattr(importlib.import_module(f".{mod}", __name__), attr)
    if name in _SUBMODULES:
        return importlib.import_module(f".{name}", __name__)
    raise AttributeError(f"module 'multispace' has no attribute '{name}'")
