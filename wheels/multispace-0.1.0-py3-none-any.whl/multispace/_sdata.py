"""Shared helpers for reading and writing the multispace SpatialData contract."""
from __future__ import annotations

import datetime as _dt
import importlib
import logging
from collections.abc import Iterable
from typing import Any

import numpy as np
import pandas as pd

from .constants import Attrs, Keys, Obs

logger = logging.getLogger(__name__)

#: Which optional extra provides which import (shown in error messages).
_EXTRA_FOR = {
    "cellpose": "seg",
    "torch": "seg",
    "tensorflow": "seg",
    "rasterio": "seg",
    "mygene": "seg",
    "celltypist": "celltype",
    "scvi": "celltype",
    "infercnvpy": "cnv",
    "insitucnv": "cnv",
    "libpysal": "analysis",
    "esda": "analysis",
    "pointpats": "analysis",
    "astropy": "analysis",
    "porespy": "analysis",
    "ripser": "analysis",
    "ot": "analysis",
    "tkinter": "gui",
    "SimpleITK": "registration",
}


class ContractError(ValueError):
    """Raised when a SpatialData object lacks what a step needs."""


def require(module: str, extra: str | None = None):
    """Import an optional dependency or fail with an install hint."""
    try:
        return importlib.import_module(module)
    except ImportError as err:  # pragma: no cover - depends on environment
        extra = extra or _EXTRA_FOR.get(module.split(".")[0], "all")
        raise ImportError(
            f"This step needs the optional dependency '{module}'. "
            f"Install it with:  pip install 'multispace[{extra}]'"
        ) from err


# ── tables ───────────────────────────────────────────────────────────────────
def get_table(sdata, key: str = Keys.TABLE):
    """Return ``sdata.tables[key]`` or raise a ContractError."""
    if key not in sdata.tables:
        raise ContractError(
            f"SpatialData has no table '{key}'. Available: {list(sdata.tables)}"
        )
    return sdata.tables[key]


def replace_table(sdata, new_table, key: str = Keys.TABLE, keep_previous_as: str | None = Keys.TABLE_ORIGINAL):
    """Make ``new_table`` the active table, keeping the previous one once.

    The first replacement moves the original table to ``keep_previous_as``;
    later replacements overwrite the active table only, so the true original
    is never lost.
    """
    if key in sdata.tables and keep_previous_as and keep_previous_as not in sdata.tables:
        sdata.tables[keep_previous_as] = sdata.tables[key]
    sdata.tables[key] = new_table


def annotated_region(table) -> str | list[str] | None:
    """Element(s) a table annotates, from its spatialdata attrs."""
    attrs = table.uns.get("spatialdata_attrs", {})
    return attrs.get("region")


def ensure_spatial(sdata, table_key: str = Keys.TABLE, coordinate_system: str = Keys.COORDINATE_SYSTEM,
                   recompute: bool = False):
    """Make sure ``table.obsm['spatial']`` holds cell centroids in ``coordinate_system``.

    Vendor readers often store centroids in microns (Xenium ``x_centroid``)
    while ``global`` is in morphology-image pixels, so the centroids are
    recomputed from the shapes / labels the table annotates (the authoritative
    geometry) and the table is marked with ``uns['multispace_spatial']``. Any
    previous ``obsm['spatial']`` is kept as ``obsm['spatial_vendor']``.
    """
    table = get_table(sdata, table_key)
    marker = table.uns.get("multispace_spatial")
    if not recompute and marker == coordinate_system and Obs.SPATIAL in table.obsm:
        return np.asarray(table.obsm[Obs.SPATIAL])

    region = annotated_region(table)
    if isinstance(region, (list, tuple, np.ndarray)):
        region = region[0] if len(region) == 1 else None
    if region is not None and region in sdata:
        from spatialdata import get_centroids

        cent = get_centroids(sdata[region], coordinate_system=coordinate_system)
        cent = cent.compute() if hasattr(cent, "compute") else cent
        ikey = table.uns["spatialdata_attrs"]["instance_key"]
        ids = table.obs[ikey].to_numpy()
        lookup = pd.Series(np.arange(len(cent)), index=cent.index.astype(str))
        pos = lookup.reindex(pd.Index(ids).astype(str)).to_numpy()
        xy = np.full((len(ids), 2), np.nan)
        ok = ~np.isnan(pos)
        xy[ok] = cent[["x", "y"]].to_numpy(dtype=float)[pos[ok].astype(int)]
        if (~ok).any():
            logger.warning("%d of %d cells have no geometry in '%s'", int((~ok).sum()), len(ids), region)
        if ok.any():
            if Obs.SPATIAL in table.obsm and "spatial_vendor" not in table.obsm:
                table.obsm["spatial_vendor"] = np.asarray(table.obsm[Obs.SPATIAL])
            table.obsm[Obs.SPATIAL] = xy
            table.uns["multispace_spatial"] = coordinate_system
            return xy

    if Obs.SPATIAL in table.obsm and len(table.obsm[Obs.SPATIAL]) == table.n_obs:
        logger.warning("Using existing obsm['spatial'] for '%s'; cannot verify it is in '%s'.",
                       table_key, coordinate_system)
        return np.asarray(table.obsm[Obs.SPATIAL])[:, :2]
    for x, y in (("centroid_x", "centroid_y"), ("x", "y"), ("x_centroid", "y_centroid")):
        if x in table.obs and y in table.obs:
            logger.warning("Using obs['%s','%s'] as coordinates; cannot verify they are in '%s'.",
                           x, y, coordinate_system)
            xy = table.obs[[x, y]].to_numpy(dtype=float)
            table.obsm[Obs.SPATIAL] = xy
            return xy
    raise ContractError(f"Cannot locate the cells of table '{table_key}'.")


def um_per_unit(sdata, default: float | None = None) -> float:
    """Microns per ``global`` unit (set at import; used to convert µm parameters)."""
    val = _root(sdata).get("um_per_unit")
    if val is None:
        if default is None:
            raise ContractError("Unknown physical scale: set sdata.attrs['multispace']['um_per_unit'] "
                                "(io.read_st does this for Xenium; pass um_per_unit for other platforms).")
        return float(default)
    return float(val)


# ── provenance ───────────────────────────────────────────────────────────────
def _root(sdata) -> dict:
    from . import __version__

    attrs = sdata.attrs if getattr(sdata, "attrs", None) is not None else {}
    root = attrs.setdefault(Attrs.ROOT, {})
    root.setdefault(Attrs.VERSION, __version__)
    root.setdefault(Attrs.STEPS, [])
    return root


def get_meta(sdata) -> dict:
    """The ``sdata.attrs['multispace']`` provenance dict (created if missing)."""
    return _root(sdata)


def record_step(sdata, name: str, params: dict[str, Any] | None = None, **outputs: Any) -> None:
    """Append a provenance entry for a finished step."""
    entry = {
        "step": name,
        "time": _dt.datetime.now().isoformat(timespec="seconds"),
        "params": _jsonable(params or {}),
        "outputs": _jsonable(outputs),
    }
    _root(sdata)[Attrs.STEPS].append(entry)


def completed_steps(sdata) -> list[str]:
    return [s["step"] for s in _root(sdata).get(Attrs.STEPS, [])]


def _jsonable(obj):
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.generic,)):
        return obj.item()
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    return str(obj)


# ── validation ───────────────────────────────────────────────────────────────
def validate(sdata, *, images: Iterable[str] = (), shapes: Iterable[str] = (), points: Iterable[str] = (),
             tables: Iterable[str] = (), obs: Iterable[str] = (), step: str = "") -> None:
    """Raise a ContractError listing every missing element / column."""
    missing = []
    for kind, names in (("images", images), ("shapes", shapes), ("points", points), ("tables", tables)):
        have = getattr(sdata, kind)
        missing += [f"{kind}['{n}']" for n in names if n not in have]
    obs = list(obs)
    if obs:
        if Keys.TABLE not in sdata.tables:
            missing.append(f"tables['{Keys.TABLE}']")
        else:
            cols = sdata.tables[Keys.TABLE].obs.columns
            missing += [f"table.obs['{c}']" for c in obs if c not in cols]
    if missing:
        where = f" for step '{step}'" if step else ""
        raise ContractError(f"SpatialData is missing {', '.join(missing)}{where}.")


def summary(sdata) -> str:
    """One-line-per-element description, used by the CLI."""
    lines = []
    for kind in ("images", "labels", "points", "shapes", "tables"):
        for name in getattr(sdata, kind):
            lines.append(f"{kind:7s} {name}")
    steps = completed_steps(sdata)
    if steps:
        lines.append("steps   " + " → ".join(steps))
    return "\n".join(lines)
