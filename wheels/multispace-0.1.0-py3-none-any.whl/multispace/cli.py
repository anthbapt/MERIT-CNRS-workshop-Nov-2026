"""Command line interface: ``multispace run | validate | init-config | info | steps``."""
from __future__ import annotations

import argparse
import logging
import sys
from importlib import resources
from pathlib import Path


def _setup_logging(level: str) -> None:
    logging.basicConfig(level=getattr(logging, level.upper(), logging.INFO),
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s", datefmt="%H:%M:%S")


def _cmd_run(a) -> int:
    from .config import load_config
    from .pipeline import Pipeline

    cfg = load_config(a.config)
    _setup_logging(a.log_level or cfg["project"].get("log_level", "INFO"))
    steps = a.steps.split(",") if a.steps else None
    Pipeline(cfg).run(steps, resume=not a.no_resume)
    return 0


def _cmd_validate(a) -> int:
    from .config import load_config
    from .pipeline import Pipeline

    pipe = Pipeline(load_config(a.config))
    print("Config OK. Steps that will run:", " → ".join(pipe.enabled_steps()))
    print("Output:", pipe.zarr_path)
    return 0


def _cmd_init(a) -> int:
    text = resources.files("multispace").joinpath("data", f"example_{a.platform}.yaml").read_text()
    if a.output:
        Path(a.output).write_text(text)
        print(f"Wrote {a.output}")
    else:
        sys.stdout.write(text)
    return 0


def _cmd_info(a) -> int:
    import spatialdata as sd

    from ._sdata import get_meta, summary

    sdata = sd.read_zarr(a.zarr)
    print(summary(sdata))
    meta = get_meta(sdata)
    for k in ("platform", "um_per_unit", "pipeline_done"):
        if k in meta:
            print(f"{k:8s}", meta[k])
    return 0


def _cmd_steps(_a) -> int:
    from .pipeline import STEPS

    print(" → ".join(STEPS))
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="multispace", description="Multimodal spatial omics pipeline on SpatialData.")
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="run the pipeline from a YAML config")
    r.add_argument("config")
    r.add_argument("--steps", help="comma-separated subset, e.g. cell_typing,analysis")
    r.add_argument("--no-resume", action="store_true", help="re-run steps already recorded as done")
    r.add_argument("--log-level", default=None)
    r.set_defaults(func=_cmd_run)

    v = sub.add_parser("validate", help="check a config without running it")
    v.add_argument("config")
    v.set_defaults(func=_cmd_validate)

    i = sub.add_parser("init-config", help="print an example config")
    i.add_argument("--platform", default="xenium", choices=["xenium", "cosmx"])
    i.add_argument("-o", "--output")
    i.set_defaults(func=_cmd_init)

    n = sub.add_parser("info", help="summarise a multispace .zarr")
    n.add_argument("zarr")
    n.set_defaults(func=_cmd_info)

    s = sub.add_parser("steps", help="list pipeline steps in order")
    s.set_defaults(func=_cmd_steps)

    a = p.parse_args(argv)
    try:
        return a.func(a)
    except Exception as err:  # concise message for config / contract errors
        from ._sdata import ContractError
        from .config import ConfigError

        if isinstance(err, (ConfigError, ContractError, FileNotFoundError)):
            print(f"error: {err}", file=sys.stderr)
            return 2
        raise


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
