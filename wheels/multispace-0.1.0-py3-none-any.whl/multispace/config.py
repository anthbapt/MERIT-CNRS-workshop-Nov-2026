"""Pipeline configuration (YAML) with defaults and validation.

A config has one block per pipeline step; a step whose block is missing,
``null`` or has ``enabled: false`` is skipped. ``multispace init-config``
writes a commented example (``configs/example_xenium.yaml``).
"""
from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

import yaml

from .constants import Keys, Platform

__all__ = ["DEFAULTS", "load_config", "validate_config", "ConfigError"]


class ConfigError(ValueError):
    pass


DEFAULTS: dict[str, Any] = {
    "project": {"name": "sample", "output_dir": "multispace_out", "checkpoint": True, "log_level": "INFO"},
    "input": {"platform": Platform.XENIUM, "path": None, "um_per_unit": None, "reader_kwargs": {}},
    "images": [],  # [{name, path, modality, channel_names}]
    "registration": [],  # [{moving, fixed, method, landmarks, ...register_image kwargs}]
    "segmentation": {"enabled": False, "factor_rescale": 4, "channel_names": None, "channels_to_use": None,
                     "cellpose": {}, "proseg": False, "gene_list_path": None, "cell_filter": None, "preprocess": None, "orientation": "check", "device": "auto",
                     "atera_config": None},
    "cell_typing": {"enabled": True, "markers": None, "methods": None, "normalization": "library_size"},
    "annotation": {"enabled": False, "regions": None, "drawn_on": None, "distance_to": None, "label_field": None},
    "cnv": {"enabled": False, "reference_key": "cell_type", "reference_categories": None,
            "params": {}},
    "analysis": {"enabled": True, "sections": ["composition", "neighborhood", "pseudobulk"],
                 "groupby": None, "grid_size_um": None, "params": {}},
    "plots": {"enabled": True, "dpi": 150},
}

_TOP = set(DEFAULTS)


def _merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(config: str | Path | dict) -> dict:
    """Read a YAML file (or dict), fill defaults, resolve paths relative to the file."""
    base_dir = Path.cwd()
    if isinstance(config, (str, Path)):
        path = Path(config)
        base_dir = path.resolve().parent
        raw = yaml.safe_load(path.read_text()) or {}
    else:
        raw = copy.deepcopy(config)
    unknown = set(raw) - _TOP
    if unknown:
        raise ConfigError(f"Unknown config sections {sorted(unknown)}; expected {sorted(_TOP)}")
    cfg = _merge(DEFAULTS, raw)
    # A block given as null means "skip"
    for key in ("segmentation", "cell_typing", "annotation", "cnv", "analysis", "plots"):
        if key in raw and raw[key] is None:
            cfg[key] = {**DEFAULTS[key], "enabled": False}
        elif key in raw and isinstance(raw[key], dict) and "enabled" not in raw[key]:
            cfg[key]["enabled"] = True  # writing a block switches the step on
    _resolve_paths(cfg, base_dir)
    validate_config(cfg)
    return cfg


def _resolve(p, base: Path):
    if p is None or (isinstance(p, str) and "://" in p):
        return p
    p = Path(p).expanduser()
    return str(p if p.is_absolute() else (base / p))


def _resolve_paths(cfg: dict, base: Path) -> None:
    cfg["project"]["output_dir"] = _resolve(cfg["project"]["output_dir"], base)
    cfg["input"]["path"] = _resolve(cfg["input"]["path"], base)
    for img in cfg["images"]:
        img["path"] = _resolve(img.get("path"), base)
    for reg in cfg["registration"]:
        if isinstance(reg.get("landmarks"), str):
            reg["landmarks"] = _resolve(reg["landmarks"], base)
    seg = cfg["segmentation"]
    seg["gene_list_path"] = _resolve(seg.get("gene_list_path"), base)
    seg["atera_config"] = _resolve(seg.get("atera_config"), base)
    ann = cfg["annotation"]
    if isinstance(ann.get("regions"), str):
        ann["regions"] = _resolve(ann["regions"], base)
    ct = cfg["cell_typing"]
    if isinstance(ct.get("markers"), str):
        ct["markers"] = _resolve(ct["markers"], base)
    gs = cfg["analysis"]["params"].get("gene_sets")
    if isinstance(gs, str) and gs.endswith(".gmt"):
        cfg["analysis"]["params"]["gene_sets"] = _resolve(gs, base)


def validate_config(cfg: dict) -> None:
    """Raise ConfigError for anything that would fail later in the run."""
    errs = []
    if not cfg["input"].get("path"):
        errs.append("input.path is required")
    if cfg["input"]["platform"] not in Platform.ALL:
        errs.append(f"input.platform must be one of {Platform.ALL}")
    names = set()
    for i, img in enumerate(cfg["images"]):
        if not img.get("name") or not img.get("path"):
            errs.append(f"images[{i}] needs name and path")
        names.add(img.get("name"))
    for i, reg in enumerate(cfg["registration"]):
        if reg.get("moving") not in names:
            errs.append(f"registration[{i}].moving '{reg.get('moving')}' is not listed under images")
        if reg.get("method", "affine") == "landmarks" and not reg.get("landmarks"):
            errs.append(f"registration[{i}] uses method 'landmarks' but gives no landmarks file")
    seg = cfg["segmentation"]
    if seg.get("enabled") and cfg["input"]["platform"] == Platform.ATERA and not seg.get("atera_config"):
        errs.append("segmentation.atera_config is required for Atera data")
    if seg.get("enabled") and cfg["input"]["platform"] == Platform.MERFISH:
        errs.append("segmentation is not adapted to MERFISH yet; disable it")
    ann = cfg["annotation"]
    if ann.get("enabled") and not ann.get("regions"):
        errs.append("annotation.regions (GeoJSON path) is required when annotation is enabled")
    if ann.get("drawn_on") and ann["drawn_on"] not in names | {Keys.MORPHOLOGY}:
        errs.append(f"annotation.drawn_on '{ann['drawn_on']}' is not an image in the config")
    if cfg["cnv"].get("enabled") and not cfg["cell_typing"].get("enabled") and cfg["cnv"]["reference_key"] == "cell_type":
        errs.append("cnv uses cell_type as reference: enable cell_typing or set cnv.reference_key")
    if errs:
        raise ConfigError("Invalid config:\n  - " + "\n  - ".join(errs))
