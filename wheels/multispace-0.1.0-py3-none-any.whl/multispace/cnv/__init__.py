"""Module 6 — copy number variation (InSituCNV + inferCNVpy, ``pip install 'multispace[cnv]'``)."""
from .api import infer_cnv

__all__ = ["infer_cnv"]
