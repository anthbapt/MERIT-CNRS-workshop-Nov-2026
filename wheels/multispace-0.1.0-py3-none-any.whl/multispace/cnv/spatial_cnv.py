#!/usr/bin/env python3
"""Reusable spatial CNV analysis functions for caller-supplied AnnData.

This module implements the InSituCNV + inferCNVpy workflow used by the
spatial_Test scripts, while accepting an existing AnnData object instead of
assuming a particular dataset or on-disk layout.

Core requirements in the selected ``smo_py313`` environment:
``anndata``, ``scanpy``, ``infercnvpy`` and ``insitucnv``. The last two are
loaded only when the corresponding analysis function is called. Nothing is
installed automatically.

Example (from Python)::

    from spatial_cnv import run_spatial_cnv
    result = run_spatial_cnv(
        adata, output_dir="results/cnv/sample1",
        reference_key="cell_type", reference_categories=["T", "B", "Myeloid"],
    )

Expected input: raw counts in ``adata.layers['counts']`` (or an explicitly
selected raw layer / integer-count ``adata.X``), spatial coordinates in
``adata.obsm['spatial']`` or coordinate columns in ``adata.obs``, genomic gene
coordinates in ``adata.var`` or inferCNVpy-supported gene identifiers, and a
reference annotation in ``adata.obs``.
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

DEFAULT_EXCLUDED_REFERENCE_PATTERNS = (
    r"epithelial", r"tumou?r", r"malignan", r"cancer", r"carcinoma", r"hepatocyte",
)


def select_reference_categories(
    adata,
    *,
    reference_key: str,
    reference_categories: Sequence[str] | None = None,
    exclude_patterns: Sequence[str] = DEFAULT_EXCLUDED_REFERENCE_PATTERNS,
    case_sensitive: bool = False,
) -> list[str]:
    """Select present reference labels, defaulting to non-epithelial/non-tumor.

    Pass ``reference_categories`` to explicitly choose labels. Otherwise all
    observed categories not matching ``exclude_patterns`` are references.
    Patterns are regular expressions and can be changed or disabled with an
    empty sequence.
    """
    import re

    if reference_key not in adata.obs:
        raise KeyError(f"Missing reference annotation adata.obs[{reference_key!r}].")
    present = list(pd.unique(adata.obs[reference_key].dropna().astype(str)))
    if reference_categories is not None:
        requested = [str(cat) for cat in reference_categories]
        selected = [cat for cat in requested if cat in set(present)]
    else:
        flags = 0 if case_sensitive else re.IGNORECASE
        selected = [
            label for label in present
            if not any(re.search(pattern, label, flags=flags) for pattern in exclude_patterns)
        ]
    if not selected:
        raise ValueError(
            f"No reference categories selected in adata.obs[{reference_key!r}]. "
            f"Observed labels: {sorted(present)}. Customize reference_categories "
            "or exclude_patterns."
        )
    return selected


def _analysis_imports():
    """Import analysis dependencies with a useful, non-installing error."""
    try:
        import anndata as ad
        import infercnvpy as cnv
        import insitucnv as icv
        import matplotlib.pyplot as plt
        import scanpy as sc
    except ImportError as exc:
        missing = exc.name or "a required package"
        raise ImportError(
            f"Spatial CNV analysis needs {missing!r}. No packages were installed. "
            "Install infercnvpy and insitucnv into the smo_py313 environment "
            "after approval, then rerun."
        ) from exc
    return ad, cnv, icv, plt, sc


def _matrix_max(matrix: Any) -> float:
    value = matrix.max()
    return float(value.toarray().max() if hasattr(value, "toarray") else value)


def prepare_adata(
    adata,
    *,
    raw_layer: str = "counts",
    reference_key: str,
    reference_categories: Sequence[str] | None = None,
    coordinate_columns: Sequence[tuple[str, str]] = (
        ("x", "y"), ("x_centroid", "y_centroid"), ("x_shifted", "y_shifted")
    ),
    min_genes: int = 10,
    min_cells: int = 10,
    max_cells: int | None = None,
    random_seed: int = 0,
):
    """Copy, validate and standardize a custom AnnData for CNV analysis.

    Raw counts are preserved in ``layers['raw_counts']``. Coordinates are
    copied from the first matching obs coordinate pair when needed. Returns
    ``(prepared_adata, selected_reference_categories)``.
    """
    _, _, _, _, sc = _analysis_imports()
    work = adata.copy()
    if reference_key not in work.obs:
        raise KeyError(f"Missing reference annotation adata.obs[{reference_key!r}].")

    if raw_layer in work.layers:
        work.layers["raw_counts"] = work.layers[raw_layer].copy()
    else:
        x = work.X
        integer = np.issubdtype(x.dtype, np.integer)
        if integer or _matrix_max(x) > 50:
            work.layers["raw_counts"] = x.copy()
        else:
            raise ValueError(
                f"Raw counts not found in layers[{raw_layer!r}] and adata.X does "
                "not look like raw counts. Supply an untransformed count layer."
            )

    if "spatial" not in work.obsm:
        for x_col, y_col in coordinate_columns:
            if x_col in work.obs and y_col in work.obs:
                work.obsm["spatial"] = work.obs[[x_col, y_col]].to_numpy()
                break
    if "spatial" not in work.obsm:
        raise KeyError("Spatial coordinates missing: provide obsm['spatial'] or x/y obs columns.")
    xy = np.asarray(work.obsm["spatial"])
    if xy.ndim != 2 or xy.shape[0] != work.n_obs or xy.shape[1] < 2:
        raise ValueError("obsm['spatial'] must have one row per cell and at least two columns.")
    if not np.isfinite(xy[:, :2]).all():
        raise ValueError("Spatial coordinates contain NaN or infinite values.")

    work.obs[reference_key] = work.obs[reference_key].astype("category")
    refs = select_reference_categories(
        work, reference_key=reference_key, reference_categories=reference_categories,
    )

    sc.pp.filter_cells(work, min_genes=min_genes)
    sc.pp.filter_genes(work, min_cells=min_cells)
    if max_cells is not None and work.n_obs > max_cells:
        sc.pp.subsample(work, n_obs=max_cells, random_state=random_seed)
    if work.n_obs == 0 or work.n_vars == 0:
        raise ValueError("Filtering left no cells or genes for CNV analysis.")
    return work, refs


def _run_infercnv(
    adata,
    cnv,
    icv,
    *,
    reference_key: str,
    reference_categories: Sequence[str],
    window_size: int,
    step: int,
    lfc_clip: float,
    chunksize: int,
    exclude_chromosomes: Sequence[str] = ("chrY",),
):
    adata.X = adata.layers["M"].copy()
    import scanpy as sc
    sc.pp.normalize_total(adata)
    sc.pp.log1p(adata)
    adata = icv.pp.add_genomic_positions(adata)
    cnv.tl.infercnv(
        adata,
        window_size=window_size,
        step=step,
        lfc_clip=lfc_clip,
        reference_key=reference_key,
        reference_cat=list(reference_categories),
        chunksize=chunksize,
        calculate_gene_values=True,
        exclude_chromosomes=tuple(exclude_chromosomes) if exclude_chromosomes else (),
    )
    return adata


def cluster_cnv(adata, cnv, *, resolutions=(0.1, 0.2, 0.3), resolution: float | None = None,
                output_dir: str | Path | None = None):
    """Calculate CNV embedding/neighbors and Leiden clusters.

    If available, InSituCNV's optimal-resolution metrics are written to disk
    and used to select resolution. Otherwise the first configured resolution
    is used. Returns ``(adata, cluster_key, metrics_dataframe)``.
    """
    cnv.tl.pca(adata)
    cnv.pp.neighbors(adata)
    metrics = pd.DataFrame()
    try:
        from insitucnv.analysis import find_optimal_clustering
        metrics = find_optimal_clustering(
            adata, resolutions=list(resolutions), obsm_key="X_cnv", spatial_key="spatial"
        )
    except (ImportError, AttributeError):
        pass
    if output_dir is not None:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        if not metrics.empty:
            metrics.to_csv(Path(output_dir) / "cluster_resolution_metrics.csv", index=False)
    if resolution is None:
        if not metrics.empty:
            try:
                from insitucnv.workflow import select_best_resolution
                resolution = float(select_best_resolution(metrics))
            except (ImportError, AttributeError, ValueError, TypeError):
                resolution = float(resolutions[0])
        else:
            resolution = float(resolutions[0])
    cluster_key = f"cnv_leiden_{resolution:g}"
    cnv.tl.leiden(adata, resolution=resolution, key_added=cluster_key)
    summary = adata.obs[cluster_key].astype(str).value_counts().sort_index()
    summary.rename_axis(cluster_key).to_frame("n_cells").to_csv(
        (Path(output_dir) if output_dir is not None else Path.cwd()) / f"{cluster_key}_cluster_summary.csv"
    )
    return adata, cluster_key, metrics


def save_cnv_plots(adata, cnv, output_dir: str | Path, *, reference_key: str,
                   cluster_key: str | None = None, point_size: float = 12,
                   color_keys: Sequence[str] = (), copper_keys: Sequence[str] = ()):
    """Save spatial annotation/cluster plots and inferCNV chromosome heatmap."""
    _, _, _, plt, sc = _analysis_imports()
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    keys = [reference_key]
    if cluster_key:
        keys.append(cluster_key)
    keys.extend(color_keys)
    keys.extend(key for key in copper_keys if key in adata.obs)
    for key in dict.fromkeys(keys):
        if key not in adata.obs:
            continue
        sc.pl.embedding(adata, basis="spatial", color=key, frameon=False,
                        size=point_size, show=False)
        plt.savefig(out / f"spatial_{key}.png", dpi=150, bbox_inches="tight")
        plt.close()
    if cluster_key:
        if f"dendrogram_{cluster_key}" not in adata.uns:
            sc.tl.dendrogram(adata, groupby=cluster_key)
        cnv.pl.chromosome_heatmap(
            adata, groupby=cluster_key, dendrogram=True,
            vmin=-0.4, vmax=0.4, show=False,
        )
        plt.savefig(out / f"chromosome_heatmap_{cluster_key}.png", dpi=150, bbox_inches="tight")
        plt.close()


def summarize_cluster_annotations(adata, *, cluster_key: str, annotation_keys: Sequence[str],
                                  output_dir: str | Path):
    """Write cluster-by-annotation counts, row percentages and heatmaps."""
    _, _, _, plt, _ = _analysis_imports()
    try:
        import seaborn as sns
    except ImportError as exc:
        raise ImportError("Cluster annotation heatmaps require seaborn; no packages installed.") from exc
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    result = {}
    for key in annotation_keys:
        if key not in adata.obs:
            continue
        counts = pd.crosstab(adata.obs[cluster_key], adata.obs[key], dropna=False)
        pct = counts.div(counts.sum(axis=1).replace(0, np.nan), axis=0).mul(100).fillna(0)
        stem = f"crosstab_{cluster_key}_vs_{key}"
        counts.to_csv(out / f"{stem}_counts.csv")
        pct.to_csv(out / f"{stem}_percent.csv")
        fig, ax = plt.subplots(figsize=(max(7, 0.5 * pct.shape[1] + 3), max(4, 0.45 * pct.shape[0] + 2)))
        sns.heatmap(pct, cmap="viridis", annot=pct.size <= 150, fmt=".1f", ax=ax,
                    cbar_kws={"label": "% within CNV cluster"})
        ax.set(title=f"{key} composition by {cluster_key}", xlabel=key, ylabel="CNV cluster")
        fig.tight_layout()
        fig.savefig(out / f"{stem}.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
        result[key] = {"counts": counts, "percent": pct}
    return result


def metal_cluster_summary(adata, *, cluster_key: str, metal_keys: Sequence[str],
                          output_dir: str | Path):
    """Summarize numeric metal channels by CNV cluster with CSV and bar plots.

    This operates on per-cell obs measurements. Spatial density correlation
    requires image/grid-level metal maps and is intentionally not inferred from
    cell averages.
    """
    _, _, _, plt, _ = _analysis_imports()
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for key in metal_keys:
        if key not in adata.obs:
            continue
        values = pd.to_numeric(adata.obs[key], errors="coerce")
        frame = pd.DataFrame({cluster_key: adata.obs[cluster_key].astype(str), "value": values})
        grouped = frame.groupby(cluster_key, observed=True)["value"].agg(["count", "mean", "median", "std"])
        grouped.to_csv(out / f"{key}_by_{cluster_key}.csv")
        rows.extend({"channel": key, "cluster": idx, **row.to_dict()} for idx, row in grouped.iterrows())
        ax = grouped["mean"].plot(kind="bar", figsize=(max(6, len(grouped) * 0.7), 4),
                                   ylabel=f"Mean {key}", title=f"{key} by CNV cluster")
        fig = ax.figure
        fig.tight_layout()
        fig.savefig(out / f"{key}_by_{cluster_key}.png", dpi=150, bbox_inches="tight")
        plt.close(fig)
    summary = pd.DataFrame(rows)
    summary.to_csv(out / "metal_by_cnv_cluster.csv", index=False)
    return summary


def slim_cnv_adata(adata, *, cluster_key: str | None = None):
    """Return a compact AnnData retaining counts, annotations and CNV outputs."""
    ad, _, _, _, _ = _analysis_imports()
    counts = adata.layers.get("counts", adata.layers.get("raw_counts", adata.X)).copy()
    slim = ad.AnnData(X=counts, obs=adata.obs.copy(), var=adata.var.copy())
    slim.layers["counts"] = counts
    for key in ("spatial", "X_cnv"):
        if key in adata.obsm:
            arr = adata.obsm[key]
            slim.obsm[key] = arr if hasattr(arr, "toarray") else np.asarray(arr, dtype=np.float32)
    var_cols = [k for k in ("gene_name", "chromosome", "start", "end") if k in slim.var]
    if var_cols:
        slim.var = slim.var[var_cols].copy()
    slim.uns = {k: v for k, v in adata.uns.items()
                if k.startswith("cnv") or (cluster_key and k == f"dendrogram_{cluster_key}")}
    return slim


def run_spatial_cnv(
    adata,
    *,
    output_dir: str | Path,
    reference_key: str,
    reference_categories: Sequence[str] | None = None,
    raw_layer: str = "counts",
    smoothing_neighbors: int = 20,
    expression_neighbors: int = 15,
    window_size: int = 60,
    step: int = 10,
    lfc_clip: float = 4,
    chunksize: int = 1000,
    resolutions: Sequence[float] = (0.1, 0.2, 0.3),
    resolution: float | None = None,
    max_cells: int | None = None,
    random_seed: int = 0,
    min_genes: int = 10,
    min_cells: int = 10,
    copper_keys: Sequence[str] = (),
    annotation_keys: Sequence[str] = (),
    metal_keys: Sequence[str] = (),
    save_result: bool = True,
    slim_result: bool = True,
):
    """Run prepare → spatial smoothing → inferCNV → clustering → plots.

    Input is copied and not mutated. Returns the full working AnnData with CNV
    results; writes plots, summaries, run metadata and (optionally)
    ``adata_cnv_results.h5ad`` under output_dir. Set ``slim_result=False`` to
    save the full working AnnData, including intermediate layers.
    """
    ad, cnv, icv, _, sc = _analysis_imports()
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    try:
        sc.set_figure_params(dpi=120, facecolor="white")
    except AttributeError:
        sc.settings.set_figure_params(dpi=120, facecolor="white")
    work, refs = prepare_adata(
        adata, raw_layer=raw_layer, reference_key=reference_key,
        reference_categories=reference_categories, min_genes=min_genes,
        min_cells=min_cells, max_cells=max_cells, random_seed=random_seed,
    )
    work.X = work.layers["raw_counts"].copy()
    sc.pp.normalize_total(work)
    work.layers["norm"] = work.X.copy()
    sc.pp.log1p(work)
    sc.pp.pca(work)
    sc.pp.neighbors(work, n_neighbors=expression_neighbors)
    icv.tl.smooth_data_for_cnv(work, layer_w_norm_counts="norm", n_neighbors=smoothing_neighbors)
    work.layers["smooth_norm"] = work.layers["M"].copy()
    work = _run_infercnv(
        work, cnv, icv, reference_key=reference_key, reference_categories=refs,
        window_size=window_size, step=step, lfc_clip=lfc_clip, chunksize=chunksize,
    )
    work, cluster_key, metrics = cluster_cnv(
        work, cnv, resolutions=resolutions, resolution=resolution, output_dir=out,
    )
    save_cnv_plots(work, cnv, out / "figures", reference_key=reference_key,
                   cluster_key=cluster_key, copper_keys=copper_keys)
    annotations = summarize_cluster_annotations(
        work, cluster_key=cluster_key,
        annotation_keys=list(dict.fromkeys([*annotation_keys, reference_key])),
        output_dir=out / "summaries",
    ) if annotation_keys or reference_key else {}
    metals = metal_cluster_summary(work, cluster_key=cluster_key, metal_keys=metal_keys,
                                   output_dir=out / "summaries") if metal_keys else pd.DataFrame()
    if save_result:
        result_path = out / "adata_cnv_results.h5ad"
        saved = slim_cnv_adata(work, cluster_key=cluster_key) if slim_result else work
        saved.write_h5ad(result_path, compression="gzip")
    else:
        result_path = None
    summary = {
        "n_cells": int(work.n_obs), "n_genes": int(work.n_vars),
        "reference_key": reference_key, "reference_categories": refs,
        "cluster_key": cluster_key, "resolution": float(cluster_key.removeprefix("cnv_leiden_")),
        "smoothing_neighbors": int(smoothing_neighbors), "window_size": int(window_size),
        "step": int(step), "lfc_clip": float(lfc_clip), "result_path": str(result_path) if result_path else None,
    }
    (out / "run_summary.json").write_text(json.dumps(summary, indent=2))
    work.uns["spatial_cnv_run_summary"] = summary
    # Keep summaries accessible on the returned object as well.
    return work


def main(argv: Sequence[str] | None = None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Annotated input .h5ad")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--reference-key", required=True)
    parser.add_argument("--reference-categories", nargs="+", default=None)
    parser.add_argument("--raw-layer", default="counts")
    parser.add_argument("--resolution", type=float, default=None)
    parser.add_argument("--max-cells", type=int, default=None)
    parser.add_argument("--no-slim-result", action="store_true",
                        help="Save full result AnnData, retaining intermediate layers")
    parser.add_argument("--annotation-keys", nargs="*", default=[])
    parser.add_argument("--metal-keys", nargs="*", default=[])
    parser.add_argument("--copper-keys", nargs="*", default=[])
    args = parser.parse_args(argv)
    try:
        import anndata as ad
    except ImportError as exc:
        raise SystemExit("Reading h5ad requires anndata in smo_py313.") from exc
    data = ad.read_h5ad(args.input)
    run_spatial_cnv(
        data, output_dir=args.output_dir, reference_key=args.reference_key,
        reference_categories=args.reference_categories, raw_layer=args.raw_layer,
        resolution=args.resolution, max_cells=args.max_cells,
        annotation_keys=args.annotation_keys, metal_keys=args.metal_keys,
        copper_keys=args.copper_keys, slim_result=not args.no_slim_result,
    )


if __name__ == "__main__":
    main()
