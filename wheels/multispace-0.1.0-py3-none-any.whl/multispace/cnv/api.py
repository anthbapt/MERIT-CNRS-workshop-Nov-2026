"""Module 6 — copy number variation, wired into the SpatialData contract.

Runs the InSituCNV + inferCNVpy workflow (:func:`multispace.cnv.spatial_cnv.run_spatial_cnv`)
on the active table, using cell types from module 4 as the normal reference,
and writes back per cell:

* ``cnv_score``   — mean absolute CNV signal per cell (``X_cnv``);
* ``cnv_cluster`` — CNV leiden cluster.

Genomic positions come from the reference bundled with ``insitucnv``
(genes without a position are dropped). Cells removed by the CNV QC filters get NaN. Full results (``X_cnv``,
plots, summaries) stay in ``output_dir``.
"""
from __future__ import annotations

import logging
from collections.abc import Sequence
from pathlib import Path

import numpy as np
import pandas as pd

from .._sdata import ContractError, ensure_spatial, get_table, record_step, require
from ..constants import Keys, Obs

logger = logging.getLogger(__name__)

__all__ = ["infer_cnv"]


def infer_cnv(
    sdata,
    *,
    output_dir: str | Path,
    reference_key: str = Obs.CELL_TYPE,
    reference_categories: Sequence[str] | None = None,
    table: str = Keys.TABLE,
    **kwargs,
):
    """Infer CNVs for ``sdata.tables[table]``.

    Parameters
    ----------
    reference_key
        obs column defining normal reference cells (default: module 4's ``cell_type``).
    reference_categories
        Normal cell types (e.g. ``["T-cells", "B-cells", "Myeloid"]``). ``None``
        lets the CNV module choose (non-epithelial types).
    **kwargs
        Passed to :func:`run_spatial_cnv` (``window_size``, ``step``, ``resolution``, ...).
    """
    require("infercnvpy", "cnv")
    from .spatial_cnv import run_spatial_cnv

    adata = get_table(sdata, table)
    if reference_key not in adata.obs:
        raise ContractError(f"table.obs['{reference_key}'] missing: run cell typing (module 4) before CNV.")
    ensure_spatial(sdata, table)
    work = adata.copy()
    if Obs.COUNTS_LAYER not in work.layers:
        work.layers[Obs.COUNTS_LAYER] = work.X.copy()

    result = run_spatial_cnv(work, output_dir=output_dir, reference_key=reference_key,
                             reference_categories=reference_categories, raw_layer=Obs.COUNTS_LAYER, **kwargs)
    cluster_key = result.uns["spatial_cnv_run_summary"]["cluster_key"]
    score = _cnv_score(result)
    adata.obs[Obs.CNV_SCORE] = pd.Series(score, index=result.obs_names).reindex(adata.obs_names).to_numpy()
    clusters = result.obs[cluster_key].astype(str).reindex(adata.obs_names)
    adata.obs[Obs.CNV_CLUSTER] = pd.Categorical(clusters)
    record_step(sdata, "cnv", {"reference_key": reference_key, "reference_categories": reference_categories,
                               **{k: v for k, v in kwargs.items() if np.isscalar(v)}},
                output_dir=str(output_dir), n_cells=int(result.n_obs), cluster_key=cluster_key)
    return sdata


def _cnv_score(result) -> np.ndarray:
    x = result.obsm["X_cnv"]
    x = abs(x)
    return np.asarray(x.mean(axis=1)).ravel()
